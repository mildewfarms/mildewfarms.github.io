#!/usr/bin/perl
# event box example
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Event Box Example');
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);

my $image = Gtk2::Image->new_from_stock('gtk-dialog-info', 'dialog');

# a Gtk2::Image widget can't have the 'clicked' signal, so this causes
# an error:
$image->signal_connect('clicked', \&clicked);

my $box = Gtk2::EventBox->new;

# but this works!
$box->signal_connect('button_release_event', \&clicked);

$box->add($image);

$window->add($box);

$window->show_all;

Gtk2->main;

sub clicked {
	print "someone clicked me!\n";
}
