#!/usr/bin/perl
# pane example
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Pane Example');
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);

my $vpaned = Gtk2::VPaned->new;
$vpaned->set_border_width(8);

$vpaned->add1(Gtk2::Button->new('Top Pane'));
$vpaned->add2(Gtk2::Button->new('bottom Pane'));

my $frame = Gtk2::Frame->new('Right Pane');
$frame->add($vpaned);

my $hpaned = Gtk2::HPaned->new;
$hpaned->set_border_width(8);

$hpaned->add1(Gtk2::Button->new('Left Pane'));
$hpaned->add2($frame);

$window->add($hpaned);

$window->show_all;

Gtk2->main;
