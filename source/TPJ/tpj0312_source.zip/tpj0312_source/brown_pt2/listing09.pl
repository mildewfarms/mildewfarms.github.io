#!/usr/bin/perl
# scrolled window example
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Scrolled Window Example');
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);

my $image = Gtk2::Image->new_from_file('butterfly.jpg');

my $scrwin = Gtk2::ScrolledWindow->new;
$scrwin->set_policy('automatic', 'automatic');

$scrwin->add_with_viewport($image);

$window->add($scrwin);

$window->show_all;

Gtk2->main;
