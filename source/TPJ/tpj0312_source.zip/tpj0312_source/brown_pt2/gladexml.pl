#!/usr/bin/perl
# Gtk2::GladeXML example
use Gtk2 -init;
use Gtk2::GladeXML;
use strict;

my $gladexml = Gtk2::GladeXML->new('example.glade');

$gladexml->signal_autoconnect_from_package('main');

Gtk2->main;

exit;

# this is called when the main window is closed:
sub on_main_window_delete_event {
	Gtk2->main_quit;
}

# this is called when the Quit button is clicked:
sub on_quit_button_clicked {
	Gtk2->main_quit;
}

# this is called when the OK button is clicked:
sub on_ok_button_clicked {
	$gladexml->get_widget('thanks_dialog')->run;
}

# this is called when the Delete button is clicked:
sub on_evil_button_clicked {
	$gladexml->get_widget('error_dialog')->run;
}

# this is called when the 
sub on_thanks_ok_button_clicked {
	Gtk2->main_quit;
}

sub on_error_dialog_ok_button_clicked {
	Gtk2->main_quit;
}
