#!/usr/bin/perl
# simplelist example
use Gtk2 -init;
use Gtk2::SimpleList;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('List Example');
$window->set_default_size(300, 200);
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);

my $list = Gtk2::SimpleList->new(
	'Browser Name'	=> 'text',
	'Version'	=> 'text',
	'Uses Gecko?'	=> 'bool',
	'Icon'		=> 'pixbuf'
);

$list->set_column_editable(0, 1);

@{$list->{data}} = (
	[ 'Epiphany',	'1.0.4', 1, Gtk2::Gdk::Pixbuf->new_from_file('epiphany.png') ],
	[ 'Galeon',	'1.3.9', 1, Gtk2::Gdk::Pixbuf->new_from_file('galeon.png') ],
	[ 'Konqueror',	'3.1.4', 0, Gtk2::Gdk::Pixbuf->new_from_file('konqueror.png') ],
);

my $scrwin = Gtk2::ScrolledWindow->new;
$scrwin->set_policy('automatic', 'automatic');

$scrwin->add_with_viewport($list);

my $button = Gtk2::Button->new_from_stock('gtk-ok');
$button->signal_connect('clicked', \&clicked);

my $vbox = Gtk2::VBox->new;
$vbox->set_spacing(8);

$vbox->pack_start($scrwin, 1, 1, 0);
$vbox->pack_start($button, 0, 1, 0);

$window->add($vbox);

$window->show_all;

Gtk2->main;

sub clicked {
	my $selection = ($list->get_selected_indices)[0];
	my @row = @{(@{$list->{data}})[$selection]};
	printf(
		"You selected %s, which is at version %s and %s Gecko.\n",
		$row[0],
		$row[1],
		($row[2] == 1 ? "uses" : "doesn't use")
	);
	Gtk2->main_quit;
}
