#!/usr/bin/perl
# simplemenu example
use Gtk2 -init;
use Gtk2::SimpleMenu;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Menu Example');
$window->set_default_size(300, 200);
$window->signal_connect('delete_event', sub { Gtk2->main_quit });

my $vbox = Gtk2::VBox->new;

my $menu_tree = [
	_File => {
		item_type => '<Branch>',
		children => [
			_New => {
				item_type	=> '<StockItem>',
				callback	=> \&new_document,
				accelerator	=> '<ctrl>N',
				extra_data	=> 'gtk-new',
			},
			_Save => {
				item_type	=> '<StockItem>',
				callback	=> \&save_document,
				accelerator	=> '<ctrl>S',
				extra_data	=> 'gtk-save',
			},
			_Quit => {
				item_type	=> '<StockItem>',
				callback	=> sub { Gtk2->main_quit },
				accelerator	=> '<ctrl>Q',
				extra_data	=> 'gtk-quit',
			},
		],
	},
	_Edit => {
		item_type => '<Branch>',
		children => [
			_Cut => {
				item_type	=> '<StockItem>',
				callback_action	=> 0,
				accelerator	=> '<ctrl>X',
				extra_data	=> 'gtk-cut',
			},
			_Copy => {
				item_type	=> '<StockItem>',
				callback_action	=> 1,
				accelerator	=> '<ctrl>C',
				extra_data	=> 'gtk-copy',
			},
			_Paste => {
				item_type	=> '<StockItem>',
				callback_action	=> 2,
				accelerator	=> '<ctrl>V',
				extra_data	=> 'gtk-paste',
			},
		],
	},
	_Help => {
		item_type => '<LastBranch>',
		children => [
			_Help => {
				item_type	=> '<StockItem>',
				callback_action	=> 3,
				accelerator	=> '<ctrl>H',
				extra_data	=> 'gtk-help',
			}
		],
	},
];

my $menu = Gtk2::SimpleMenu->new (
  		menu_tree		=> $menu_tree,
		default_callback	=> \&default_callback,
	);


$vbox->pack_start($menu->{widget}, 0, 0, 0);
$vbox->pack_start(Gtk2::Label->new('Rest of application  here'), 1, 1, 0);

$window->add($vbox);

$window->show_all;

Gtk2->main;

sub new_document {
	print "user wants a new document.\n";
}

sub save_document {
	print "user wants to save.\n";
}

sub default_callback {
	my (undef, $callback_action, $menu_item) = @_;
	print "callback action number $callback_action\n";
}
