#!/usr/local/bin/perl

# sample1.pl
# Julius C. Duque

#use diagnostics;
#use strict;
#use warnings;
use Cwd;
use Getopt::Long;
use File::Find;
use Win32::Autoglob;
use Digest::MD5;

my $VERSION = "1.0.0 (for TPJ)";

my ($showfiles, $showdigests, $recursive, $all, $quiet, $help) = ();

GetOptions(
    "showfiles"   => \$showfiles,
    "showdigests" => \$showdigests,
    "recursive"   => \$recursive,
    "all"         => \$all,
    "quiet"       => \$quiet,
    "help"        => \$help
);

$showfiles = $showdigests = 1 if ($all);

syntax() if ($help or !@ARGV);

foreach my $infile (@ARGV) {
    chomp $infile;
    if (! -e $infile) {
        print "*** ERROR: $infile does not exist, skipping it...\n" if (!$quiet);
        next;
    } elsif (-d $infile) {
        if ($recursive) {
            find({wanted => sub {
                if (-f) {
                    print make_digest($_, 'MD5');
                    print "  $_" if ($showfiles);
                    print "  [MD5]" if ($showdigests);
                    print "\n";
                }
            }, no_chdir => 1}, $infile);
        } else {
            if (!$quiet) {
                print "*** ERROR: $infile is actually a directory, skipping it.\n";
                print "*** ERROR: Use --recursive if you want to process $infile recursively\n";
            }

            next;
        }
    } else {
        print make_digest($infile, 'MD5');
        print "  $infile" if ($showfiles);
        print "  [MD5]" if ($showdigests);
        print "\n";
    }
}

sub make_digest
{
    my ($file, $tmd) = @_;
    my $digest_obj;
    open INFILE, $file or die "Cannot open $file: $!";
    binmode INFILE;
    $tmd = $tmd =~ /^Digest::/ ? $tmd : "Digest::$tmd";
    eval "require $tmd";
    $digest_obj = new $tmd;
    $digest_obj->addfile(*INFILE);
    close INFILE;
    return $digest_obj->hexdigest;
}

sub syntax
{
    if ($^O eq "MSWin32") {
        $0 =~ s/.*\\//g;    # Windows
    } else {
        $0 =~ s/.*\///g;
    }

    print "$0 $VERSION\n\n";
    print "Usage: $0 file1 [file2 ...]\n";
    print "\n";
    print "Other options:\n";
    print "  --showfiles    print filenames\n";
    print "  --showdigests  print digests used\n";
    print "  --recursive    recursively descend into directory\n";
    print "  --all          implies --showfiles and --showdigests output\n";
    print "  --quiet        suppress error messages\n";
    print "  --help         print this help message\n";
    exit 1;
}

