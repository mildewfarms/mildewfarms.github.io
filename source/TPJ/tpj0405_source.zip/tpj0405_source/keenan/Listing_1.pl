#!/usr/bin/perl
use strict;
use warnings;

my ($raw, @selections, @sources);
open LIST, 'slidelist' or die "Can't open slidelist for reading:  $!";
while ($raw = <LIST>) {
    next if ($raw =~ /^\s+$/ or $raw =~ /^#/); # no comments or blanks
    next unless ($raw =~ /\.slide\.txt$/);
    chomp $raw;
    push(@selections, "texts/$raw");
}
close LIST or die "Cannot close slidelist:  $!";

opendir DIR, 'texts' or die "Couldn't open texts directory: $!";
@sources = map {"texts/$_"} grep {/\.slide\.txt$/} readdir DIR;
closedir DIR;

my (%seen_selections, %seen_sources);
$seen_selections{$_}++ foreach @selections;
$seen_sources{$_}++    foreach @sources;

my $subset_status = 1;
foreach (@selections) {
	if (! exists $seen_sources{$_}) {
		$subset_status = 0;
		last;
	}
}

unless ($subset_status) {
	my (%selections_only);
	foreach (keys %seen_selections) {
		$selections_only{$_}++ if (! exists $seen_sources{$_});
	}
	print "These files, though listed in 'slidelist', are not found in 'texts' directory.\n\n";
	print "    $_\n" foreach (keys %selections_only);
	print "\nEdit 'slidelist' as needed and re-run script.\n";
	exit (0);
}

my (%intersection, %difference);
foreach (keys %seen_selections) {
	$intersection{$_}++ if (exists $seen_sources{$_});
}
foreach (keys %seen_sources) {
	$difference{$_}++ unless (exists $intersection{$_});
}

my @unused = keys %difference;
open UNUSED, ">unused" or die "Could not open unused for writing: $!";
print UNUSED "Files currently unused:\n";
if (@unused) {
	print UNUSED "    $_\n" foreach (sort @unused);
    print "There are unused files; see 'unused'.\n";
} else {
	print UNUSED "    [None.]\n";
	print "There are no unused files.\n";
}
close UNUSED or die "Could not close unused: $!";

