#!/usr/bin/perl
use strict;
use warnings;
use List::Compare;

my ($raw, @selections, @sources);
open LIST, 'slidelist' or die "Can't open slidelist for reading:  $!";
while ($raw = <LIST>) {
    next if ($raw =~ /^\s+$/ or $raw =~ /^#/); # no comments or blanks
    next unless ($raw =~ /\.slide\.txt$/);
    chomp $raw;
    push(@selections, "texts/$raw");
}
close LIST or die "Cannot close slidelist:  $!";

opendir DIR, 'texts' or die "Couldn't open texts directory: $!";
@sources = map {"texts/$_"} grep {/\.slide\.txt$/} readdir DIR;
closedir DIR;

my $lc = List::Compare->new(\@selections, \@sources);
my $LR = $lc->is_LsubsetR;
unless ($LR) {
	my @slidelist_only = $lc->get_unique();
	print "These files, though listed in 'slidelist', are not found in 'texts' directory.\n\n";
	print "    $_\n" foreach (@slidelist_only);
	print "\n";
	print "Edit 'slidelist' as needed and re-run script.\n";
	exit (0);
}

my @unused = $lc->get_complement;
open(UNUSED, ">unused") or die "Could not open unused for writing: $!";
print UNUSED "Files currently unused:\n";
if (scalar(@unused)) {
	print UNUSED "    $_\n" foreach (sort @unused);
    print "There are unused files; see 'texts/unused'.\n";
} else {
	print UNUSED "    [None.]\n";
	print "There are no unused files.\n";
}
close(UNUSED) or die "Could not close unused: $!";
