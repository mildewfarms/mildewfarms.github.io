/*
 * module:
 *    lad-medfit.c(Least Absolute Deviation Median Fit)
 *
 * description:
 *    do short and long term linear clock fits on clock
 *    pairs.  with 5 RTs there will be 10(5 combination 2)
 *    clock pairs.
 *
 * requirments:
 *    clk-cor-raw file: raw clock pair data to do long term
 *                      fit on for outlier detection and elimination
 *    clk-cor-out file: outlier removed clock pair data to do
 *                      short term fit on
 *
 * usage:
 *    called twice by perl script mlda.  reads data files created by mlda
 *    and passes data back thru pipe for mlda.  needs one arg of 0 for
 *    one long term fit and positive integer of pts for short term fits.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* numerical recipes in C header files */
#include <nr.h>
#include <nrutil.h>

   int
main(int argc, char *argv[])
{
   static int j, k, l, m, n;
   static char dum[16];
   static int npt, pair, mpts, cor;
   static int st_fit;
   static float a, b, abdev, *x, *y, *z;
   static float *x_st, *y_st, siga, sigb, chi2, q;
   static int xpts[65536], ypts[10][65536];
   static int jloc[65536];
   static FILE *fp;

   /*
    * lad-medfit called with one arg:
    * number of points for each short term fit or 0 for one long term fit
    */
   st_fit = strtoul(argv[1], (char **)NULL, 10);

   /*
    * open clock data file to do fits on.
    *
    *    initial call to lad-medfit: data will come from clk-cor-raw file with
    *    arg of 0 to do overall fit of file for outlier detection and elimination.
    *
    *    second call to lad-medfit: data will come from clk-cor-out file
    *    with outliers already eliminated.  short term fits are done and
    *    arg will be a positive integer.
    */
   if ( st_fit == 0 )
   {
      fp = fopen("clk-cor-raw", "r");
   }
   else
   {
      fp = fopen("clk-cor-out", "r");
   }
   /* useless array size string at start of file */
   fscanf(fp, "%s %s %d", dum, dum, &npt);

   /* read in time in ms and each of 10(5 combination 2) clock differences to fit */
   for ( npt=0 ;; npt++ )
   {
      if ( (fscanf(fp, "%d %d %d %d %d %d %d %d %d %d %d",
               &xpts[npt],
               &ypts[0][npt],
               &ypts[1][npt],
               &ypts[2][npt],
               &ypts[3][npt],
               &ypts[4][npt],
               &ypts[5][npt],
               &ypts[6][npt],
               &ypts[7][npt],
               &ypts[8][npt],
               &ypts[9][npt])) == EOF )
      {
         break;
      }
   }
   /* at this point npt should be the number of points in raw data */

   /* allocate vectors for medfit() */
   x = vector(1, 65536);
   y = vector(1, 65536);
   z = vector(1, 65536);

   /* allocate vectors for fit() */
   x_st = vector(1, 2*st_fit);
   y_st = vector(1, 2*st_fit);

   /* each clock difference pair is fit seperately */
   for ( pair=0 ; pair<10 ; pair++ )
   {
      /* copy data pts to new array with missing data pts(-1) compressed out */
      for ( j=0,n=0 ; j<npt ; j++ )
      {
         if ( ypts[pair][j] != -1 )
         {
            n++;
            x[n] = xpts[j];
            y[n] = ypts[pair][j];

            /*
             * save location of data pts in clk-cor array
             * for use in filling in smoothed clk-cor array
             */
            jloc[n] = j;
         }
      }
      /* n should be number of pts in compressed arrays - arrays subscript from 1 */

      /* adjust y[] data for clock 64k rollover, storing in z[] array */
      z[1] = y[1];
      for ( j=2,cor=0 ; j<=n ; j++ )
      {
         if ( ( y[j] - y[j-1] ) > 65000 )
         {
            cor -= 65536;
         }
         if ( ( y[j] - y[j-1] ) < -65000 )
         {
            cor += 65536;
         }
         z[j] = y[j] + cor;
      }

      /* if lad-medfit arg is zero do only whole file least squares fit */
      if ( st_fit == 0 )
      {
         a = b = abdev = 0.;
         if ( n > 1 )
            medfit(x, z, n, &a, &b, &abdev);
         printf("%d %lf %lf %lf\n", n, a, b, abdev);
      }
      else
      {
         /*
          * st_fit should be number of pts in z[] array to do short term fits on.
          * do successive fits of st_fit pts with last fit including excess pts
          */
         for ( j=1,k=0 ; k<n ; j+=st_fit )
         {
            /* j is beginning subscript of short term fit pts */
            /* k is ending subscript of short term fit pts */
            k = j + st_fit;

            /* mpts is number of pts in short term fit */
            mpts = st_fit;

            /* adjust k and mpts if last fit of z[] array */
            if ( k + st_fit >= n )
            {
               k = n;
               mpts = k - j;
            }

            /* copy mpts from x[] and z[] arrays to x_st[] and y_st[] arrays for fit calculation */
            for ( l=j,m=1 ; l<k ; l++,m++ )
            {
               x_st[m] = x[l];
               y_st[m] = z[l];
            }

            /* do fit - supposed to be medfit() but mysteriously infinite loops on some short term fits */
            fit(x_st, y_st, mpts, NULL, 0, &a, &b, &siga, &sigb, &chi2, &q);

            /*
             * output:
             *    total number of clock pair pts
             *    starting pt of short term fit
             *    ending pt of short term fit
             *    pts in short term fit
             *    y intercept
             *    slope
             *    chi squared(relative measure of goodness of fit)
             */
            printf("%6d %6d %6d %6d %6d %12.3f %12.8f %15.f\n", pair, n, j, k, mpts, a, b, chi2);

            /*
             * using linear fit parameters fill in all elements
             * of clk-cor array read in at start
             */
            for ( l=jloc[j] ; l<=jloc[k] ; l++ )
            {
               ypts[pair][l] = b * xpts[l] + a;
            }
         }
      }
   }

   /* if short term fits done output recalculated clk-cor file */
   if ( st_fit > 0 )
   {
      for ( j=0 ; j<npt ; j++ )
      {
         printf("%10d %6d %6d %6d %6d %6d %6d %6d %6d %6d %6d \n",
            xpts[j],
            ypts[0][j],
            ypts[1][j],
            ypts[2][j],
            ypts[3][j],
            ypts[4][j],
            ypts[5][j],
            ypts[6][j],
            ypts[7][j],
            ypts[8][j],
            ypts[9][j]);
      }
   }

   return 0;
}

