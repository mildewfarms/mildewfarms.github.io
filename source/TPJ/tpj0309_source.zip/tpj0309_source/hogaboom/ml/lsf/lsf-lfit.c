/*
 * module:
 *
 * description:
 *
 * requirments:
 *
 * usage:
 *
 */

#include <stdio.h>
#include <math.h>
#include <nr.h>
#include <nrutil.h>

main(int argc, char *argv[])
{
   static int i, j, n;
   static int npt, rt, cor;
   static char t;
   static float chi2, *sig;
   static float *a, **covar, *xx, *yy;
   static int xpts[65536], ypts[10][65536];
   static int x[65536], y[65536], z[65536];
   static int *ia;
   static FILE *fp;

   fp = fopen("clk_cor", "r");
   fscanf(fp, "%s %s %d", &t, &t, &npt);

   for ( npt=0 ;; npt++ )
   {
      if ( (rt = fscanf(fp, "%d %d %d %d %d %d %d %d %d %d %d",
                   &xpts[npt],
                   &ypts[0][npt],
                   &ypts[1][npt],
                   &ypts[2][npt],
                   &ypts[3][npt],
                   &ypts[4][npt],
                   &ypts[5][npt],
                   &ypts[6][npt],
                   &ypts[7][npt],
                   &ypts[8][npt],
                   &ypts[9][npt])) == EOF )
      {
         break;
      }
   }

   a = vector(1, 2);
   ia = ivector(1, 2);
   ia[0] = 1; ia[1] = 1;
   covar = matrix(1, 2, 1, 2);
   for ( i=0 ; i<10 ; i++ )
   {
      for ( j=0,n=0 ; j<npt ; j++ )
      {
         if ( ypts[i][j] != -1 )
         {
            n++;
            x[n] = xpts[j];
            y[n] = ypts[i][j];
         }
      }
      z[1] = y[1];
      for ( j=2,cor=0 ; j<=n ; j++ )
      {
         if ( ( y[j] - y[j-1] ) > 65000 )
         {
            cor -= 65536;
         }
         if ( ( y[j] - y[j-1] ) < -65000 )
         {
            cor += 65536;
         }
         z[j] = y[j] + cor;
      }

      xx = vector(1, n);
      yy = vector(1, n);
      sig = vector(1, n);
      for ( j=1 ; j<=n ; j++ )
      {
         xx[j] = x[j];
         yy[j] = z[j];
         sig[j] = .001;
         printf("%d %lf %lf\n", n, xx[j], yy[j]);
      }
      if ( n > 1 )
         lfit(xx, yy, sig, n, a, ia, 2, covar, &chi2, fpoly);
      printf("%d %lf %lf\n", n, a[1], a[2]);
      free_vector(xx, 1, n);
      free_vector(yy, 1, n);
      free_vector(sig, 1, n);
   }
}

