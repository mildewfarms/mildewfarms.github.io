/*
 * module:
 *
 * description:
 *
 * requirments:
 *
 * usage:
 *
 */

#include <stdio.h>
#include <math.h>
#include <nr.h>
#include <nrutil.h>

main(int argc, char *argv[])
{
   static int i, j;
   static int N = 2;
   static int NPT = 100;
   static int idum = -911;
   static float chisq, *x, *y, *sig;
   static float *a, *w, **u, **v, **cvm;
   static float s = .001;

   x = vector(1, NPT);
   y = vector(1, NPT);
   sig = vector(1, NPT);
   a = vector(1, N);
   u = matrix(1, NPT, 1, N);
   v = matrix(1, N, 1, N);
   w = vector(1, N);
   cvm = matrix(1, N, 1, N);
   for ( i=1 ; i<=NPT ; i++ )
   {
      x[i] = .02*i;
      y[i] = 1.0+x[i]*9.0;
      /* y[i] = 1.0+x[i]*(2.0+x[i]*(3.0+x[i]*(4.0+x[i]*5.0))); */
      /* y[i] *= (1.0+s*gasdev(&idum)); */
      sig[i] = y[i]*s;
   }
   svdfit(x, y, sig, NPT, a, N, u, v, w, &chisq, fpoly);
   for ( i=1 ; i<=N ; i++ )
   {
      for ( j=1 ; j<=N ; j++ )
      {
         printf("%12.6f ", v[i][j]);
      }
      printf("\n");
   }
   printf("\n");
   for ( i=1 ; i<=N ; i++ )
   {
      printf("%12.6f ", w[i]);
   }
   printf("\n");
   svdvar(v, N, w, cvm);
   for ( i=1 ; i<=N ; i++ )
      printf("%12.6f +- %10.6f\n", a[i], sqrt(cvm[i][i]));
}

