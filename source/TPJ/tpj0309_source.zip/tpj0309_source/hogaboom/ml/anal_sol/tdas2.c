/*
 * module:
 *    tdas2.c(Time Difference Analytical Solution - Two Dimensional)
 *
 * description:
 *    calculates position of transmitter from three receiver
 *    stations based on time of arrival differences.
 *
 * usage: tdas2 <params file> [progagation times file]
 *    see below for file format specifications.  if propagation times file
 *    omitted use stdin.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(int argc, char *argv[])
{
   static int i = 0;

   /* c = 2.997925e8 m/s or 2.997925 m/10ns */
   static double c = 2.997925;
   static double n = 1.000350; /* index of refraction - est. based on air, 20 deg. C, 75% hum. */

   /* epsilon used to determine special cases */
   static double e = 1.e-5;

   /* coordinates of solution points and three GIRUs */
   static double xs1, ys1, xs2, ys2;
   static double x1, y1;
   static double x2, y2;
   static double x3, y3;

   /* times of arrival of squitter signal at GIRUs with integer granularity of 10ns(1.5=15ns) */
   static double t1, t2, t3;

   /* intermediate variables for solution */
   static double m, b, A, B, C;
   static double m2, b2;
   static double R12, R13;
   static double d1, d2, d3;
   static double x21, x31, x32;
   static double y21, y32;
   static double tmp, u, v;
   static double R1p, R2p, R1n, R2n;

   /*
    * params file - three lines with x, y coordinates
    *    GIRU 1 - x1, y1
    *    GIRU 2 - x2, y2
    *    GIRU 3 - x3, y3
    */
   static FILE *fp_params;

   /*
    * for input of squitter signal arrival times(t0, t1, t2)
    */
   static FILE *fp_ptf;
  
   /* for options processing */
   static int ch;
   extern int optind;

   static double R21, R23, x12;

   while ((ch = getopt(argc, argv, "")) != EOF)
      switch ( ch )
      {
         case '?':
            (void)fprintf(stderr, "usage: tdas2 <params file> [propagation times file]\n");
            exit(1);
            break;
      }

   if ( optind+1 != argc && optind+2 != argc )
   {
      (void)fprintf(stderr, "usage: tdas2 <params file> [propagation times file]\n");
      exit(1);
   }

   if ( (fp_params = fopen(argv[optind], "r")) == NULL )
   {
      (void)fprintf(stderr, "tdas2: Cannot open %s\n", argv[optind]);
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf", &x1, &y1) != 2 )
   {
      (void)fprintf(stderr, "tdas2: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf", &x2, &y2) != 2 )
   {
      (void)fprintf(stderr, "tdas2: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf", &x3, &y3) != 2 )
   {
      (void)fprintf(stderr, "tdas2: Bad data.\n");
      exit(1);
   }
 
   if ( optind+2 == argc )
   {
      if ( (fp_ptf = fopen(argv[optind+1], "r")) == NULL )
      {
         (void)fprintf(stderr, "tdas2: Cannot open %s\n", argv[optind+1]);
         exit(1);
      }
   }
   else
      fp_ptf = stdin;
 
   c = c/n;

   for (;;)
   {
      if ( fscanf(fp_ptf, "%lf %lf %lf", &t1, &t2, &t3) != 3 )
      {
         (void)fprintf(stderr, "tdas2: EOF/Bad data.\n");
         exit(1);
      }
 
      if ( t1 < 0. || t2 < 0. || t3 < 0. )
      {
         (void)fprintf(stderr, "Error: All initialization parameters must be positive.\n");
         exit(1);
      }

      R12 = c*(t1-t2);
      R13 = c*(t1-t3);
      d1 = x1*x1+y1*y1;
      d2 = x2*x2+y2*y2;
      d3 = x3*x3+y3*y3;
      x21 = x2-x1;
      y21 = y2-y1;
      x31 = x3-x1;

      if ( fabs(t1-t2) < e )
      {
         if ( fabs(t1-t3) > e )
         {
            tmp = x2;x2 = x3;x3 = tmp;
            tmp = y2;y2 = y3;y3 = tmp;
         }
         else
         {
            x32 = x3-x2;
            y32 = y3-y2;
            u = ( (x21*d2)/x32-(x21*d3)/x32-d1+d2 )/(2.*y21);
            v = 1.-(x21*y32)/(y21*x32);
            ys1 = u/v;
            xs1 = (-d2+d3)/(2.*x32)-ys1*(y32/x32);
            printf("Solution: xs1 = %10.3f ys1 = %10.3f\n", xs1, ys1);
            continue;
         }
      }

      m = ( R12*x31-R13*x21 )/( y1*(R12-R13)+y2*R13-y3*R12 );

      b = ( R12*R13*R13-R13*R12*R12+(R12-R13)*d1+R13*d2-R12*d3 )/( 2.*( y1*(R12-R13)+y2*R13-y3*R12 ) );

      {
         R21 = c*(t2-t1);
         R23 = c*(t2-t3);
         x32 = x3-x2;
         x12 = x1-x2;

          m = ( R12*x31-R13*x21 )/( y1*(R12-R13)+y2*R13-y3*R12 );
         m2 = ( R21*x32-R23*x12 )/( y2*(R21-R23)+y1*R23-y3*R21 );

          b = ( R12*R13*R13-R13*R12*R12+(R12-R13)*d1+R13*d2-R12*d3 )/( 2.*( y1*(R12-R13)+y2*R13-y3*R12 ) );
         b2 = ( R21*R23*R23-R23*R21*R21+(R21-R23)*d1+R23*d2-R21*d3 )/( 2.*( y2*(R21-R23)+y1*R23-y3*R21 ) );

         printf("m1 = %lf b1 = %lf\n", m, b);
         printf("m2 = %lf b2 = %lf\n", m2, b2);
      }

      A = 1.+m*m-(x21*x21)/(R12*R12)-(2.*m*x21*y21)/(R12*R12)-(m*m*y21*y21)/(R12*R12);

      B = -2.*x1+2.*m*b-2.*m*y1-x21-m*y21+
             (-d1*x21-d1*m*y21+d2*x21+d2*m*y21-2.*b*x21*y21-2.*b*m*y21*y21)/(R12*R12);

      C = x1*x1+b*b-2.*b*y1+y1*y1-.25*R12*R12-.5*d1+.5*d2-b*y21+
             (-.25*d1*d1+.5*d1*d2-d1*b*y21-.25*d2*d2+d2*b*y21-b*b*y21*y21)/(R12*R12);

      if ( fabs(A) < e )
      {
         xs1 = -C/B;
         ys1 = m*xs1+b;
         printf("Solution: xs1 = %10.3f ys1 = %10.3f\n", xs1, ys1);
      }
      else
      {
         xs1 = ( -B + sqrt( B*B - 4.*A*C ))/(2.*A);
         xs2 = ( -B - sqrt( B*B - 4.*A*C ))/(2.*A);
         ys1 = m*xs1+b;
         ys2 = m*xs2+b;
         R1p = sqrt( (x1-xs1)*(x1-xs1)+(y1-ys1)*(y1-ys1) );
         R2p = sqrt( (x2-xs1)*(x2-xs1)+(y2-ys1)*(y2-ys1) );
         R1n = sqrt( (x1-xs2)*(x1-xs2)+(y1-ys2)*(y1-ys2) );
         R2n = sqrt( (x2-xs2)*(x2-xs2)+(y2-ys2)*(y2-ys2) );
         if ( fabs(R1p-R2p-R12) < e )
         {
            printf("Solution(+): xs1 = %10.3f ys1 = %10.3f\n", xs1, ys1);
         }
         if ( fabs(R1n-R2n-R12) < e )
         {
            printf("Solution(-): xs2 = %10.3f ys2 = %10.3f\n", xs2, ys2);
         }
      }
   }
}

