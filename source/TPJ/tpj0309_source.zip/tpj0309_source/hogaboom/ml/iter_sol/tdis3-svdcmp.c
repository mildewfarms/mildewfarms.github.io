/*
 * module:
 *    tdis3.c(Time Differences Iterative Solution - Three Dimensional)
 *
 * description:
 *    calculates position of transmitter from four receiver
 *    stations based on time of arrival differences.  uses
 *    iterative flat earth algorithm from reference below
 *    modified for three dimensions.
 *
 * references:
 *    algorithm -
 *    New Algorithms for Converting LORAN Time Differences to Position,
 *    B. Friedland and M. F. Hutton, Journal of The Institute of Navigation,
 *    Vol. 20, No. 2, Summer 1973.
 *
 *    index of refraction in air -
 *    Anomalous Microwave Propagation Through Atmospheric Ducts, Harvey W. Ko,
 *    James W. Sari and Joseph P. Skura, Johns Hopkins APL Technical Digest.
 *
 * usage: tdis3 [-i] <params file> [propagation times file]
 *    see below for file format specifications.  if propagation times file
 *    omitted use stdin.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "nr.h"
#include "nrutil.h"

#define N 4

main(int argc, char *argv[])
{
   static int i = 0;

   /* c = 2.997925e8 m/s or 2.997925 m/10ns */
   static double c = 2.997925;
   static double n = 1.000350; /* index of refraction - est. based on air, 20 deg. C, 75% hum. */

   /* epsilon used to terminate iterative calculation */
   static double e;

   /* singular value epsilon used to zero w[] singular values */
   static double sve = 1.e-6;

   /* coordinates of solution point and four GIRUs */
   static double x, y, z;
   static double x0, y0, z0;
   static double x1, y1, z1;
   static double x2, y2, z2;
   static double x3, y3, z3;

   /* R0 - initialy set to estimate, then iteratively changed by dR0 */
   static double R0, dR0;

   /* delta distances between 0 GIRU to target and 1,2 and 3 GIRUs to target */
   static double d1, d2, d3;

   static double ds0, ds1, ds2, ds3;

   /*
    * for system of linear equations - ax = b
    */
   static double wmax, wmin;
   static double *w, *s, *b;
   static double **a, **v;

   /* times of arrival of squitter signal at GIRUs with integer granularity of 10ns(1.5=15ns) */
   static double t0, t1, t2, t3;

   /*
    * params file - six lines with GIRU x, y, z coordinates,
    * estimate of range to target(R0) and calculation terminator epsilon(e)
    *    GIRU 0 - x0, y0, z0
    *    GIRU 1 - x1, y1, z1
    *    GIRU 2 - x2, y2, z2
    *    GIRU 3 - x3, y3, z3
    *    R0
    *    e
    */
   static FILE *fp_params;

   /*
    * for input of squitter signal arrival times(t0, t1, t2, t3)
    */
   static FILE *fp_ptf;

   /* for options processing */
   static int ch;
   extern int optind;

   /* flag to print iterative solution data */
   static int iflg = 0;

   while ((ch = getopt(argc, argv, "i")) != EOF)
      switch ( ch )
      {
         case 'i':
            iflg++;
            break;

         case '?':
            (void)fprintf(stderr, "usage: tdis3 [-i] <params file> [propagation times file]\n");
            exit(1);
            break;
      }

   if ( optind+1 != argc && optind+2 != argc )
   {
      (void)fprintf(stderr, "usage: tdis3 [-i] <params file> [propagation times file]\n");
      exit(1);
   }

   if ( (fp_params = fopen(argv[optind], "r")) == NULL )
   {
      (void)fprintf(stderr, "tdis3: Cannot open %s\n", argv[optind]);
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf %lf", &x0, &y0, &z0) != 3 )
   {
      (void)fprintf(stderr, "tdis3: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf %lf", &x1, &y1, &z1) != 3 )
   {
      (void)fprintf(stderr, "tdis3: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf %lf", &x2, &y2, &z2) != 3 )
   {
      (void)fprintf(stderr, "tdis3: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf %lf", &x3, &y3, &z3) != 3 )
   {
      (void)fprintf(stderr, "tdis3: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf", &R0) != 1 )
   {
      (void)fprintf(stderr, "tdis3: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf", &e) != 1 )
   {
      (void)fprintf(stderr, "tdis3: Bad data.\n");
      exit(1);
   }

   if ( optind+2 == argc )
   {
      if ( (fp_ptf = fopen(argv[optind+1], "r")) == NULL )
      {  
         (void)fprintf(stderr, "tdis3: Cannot open %s\n", argv[optind+1]);
         exit(1);
      }  
   }
   else
      fp_ptf = stdin;

   if ( R0 < 1. || e < 0. )
   {
      (void)fprintf(stderr, "Error: Initial R0 estimate too small or epsilon < 0. .\n");
      exit(1);
   }

   c = c/n;

   w = dvector(1, N);
   s = dvector(1, N);
   b = dvector(1, N);
   a = dmatrix(1, N, 1, N);
   v = dmatrix(1, N, 1, N);

   a[1][1] = 1.; a[1][2] = -2.*x0; a[1][3] = -2.*y0; a[1][4] = -2.*z0;
   a[2][1] = 1.; a[2][2] = -2.*x1; a[2][3] = -2.*y1; a[2][4] = -2.*z1;
   a[3][1] = 1.; a[3][2] = -2.*x2; a[3][3] = -2.*y2; a[3][4] = -2.*z2;
   a[4][1] = 1.; a[4][2] = -2.*x3; a[4][3] = -2.*y3; a[4][4] = -2.*z3;

   svdcmp(a, N, N, w, v);

   wmax = 0.0;

   for ( i=1 ; i<=N ; i++ )
   {
      if ( w[i] > wmax )
         wmax = w[i];
   }

   wmin = wmax * sve;

   for ( i=1 ; i<=N ; i++ )
   {
      if ( w[i] < wmin )
      {
         w[i] = 0.0;
         printf("Singular value: w[%02d], wmax = %lf wmin = %lf epsilon = %lf\n", i, wmax, wmin, sve);
      }
   }

   for (;;)
   {
      if ( fscanf(fp_ptf, "%lf %lf %lf %lf", &t0, &t1, &t2, &t3) != 4 )
      {
         (void)fprintf(stderr, "tdis3: EOF.\n");
         exit(1);
      }

      if ( t0 < 0. || t1 < 0. || t2 < 0. || t3 < 0. )
      {
         (void)fprintf(stderr, "Error: All initialization parameters must be positive.\n");
         exit(1);
      }

      d1 = c * ( t1 - t0 );
      d2 = c * ( t2 - t0 );
      d3 = c * ( t3 - t0 );

      ds0 = x0*x0 + y0*y0 + z0*z0;
      ds1 = x1*x1 + y1*y1 + z1*z1;
      ds2 = x2*x2 + y2*y2 + z2*z2;
      ds3 = x3*x3 + y3*y3 + z3*z3;

      i = 0;
      do
      {
         b[1] = R0*R0 - ds0;
         b[2] = R0*R0 + 2.*R0*d1 + d1*d1 - ds1;
         b[3] = R0*R0 + 2.*R0*d2 + d2*d2 - ds2;
         b[4] = R0*R0 + 2.*R0*d3 + d3*d3 - ds3;

         svbksb(a, w, v, N, N, b, s);

         dR0 = 0.5 * ( ((s[2]-x0)*(s[2]-x0) + (s[3]-y0)*(s[3]-y0) + (s[4]-z0)*(s[4]-z0))/R0 - R0 );
         if ( fabs(dR0) > R0 )
         {
            printf("Error: fabs(dR0) > R0. R0 = %10.3f dR0 = %10.3f\n", R0, dR0);
            exit(1);
         }
         if ( iflg == 1 )
            printf("R0 = %10.3f dR0 = %10.3f x = %10.3f y = %10.3f z = %10.3f\n", R0, dR0, s[2], s[3], s[4]);
         R0 += dR0;
         if ( ++i > 1000 )
         {
            printf("Error: solution does not converge in 1000 iterations.\n");
            exit(1);
         }
      } while( fabs(dR0) > e );

      printf("Solution: R0 = %10.3f x = %10.3f y = %10.3f z = %10.3f\n", R0, s[2], s[3], s[4]);
   }
}

