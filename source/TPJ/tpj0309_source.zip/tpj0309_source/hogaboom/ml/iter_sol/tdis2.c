/*
 * module:
 *    tdis2.c(Time Differences Iterative Solution - Two Dimensional)
 *
 * description:
 *    calculates position of transmitter from three receiver
 *    stations based on time of arrival differences.  uses
 *    iterative flat earth algorithm.
 *
 * requirments:
 *    1. the girus cannot be colinear
 *    2. the target should be within the triangle of the girus,
 *       or outside opposite a triangle line, but not within or
 *       close to the open ended wedges of the base line extensions.
 *
 * reference:
 *    algorithm -
 *    New Algorithms for Converting LORAN Time Differences to Position,
 *    B. Friedland and M. F. Hutton, Journal of The Institute of Navigation,
 *    Vol. 20, No. 2, Summer 1973.
 *
 *    index of refraction in air -
 *    Anomalous Microwave Propagation Through Atmospheric Ducts, Harvey W. Ko,
 *    James W. Sari and Joseph P. Skura, Johns Hopkins APL Technical Digest.
 *
 * usage: tdis2 [-i] <params file> [propagation times file]
 *    see below for file format specifications.  if propagation times file
 *    omitted use stdin.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(int argc, char *argv[])
{
   static int i = 0;

   /* c = 2.997925e8 m/s or 2.997925 m/10ns */
   static double c = 2.997925;
   static double n = 1.000350; /* index of refraction - est. based on air, 20 deg. C, 75% hum. */

   /* epsilon used to terminate iterative calculation */
   static double e;

   /* coordinates of solution point and three GIRUs */
   static double x, y;
   static double x0, y0;
   static double x1, y1;
   static double x2, y2;

   /* derived constants from GIRU locations */
   static double D, D1, D2, C11, C12, C21, C22;

   /* R0 - initialy set to estimate, then iteratively changed by dR0 */
   static double R0, dR0;

   /* delta distances between 0 GIRU to target and 1 and 2 GIRUs to target */
   static double d1, d2;

   /* intermediate values in calculation */
   static double u1, u2;

   /* times of arrival of squitter signal at GIRUs with integer granularity of 10ns(1.5=15ns) */
   static double t0, t1, t2;

   /*
    * params file - five lines with GIRU x, y coordinates,
    * estimate of range to target(R0) and calculation terminator epsilon(e)
    *    GIRU 0 - x0, y0
    *    GIRU 1 - x1, y1
    *    GIRU 2 - x2, y2
    *    R0
    *    e
    */
   static FILE *fp_params;

   /*
    * for input of squitter signal arrival times(t0, t1, t2)
    */
   static FILE *fp_ptf;
  
   /* for options processing */
   static int ch;
   extern int optind;

   /* flag to print iterative solution data */
   static int iflg = 0;

   while ((ch = getopt(argc, argv, "i")) != EOF)
      switch ( ch )
      {
         case 'i':
            iflg++;
            break;

         case '?':
            (void)fprintf(stderr, "usage: tdis2 [-i] <params file> [propagation times file]\n");
            exit(1);
            break;
      }

 
   if ( optind+1 != argc && optind+2 != argc )
   {
      (void)fprintf(stderr, "usage: tdis2 [-i] <params file> [propagation times file]\n");
      exit(1);
   }
   
   if ( (fp_params = fopen(argv[optind], "r")) == NULL )
   {
      (void)fprintf(stderr, "tdis2: Cannot open %s\n", argv[optind]);
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf", &x0, &y0) != 2 )
   {
      (void)fprintf(stderr, "tdis2: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf", &x1, &y1) != 2 )
   {
      (void)fprintf(stderr, "tdis2: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf %lf", &x2, &y2) != 2 )
   {
      (void)fprintf(stderr, "tdis2: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf", &R0) != 1 )
   {
      (void)fprintf(stderr, "tdis2: Bad data.\n");
      exit(1);
   }
   if ( fscanf(fp_params ,"%lf", &e) != 1 )
   {
      (void)fprintf(stderr, "tdis2: Bad data.\n");
      exit(1);
   }
 
   if ( optind+2 == argc )
   {
      if ( (fp_ptf = fopen(argv[optind+1], "r")) == NULL )
      {
         (void)fprintf(stderr, "tdis2: Cannot open %s\n", argv[optind+1]);
         exit(1);
      }
   }
   else
      fp_ptf = stdin;

   if ( R0 < 1. || e < 0. )
   {
      (void)fprintf(stderr, "Error: Initial R0 estimate too small or epsilon < 0. .\n");
      exit(1);
   }

   c = c/n;

   D = 2.0 * ( (x2-x0)*(y1-y0) - (x1-x0)*(y2-y0) );
   C11 = (y0-y2)/D;
   C12 = (y1-y0)/D;
   C21 = (x2-x0)/D;
   C22 = (x0-x1)/D;
   D1 = x1*x1 + y1*y1 - x0*x0 - y0*y0;
   D2 = x2*x2 + y2*y2 - x0*x0 - y0*y0;

   for (;;)
   {
      if ( fscanf(fp_ptf, "%lf %lf %lf", &t0, &t1, &t2) != 3 )
      {
         (void)fprintf(stderr, "tdis2: EOF/Bad data.\n");
         exit(1);
      }

      if ( t0 < 0. || t1 < 0. || t2 < 0. )
      {
         (void)fprintf(stderr, "Error: All initialization parameters must be positive.\n");
         exit(1);
      }

      d1 = c * ( t1 - t0 );
      d2 = c * ( t2 - t0 );

      i = 0;
      do
      {
         u1 = D1 - d1 * ( 2*R0 + d1 );
         u2 = D2 - d2 * ( 2*R0 + d2 );
         x = C11*u1 + C12*u2;
         y = C21*u1 + C22*u2;
         dR0 = 0.5 * ( ((y-y0)*(y-y0) + (x-x0)*(x-x0))/R0 - R0 );
         if ( fabs(dR0) > R0 )
         {
            printf("Error: fabs(dR0) > R0.\n");
            exit(1);
         }
         if ( iflg == 1 )
            printf("R0 = %10.3f dR0 = %10.3f x = %10.3f y = %10.3f\n", R0, dR0, x, y);
         R0 += dR0;
         if ( ++i > 1000 )
         {
            printf("Error: solution does not converge in 1000 iterations.");
            exit(1);
         }
      } while( fabs(dR0) > e );

      printf("Solution: R0 = %10.3f x = %10.3f y = %10.3f\n", R0, x, y);
   }
}

