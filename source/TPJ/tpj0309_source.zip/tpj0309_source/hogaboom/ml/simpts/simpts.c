/*
 * module:
 *    simpts.c(Simulated time to GIRUs for linearly moving target - Three Dimensional)
 *
 * description:
 *    calculate times in 10s of ns to girus from a linearly moving target
 *    starting at an initial position and moving by fixed distances
 *    along a straight line.
 *
 * reference:
 *    Anomalous Microwave Propagation Through Atmospheric Ducts, Harvey W. Ko,
 *    James W. Sari and Joseph P. Skura, Johns Hopkins APL Technical Digest.
 *
 * usage: simpts <init params file>
 *    see below for file format specifications
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_GIRUS 64

main(int argc, char *argv[])
{
   static int i, j;

   /* c = 2.997925e8 m/s or 2.997925 m/10ns */
   static double c = 2.997925;
   static double n = 1.000350; /* index of refraction - est. based on air, 20 deg. C, 75% hum. */
   static double cm1; /* 1./c */

   /* giru locations, x,y,z up to 64 */
   static double giru_pos[3][MAX_GIRUS];

   /* giru ranges from target points */
   static double giru_rng[MAX_GIRUS];

   /* number of girus */
   static int ngiru;

   /* x0, y0, z0 target start point, x, y, z iterated target point */
   static double x0, y0, z0;
   static double x, y, z;

   /* a, b, c target start direction vector - V = Ai+Bj+Ck */
   static double A, B, C;
   static double L; /* length of ABC vector */

   /* number of points to calculate */
   static int npts;

   /* point spacing interval */
   static double ptint;

   /* propagation times jitter in ns */
   static double max_jit = 0;
   static double jit = 0.;

   /*
    * parameter file - format as follows - coordinates in meters
    *    ngiru                    number of GIRUs   
    *    x1, y1, z1               GIRU 1 location
    *    x2, y2, z2               GIRU 2 location
    *     .                        .
    *     .                        .
    *    xn, yn, zn               GIRU n location
    *    x0, y0, z0               target start point
    *    A, B, C                  target start direction vector
    *    npts                     number of points to calculate
    *    ptint                    point spacing interval
    *    max_jit                  maximum point jitter
    */
   static FILE *fp_params;

   /* for options processing */
   extern char *optarg;
   extern int optind, opterr, optopt;

   static int ch;
   static int sflg = 0;

   while ((ch = getopt(argc, argv, "s")) != EOF)
      switch ( ch )
      {  
         case 's':
            sflg = 1;
            break;

         case '?':
            (void)fprintf(stderr, "usage: simpts <init params file>\n");
            exit(1);
            break;
      }   

   if ( optind+1 != argc )
   {
      (void)fprintf(stderr, "usage: simpts <init params file>\n");
      exit(1);
   }

   if ( ngiru > MAX_GIRUS )
   {
      (void)fprintf(stderr, "Error: Too many GIRUs.\n");
      exit(1);
   }

   fp_params = fopen(argv[optind], "r");
   fscanf(fp_params ,"%d", &ngiru);
   for ( i=0 ; i<ngiru ; i++ )
   {
      fscanf(fp_params ,"%lf %lf %lf", &giru_pos[0][i], &giru_pos[1][i], &giru_pos[2][i]);
   }
   fscanf(fp_params ,"%lf %lf %lf", &x0, &y0, &z0);
   fscanf(fp_params ,"%lf %lf %lf", &A, &B, &C);
   fscanf(fp_params ,"%d", &npts);
   fscanf(fp_params ,"%lf", &ptint);
   fscanf(fp_params ,"%lf", &max_jit);

   max_jit /= 10;
   srand48(1);

   c = c/n;
   cm1 = 1./c;

   L = sqrt(A*A + B*B + C*C);
   A = A/L; B = B/L; C = C/L;

   for ( i=0 ; i<npts ; i++ )
   {
      x = i*ptint*A + x0;
      y = i*ptint*B + y0;
      z = i*ptint*C + z0;
      if ( sflg == 0 )
         printf("%3d %10.3f %10.3f %10.3f ", i+1, x, y, z);
      for ( j=0 ; j<ngiru ; j++ )
      {
         giru_rng[j] = sqrt(
                              pow((giru_pos[0][j]-x), 2.) +
                              pow((giru_pos[1][j]-y), 2.) +
                              pow((giru_pos[2][j]-z), 2.)
                           );
         /* output time delays to girus in units of 10s of ns(1.5=15ns) */
         jit = drand48();
         jit = 2.*jit*max_jit - max_jit;
         printf("%10.3f ", giru_rng[j]*cm1+jit);
      }
      printf("\n");
   }
}

