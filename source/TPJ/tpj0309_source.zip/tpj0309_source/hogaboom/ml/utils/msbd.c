/*
 * module:
 *    msbd.c(Mode S Bit Difference)
 *
 * usage: msbd [-l] <filename> <Mode S Address> <max bits diff> <rt num>
 *
 */

#include <stdio.h>

main(int argc, char *argv[])
{
   static FILE *fp;
   static unsigned long i;
   static unsigned long l;
   static unsigned long lsav;
   static unsigned long lflg = 0;
   static unsigned long stop;
   static char c[256];
   static char ms[256];
   static unsigned long msa;
   static unsigned long nbits;
   static unsigned long rt, rti;
   static unsigned long cnt;
   static unsigned long mask = 0x00000001;
   static unsigned long tot[4];

   if ( strcmp(argv[1], "-l", 2) == 0 )
   {
      lflg = 1;
      argc--;
      argv++;
   }

   if ( argc != 5 )
   {
      printf("usage: msbd [-l] <filename> <Mode S Address> <max bits diff> <rt num>\n");
      exit(1);
   }

   if ( (fp = fopen(argv[1], "r")) == NULL )
   {
      printf("msbd: Unable to open file. file = %s\n", argv[1]);
      exit(1);
   }
   if ( strlen(argv[2]) != 6 )
   {
      printf("msbd: Invalid Mode S Address - Need 6 chars.\n");
      exit(1);
   }
   sscanf(argv[2], "%6x", &msa);
   sscanf(argv[3], "%d", &nbits);
   if ( nbits < 0 || nbits > 3 )
   {
      printf("msbd: Invalid number of bit differences specified - 0-3 valid.\n");
      exit(1);
   }
   sscanf(argv[4], "%d", &rt);
   if ( rt < 0 || rt > 4 )
   {
      printf("msbd: Invalid RT number - 0-4 valid.\n");
      exit(1);
   }

   for (;;)
   {
      if ( fgets(c, 256, fp) == NULL )
         break;
      if ( strlen(c) < 91 )
         continue;
      sscanf(&c[61], "%d", &rti);
      if ( rti != rt )
         continue;
      memmove(ms, &c[73], 8);
      memmove(&ms[2], &ms[3], 2);
      memmove(&ms[4], &ms[6], 2);
      sscanf(ms, "%6x", &l);
      lsav = l;
      l = l^msa;
      for ( i=0,cnt=0,stop=0 ; i<24 ; i++,l=l>>1 )
      {
         if ( mask & l )
         {
            cnt++;
            if ( cnt > nbits )
            {
               stop = 1;
               break;
            }
         }
      }
      if ( stop == 0 )
      {
         if ( lflg == 1 && cnt != 0 )
            printf("0x%08x\n", lsav);
         tot[cnt]++;
      }
   }

   for ( i=0 ; i<=nbits ; i++ )
   {
      printf("Total different by %1d bits = %06d\n", i, tot[i]);
   }
}

