#!/usr/bin/perl

use Astro::MoonPhase;

package Astro::MoonPhase;
use Date::Format;

my $lunation = lunation();

my @dates = 
	map { time2str( "%h %e", $_ ) }
	map { jdaytosecs( truephase( $lunation, $_ ) ) } 
		( 0, 0.25, 0.5, 0.75 );

printf "N: %s   1: %s   F: %s   3: %s\n", @dates;

sub lunation
	{
	my $sdate = jtime( shift || time );
	my $k = undef;
	
	my $ndate1 = meanphase( $sdate, 0.0, \$k );

	$k++ if $ndate < $sdate;
	
	return $k;
	}