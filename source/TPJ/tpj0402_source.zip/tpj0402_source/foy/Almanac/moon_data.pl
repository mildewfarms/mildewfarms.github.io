#!/usr/bin/perl

use Astro::MoonPhase;
use Date::Format;
use GD::Graph::lines;
use Time::Local;

my $tz_offset = $ARGV[1] || 0;
my $year      = $ARGV[0] || ( (localtime)[5] + 1900 );

# get the first Sunday in the year
my $now = do {
	for( $i = 1; ; $i++ )
		{
		$time = timegm( 0, 0, 0, $i, 0, $year );
		last unless (localtime($time + $tz_offset))[6];
		}
		
	$time;
	};
	
my $then = timegm(59, 59, 23, 31, 11, $year);

# calculate the moon phase for every three hours
for( my $i = $now; $i < $then; $i += 60 * 60 * 3 )
	{	
	my @data = phase( $i + $tz_offset );
	
	printf "%.4f\n",  $data[1];
		
	push @time, $i;
	push @illum, $data[1];
	}
	
my @data = ( \@time, \@illum,);

my $my_graph = new GD::Graph::lines( 800, 300 );

#print Data::Dumper::Dumper( $my_graph );
use Data::Dumper;

$my_graph->set(
	x_label             => 'Day',
	y_label             => 'Moon Illumination',
	title               => 'Moon Illumination',
	x_number_format     => sub { time2str( "%h %e", $_[0] ) },
	line_width          => 1,
	x_label_position    => 1/2,
	r_margin            => 15,
	x_min_value         => $time[0],
	x_max_value         => $time[-1],
	x_tick_number       => 52,
	transparent         => 0,
	x_labels_vertical   => 1,
	tick_clr            => 'gray',
	border_clr          => 'dgray',
	x_long_ticks        => 1,
	y_long_ticks        => 0,
	border              => 1,
	border_clr          => 'black',
);

my $gd = $my_graph->plot(\@data);

open IMG, "> /Users/brian/Desktop/moon-short.png";
print IMG $gd->png;
close IMG;
