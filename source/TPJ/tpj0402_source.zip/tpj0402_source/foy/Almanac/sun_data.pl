#!/usr/bin/perl
use strict;

use Astro::Sunrise;
use ConfigReader::Simple;
use GD::Graph::lines;
use Time::Local;
use Date::Format;

my $year = (localtime)[5] + 1900;

my $config = ConfigReader::Simple->new( ".almanacrc" );

my $long = $config->longitude;
my $lat  = $config->latitude;
my $tz   = $config->time_zone;

my( @time, @sunrises, @sunsets );

# get the first Sunday in the year
my $now = do {
	my $time;
	
	for( my $i = 1; ; $i++ )
		{
		$time = timegm( 0, 0, 0, $i, 0, $year );
		last unless (localtime($time + $tz))[6];
		}
		
	$time;
	};
	
my $then = timegm(59, 59, 23, 31, 11, $year);

# calculate the moon phase for every three hours
for( my $i = $now; $i < $then ; $i += 60 * 60 * 3 )
	{
	my @date = localtime( $i );
			
	push @time, $i;
	
	my( $sunrise, $sunset ) = map { s/://; $_ }
		sunrise( @date[5,4,3], 
			$long, $lat, $tz, $date[8], -12 );

	push @sunrises, $sunrise;
	push @sunsets, $sunset;
	}

my @data = ( \@time, \@sunrises, \@sunsets );

my $my_graph = new GD::Graph::lines( 800, 300 );

$my_graph->set(
	x_label             => 'Day',
	y_label             => 'Time',
	title               => 'Sunrise & Sunset',
	x_number_format     => sub { time2str( "%h %e", $_[0] ) },
	line_width          => 1,
	x_label_position    => 1/2,
	r_margin            => 15,
	x_min_value         => $time[0],
	x_max_value         => $time[-1],
	x_tick_number       => 52,
	y_max_value         => 2400,
	transparent         => 0,
	x_labels_vertical   => 1,
	tick_clr            => 'gray',
	border_clr          => 'dgray',
	x_long_ticks        => 1,
	y_long_ticks        => 0,
	border              => 1,
	border_clr          => 'black',
);

my $gd = $my_graph->plot(\@data);

open IMG, "> /Users/brian/Desktop/sun.png";
print IMG $gd->png;
close IMG;
