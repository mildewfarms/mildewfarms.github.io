#!/usr/bin/perl
use strict;

use Astro::MoonPhase;
use Astro::Sunrise;
use ConfigReader::Simple;
use Date::Format;

use vars qw( $date @sunrises $moon_phase );

my $config = ConfigReader::Simple->new( ".almanacrc" );

my $long = $config->longitude;
my $lat  = $config->latitude;
my $tz   = $config->time_zone;

my $now = time;

for( my $i = $now; $i < $now + 3.15e7/12 ; $i += 24 * 60 * 60 )
	{	
	my @date = localtime( $i );
	
	print "\n" unless $date[6];
	
	$date = time2str( "%a %b %d", $i );
	
	@sunrises = ();
	
	foreach my $altitude ( -0.833, -6, -12, -18 )
		{
		push @sunrises, sunrise( @date[5,4,3], 
			$long, $lat, $tz, $date[8], $altitude );
		}
		
	$moon_phase = sprintf "%3d", 100 * ( phase( $i + $tz ) )[1];

	write;	
	}
	
format STDOUT = 
@<<<<<<<<<  @>>>> @>>>>  @>>>> @>>>>  @>>>> @>>>>  @>>>> @>>>>  @>>
$date,      @sunrises,            $moon_phase
.

format STDOUT_TOP =
Date           Upper        Civil       Nautical      Astro    Illum
.
