use Time::Local;
my  ( $city , @time , @temp , %rates );

open  F, " unzip -c $ARGV [0] | "  or  die  " Can't open $ARGV [0]: $! " ;
while  (<F>) {
if  ( / ^ \s +  ( \d +)  \s +  ( \d +)  \s +  ( \d +)  \s +  ( [ \-\d\. ] +) /x ) {
next  if  $4  == -99 ;             # code for no data available 
push  @time , timegm( 0 , 0 , 12 ,  # sec, min, hour (assume noon) 
$2 , $1 -1 , $3 -1900 ); # mday, month (0-11), year 
push  @temp , ( $4 -32 )/ 1.8 ;       # convert to degree C 
}
if  ( / ^ \s +  inflating: \s +   ( \w +)  \. txt /x ) {
process( \@time , \@temp ) if  $city ;
$city = $1 ; @time = (); @temp = ();
}
}
process( \@time , \@temp ); #last one 
close  F;

printf  " Average change is %1.4f  � %1.4f  (�C/year) for %d  cities \n " ,
calc_stats()->as_list;

use Inline Octave => q{ 
function  TperYr= process( time, temp ) ; 
time_step=  [ 0 ; diff(time) / 2 ]  +  [ diff(time) / 2 ; 0 ] ; 
year_freq=  1 / ( 365.2422 * 24 * 60 * 60  ) ; 
harmonics=  2 * pi * ( 1 : 3 ) * year_freq ; 
year_osc=   [  sin (time *  harmonics), cos (time *  harmonics) ]  ... 
.*  (time_step *  ones ( 1 , 2 * length(harmonics))) ; 
component=  (temp '  *  year_osc) ./  sumsq( year_osc ) ; 

temp_clean= temp -  year_osc *  component ' ;  # remove harmonics of year 
fit = polyfit( time, temp_clean, 1 ) ;       # fit to line 
TperYr = fit( 1 ) /  year_freq ;               # convert slope to deg/year 

global sites= [] ;  static site_no= 1 ; 
sites( site_no ++  ) = TperYr ;              # store city data 
endfunction 

function  stat_data= calc_stats()            # mean, std err, number 
global sites ;                             # load city data 
n_sites=   length(sites) ; 
stat_data= [ mean (sites), std (sites) / sqrt (n_sites), n_sites ] ; 
endfunction 
} ;

