package  Example; 
use strict ;
use Carp;

use IO::Handle;
my  $Oerr = new  IO::Handle;

use IPC::Open3;
open3( my  $Oin , my  $Oout , $Oerr , " octave -qH " );
setpriority  0 , 0 , ( getpriority  0 , 0 ) +4 ; #lower priority slightly 

use IO::Select;
my  $select  = IO::Select-> new ( $Oerr , $Oout );
sub  interpret  {
my  $cmd = shift ;
my  $marker = " -9Ahv87uhBa8l_8Onq,zU9- " ; # random string 
my  $marker_len = length ( $marker ) +1 ;

print  $Oin  " \n\n $cmd \n disp(' $marker ');fflush(stdout); \n " ;

my  $input ;
while  ( 1  ) {
for  my  $fh  ( $select ->can_read() ) {
if  ( $fh  eq  $Oerr ) {
process_errors();
} else  {
sysread  $fh , ( my  $line ), 16384 ;
$input .= $line ;
}
}
last  if  substr ( $input , - $marker_len , -1 ) eq  $marker ;
}

# the process must be left blocked doing something, or it can't handle CTRL-C 
print  $Oin  " \n\n fread(stdin,1); \n " ;
return  substr ( $input  , 0  , - $marker_len  );
}

sub  process_errors 
{
my  $select = IO::Select-> new ( $Oerr  );

my  $input ;
while  ( $select ->can_read( 0.1 ) ) {
sysread  $Oerr , ( my  $line ), 1024 ;
last  unless  $line ;
$input .= $line ;
}

croak  " $input  (in octave code) "  if  $input  =~  / error: / ;
carp   " $input  (in octave code) "  if  $input ;
}

1 ;
