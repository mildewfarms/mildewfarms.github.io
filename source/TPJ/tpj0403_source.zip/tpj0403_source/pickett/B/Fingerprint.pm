package B::Fingerprint;

our $VERSION = 0.0.1;

use strict;
# Import these functions from B.
use B qw(svref_2object main_root class ppname OPf_KIDS);

# Use these symbols for each type of operator.
our %opclass = ('OP' => "0", 'UNOP' => "1", 'BINOP' => "2", 'LOGOP' => "|",
  'LISTOP' => "@", 'PMOP' => "/", 'SVOP' => "\$", 'GVOP' => "*",
  'PVOP' => '"', 'LOOP' => "L", 'COP' => ";", 'PADOP' => "#");


# Traverse the op tree, printing each operator and its children.
# Some of this code lifted from B::Concise.
sub serialize
{
  my $root = shift;

  # Print this node's symbol.
  print $opclass{class($root)};

  # Do children (if any).
  if ($root->flags & OPf_KIDS)
  {
    print "{";
      for (my $kid = $root->first; $$kid; $kid = $kid->sibling) {
        serialize($kid);
      }
    print "}";
  }
  if (class($root) eq "PMOP")
  {
    if (ref $root->pmreplroot
    && $root->pmreplroot->isa("B::OP")) {
      print "[";
        serialize($root->pmreplroot);
      print "]";
    }
  }
}


# A list of the subroutines that we've already output the fingerprint
# for.
our %subs_done = ();

# Serialize any subroutines that the code defines.
# Some of this code lifted from B::Concise.
sub serialize_subs
{
  my $package = shift;

  my $stash;

  if ($package eq "")
  {
    # Use root stash.
    $stash = \%::;
  }
  else
  {
    # Use given package's stash.
    no strict 'refs';
    $stash = \%$package;
  }

  # Get this package's stash.
  my %stash = svref_2object($stash)->ARRAY;

  while (my ($key, $val) = each %stash)
  {
    # Avoid infinite recursion.
    next if $key eq 'main::';
    
    # Examine anything that's a glob.
    if (class($val) eq "GV")
    {
      # Do all code values that aren't special.
      if (class(my $cv = $val->CV) ne "SPECIAL") {
        # Skip subs already done.
        next if $subs_done{$$val}++;
        # Skip sub aliases done with typeglob magic.
        next if $$val != ${$cv->GV};
        # Skip anything not defined in the same file.
        next if $cv->FILE ne $0;
        # Print this subroutine's fingerprint.
        serialize($cv->ROOT);
      }
      # Recurse into multilevel packages.
      if (class($val->HV) ne "SPECIAL" && $key =~ /::$/) {
        serialize_subs($package . $key);
      }
    }
  }

}

# Entry point for module.
sub compile
{
  return sub {
    # Serialize any subroutines defined in the code.
    serialize_subs("");
    # Serialize the main code.
    serialize(main_root);
  };
}

1;
