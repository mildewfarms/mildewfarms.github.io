package User;

use strict;
use Carp 'croak';
use Class::PObject;

pobject {
  columns => ['id', 'name', 'password', 'email'],
  driver  => 'file'
};


sub authenticate {
  my $class = shift;
  my ($name, $password) = @_;

  unless ( $name && $password ) {
    croak "authenticate(): usage error";
  }
  return $class->load({name=>$name, password=>$password});
}

1;

__END__;

=head1 NAME

User - Class representing a User object in our imaginary project

=head1 SYNOPSIS

  use User;
  # to create a user:
  my $user = new User(name=>'sherzod', password=>'secret');
  $user->save();

  # to load a user from disk:
  my $user = User->load({name=>'sherzod'});

=head1 DESCRIPTION

C<User> is a class representing a single user registered with our web site. C<User>
C<"inherites"> from L<Class::PObject|Class::PObject>, so it supports all the features
documented in Class::PObject's manual.

=head2 DATA ACCESS METHODS

Following data access methods are available:

=over 4

=item id

Numeric ID of the user

=item name

Name of the user. It's also used as the user's login name.

=item password

Password of the user. WARNING: it is not encrypted.

=item email

Email address of the user

=back

To modify any of the above fields, just pass a new value as the first and the only argument:

  # to change a user's e-mail address:
  $user->email('new@email.com');

=head1 SEE ALSO

L<Class::PObject>, L<Class::PObject::Driver::file>.

=head1 AUTHOR

Sherzod Ruzmetov, E<lt>sherzodr@cpan.orgE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright 2003 by Sherzod B. Ruzmetov.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself. 

=cut
