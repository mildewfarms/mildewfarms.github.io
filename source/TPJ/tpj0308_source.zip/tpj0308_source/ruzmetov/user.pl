#!/usr/bin/perl -w

use strict;
use Test::More 'no_plan';
use User;

# list of all the users:
my @users = (
	['sherzod', 'secret', 'sherzodr@handalak.com'],
	['webmaster', 'system', 'webmaster@handalak.com'],
	['lola',      'geekchick', 'lola@handalak.com']
);

for my $row ( @users ) {
	my $user = new User(name=>$row->[0], password=>$row->[1], email=>$row->[2]);
	ok($user->save);
}

# changing my password:
my $me = User->load({name=>'sherzod'}) or die;
ok($me->password eq 'secret');
$me->password('topsecret');
ok($me->save);

undef($me);


# checking if the password was really saved:
my $user = User->load({name=>'sherzod'});
ok($user->password eq 'topsecret');


# trying to log 'lola' in:
my $lola = User->authenticate('lola', 'intentionally-wrong-password');
ok($lola ? 0 : 1);

# trying again
$lola = User->authenticate('lola', 'geekchick');
ok($lola);

ok(User->remove_all);
