
use     strict;
use     warnings;

use     Win32::TieRegistry;

die "usage:  typeLib <classname>\n"
    unless @ARGV;

my  $classes = $Registry->{"Classes\\"};

die "* Unable to get HKEY_ROOT_CLASSES from Registry\n"
    unless UNIVERSAL::isa($classes, 'Win32::TieRegistry');

for my $class (@ARGV) {
    print "$class:\n";
    
    for my $key (keys %$classes) {
        next unless $key =~ /$class/;
        
        my  $clsid = $classes->{$key}->{"CLSID\\\\"};
        
        $key =~ s/\\+$//;
        print "  $key:\n";
        
        unless ($clsid) {
            print "    * No class ID\n";
            next;
        }
        
        print "    CLSSID:   $clsid\n";
        
        my  $typid = $Registry->{"Classes\\CLSID\\$clsid\\TypeLib\\\\"};
        
        unless ($typid) {
            print "    * No type library ID\n";
            next;
        }
        
        print "    TypeLib:  $typid\n";
        
        my  $typlb = $Registry->{"Classes\\TypeLib\\$typid\\"};
        
        print "    Library:  $typlb\n";
        
        unless ($typlb) {
            print "    * No type library key\n";
            next;
        }
        
        print "      $_ => $typlb->{$_}->{'\\'}\n" for keys %$typlb;
    }
}
