
use     strict;
use     warnings;

use     Acme::Time::Asparagus;
use     HTTP::Daemon;
use     Win32::OLE;

my  $port = 9183;   # just pick one

# Generate the HTML page with the vegetable time:
sub timePage
{
    my  $conn = shift;
    $conn->send_response(<<VEGETABLE);
200 OK

<html>
<body>
  <h2>Vegetable Clock</h2>
  <p><em>At the tone the time will be:</em>&nbsp;
     <strong>@{[veggietime]}</strong></p>
</body>
</html>
VEGETABLE
}

# Main program, start Internet Explorer first:
my  $explorer = new Win32::OLE('InternetExplorer.Application', 'Quit')
                or die "Unable to create OLE object:\n  ",
                       Win32::OLE->LastError, "\n";

$explorer->Navigate("http://localhost:$port/", 3);

# Start up a tiny, single-function HTTP server:
my  $daemon = new HTTP::Daemon(LocalPort => $port)
              or die "Unable to create daemon\n";

while (my $conn = $daemon->accept) {
    while (my $rqst = $conn->get_request) {
        timePage($conn) if $rqst->method eq 'GET';
    }
    $conn->close;
    undef $conn;
}
