#!/usr/bin/perl
# mandelbrot.pl - draw the Mandelbrot set
use strict;
use warnings;
use Fractal qw(draw min_max);

# xmin, xmax, ymin, and ymax specify the range of coordinates
# steps is the number of points used between (xmin .. xmax),
#   [which is the same number used between (ymin .. ymax)]
# maxit is the maximum number of iterations
my ($xmin, $xmax, $ymin, $ymax, $steps, $maxit) =
  (-1.6, 0.6, -1.2, 1.2, 300, 200);

my $points = mandelbrot();

draw(pts => $points, file => 'mandelbrot.png', size => $steps);

# Mandelbrot set, as defined by
#    x[n+1] = x[n]*x[n] - y[n]*y[n] + c_x
#    y[n+1] = 2*x[n]*y[n] + c_y
# where (c_x, c_y) are the pixel coordinates
# and the iterations begin at (x, y) = (0, 0)

sub mandelbrot {
  my $pts = [];
# determine step size between (xmin .. xmax) and (ymin .. ymax)
  my $xstep = ($xmax - $xmin) / $steps;
  my $ystep = ($ymax - $ymin) / $steps;

  for (my $cx=$xmin; $cx<=$xmax; $cx+=$xstep) {
    for (my $cy=$ymin; $cy<=$ymax; $cy+=$ystep) {
      my ($oldx, $oldy, $newx, $newy) = (0,0,0,0); # start at x = y = 0
      my $i=1;  # iteration number before breakout condition is met
      for ($i=1; $i<$maxit; $i++) {
	$newx = $oldx*$oldx - $oldy*$oldy + $cx;
	$newy = 2*$oldx*$oldy + $cy;
	last if sqrt($newx*$newx + $newy*$newy) > 2; # breakout condition
	($oldx, $oldy) = ($newx, $newy);
      }
      push @$pts, [$cx, $cy, $i];
    }
  }

  return $pts;
}
