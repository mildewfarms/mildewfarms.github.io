package Fractal;
use strict;
use warnings;
use GD;
use MIDI::Simple;
use Exporter;

@Fractal::ISA = qw(Exporter);
@Fractal::EXPORT_OK = qw(draw compose min_max);

my ($min, $max);

# A 2 octave G major scale 
my @gm_notes = (55, 57, 59, 60, 62, 64, 66, 67,
		69, 71, 72, 74, 76, 78, 79);

# routine to draw a fractal
sub draw {
  my %args = @_;

# pts is an array of arrays, specifying the x and y coordinates
# as well as a number used in determining the color
  my $pts = $args{pts};
  die 'Must supply a reference to an array of arrays for "pts"' 
    unless ($pts and ref($pts) eq 'ARRAY' and ref($pts->[0]) eq 'ARRAY');

# rgbindex returns an index used by rgb to specify the color
  for (qw (rgbindex rgb)) {
    if ($args{$_}) {
      die 'Please supply a CODE reference for "$_"'
	unless (ref($args{$_}) eq 'CODE');
    }
  }
  my $rgbindex = $args{rgbindex} || \&default_rgbindex;
  my $rgb = $args{rgb} || \&default_rgb;
  my $file = $args{file} or die 'Please specify a file name';

  my $size = $args{size} || die 'Please specify the size of the image';
  my $im = GD::Image->new($size, $size);
  my $white = $im->colorAllocate(255, 255, 255);
  $im->transparent($white);
  $im->interlaced('true');
  
  ($min, $max) = min_max($pts);
  my ($xmin, $xmax, $ymin, $ymax) = 
    ($min->[0], $max->[0], $min->[1], $max->[1]);
  my %colors;

# cycle through all the points provided and plot them
# according to the color specified
  foreach (@$pts) {
    my $index = $rgbindex->($_);
    my @rgb = $rgb->($index);
    $colors{$index} = $im->colorAllocate($rgb[0], $rgb[1], $rgb[2])
      unless ($colors{$index});

# transform to pixel coordinates
    my $px = int( ($_->[0] - $xmin) / ($xmax - $xmin) * $size);
    my $py = int( ($ymax - $_->[1]) / ($ymax - $ymin) * $size);
    $im->arc($px, $py, 1, 1, 0, 360, $colors{$index});
  }

  open(PNG, ">$file") or die "Cannot open $file: $!";
  binmode PNG;
  print PNG $im->png;
  close PNG;
}

# default routine to fix the index
sub default_rgbindex {
  my $p = shift;
  return int($p->[2]/$max->[2]*255);
}

# default routine to associate an rgb triplet with an index 
sub default_rgb {
  my $index = shift;
  return map{hex} unpack "a2a2a2", 
    sprintf("%02X", int($index*255*255));
}

# routine to compose a score
sub compose {
  my %args = @_;

# tempo determines the speed, and patch the instrument
  my $tempo = $args{tempo} || 90000;
  my $patch = $args{patch} || 33;

# pts is an array reference for the points used in the score
  my $pts = $args{pts};
  die 'Must supply an ARRAY reference for "pts"' 
    unless ($pts and ref($pts) eq 'ARRAY');

# noteindex returns an index used by note to determine the note
  for (qw (noteindex note)) {
    if ($args{$_}) {
      die 'Please supply a CODE reference for "$_"'
	unless (ref($args{$_}) eq 'CODE');
    }
  }
  my $noteindex = $args{noteindex} || \&default_noteindex;
  my $note = $args{note} || \&default_note;
  ($min, $max) = min_max($pts);

  my $file = $args{file} or die 'Please specify a file name';
  my $score = MIDI::Simple->new_score();
  $score->set_tempo($tempo);
  $score->patch_change(0, $patch);

# cycle through the points provided and write a note
# in the score according to the note specified
  foreach (@$pts) {
    my $index = $noteindex->($_);
    my $n = $note->($index);
    $score->n('hn', $n);
  }
  $score->write_score($file);
}

# default routine to determine the note index
sub default_noteindex {
  my $x = shift;
  $x = ($x - $min) / ($max - $min);
  return int($x * $#gm_notes);
}

# default routine to associate a note to an index
sub default_note {
  my $index = shift;
  return $gm_notes[$index];
}

# routine to determine the minimum and maximum of
# either an array reference or an array of arrays
sub min_max {
  my $p = shift;
  die 'Please supply an ARRAY reference'
    unless ($p and ref($p) eq 'ARRAY');
  my ($min, $max);

  my $ref = ref($p->[0]);
  if ($ref eq 'ARRAY') {
    my $size = scalar @{$p->[0]} - 1;
    $min->[$_] = $max->[$_] = $p->[0]->[$_] for (0 .. $size);
    foreach my $row (@$p) {
      for (0 .. $size) {
	my $member = $row->[$_];
	$min->[$_] = $member if $member < $min->[$_];
	$max->[$_] = $member if $member > $max->[$_];
      }
    }
  }
  elsif (not $ref) {
    $min = $max = $p->[0];
    foreach (@$p) {
      $min = $_ if $_ < $min;
      $max = $_ if $_ > $max;
    }
  }
  else {
    die 'Cannot handle a "$ref" reference';
  }
  return ($min, $max);
}

1;
