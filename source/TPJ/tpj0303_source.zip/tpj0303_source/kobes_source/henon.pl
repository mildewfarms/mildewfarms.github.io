#!/usr/bin/perl
# henon.pl - hear the henon map
use strict;
use warnings;
use Fractal qw(compose min_max);
# where to start the map at
my ($xstart, $ystart) = (0.4, 0.2);
# the parameters a and b, and the number of notes
my ($a, $b, $maxit) = (1.4, 0.3, 256);

# use a chromatic scale
my @notes = (55 .. 89);

my $points = henon();
my ($min, $max) = min_max($points);
compose(pts => $points, file => 'henon.mid',
	tempo => 100000, patch => 44,
	noteindex => \&my_noteindex, note => \&my_note);

sub henon {
  my $pts = [];
  my ($oldx, $oldy, $newx, $newy) = ($xstart, $ystart, 0, 0);
  push @$pts, $xstart;
  for (my $i=1; $i<$maxit; $i++) {
    $newx = $a - $oldx*$oldx + $b*$oldy;
    $newy = $oldx;
    push @$pts, $newx;
    ($oldx, $oldy) = ($newx, $newy);
  }
  return $pts;
}

sub my_noteindex {
  my $x = shift;
  $x = ($x - $min) / ($max - $min);
  return int($x * $#notes);
}

sub my_note {
  my $index = shift;
  return $notes[$index];
}
