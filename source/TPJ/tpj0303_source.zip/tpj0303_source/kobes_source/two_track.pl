#!/usr/bin/perl
# two_track.pl - hear a point of the Mandelbrot set
use strict;
use warnings;
use Fractal qw(min_max);
use MIDI::Simple;

my $maxit = 200; # maximum number of notes
my ($cx, $cy) = (-0.1, -0.9); # pick a point on the Mandelbrot set
my $file = 'mandelbrot.mid';
my ($tempo, $patch_0, $patch_1) = (90000, 33, 66);

my @xnotes = (55, 57, 59, 60, 62, 64, 66, 67);

my @ynotes = (67, 69, 71, 72, 74, 76, 78, 79);

my $points = mandelbrot();
my ($min, $max) = min_max($points);
my ($xmin, $xmax, $ymin, $ymax) =
  ($min->[0], $max->[0], $min->[1], $max->[1]);

new_score();
patch_change 0, $patch_0;
patch_change 1, $patch_1;
set_tempo($tempo);
my @subs = (\&track_0, \&track_1);
my ($x, $y);

foreach (@$points) {
  ($x, $y) = ($_->[0], $_->[1]);
  synch(@subs);
}
write_score($file);

sub mandelbrot {
  my $pts = [];
  my ($oldx, $oldy, $newx, $newy) = (0,0,0,0); # start at x = y = 0
  push @$pts, [$oldx, $oldy];
  my $i=1;  # iteration number before breakout condition is met
  for ($i=1; $i<$maxit; $i++) {
    $newx = $oldx*$oldx - $oldy*$oldy + $cx;
    $newy = 2*$oldx*$oldy + $cy;
	last if sqrt($newx*$newx + $newy*$newy) > 2; # breakout condition
    ($oldx, $oldy) = ($newx, $newy);
    push @$pts, [$newx, $newy];
  }
  return $pts;
}

sub track_0 {
  my $it = shift;
  my $note = xnote();
  $it->n('c0', 'hn', $note);
}

sub track_1 {
  my $it = shift;
  my $note = ynote();
  $it->n('c1', 'hn', $note);
}

sub xnote {
  my $xn = ($x - $xmin) / ($xmax - $xmin);
  my $index = int($xn * $#xnotes);
  return $xnotes[$index];
}

sub ynote {
  my $yn = ($ymax - $y) / ($ymax - $ymin);
  my $index = int($yn * $#ynotes);
  return $ynotes[$index];
}
