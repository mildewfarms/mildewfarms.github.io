#!/usr/bin/perl
# fern.pl - draw a fern
use strict;
use warnings;
use Fractal qw(draw min_max);

# specify the maximum number of iterations used,
# and the size of the desired image
my ($maxit, $size) = (100000, 300);

# specify the transformations
#     x[n+1] = a[i]*x[n] + b[i]*y[n] + e[i]
#     y[n+1] = c[i]*x[n] + d[i]*y[n] + f[i]
# where "i" labels the particular transformation

my @a = (0.85, 0.20, -0.15, 0);
my @b = (0.04, -0.26, 0.28, 0);
my @e = (0.075, 0.4, 0.575, 0.5);
my @c = (-0.04, 0.23, 0.26, 0);
my @d = (0.85, 0.22, 0.24, 0.16);
my @f = (0.18, 0.045, -0.086, 0);

# specify the probablility for which to choose each transformation
# and check that they all add up to 1
my %prob = (0 => 0.77, 1 => 0.12, 2 => 0.1, 3 => 0.01);
my $sum = 0;
$sum += $_ for values %prob;
die 'The probablilities have to add up to 1'
  unless ( abs($sum - 1) < 0.001);

# where to begin the iterations at
my ($xstart, $ystart) = (0, 0);

my $points = ifs_specified();
my ($min, $max) = min_max($points);
draw(pts => $points, file => 'fern.png', size => $size,
     rgbindex => \&my_rgbindex, rgb => \&my_rgb);

# routine to find the points of an ifs by choosing the 
# transformation as specified by a user-set probability
sub ifs_specified {
  my $pts = [];
  push @$pts, [$xstart, $ystart, 0];
  my ($oldx, $oldy, $newx, $newy) = ($xstart, $ystart, 0, 0);

# set up bounds to use in test for deciding which
# transformation to use
  my %bounds;
  my $last = 0;
  my @indices = sort {$a <=> $b} keys %prob;
  for (@indices) {
    $last += $prob{$_};
    $bounds{$_} = $last;
  }
  for (my $count=1; $count<$maxit; $count++) {
# decide which transformation to use
    my $index;
    my $r = rand;
    for (@indices) {
      if ($r < $bounds{$_}) {
	$index = $_;
	last;
      }
    }

    $newx = $a[$index]*$oldx + $b[$index]*$oldy + $e[$index];
    $newy = $c[$index]*$oldx + $d[$index]*$oldy + $f[$index];
    push @$pts, [$newx, $newy, $index];
    ($oldx, $oldy) = ($newx, $newy);
  }
  return $pts;
}

sub my_rgbindex {
  my $p = shift;
  return int($p->[2]/$max->[2]*255);
}

sub my_rgb {
  my $index = shift;
  return ($index*20, 128, (255 - $index*10));
}
