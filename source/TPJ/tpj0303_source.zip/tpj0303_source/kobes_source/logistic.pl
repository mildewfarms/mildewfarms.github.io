#!/usr/bin/perl
# logistic.pl - hear the logistic map
use strict;
use warnings;
use Fractal qw(compose);
# where to start the map at, the parameter mu, and the number of notes
my ($xstart, $A, $maxit) = (0.4, 3.82, 256);

my $points = logistic();
compose(pts => $points, file => 'logistic.mid');

sub logistic {
  my $pts = [];
  my ($oldx, $newx) = ($xstart, 0);
  push @$pts, $xstart;
  for (my $i=1; $i<$maxit; $i++) {
    $newx = $A*$oldx*(1-$oldx);
    push @$pts, $newx;
    $oldx = $newx;
  }
  return $pts;
}
