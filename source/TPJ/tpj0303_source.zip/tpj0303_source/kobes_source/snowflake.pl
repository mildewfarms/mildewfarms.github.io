#!/usr/bin/perl
# snowflake.pl - draw a snowflake
use strict;
use warnings;
use Fractal qw(draw min_max);

# specify the maximum number of iterations used,
# and the size of the desired image
my ($maxit, $size) = (500000, 300);

# specify the transformations
#     x[n+1] = a[i]*x[n] + b[i]*y[n] + e[i]
#     y[n+1] = c[i]*x[n] + d[i]*y[n] + f[i]
# where "i" labels the particular transformation

my @a = (.75, .5, .25, .25, .25, .25);
my @b = (0, -0.5, 0, 0, 0, 0);
my @e = (.125, .5, 0, .75, 0, .75);
my @c = (0, .5, 0, 0, 0, 0);
my @d = (.75, .5, .25, .25, .25, .25);
my @f = (.125, 0, .75, .75, 0, 0);

# where to begin the iterations at
my ($xstart, $ystart) = (0.6, 0.5);

my $points = ifs_random();
my ($min, $max) = min_max($points);
draw(pts => $points, file => 'snowflake.png', size => $size,
     rgbindex => \&my_rgbindex, rgb => \&my_rgb);

# routine to find the points of an ifs by 
# choosing the transformation used randomly
sub ifs_random {
  my $pts = [];
  push @$pts, [$xstart, $ystart, 0];
  my ($oldx, $oldy, $newx, $newy) = ($xstart, $ystart, 0, 0);
  for (my $count = 1; $count < $maxit; $count++) {
# choose a transformation randomly
    my $index = int(rand @a); 
    $newx = $a[$index]*$oldx + $b[$index]*$oldy + $e[$index];
    $newy = $c[$index]*$oldx + $d[$index]*$oldy + $f[$index];
    push @$pts, [$newx, $newy, $index];
    ($oldx, $oldy) = ($newx, $newy);
  }
  return $pts;
}

sub my_rgbindex {
  my $p = shift;
  return int($p->[2]/$max->[2]*100);
}

sub my_rgb {
  my $index = shift;
  return (128, 0, 128);
}
