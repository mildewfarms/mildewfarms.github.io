use strict;
use warnings;
use Petal;
                                                                                                                              
$ENV{REMOTE_USER} = 'larry';
my $template_file = 'example1_03.html';
my $template = new Petal ( $template_file );
print $template->process ( ENV => \%ENV );
