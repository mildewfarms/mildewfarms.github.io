use LWP::Simple;
use XML::RSS;
use Petal;
my $uri = 'http://mkdoc.com/rss100headline.rdf';
my $content = get ($uri) || die 'nuthin?';
my $rss = new XML::RSS;
$rss->parse ($content);
print Petal->new ('example2_02.html')->process (rss => $rss);
