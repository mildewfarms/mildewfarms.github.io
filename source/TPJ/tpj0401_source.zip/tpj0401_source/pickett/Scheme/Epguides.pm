# Epguides scheme.
# Designed for update-episodes.
# Copyright (C) 2003 Deborah Pickett

package Scheme::Epguides;

use strict;

# Some web-related modules needed.
use LWP::UserAgent;
use HTML::Parser;
use HTML::Entities;
use URI;

# These two values are configurable by the user.
our $menuURL = "http://www.epguides.com/menu/";
our $synopsisLimit = 2000;    # Keep at 4000 or smaller.

=head1 NAME

Scheme::* - scheme handlers for update-episodes

=head1 METHODS

A scheme handler needs to have the following methods:

=over

=item $handler = Scheme::Epguides-E<gt>new($series, $url)

Takes a series name (string) and its URL and returns a new scheme
handler object.

=back

=cut

# Initialize a new scheme object.
# Parameters:
#   Series name
#   Current Series URL
# Return value:
#   New Scheme object.
sub new
{
  my ($class, $seriesName, $url) = @_;
  return bless {
    seriesName => $seriesName,
    url => $url,
  }, $class;
}

=over

=item $handler-E<gt>guessSeriesURL() [optional]

Returns a list of hashes suggesting a URL for this series.  Each hash
looks like:

=over

    {
        title => title of series,
        url => URL of this series
    }

=back

=back

=cut

# Return a list of guesses for the URL for this series.
# Parameters:
#   none
# Return value:
#   list of hashes:
#     { title => title of series,
#       url => URL of series episode list }
sub guessSeriesURL
{
  my $self = shift;

  my @guesses;

  # Look through Epguides' "complete list of all series" menu webpage.
  my $response = getPage($menuURL);
  unless ($response->is_success())
  {
    warn "Can't fetch $menuURL: ", $response->status_line(), "\n";
    return;
  }
  
  # Parse the web page.
  my @series = parseSeries($response->content());

  # Find which series even remotely match.
  # Strip non-alphanumerics and the words (and an a the)
  # from both strings.
  my $strippedName = lc $self->{seriesName};
  $strippedName =~ s/(^|\b)(the|a|and)($|\b)//g;
  $strippedName =~ s/[^a-z0-9]//g;
  @guesses = grep {
    my $strippedTry = lc $_->{title};
    $strippedTry =~ s/(^|\b)(the|a|and)($|\b)//g;
    $strippedTry =~ s/[^a-z0-9]//g;
    $strippedTry =~ $strippedName;
  } @series;

  # Make the URLs absolute.
  map { $_->{url} =
    URI->new_abs( $_->{url}, $response->base() )
  } @guesses;

  return @guesses;
}


=over

=item $handler-E<gt>setURL($url)

Tell this object to use $url from now on.

=back

=cut

# Change the scheme object's series URL.
# Parameters:
#   URL to use for this series.
sub setURL
{
  my ($self, $url) = @_;

  $self->{url} = $url;
}


=over

=item $handler-E<gt>getCast()

Return a list of cast in this series (strings), one list element per cast member.

=back

=cut

# Get the series' cast list.
# Parameters:
#   none
# Return value:
#   list of strings, one cast member per line.
sub getCast
{
  my ($self) = @_;

  my @result;

  # Get the page that contains the cast.
  my $seriesURL = $self->{url};
  my $response = getPage($seriesURL);

  unless ($response->is_success())
  {
    warn "Can't fetch $seriesURL: ", $response->status_line(), "\n";
    return;
  }

  # Process the web page.
  @result = parseCast($response->content());

  return @result;
}


=over

=item $handler-E<gt>getEpisodes($getSynopses)

Return a list of episodes in this series, as a list of hashes, each of
the form:

=over

    {
        order => this episode's position in the series,
        season => season (number, may be alpha),
        episode => episode within season (number, may be alpha),
        prodnum => production number (may be empty),
        airdate => original air date (string),
        title => episode name,
        synopsisURL => URL of synopsis, even if no synopses were requested,
        synopsis => synopsis string, or blank
    }

=back

If $getSynopses is zero, do not try to get synopses for episodes in this series.

=back

=cut

# Extract the episode names from the episode list.
# Parameters:
#   boolean, should synopses be fetched too?
# Return value:
#   List of hashes:
#     {
#       order => this episode's position in the series,
#       season => season (number, may be alpha),
#       episode => episode within season (number, may be alpha),
#       prodnum => production number (may be empty),
#       airdate => original air date (string),
#       title => episode name,
#       synopsisURL => URL of synopsis, even if no synopses were
#         requested,
#       synopsis => synopsis string, or blank
#     }
sub getEpisodes
{
  my ($self, $getSynopsis) = @_;

  my @result;

  # Get the page.
  my $seriesURL = $self->{url};
  my $response = getPage($seriesURL);

  unless ($response->is_success())
  {
    warn "Can't fetch $seriesURL ", $response->status_line(), "\n";
  }
  my $content = $response->content();

  # Does this page have an <!--#include virtual="..."--> entry?
  # If so, fetch it and insert it.  The epguides server ought to
  # do this, but I think it's getting confused.
  $content =~ s{<!--#include virtual="([^">]+)"-->}{
    my $subresponse = getPage(
      URI->new_abs( $1, $response->base() )
    );
    $subresponse->is_success() ?
      $subresponse->content() :
      "ERROR: " . $subresponse->status_line();
  }eg;
  
  # Parse the episode list.
  @result = parseEpisodes($content);

  # Flesh out with synopsis, if asked for.
  if ($getSynopsis)
  {
    foreach my $episode (@result)
    {
      next if !defined $episode->{synopsisURL};
      # Make synposis URL absolute.
      $episode->{synopsisURL} = 
        URI->new_abs( $episode->{synopsisURL}, $response->base() );
      # Some formats to avoid for the moment.
      next if ($episode->{synopsisURL} =~ m#http://www.tvtome.com/(tvtome|servlets)/#);
      # Get the actual synopsis.
      $episode->{synopsis} =
        $self->getSynopsis($episode->{synopsisURL});
      # Truncate the synopsis so that the Palm database isn't too big.
      if (length ($episode->{synopsis}) > $synopsisLimit)
      {
        substr($episode->{synopsis}, $synopsisLimit) = "...[truncated]...";
      }
    }
  }

  # Ignore the claimed order and re-order them as listed (epguides
  # quirk).
  for (my $i = 0; $i < @result; $i++)
  {
    $result[$i]{order} = $i;
  }

  return @result;
}

# Get the synopsis of an episode.
# Parameters:
#   URL of page that contains synopsis.
# Return value:
#   String, text of synopsis.
sub getSynopsis
{
  my ($self, $synopsisURL) = @_;
  my $result;
  my $anchor;

  # Does this URL have an anchor?
  if ($synopsisURL =~ s/#(.+)$//)
  {
    # Remember the anchor, and strip it from the URL to fetch.
    $anchor = $1;
  }

  # Get the page.
  my $response = getPage($synopsisURL);

  unless ($response->is_success())
  {
    warn "Can't fetch $synopsisURL: ", $response->status_line(), "\n";
    return;
  }

  # Parse the page.
  $result = parseSynopsis($response->content(), $anchor);

  return $result;
}

=over

=item $handler-E<gt>getCopyright()

Return a string specifying the copyright/terms of use for the web page
we're parsing.

=back

=cut

# Get the copyright/terms of use information on the page.
# Parameters:
#   none
# Return value:
#   String, contents of copyright/terms of use data.
sub getCopyright
{
  my ($self) = @_;

  my $result;

  # Get the series page.
  my $seriesURL = $self->{url};
  my $response = getPage($seriesURL);

  # Get the page.
  unless ($response->is_success())
  {
    warn "Can't fetch $seriesURL: ", $response->status_line(), "\n";
    return;
  }

  # Parse the page.
  $result = parseCopyright($response->content());

  return $result;
}

=head1 BUGS

getSynopsis for the last episode on a web page may have some trailing
garbage.

getCopyright returns poorly-formatted strings.

=head1 AUTHOR

Deborah Pickett E<lt>debbiep@csse.monash.edu.auE<gt>

The latest version of update-episodes can be found at
C<http://www.csse.monash.edu.au/~debbiep/palm/update-episodes/>.

=cut

### End of public methods

# Functions for getting the series from the menu web page..
{
  # Epguides menu page contains all series inside a table.  Hyperlinks
  # which appear in a table, after an <a name=""> section, are probably
  # series.

  my $parseSeriesTableLevel;
  my $parseSeriesNameFlag;
  my $parseSeriesALevel;
  my $parseSeriesURL;
  my $parseSeriesName;
  my @parseSeriesAll;

  sub parseSeries
  {
    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseSeriesStartTag, "tagname, attr"],
      end_h => [\&parseSeriesEndTag, "tagname"],
      text_h => [\&parseSeriesText, "text"],
    );
    
    $parseSeriesTableLevel = 0;
    $parseSeriesNameFlag = 0;
    $parseSeriesALevel = 0;
    @parseSeriesAll = ();
    $p->parse(shift);
    return @parseSeriesAll;
  }
  
  sub parseSeriesStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "table")
    {
      $parseSeriesTableLevel++;
    }
    elsif ($tagname eq "a" && exists $attrRef->{name} && $parseSeriesTableLevel == 1)
    {
      $parseSeriesNameFlag = 1;
    }
    elsif ($tagname eq "a" && exists $attrRef->{href})
    {
      $parseSeriesURL = $attrRef->{href};
      $parseSeriesName = "";
      $parseSeriesALevel++;
    }
  }
  
  sub parseSeriesEndTag
  {
    my ($tagname) = @_;
    if ($tagname eq "table")
    {
      $parseSeriesTableLevel--;
      $parseSeriesNameFlag = 0;
    }
    elsif ($tagname eq "a")
    {
      if ($parseSeriesName ne "")
      {
        push @parseSeriesAll, { title => $parseSeriesName, url => $parseSeriesURL };
        $parseSeriesName = "";
      }
      $parseSeriesALevel--;
    }
  }
  
  sub parseSeriesText
  {
    my ($text) = @_;
    if ($parseSeriesTableLevel == 1
      && $parseSeriesNameFlag
      && $parseSeriesALevel == 1)
    {
      $parseSeriesName .= $text;
    }
  }

}

# Functions for processing the cast.
{
  # Cast appear on the series page as list items inside an unordered
  # list that isn't in a <pre> section.
 
  my $parseCastULLevel;
  my $parseCastPre;
  my $parseCastLI;
  my $parseCastBucket;
  my @parseCastAll;

  sub parseCast
  {
    my $str = shift;
    $str =~ s/\015\012?/\n/g;

    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseCastStartTag, "tagname, attr"],
      end_h => [\&parseCastEndTag, "tagname"],
      text_h => [\&parseCastText, "text"],
    );
    
    $parseCastULLevel = 0;
    $parseCastPre = 0;
    $parseCastLI = 0;
    $parseCastBucket = "";
    @parseCastAll = ();
    $p->parse($str);
    return @parseCastAll;
  }
  
  sub parseCastStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "pre")
    {
      $parseCastPre = 1;
    }
    elsif ($tagname eq "ul")
    {
      $parseCastULLevel++;
    }
    elsif ($tagname eq "p")
    {
      # Paragraphs void LI things at epguides.
      $parseCastLI = 0;
    }
    elsif ($tagname eq "li")
    {
      if ($parseCastBucket ne "")
      {
        chomp $parseCastBucket;
        push @parseCastAll, decode_entities($parseCastBucket);
        $parseCastBucket = "";
      }
      $parseCastLI = 1;
    }
  }
  
  sub parseCastEndTag
  {
    my ($tagname) = @_;
    if ($tagname eq "pre")
    {
      $parseCastPre = 0;
    }
    elsif ($tagname eq "ul")
    {
      if ($parseCastBucket ne "")
      {
        chomp $parseCastBucket;
        push @parseCastAll, decode_entities($parseCastBucket);
        $parseCastBucket = "";
      }
      $parseCastULLevel--;
    }
  }
  
  sub parseCastText
  {
    my ($text) = @_;
    if ($parseCastPre == 0 &&
      $parseCastULLevel == 1 &&
      $parseCastLI == 1)
    {
      $parseCastBucket .= $text;
    }
  }

}


# Functions for getting the episodes from the series web page.
{
  # Episodes are in a <pre> section, so avoid using HTML::Parser here.
  # Just process the text a line at a time.

  sub parseEpisodes
  {
    my $str = $_[0];
    my $pre = 0;
    my @result;

    $str =~ s/\015\012?/\n/g;
    LINE: while ($str !~ /\A^\s*\Z$/)
    {
      my $line;
      if ((($str =~ s/^(.*)\n//)) == 0) { last; }
      $line = $1;

      if (lc $line eq "<pre>")
      {
        $pre = 1;
      }
      elsif (lc $line eq "</pre>")
      {
        $pre = 0;
      }

      if ($pre)
      {
        # This is a line.
        my ($order, $season, $episode, $prodnum, $title, $airdate, $synopsisURL);

        # Strip any html.
        if ($line =~ s/\<a\s+href=\"([^"]*)\"\s*\>([^\<]*)<\/a>/$2/)
        {
          $synopsisURL = $1;
        }
        else
        {
          undef $synopsisURL;
        }
        # Lose any other HTML.
        $line =~ s/\<.+?\>//g;

        # Unescape the HTML.
        $line = decode_entities($line);
        # Try this format.  This seems to work on most series.
        if ($line =~
          /^\s?
          (?:([\s\d]{2}\d\.)\s|(\s{4})\s|)          #  $1 = order (optional)
          ([\d\s\w]{3,4}?)-([\d\s\w]{1,2})\s        #  $3 = season, $4 = episode
          (.{10,14})?\s                             #  $5 = prod num (may be blank)
          ((?:[\s\d]\d\s\w{3}\s\d\d)|(?:\s{9})|(?:\sUNAIRED\s))\s{2,3}?  #  $6 = airdate
          ([\S].*)                                  #  $7 = title
          $/x) 
        {
          # If a successful match, get the matching text.
          ($order, $season, $episode, $prodnum, $airdate, $title) =
            ($1, $3, $4, $5, $6, $7);
          foreach ($order, $season, $episode, $prodnum, $airdate)
          {
            next if !defined $_;
            s/^\s*//;
            s/\s*$//;
          }
        }
        else
        {
          next LINE;
        }

        # Put this episode onto our list.
        push @result, {
          order => $order,
          season => $season,
          episode => $episode,
          prodnum => $prodnum,
          airdate => $airdate,
          title => $title,
          synopsisURL => $synopsisURL,
          synopsis => "",
        };
      }
    }
    return @result;
  }
}

# Functions for parsing episode synopses.
{
  # Synopses on Epguides are <a name=""> sections in a different
  # web page to the actual episode lists.  Any text between <a name="">
  # parts is going to be the synopsis.
 
  my $anchor;
  my $parseSynopsisGathering;
  my $parseSynopsisBody;
  my $parseSynopsisBucket;

  sub parseSynopsis
  {
    my $str;
    ($str, $anchor) = @_;
    $str =~ s/\015\012?/\n/g;

    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseSynopsisStartTag, "tagname, attr"],
      end_h => [\&parseSynopsisEndTag, "tagname"],
      text_h => [\&parseSynopsisText, "text"],
    );
    
    $parseSynopsisBucket = "";
    $parseSynopsisGathering = 0;
    $p->parse($str);
    return $parseSynopsisBucket;
  }

  sub parseSynopsisStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "a" && exists $attrRef->{name})
    {
      if ($attrRef->{name} eq $anchor)
      {
        $parseSynopsisGathering = 1;
      }
      else
      {
        $parseSynopsisGathering = 0;
      }
    }
    elsif ($tagname eq "p" || $tagname eq "br" || $tagname eq "hr"
      || $tagname eq "tr" || $tagname eq "li")
    {
      # These vaguely translate to newline.
      $parseSynopsisBucket .= "\n" if $parseSynopsisGathering;
    }
  }
  
  sub parseSynopsisEndTag
  {
    my ($tagname) = @_;
  }
  
  sub parseSynopsisText
  {
    my ($text) = @_;
    if ($parseSynopsisGathering)
    {
      $text =~ s/\n/ /g;
      $parseSynopsisBucket .= decode_entities($text);
    }
  }

}

# For parsing the copyright/terms of use info.
{
  # This information is basically everything on the web page that isn't
  # episode titles or cast lists.  We're not too finicky about the
  # format we grab this in, because no one's really going to be looking
  # at it too closely.

  my $parseCopyrightLevel;
  my $parseCopyrightBody;
  my $parseCopyrightBucket;

  sub parseCopyright
  {
    my $str = shift;
    $str =~ s/\015\012?/\n/g;

    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseCopyrightStartTag, "tagname, attr"],
      end_h => [\&parseCopyrightEndTag, "tagname"],
      text_h => [\&parseCopyrightText, "text"],
    );
    
    $parseCopyrightBody = 0;
    $parseCopyrightLevel = 0;
    $parseCopyrightBucket = "";
    $p->parse($str);
    return $parseCopyrightBucket;
  }

  sub parseCopyrightStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "pre" || $tagname eq "table" || $tagname eq "ul" || ($tagname =~ /^h[1-6]$/) )
    {
      $parseCopyrightLevel++;
    }
    elsif ($tagname eq "body")
    {
      $parseCopyrightBody = 1;
    }
    elsif ($tagname eq "p")
    {
      if ($parseCopyrightBody && $parseCopyrightLevel)
      {
        $parseCopyrightBucket .= "\n";
      }
    }
  }
  
  sub parseCopyrightEndTag
  {
    my ($tagname) = @_;
    if ($tagname eq "pre" || $tagname eq "table" || $tagname eq "ul" || ($tagname =~ /^h[1-6]$/) )
    {
      $parseCopyrightLevel--;
    }
  }
  
  sub parseCopyrightText
  {
    my ($text) = @_;
    if ($parseCopyrightLevel == 0)
    {
      if ($parseCopyrightBody)
      {
        $text =~ s/^\s*//;
        $text =~ s/\s*$//;
        $parseCopyrightBucket .= decode_entities($text);
      }
    }
  }

}

# Caching of web pages.
{
  # A cache of HTTP responses, including the requested web pages.
  my %responseCache;

  # Get a web page
  # Parameters:
  #   URL
  # Return value:
  #   HTTP::Response object.
  sub getPage
  {
    my $url = shift;

    if (exists $responseCache{$url})
    {
      return $responseCache{$url};
    }
    
    # Use LWP::UserAgent to fetch the web page.
    my $ua = LWP::UserAgent->new(env_proxy => 1);
    my $req = HTTP::Request->new(GET => $url);
    
    # Cache the response.
    $responseCache{$url} = $ua->request($req);

    unless ($responseCache{$url}->is_success())
    {
      return $responseCache{$url};
      warn "Got error: ", $responseCache{$url}->message(), "\n";
    }
    return $responseCache{$url};
  }
}

1;
