# TVTome scheme.
# Designed for update-episodes.
# Copyright (C) 2003 Deborah Pickett

package Scheme::TVTome;

use strict;

# Some web-related modules needed.
use LWP::UserAgent;
use HTML::Parser;
use HTML::Entities;
use URI;

# These two values are configurable by the user.
our $menuURL = "http://www.tvtome.com/tvtome/servlet/ListShowsServlet/";
our $synopsisLimit = 2000;    # Keep at 4000 or smaller.

=head1 NAME

Scheme::* - scheme handlers for update-episodes

=head1 METHODS

A scheme handler needs to have the following methods:

=over

=item $handler = Scheme::Epguides-E<gt>new($series, $url)

Takes a series name (string) and its URL and returns a new scheme
handler object.

=back

=cut

# Initialize a new scheme object.
# Parameters:
#   Series name
#   Current Series URL
# Return value:
#   New Scheme object.
sub new
{
  my ($class, $seriesName, $url) = @_;
  return bless {
    seriesName => $seriesName,
    url => $url,
  }, $class;
}

=over

=item $handler-E<gt>guessSeriesURL() [optional]

Returns a list of hashes suggesting a URL for this series.  Each hash
looks like:

=over

    {
        title => title of series,
        url => URL of this series
    }

=back

=back

=cut

# Return a list of guesses for the URL for this series.
# Parameters:
#   none
# Return value:
#   list of hashes:
#     { title => title of series,
#       url => URL of series episode list }
sub guessSeriesURL
{
  my $self = shift;

  my @guesses;

  # Look through TVTome's "complete list of all series" menu webpage.
  my $response = getPage($menuURL);
  unless ($response->is_success())
  {
    warn "Can't fetch $menuURL: ", $response->status_line(), "\n";
    return;
  }
  
  # Parse the web page.
  my @series = parseSeries($response->content());

  
  # Find which series even remotely match.
  # Strip non-alphanumerics and the words (and an a the)
  # from both strings.
  my $strippedName = lc $self->{seriesName};
  $strippedName =~ s/(^|\b)(the|a|and)($|\b)//g;
  $strippedName =~ s/[^a-z0-9]//g;
  @guesses = grep {
    my $strippedTry = lc $_->{title};
    $strippedTry =~ s/(^|\b)(the|a|and)($|\b)//g;
    $strippedTry =~ s/[^a-z0-9]//g;
    $strippedTry =~ $strippedName;
  } @series;

  # Make the URLs absolute.
  map { $_->{url} =
    URI->new_abs( $_->{url}, $response->base() )
  } @guesses;

  return @guesses;
}


=over

=item $handler-E<gt>setURL($url)

Tell this object to use $url from now on.

=back

=cut

# Change the scheme object's series URL.
# Parameters:
#   URL to use for this series.
sub setURL
{
  my ($self, $url) = @_;

  $self->{url} = $url;
}


=over

=item $handler-E<gt>getCast()

Return a list of cast in this series (strings), one list element per cast member.

=back

=cut

# Get the series' cast list.
# Parameters:
#   none
# Return value:
#   list of strings, one cast member per line.
sub getCast
{
  my ($self) = @_;

  my @result;

  # Get the page that contains the cast.
  my $seriesURL = $self->{url};
  my $response = getPage($seriesURL);

  unless ($response->is_success())
  {
    warn "Can't fetch $seriesURL: ", $response->status_line(), "\n";
    return;
  }

  # Process the web page.
  @result = parseCast($response->content());

  return @result;
}


=over

=item $handler-E<gt>getEpisodes($getSynopses)

Return a list of episodes in this series, as a list of hashes, each of
the form:

=over

    {
        order => this episode's position in the series,
        season => season (number, may be alpha),
        episode => episode within season (number, may be alpha),
        prodnum => production number (may be empty),
        airdate => original air date (string),
        title => episode name,
        synopsisURL => URL of synopsis, even if no synopses were requested,
        synopsis => synopsis string, or blank
    }

=back

If $getSynopses is zero, do not try to get synopses for episodes in this series.

=back

=cut

# Extract the episode names from the episode list.
# Parameters:
#   boolean, should synopses be fetched too?
# Return value:
#   List of hashes:
#     {
#       order => this episode's position in the series,
#       season => season (number, may be alpha),
#       episode => episode within season (number, may be alpha),
#       prodnum => production number (may be empty),
#       airdate => original air date (string),
#       title => episode name,
#       synopsisURL => URL of synopsis, even if no synopses were
#         requested,
#       synopsis => synopsis string, or blank
#     }
sub getEpisodes
{
  my ($self, $getSynopsis) = @_;

  my @result;

  # Get the page.
  my $listURL = $self->{url};
  $listURL =~ s!/?$!/eplist.html!;
  my $response = getPage($listURL);

  unless ($response->is_success())
  {
    warn "Can't fetch $listURL ", $response->status_line(), "\n";
  }
  my $content = $response->content();

  ## Does this page have an <!--#include virtual="..."--> entry?
  ## If so, fetch it and insert it.  The epguides server ought to
  ## do this, but I think it's getting confused.
  #$content =~ s{<!--#include virtual="([^">]+)"-->}{
  #  my $subresponse = getPage(
  #    URI->new_abs( $1, $response->base() )
  #  );
  #  $subresponse->is_success() ?
  #    $subresponse->content() :
  #    "ERROR: " . $subresponse->status_line();
  #}eg;
  
  # Parse the episode list.
  @result = parseEpisodes($content);

  # Flesh out with synopsis, if asked for.
  if ($getSynopsis)
  {
    foreach my $episode (@result)
    {
      next if !defined $episode->{synopsisURL};
      # Make synposis URL absolute.
      $episode->{synopsisURL} = 
        URI->new_abs( $episode->{synopsisURL}, $response->base() );
      # Get the actual synopsis.
      $episode->{synopsis} =
        $self->getSynopsis($episode->{synopsisURL});
      # Truncate the synopsis so that the Palm database isn't too big.
      if (length ($episode->{synopsis}) > $synopsisLimit)
      {
        substr($episode->{synopsis}, $synopsisLimit) = "...[truncated]...";
      }
    }
  }

  # Ignore the claimed order and re-order them as listed (TVTome
  # quirk).
  for (my $i = 0; $i < @result; $i++)
  {
    $result[$i]{order} = $i;
  }

  return @result;
}

# Get the synopsis of an episode.
# Parameters:
#   URL of page that contains synopsis.
# Return value:
#   String, text of synopsis.
sub getSynopsis
{
  my ($self, $synopsisURL) = @_;
  my $result;

  # Get the page.
  my $response = getPage($synopsisURL);

  unless ($response->is_success())
  {
    warn "Can't fetch $synopsisURL: ", $response->status_line(), "\n";
    return;
  }

  # Parse the page.
  $result = parseSynopsis($response->content());

  return $result;
}

=over

=item $handler-E<gt>getCopyright()

Return a string specifying the copyright/terms of use for the web page
we're parsing.

=back

=cut

# Get the copyright/terms of use information on the page.
# Parameters:
#   none
# Return value:
#   String, contents of copyright/terms of use data.
sub getCopyright
{
  my ($self) = @_;

  my $result;

  # Get the series page.
  my $seriesURL = $self->{url};
  my $response = getPage($seriesURL);

  # Get the page.
  unless ($response->is_success())
  {
    warn "Can't fetch $seriesURL: ", $response->status_line(), "\n";
    return;
  }

  # Parse the page.
  $result = parseCopyright($response->content());

  return $result;
}

=head1 BUGS

None yet.

=head1 AUTHOR

Deborah Pickett E<lt>debbiep@csse.monash.edu.auE<gt>

The latest version of update-episodes can be found at
C<http://www.csse.monash.edu.au/~debbiep/palm/update-episodes/>.

=cut

### End of public methods

# Functions for getting the series from the menu web page..
{
  # TVTome menu page contains all series inside a table.  Hyperlinks
  # which appear in a table, after an <a name=""> section, are probably
  # series.

  my $parseSeriesTableLevel;
  my $parseSeriesNameFlag;
  my $parseSeriesALevel;
  my $parseSeriesURL;
  my $parseSeriesName;
  my @parseSeriesAll;

  sub parseSeries
  {
    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseSeriesStartTag, "tagname, attr"],
      end_h => [\&parseSeriesEndTag, "tagname"],
      text_h => [\&parseSeriesText, "text"],
    );
    
    $parseSeriesTableLevel = 0;
    $parseSeriesNameFlag = 0;
    $parseSeriesALevel = 0;
    @parseSeriesAll = ();
    $p->parse(shift);
    return @parseSeriesAll;
  }
  
  sub parseSeriesStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "table")
    {
      $parseSeriesTableLevel++;
    }
    elsif ($tagname eq "a" && exists $attrRef->{name} && $parseSeriesTableLevel == 1)
    {
      $parseSeriesALevel++;
      $parseSeriesNameFlag = 1;
    }
    elsif ($tagname eq "a" && exists $attrRef->{href})
    {
      $parseSeriesURL = $attrRef->{href};
      $parseSeriesName = "";
      $parseSeriesALevel++;
    }
  }
  
  sub parseSeriesEndTag
  {
    my ($tagname) = @_;
    if ($tagname eq "table")
    {
      $parseSeriesTableLevel--;
      $parseSeriesNameFlag = 0;
    }
    elsif ($tagname eq "a")
    {
      if ($parseSeriesName ne "")
      {
        push @parseSeriesAll, { title => $parseSeriesName, url => $parseSeriesURL };
        $parseSeriesName = "";
      }
      $parseSeriesALevel--;
    }
  }
  
  sub parseSeriesText
  {
    my ($text) = @_;
    if ($parseSeriesTableLevel == 1
      && $parseSeriesNameFlag
      && $parseSeriesALevel == 1)
    {
      $parseSeriesName .= $text;
    }
  }

}

# Functions for processing the cast.
{
  # Cast lists are between sections <td class="moduletitle">
  # in sections called <table class="mainbody">.  The text in the
  # "moduletitle" element is "Show Stars".

  my $parseCastHeader;
  my $parseCastModuleTitle;
  my $parseCastMainBody;
  my $parseCastBucket;
  my @parseCastAll;

  sub parseCast
  {
    my $str = shift;
    $str =~ s/\015\012?/\n/g;

    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseCastStartTag, "tagname, attr"],
      end_h => [\&parseCastEndTag, "tagname"],
      text_h => [\&parseCastText, "text"],
    );
    
    $parseCastHeader = 0;
    $parseCastModuleTitle = 0;
    $parseCastMainBody = 0;
    $parseCastBucket = "";
    @parseCastAll = ();
    $p->parse($str);
    foreach (@parseCastAll)
    {
      s/^\s+//;
      s/\s+$//;
    }
    return @parseCastAll;
  }
  
  sub parseCastStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "table")
    {
      if ($parseCastHeader && exists $attrRef->{"class"} && $attrRef->{"class"} eq "mainbody")
      {
        $parseCastMainBody = 1;
      }
    }
    elsif ($tagname eq "td")
    {
      if (exists $attrRef->{"class"} && $attrRef->{"class"} eq "moduletitle")
      {
        $parseCastModuleTitle = 1;
      }
    }
    elsif ($tagname eq "br")
    {
      if ($parseCastBucket ne "")
      {
        chomp $parseCastBucket;
        push @parseCastAll, decode_entities($parseCastBucket);
        $parseCastBucket = "";
      }
    }
  }
  
  sub parseCastEndTag
  {
    my ($tagname) = @_;
    if ($tagname eq "td")
    {
      if ($parseCastBucket ne "")
      {
        chomp $parseCastBucket;
        push @parseCastAll, decode_entities($parseCastBucket);
        $parseCastBucket = "";
      }
      $parseCastModuleTitle = 0;
      $parseCastMainBody = 0;
    }
  }
  
  sub parseCastText
  {
    my ($text) = @_;
    if ($parseCastMainBody)
    {
      $parseCastBucket .= $text;
    }
    elsif ($parseCastModuleTitle)
    {
      if ($text eq "Show Stars")
      {
        $parseCastHeader = 1;
      }
      else
      {
        $parseCastHeader = 0;
      }
    }
  }

}


# Functions for getting the episodes from the series web page.
{
  # Episode names are on their own page.
  # Actual titles are in a table which is inside a <div
  # class="mainbody"> which is after a <td class="moduletitle"> that
  # contains the text "Episode List".
  # Only lines containing six <td> elements without any "colspan"
  # attributes are likely to be episodes.  Of those, anything with all
  # empty fields is probably a header and not a real episode.

  my $parseEpisodesHeader;
  my $parseEpisodesModuleTitle;
  my $parseEpisodesMainBody;
  my $parseEpisodesEligible;
  my $parseEpisodesTDCount;
  my @parseEpisodesTDContent;
  my $parseEpisodesSynopsisURL;
  my @parseEpisodesAll;

  sub parseEpisodes
  {
    my $str = shift;
    $str =~ s/\015\012?/\n/g;

    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseEpisodesStartTag, "tagname, attr"],
      end_h => [\&parseEpisodesEndTag, "tagname"],
      text_h => [\&parseEpisodesText, "text"],
    );
    
    $parseEpisodesHeader = 0;
    $parseEpisodesModuleTitle = 0;
    $parseEpisodesMainBody = 0;
    $parseEpisodesEligible = 0;
    @parseEpisodesAll = ();
    $p->parse($str);
    return @parseEpisodesAll;
  }
  
  sub parseEpisodesStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "table" || $tagname eq "div")
    {
      if ($parseEpisodesHeader && exists $attrRef->{"class"} && $attrRef->{"class"} eq "mainbody")
      {
        $parseEpisodesMainBody = 1;
      }
    }
    elsif ($tagname eq "tr" && $parseEpisodesMainBody)
    {
      $parseEpisodesEligible = 1;
      $parseEpisodesTDCount = -1;    # First TD will set it to zero.
      @parseEpisodesTDContent = ("") x 6;
    }
    elsif ($tagname eq "td")
    {
      if (exists $attrRef->{"class"} && $attrRef->{"class"} eq "moduletitle")
      {
        $parseEpisodesModuleTitle = 1;
      }
      elsif (exists $attrRef->{"colspan"} && $attrRef->{"colspan"} > 1)
      {
        # Column spans are verboten.
        $parseEpisodesEligible = 0;
      }
      elsif ($parseEpisodesEligible)
      {
        $parseEpisodesTDCount++;
      }
    }
    elsif ($tagname eq "a" && exists $attrRef->{"href"} &&
    $parseEpisodesEligible && $parseEpisodesTDCount == 5)
    {
      # Got URL for episode synopsis.
      $parseEpisodesSynopsisURL = $attrRef->{"href"};
    }
  }
  
  sub parseEpisodesEndTag
  {
    my ($tagname) = @_;

    if ($tagname eq "tr" && $parseEpisodesEligible &&
      $parseEpisodesTDCount == 5)
    {

      # Strip spaces.
      foreach my $i (0 .. 5)
      {
        $parseEpisodesTDContent[$i] =~ s/\xA0/ /g;   # &nbsp;
        $parseEpisodesTDContent[$i] =~ s/^\s+//;
        $parseEpisodesTDContent[$i] =~ s/\s+$//;
      }
      # Fifth <td> blank and episode title not blank?
      if ($parseEpisodesTDContent[4] eq "" && $parseEpisodesTDContent[5] ne "")
      {
        # Got a season and episode number?
        my ($season, $episode);
        if ($parseEpisodesTDContent[1] =~ /^([\d\w]+)-([\d\w]+)$/)
        {
          # Put this episode onto our list.
          $season = $1;
          $episode = $2;
 
          push @parseEpisodesAll, {
            order => $parseEpisodesTDContent[0],
            season => $season,
            episode => $episode,
            prodnum => $parseEpisodesTDContent[2],
            airdate => $parseEpisodesTDContent[3],
            title => $parseEpisodesTDContent[5],
            synopsisURL => $parseEpisodesSynopsisURL,
            synopsis => "",               # Will be done later.
          };
 
        }
 
      }
      $parseEpisodesEligible = 0; 
    }
    elsif ($tagname eq "td")
    {
      $parseEpisodesModuleTitle = 0;
    }
  }
  
  sub parseEpisodesText
  {
    my ($text) = @_;
    if ($parseEpisodesMainBody && $parseEpisodesEligible)
    {
      $parseEpisodesTDContent[$parseEpisodesTDCount] .= decode_entities($text);
    }
    elsif ($parseEpisodesModuleTitle)
    {
      if ($text eq "Episode List")
      {
        $parseEpisodesHeader = 1;
      }
      else
      {
        $parseEpisodesHeader = 0;
      }
    }
  }

}

# Functions for parsing episode synopses.
{
  # Doing this on TVTome is probably an unkind thing to do to its
  # servers, since each episode is on its own page.
 
  my $parseSynopsisHeader;
  my $parseSynopsisModuleTitle;
  my $parseSynopsisMainBody;
  my $parseSynopsisBucket;

  sub parseSynopsis
  {
    my $str = shift;
    $str =~ s/\015\012?/\n/g;

    my $p = HTML::Parser->new( api_version => 3,
      start_h => [\&parseSynopsisStartTag, "tagname, attr"],
      end_h => [\&parseSynopsisEndTag, "tagname"],
      text_h => [\&parseSynopsisText, "text"],
    );
    
    $parseSynopsisHeader = 0;
    $parseSynopsisModuleTitle = 0;
    $parseSynopsisMainBody = 0;
    $parseSynopsisBucket = "";
    $p->parse($str);
    $parseSynopsisBucket =~ s/^\s+//;
    $parseSynopsisBucket =~ s/\s+$//;
    return $parseSynopsisBucket;
  }
  
  sub parseSynopsisStartTag
  {
    my ($tagname, $attrRef) = @_;
    if ($tagname eq "table")
    {
      if ($parseSynopsisHeader && exists $attrRef->{"class"} && $attrRef->{"class"} eq "mainbody")
      {
        $parseSynopsisMainBody = 1;
      }
    }
    elsif ($tagname eq "td")
    {
      if (exists $attrRef->{"class"} && $attrRef->{"class"} eq "moduletitle")
      {
        $parseSynopsisModuleTitle = 1;
      }
    }
    elsif ($tagname eq "br" || $tagname eq "p" || $tagname eq "div")
    {
      if ($parseSynopsisMainBody)
      {
        $parseSynopsisBucket .= "\n";
      }
    }
  }
  
  sub parseSynopsisEndTag
  {
    my ($tagname) = @_;
    if ($tagname eq "td")
    {
      $parseSynopsisModuleTitle = 0;
      $parseSynopsisMainBody = 0;
    }
  }
  
  sub parseSynopsisText
  {
    my ($text) = @_;
    if ($parseSynopsisMainBody)
    {
      $parseSynopsisBucket .= decode_entities($text);
    }
    elsif ($parseSynopsisModuleTitle)
    {
      if ($text eq "Synopsis")
      {
        $parseSynopsisHeader = 1;
      }
      else
      {
        $parseSynopsisHeader = 0;
      }
    }
  }
}

# For parsing the copyright/terms of use info.
{
  # Don't seem to be any terms of use for TVTome that relate to
  # screen-scraping, so leave this blank.

  sub parseCopyright
  {
    return "";
  }
}

# Caching of web pages.
{
  # A cache of HTTP responses, including the requested web pages.
  my %responseCache;

  # Get a web page
  # Parameters:
  #   URL
  # Return value:
  #   HTTP::Response object.
  sub getPage
  {
    my $url = shift;

    if (exists $responseCache{$url})
    {
      return $responseCache{$url};
    }
    
    # Use LWP::UserAgent to fetch the web page.
    my $ua = LWP::UserAgent->new(env_proxy => 1);
    my $req = HTTP::Request->new(GET => $url);
    
    # Cache the response.
    $responseCache{$url} = $ua->request($req);

    unless ($responseCache{$url}->is_success())
    {
      return $responseCache{$url};
      warn "Got error: ", $responseCache{$url}->message(), "\n";
    }
    return $responseCache{$url};
  }
}

1;
