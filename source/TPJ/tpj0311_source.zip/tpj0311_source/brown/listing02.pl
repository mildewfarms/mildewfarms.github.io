#!/usr/bin/perl
# example dialog program
use Gtk2 -init;
use strict;

my $dialog = Gtk2::Dialog->new;

$dialog->set_title('Example Dialog');
$dialog->set_border_width(8);
$dialog->vbox->set_spacing(8);
$dialog->set_position('center');
$dialog->set_default_size(200, 100);

$dialog->add_buttons(
	'gtk-cancel' => 'cancel',
	'gtk-ok' => 'ok'
);

$dialog->signal_connect('response', \&response);

my $label = Gtk2::Label->new('Example dialog');

$dialog->vbox->pack_start($label, 1, 1, 0);

$dialog->show_all;

$dialog->run;

sub response {
	my ($button, $response) = @_;
	print "response code is $response\n";
	exit;
}
