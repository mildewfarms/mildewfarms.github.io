#!/usr/bin/perl
# frames example
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Frame Example');
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);

my $frame = Gtk2::Frame->new('Frame Title');

$frame->set_shadow_type('etched_in');

my $button = Gtk2::Button->new('Frame Contents');
$button->signal_connect('clicked', sub { Gtk2->main_quit });
$button->set_border_width(8);

$frame->add($button);

$window->add($frame);

$window->show_all;

Gtk2->main;
