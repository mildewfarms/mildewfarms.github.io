#!/usr/bin/perl
# example packing box script.
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Packing Box Example');
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);

my $label  = Gtk2::Label->new("Here's a label");
my $button = Gtk2::Button->new("Here's a button");
my $image  = Gtk2::Image->new_from_stock('gtk-dialog-info', 'dialog');

$button->signal_connect('clicked', \&clicked);

my $box = Gtk2::HBox->new;
$box->set_spacing(8);

$box->pack_start($label,  0, 0, 0);
$box->pack_start($button, 0, 0, 0);
$box->pack_start($image,  0, 0, 0);

$window->add($box);

$window->show_all;

Gtk2->main;

exit;

sub clicked {

	$window->remove($box);		# remove from the window
	foreach my $child ($box->get_children) {
		$box->remove($child);	# remove all the children
	}
	$box->destroy;			# destroy

	# create a new box:
	my $new_box = (ref($box) eq 'Gtk2::VBox' ? Gtk2::HBox->new : Gtk2::VBox->new);

	# re-pack the widgets:
	$new_box->pack_start($label,  0, 0, 0);
	$new_box->pack_start($button, 0, 0, 0);
	$new_box->pack_start($image,  0, 0, 0);
	$new_box->show_all;

	$box = $new_box;
	$window->add($box);	# add the new box
	return 1;
}
