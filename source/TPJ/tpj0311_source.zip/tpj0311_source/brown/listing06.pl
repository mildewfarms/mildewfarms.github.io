#!/usr/bin/perl
# Table Example
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Table Example');
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);

my $table = Gtk2::Table->new(4, 2);
$table->set_col_spacings(8);
$table->set_row_spacings(8);

# two buttons side-by-side:
$table->attach_defaults(Gtk2::Button->new('0,0 -> 1, 0'), 0, 1, 0, 1);
$table->attach_defaults(Gtk2::Button->new('1,0 -> 2, 0'), 1, 2, 0, 1);

# one button spanning two columns:
$table->attach_defaults(Gtk2::Button->new('0,1 -> 2, 1'), 0, 2, 1, 2);

# one button spanning two rows:
$table->attach_defaults(Gtk2::Button->new('0,3 -> 1, 4'), 0, 1, 2, 4);

# two more buttons to fill the space:
$table->attach_defaults(Gtk2::Button->new('1,3 -> 2, 3'), 1, 2, 2, 3);
$table->attach_defaults(Gtk2::Button->new('1,4 -> 2, 4'), 1, 2, 3, 4);

$window->add($table);
$window->show_all;

Gtk2->main;

exit;
