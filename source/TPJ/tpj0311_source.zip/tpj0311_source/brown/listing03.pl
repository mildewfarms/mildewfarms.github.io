#!/usr/bin/perl
# example label program
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_border_width(8);
$window->set_title('Label Example');

my $label = Gtk2::Label->new;

my $markup = <<"END";
This is some plain text.

<b>This is some bold text.</b>

<span size="small">This is some small text.</span>

<span size="large">This is some large text.</span>

<span foreground="blue">This is blue.</span> <span style="italic">This is italic.</span> <tt>This is monospace.</tt>
END

$label->set_markup($markup);

$window->add($label);

$window->show_all;

Gtk2->main;

exit;
