#!/usr/bin/perl
# packing box example
use Gtk2 -init;
use strict;

my $window = Gtk2::Window->new;
$window->set_title('Packing Box Example');
$window->signal_connect('delete_event', sub { Gtk2->main_quit });
$window->set_default_size(300, 200);
$window->set_border_width(8);

my $vbox = Gtk2::VBox->new;
$vbox->set_spacing(8);

my @values = (
	[ 0, 0 ],
	[ 1, 0 ],
	[ 1, 1 ],
);

foreach my $args (@values) {
	my $hbox = Gtk2::HBox->new;
	$hbox->set_spacing(8);
	$hbox->pack_start(Gtk2::Button->new('First Item'), @{$args}, 0);
	$hbox->pack_start(Gtk2::Button->new('Second'),     @{$args}, 0);
	$hbox->pack_start(Gtk2::Button->new('Third'),      @{$args}, 0);
	$vbox->pack_start($hbox, 0, 0, 0);
}

$window->add($vbox);

$window->show_all;

Gtk2->main;

exit;
