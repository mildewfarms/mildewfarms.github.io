COLLIDE.ASC
Title: COLLISION DETECTION
Keywords: GAMES   C   ANIMATION   PERFORMANCE
Published source code accompanying Dave Roberts's article on 
collision detection. Dave examines various collision-detection 
techniques, and presents code that enables your game programs to 
run as fast as possible. 

SKATER.ASC
Title: THEATRIX: A C++ GAME CLASS LIBRARY
SHARED MEMORY AND MESSAGE QUEUES
Keywords: GAMES   C++   ANIMATION   
Published source code accompanying Al Stevens' which describes 
the Theatrix a C++ class library that encapsulates the 
operations of typical arcade games. Al describes the library 
from its highest level of abstraction--where you create scenes 
that include players under the control of directors. He provides 
skater.cpp, a C++ demo of the game.

VFW.ASC
Title: VIDEO FOR WINDOWS AND WING
Keywords: GAMES  WINDOWS  VIDEO FOR WINDOWS   C  WING  WINTOON
Published source code accompanying Christopher Kelly's article  
in which he develops a custom draw handler like that found in 
WinToon, then uses it in conjunction with WinG, Microsoft's 
games interface, to scroll text across a video window.

SPRITES.ASC
Title: ATTACHED SPRITES
Keywords: GAMES   ANIMATION   C
Published source code accompanying Diana Gruber's article which 
describes how "attached" sprites can be an efficient way of 
performin sprite animation. 

VESA.ASC
Title: USING THE VESA BIOS 2.0 LINEAR FRAME BUFFER
Keywords: GRAPHICS   PERFORMANCE   
Published source code accompanying Brian Hook and Kendall 
Bennett's article which discusses the Video Electronics Standards 
Association VESA BIOS Extension 2.0 specification. This program 
(LFBPROF) is a video-card benchmarking program that tests the 
ability of the underlying hardware to handle system-to-video 
copies and frame-buffer clears in both banked and linear frame-
buffer modes.

WING.ASC
Title: IMPLEMENTING GAMES FOR WINDOWS
Keywords: GAMES  C WINDOWS   WING   AUDIO
Published source code accompanying James Finnegan's article which 
describes how you can use in combination the WinG Windows game 
interface and WaveMix DLL to create Windows-based games. Also see 
WING.ZIP.

WING.ZIP
Title: IMPLEMENTING GAMES FOR WINDOWS
Keywords: GAMES  C WINDOWS   WING   AUDIO
Executables of versions of WAVTST.EXE and WINGTST.EXE which 
accompany James Finnegan's article which describes how you can 
use in combination the WinG Windows game interface and WaveMix 
DLL to create Windows-based games. Requires PKUNZIP.EXE to 
extract.


