October 1995
Dr. Dobb's Journal

AUTO_CPP.ASC
Title: AUTOMATING ASSOCIATION IMPLEMENTATION IN C++
Keywords: OCT95   C++   OBJECT ORIENTED
Published source code David M. Papurt's article where he compares 
several unidirectional and bidirectional pointer-based methods 
for implementing one-to-one associations--a direct, handwritten 
implementation, a modular approach exploiting inheritance, and 
template-based implementations. 

ADA95.ASC
Title: ADA 95's OBJECT-ORIENTED FACILITIES
Keywords: OCT95  C++  ADA  OBJECT ORIENTED
Published source code accompanying David Moore's article in which
he examines the Ada 95 standard which specifies support for 
object-oriented programming features such as class-wide objects, 
private types and child packages, and multiple inheritance.

MOD3.ASC
Title: PARTIAL REVELATION AND MODULA-3
Keywords: OCT95   ADA   MODULA-3  OBJECT ORIENTED 
Published source code accompanying Steve Freeman's article which 
examines Modula-3 and its type system.

S.ASC
Title: OBJECT-ORIENTED PROGRAMMING IN S
Keywords: OCT95   OBJECT ORIENTED   S   DATA ANALYSIS  GRAPHICS
Published source code accompanying Richard Calaway's article on 
S, a high-level object-oriented language originally designed 
for data analysis and graphics. 

COBOL97.ASC
Title: COBOL '97: A STATUS REPORT
Keywords: OCT95   COBOL   OBJECT ORIENTED 
Published source code accompanying Henry Saade and Ann Wallace's 
article on the proposed COBOL '97 standard includes object-
oriented features such as class definition, subclassing, data 
encapsulation, and polymorphism. 

STREAM.ASC
Title: FILE STREAMING CLASSES IN C++
Keywords: OCT95   C++   CROSS-PLATFORM   OBJECT ORIENTED
Published source code accompanying Kirit Saelensminde's article 
where he implements a C++ file-streaming system that, unlike MFC 
or OWL, doesn't require a common superclass. This approach leads 
to less overhead and greater portability. Also see STREAM.ZIP.

STREAM.ZIP
Title: FILE STREAMING CLASSES IN C++
Keywords: OCT95   C++   CROSS-PLATFORM   OBJECT ORIENTED
Complete source code accompanying Kirit Saelensminde's article 
where he implements a C++ file-streaming system that, unlike MFC 
or OWL, doesn't require a common superclass. This approach leads 
to less overhead and greater portability. Requires PKUNZIP.EXE
to extract.

MFC_SER.ASC
Title: INSIDE MFC SERIALIZATION
Keywords: OCT95   C++  MFC   OBJECT ORIENTED   CLASS LIBRARY
Published code accompanying Jim Beveridge's article on the
Microsoft Foundation Class Library (MFC) which implements a 
typesafe serialization mechanism that is both fast and flexible. 

FLASH.ASC
Title: INSIDE FLASH MEMORY
Keywords: OCT95   OPERATING SYSTEM   FLASH MEMORY   EMBEDDED SYSTEMS
Published source code accompanying Brian L. Dipert's article on 
direct-execute Flash memory systems which don't require the 
gigabyte hard disks and 64-Mbit DRAM arrays common in desktop systems.

ENV_VAR.ASC
Title: ENVIRONMENT VARIABLES AND WINDOWS 3.1
Keywords: OCT95  WINDOWS   C++   NETWORKS
Published source code and executables accompanying John Lowrey's 
article on using environment variables in Windows 3.1.

VO.ASC
Title: EXAMINING CA-VISUAL OBJECTS
Keywords: OCT95   CLIENT-SERVER   VISUAL PROGRAMMING   DATABASE
Published source code accompanying Rod da Silva's article on 
CA-Visual Objects, an application development environment that 
sports an incremental, native-code compiler, visual painters and 
editors, an advanced active repository-based storage system-- and 
an object-oriented language that allows for optional strong 
typing and full object-orientation. 

NVO.ASC
Title: POWERBUILDER NVOs
Keywords: OCT95   CLIENT-SERVER   VISUAL PROGRAMMING  OBJECT ORIENTED
Published source code accompanying Mark Robinson's article on 
Non-Visual User Objects (NVOs) from PowerBuilder.

CPROG.ASC
Title: C PROGRAMMING COLUMN
Keywords: OCT95  C++    MUSIC  WINDOWS
Published source code accompanying Al Stevens'column in which he
uses C++ to begin building MidiFritz, a personal music system.

MIDIFITZ.ZIP
Title: C PROGRAMMING COLUMN
Keywords: OCT95  C++    MUSIC   WINDOWS
Complete source code accompanying Al Stevens'column in which he
uses C++ to build MidiFritz, a personal music system.

AA1095.ASC
Title: ALGORITHM ALLEY
Keywords: ALGORITHMS  NUMBER THEORY
Published source code accompanying Louis Plebani's article in 
which he examines search procedures that enable you to obtain the 
common fraction approximation of real numbers. In doing so, he 
focuses on number theories such as Farey Sequences.



