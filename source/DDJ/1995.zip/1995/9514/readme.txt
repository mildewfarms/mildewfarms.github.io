TRAPMAN.ASC
Title: WINDOWS APPS AND EXCEPTION HANDLERS
Keywords: WINDOWS   DEBUGGING   EXCEPTION HANDLING
Published source code examples illustrating Joe Hlavaty's Windows 
TrapMan debugging utility. Also see TRAPMAN.ZIP.

TRAPMAN.ZIP
Title: WINDOWS APPS AND EXCEPTION HANDLERS
Keywords: WINDOWS   DEBUGGING   EXCEPTION HANDLING
Complete source code implementing Joe Hlavaty's TrapMan WIndows 
debugging utility. Requires PKUNZIP.EXE to extract.

C_WORX.ASC
Title: SIMPLIFYING WINDOWS DEVELOPMENT
Keywords: WINDOWS    LIBRARY   EVENTS
Published source code accompanying Al Williams article presenting
the CoolWorx toolkit which simplifies Windows application 
programming. The library includes an integrated event loop, 
encapsulation of common message handling code, tool and status 
bars that automatically manage themselves, and a text editor 
software component. Also see C_WORX.ZIP.

C_WORX.ZIP
Title: SIMPLIFYING WINDOWS DEVELOPMENT
Keywords: WINDOWS    LIBRARY   EVENTS
Complete source code accompanying Al Williams article presenting
the CoolWorx toolkit which simplifies Windows application 
programming. The library includes an integrated event loop, 
encapsulation of common message handling code, tool and status 
bars that automatically manage themselves, and a text editor 
software component. Requires PKUNZIP.EXE to extract.

AXVIEW.ASC
Title: ADDING AUXILIARY VIEWS FOR WINDOWS APPS
Keywords: WINDOWS   MFC    MDI 
Published source code accompanying Robert Rosenberg's article 
which discusses how MFC supports multiple views, presenting code 
for implementing three types of views in an application. He also 
tackles the topic of customizing the titles that appear in MDI 
frame windows.

FX.ASC
Title: CREATING SPECIAL-EFFECT BITMAPS
Keywords: WINDOWS   BITMAPS    SPECIAL-EFFECTS   ALGORITHMS
Published source code accompanying Saurabh Dixit's article which
describes how skipping algorithms canbe the basis for special-
effect bitmap routines for creating effects such as exploding, 
spiraling, sliding, curtaining, and more. Also see FX.ZIP.

FX.ZIP
Title: CREATING SPECIAL-EFFECT BITMAPS
Keywords: WINDOWS   BITMAPS    SPECIAL-EFFECTS   ALGORITHMS
Complete source code accompanying Saurabh Dixit's article which
describes how skipping algorithms canbe the basis for special-
effect bitmap routines for creating effects such as exploding, 
spiraling, sliding, curtaining, and more. Requires PKUNZIP.EXE to
extract.

RT.ASC
Title: RAMBLINGS IN REAL-TIME
Keywords: WINDOWS  REAL-TIME  WING  ANIMATION
Published source code accompanying Michael Abrash's discussion of
how Windows can be an excellent real-time animation platform. In 
this article, he examines WinG software that supports fast 
double-buffered drawing on Win 3.1, Win32s, and Win32.

VBFORM.ASC
Title: A VISUAL BASIC FORM GENERATOR
Keywords:  WINDOWS  VISUAL BASIC  C  FORMS
Published source code accompanying Wei Xiao's article which 
presents a form-generator utility in C that converts a text file 
into a Visual Basic form file. In addition to handling text 
strings, the program generates text boxes, combo boxes, check 
boxes, and form attributes such as font, margin and color. Also 
see VBFORM.ZIP.

VBFORM.ZIP
Title: A VISUAL BASIC FORM GENERATOR
Keywords:  WINDOWS  VISUAL BASIC  C  FORMS
Complete source code accompanying Wei Xiao's article which 
presents a form-generator utility in C that converts a text file 
into a Visual Basic form file. In addition to handling text 
strings, the program generates text boxes, combo boxes, check 
boxes, and form attributes such as font, margin and color. 
Requires PKUNZIP.EXE to extract.



