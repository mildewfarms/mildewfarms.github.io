December 1995
Dr. Dobb's Journal

COMPBLD.ASC
Title: VISUALLY CONSTRUCTING DELPHI COMPONENTS
Keywords: DEC95   DELPHI  VISUAL PROGRAMMING  PASCAL  WINDOWS 95
Published source code accompanying Al Williams' article which  
presents CompBld, a forms-based Delphi program for creating 
components. Also see COMPBLD.ZIP.

COMPBLD.ZIP
Title: VISUALLY CONSTRUCTING DELPHI COMPONENTS
Keywords: DEC95   DELPHI  VISUAL PROGRAMMING  PASCAL  WINDOWS 95
Complete system for Al Williams' article which  presents CompBld, 
a forms-based Delphi program for creating components. Requires
PKUNZIP.EXE to extract.

TINYCOMM.ASC
Title: EXTENDING VISUAL BASIC'S COMM CONTROL
Keywords: DEC95  XMODEM  VISUAL BASIC  WINDOWS  VBX
Published source code accompanying Michael Floyd's article which 
extends the Visual Basic 4.0 communication control by adding 
support for Xmodem protocol. Also see TINYCOMM.ZIP.

TINYCOMM.ZIP
Title: EXTENDING VISUAL BASIC'S COMM CONTROL
Keywords: DEC95  XMODEM  VISUAL BASIC  WINDOWS  VBX
Complete system accompanying Michael Floyd's article which 
extends the Visual Basic 4.0 communication control by adding 
support for Xmodem protocol. Requires PKUNZIP.EXE to extract.

CPPINT.ASC
Title: A C++ INTEGRATOR CLASS
Keywords: DEC95    C++    DIFFERENTIAL EQUATIONS
Published source code accompanying Darrel Conway's article which
presents a C++ class designed to help you solve differential 
equations by enabling the rapid incorporation of new integration 
methods. Darrel focuses on adaptive stepsize Runge-Kutta 
integrators. Also see CPPINT.ZIP.

CPPINT.ZIP
Title: A C++ INTEGRATOR CLASS
Keywords: DEC95    C++    DIFFERENTIAL EQUATIONS
Complete source code accompanying Darrel Conway's article which
presents a C++ class designed to help you solve differential 
equations by enabling the rapid incorporation of new integration 
methods. Darrel focuses on adaptive stepsize Runge-Kutta 
integrators. Requires PKUNZIP.EXE to extract.

DEVMON.ASC
Title: EXAMINING THE WINDOWS 95 LAYERED FILE SYSTEM
Keywords: DEC95   WINDOWS 95  FILE SYSTEM   DRIVERS  VSD
Published source code accompanying Mark Russinovich and Bryce 
Cogswell's article which examines the Windows 95 "layered" 
approach to file-system management. Our authors explore the file 
system, focusing on the the "vendor-supplied driver" (VSD) layer, 
presenting a program called "DEVMON" which monitors device 
drivers. See DEVMON.ZIP for the complete system.

DEVMON.ZIP
Title: EXAMINING THE WINDOWS 95 LAYERED FILE SYSTEM
Keywords: DEC95   WINDOWS 95  FILE SYSTEM   DRIVERS  VSD
Complete system accompanying Mark Russinovich and Bryce 
Cogswell's article which examines the Windows 95 "layered" 
approach to file-system management. Our authors explore the file 
system, focusing on the the "vendor-supplied driver" (VSD) layer, 
presenting a program called "DEVMON" which monitors device 
drivers. Use PKUNZIP -d to extract.

TERSE.ASC
Title: TERSE: A TINY REAL-TIME OPERATING SYSTEM
Keywords: DEC95  REAL-TIME   OPERATING SYSTEM   EMBEDDED SYSTEMS
Published source code accompanying Barry Kauler's article
which presents an 8051-implementation called TERSE, a "Tiny 
Embedded Real-time Software Environment" that's only about 260 
bytes in size. Also see TERSE.ZIP.

TERSE.ZIP
Title: TERSE: A TINY REAL-TIME OPERATING SYSTEM
Keywords: DEC95  REAL-TIME   OPERATING SYSTEM   EMBEDDED SYSTEMS
Complete source code and executables accompanying Barry Kauler's 
article which presents an 8051-implementation called TERSE, a 
"Tiny Embedded Real-time Software Environment." Requires
PKUNZIP.EXE to extract.

SECURE.ASC
Title: AN APPLICATION ACCESS SECURITY MODEL
Keywords: DEC95   NETWORK   SECURITY  POWERBUILDER
Published source code accompanying Mark Robinson's article on 
designing and implementing network access security.

SPELLX.ASC
Title: VTOOLSD FOR VxD DEVELOPMENT
Keywords: DEC95   VxD   WINDOWS 95   WINDOWS 3    DRIVERS
Published source code accompanying Charles Mirho's article 
which examines VToolsD, a C/C++ toolkit for writing virtual 
device drivers (VxDs), is designed as a replacement for 
Microsoft's DDK. Also see SPELLX.ZIP.

SPELLX.ZIP
Title: VTOOLSD FOR VxD DEVELOPMENT
Keywords: DEC95   VxD   WINDOWS 95   WINDOWS 3    DRIVERS
Complete source code accompanying Charles Mirho's article which 
examines VToolsD, a C/C++ toolkit for writing virtual device 
drivers (VxDs), is designed as a replacement for Microsoft's DDK. 
Requires PKUNZIP.EXE to extract.

TIMER.ASC
Title: VISUAL PROGRAMMING WITH REUSABLE OBJECTS
Keywords: DEC95  SMALLTALK  OBJECT-ORIENTED  VISUAL PROGRAMMING
Published code accompanying Carol Jones and Morgan Kinne's 
article which explores VisualAge's object-oriented development 
environment construction-from-parts paradigm. Our authors use 
VisualAge to design and implement a timer part that runs for a 
certain length of time, then notifies other parts when the time 
limit has expired. 

CPROG.ASC
Title: C PROGRAMMING COLUMN
Keywords: DEC95  C++    RAY CASTING     GRAPHICS
Published source code accompanying Al Stevens'column in which he
builds Raycast, a ray-casting engine written entirely in C++. Also
see RAYCAST.ZIP.

RAYCAST.ZIP
Title: C PROGRAMMING COLUMN
Keywords: DEC95  C++    RAY CASTING     GRAPHICS
Complete source code accompanying Al Stevens'column in which he
builds Raycast, a ray-casting engine written entirely in C++. 
Requires PKUNZIP.EXE using the -d option to extract.

AA1295.ASC
Title: ALGORITHM ALLEY
Keywords: ALGORITHMS    
Published source code accompanying Gene Callahan article in 
"Algorithm Alley" which discusses how you go about generating 
sequential keys in an arbitrary radix.  

