November 1994
Dr. Dobb's Journal

CPPSQL.ASC
CPPSQL.ZIP
AN SQL SERVER MESSAGE-HANDLING CLASS
by Mark Betz

DBCPP.ASC
DBCPP.ZIP
DATABASE MANAGEMENT IN C++
by Art Sulger

ENDIAN.ASC
ENDIAN-NEUTRAL SOFTWARE, PART 2
by Jim Gillig

PART.ASC
PARTIIONS
by Joe Celko

LABMAT.ASC
LABMAT.ZIP
INTERFACING LABORATORY INSTRUMENTS
by Brian Anderson

ASN.ASC
SNMP's Abstract Syntax Notation
by Steve Witten (sidebar to William Stallings' article on SNMP)

SCRPTX.ASC
SCRPTX.ZIP
EXAMINING SCRIPTX
by Assaf Reznik 

MIMS.ASC
MIMS.ZIP
BUILDING MULTIMEDIA DATABASES
by Michael Regelski

CPROG.ASC
C PROGRAMMING COLUMN
by Al Stevens 

AA114.ASC
AA114.ZIP
ALGORITHM ALLEY COLUMN
by Bruce Schneier anad Colin Plumb

