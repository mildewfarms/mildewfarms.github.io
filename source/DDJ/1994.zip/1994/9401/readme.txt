January 1994
Dr. Dobb's Journal

FRIED.ASC
FRIED.ZIP
SHARED MEMORY AND PC SUPERCOMPUTING
by Steve Fried

SCHMIT.ASC
OPTIMIZING PENTIUM CODE
by Mike Schmit
article presenting optimzing code for the Pentium processor.

SCHNEIER.ASC
SKIP LISTS
by Bruce Schneier

BUNNELL.ASC
BUNNELL.ZIP
MAXIMIZING PERFORMANCE OF REAL-TIME RISC APPLICATIONS
by Mitch Bunnell

THREADS.ASC
EXAMINING OS/2 2.1 THREADS
by John Kanalakis

NORWOOD.ASC
NORWOOD.ZIP
SYMMETRIC MULTIPROCESSING FOR PCs
by John Norwood and Shankar Vaidyanathan

CPROG.ASC
C PROGRAMING COLUMN
by Al Stevens

AA194.ASC
AA194.ZIP
ALGORITHM ALLEY COLUMN
by Tom Swan 

UC194.ASC
UC194.ZIP
UNDOCUMENTED CORNER
by Andrew Schulman and Kelly Zytaruk


