December 1998
Dr. Dobb's Journal 

File: DPRL.TXT
Title: DIGITAL CONTENT & INTELLECTUAL PROPERTY RIGHTS
Author: Arun Ramanujapuram and Prasad Ram
Keywords: DEC98    DOCUMENT LANGUAGE     DPRL
Description: Published source code accompanying the article by 
Arun Ramanujapuram and Prasad Ram in which they present DPRL, the Xerox "Digital
Property Rights Language," a language that can be used to specify rights for
digital works. It provides a mechanism in which different terms and conditions
related to access, fee, and time can be specified and enforced for the different
operations on digital documents such as view, print, and copy. 

File: TWOFISH.ZIP
Title: THE TWOFISH ENCRYPTION ALGORITHM          
Author: Bruce Schneier
Keywords: DEC98   SECURITY  ENCRYPTION   AES   ALGORITHM
Description: Unpublished source code and related files accompanying the article
by Bruce Schneier in which he presents the Twofish encryption algorithm, which
was designed to become the Advanced Encryption Standard (AES), the
yet-to-be-determined standard encryption algorithm to replace DES. Bruce lays
out the algorithm, then discusses the AES and other encryption candidates.
Requires UNZIP/PKUNZIP to extract.
 
File: NTDOMAIN.TXT
Title: DOMAIN USAGE TRACKING FOR WINDOWS NT
Author: Paul Trout
Keywords:  DEC98    NT    SYSADM     NETWORKING
Description: Published source code accompanying the article by Paul Trout in
which he presents an application that system administrators can track usage by
workstation or user on Windows NT domains. Also see NTDOMAIN.ZIP.

File: NTDOMAIN.ZIP
Title: DOMAIN USAGE TRACKING FOR WINDOWS NT
Author: Paul Trout
Keywords:  DEC98    NT    SYSADM     NETWORKING
Description: Unpublished source code and related files accompanying the article
by Paul Trout in which he presents an application that system administrators can
track usage by workstation or user on Windows NT domains. Requires UNZIP/PKUNZIP
to extract.

File: SC_OTA.TXT
Title: SMART CARDS & THE OPEN TERMINAL ARCHITECTURE
Author: Edward K. Conklin
Keywords:  DEC98    SMART CARDS   FORTH   OTA
Description: Published source code examples accompanying the article by Edward
K. Conklin in which he discusses Smart cards, sometimes known as "Integrated
Circuit Cards" or "pocket PCs," are being promoted as a replacement for existing
conventional credit/debit cards. Edward examines smart cards and the Open
Terminal Architecture, a standard that defines terminal software.

File: NTLDAP.TXT
Title: EXAMINING MICROSOFT'S LDAP API
Author: Sven B. Schreiber 
Keywords: DEC98  NT  LDAP   TCP
Description: Published source code accopanying the article by Sven Schreiber in
which he examines the Lightweight Directory Access Protocol, a TCP-based
protocol that facilitates remote access to X.500-type directory services. Sven
shows how you can use LDAP to access Microsoft's Exchange Server 5.x, then
presents an LDAP DLL for programming an Exchange directory browser. Also see
NTLDAP.ZIP.

File: NTLDAP.ZIP
Title: EXAMINING MICROSOFT'S LDAP API
Author: Sven B. Schreiber 
Keywords: DEC98  NT  LDAP   TCP
Description: Unpublished source code and related files accopanying the article
by Sven Schreiber in which he examines the Lightweight Directory Access
Protocol, a TCP-based protocol that facilitates remote access to X.500-type
directory services. Sven shows how you can use LDAP to access Microsoft's
Exchange Server 5.x, then presents an LDAP DLL for programming an Exchange
directory browser. Requires UNZIP/PKUNZIP to extract.

File: WNET.TXT
Title: DELPHI 4 AND THE WNET API
Author: Fritz Lowrey
Keywords: DEC98   WIN32   DELPHI   NETWORKING
Description: Published source code accompanying the article by Fritz Lowrey in
which he uses Delphi 4 a multi-machine remote registry editing tool based on the
Win32 WNet API. In the process, he examines the WNet API, discusses some of the
differences between Delphi 4.0 and previous versions, and looks at
authentication differences between workgroups and domains.
Also see WNET.ZIP.

File: WNET.ZIP
Title: DELPHI 4 AND THE WNET API
Author: Fritz Lowrey
Keywords: DEC98   WIN32   DELPHI   NETWORKING
Description: Published source code accompanying the article by Fritz Lowrey in
which he uses Delphi 4 a multi-machine remote registry editing tool based on the
Win32 WNet API. In the process, he examines the WNet API, discusses some of the
differences between Delphi 4.0 and previous versions, and looks at
authentication differences between workgroups and domains. Requires
UNZIP/PKUNZIP to extract.

File: CPRO128.ZIP
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: DEC98  C++  UNDO   TEMPLATES
Description: Unpublished source code accompanying the column by Al Stevens in
which he begins updating his popular column Quincy project. Quincy 96, as the
new project is called, is a Windows 95-hosted integrated development environment
for C/C++ DOS text-mode programming. 

File: JQA128.TXT 
Title: JAVA Q&A
Author: W. David Pitt
Keywords: DEC98   JAVA    JFC   WFC  DRAG-AND-DROP
Description: Published source code accompanying the article by David Pitt in
which he discusses two ways you can use Java servlet technology to create
server-based Java applications with the ability to interact with web-based
clients using HTML or serialized Java objects. Also see JQA128.ZIP.

File: JQA128.ZIP
Title: JAVA Q&A
Author: W. David Pitt
Keywords: DEC98   JAVA    JFC   WFC  DRAG-AND-DROP
Description: Unpublished source code and related files 
accompanying the article by David Pitt in which he discusses two ways you can
use Java servlet technology to create server-based Java applications with the
ability to interact with web-based clients using HTML or serialized Java
objects. Requires UNZIP/PKUNZIP to extract.

4


