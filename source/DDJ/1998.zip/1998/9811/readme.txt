November 1998
Dr. Dobb's Journal 

File: SYMERA.TXT
Title: NCSA Symera
Author: Pat Flanigan and Jawed Karim
Keywords: NOV98    JAVA    DCOM    DISTRIBUTED   NT
Description: Published source code accompanying the article by 
Pat Flanigan and Jawed Karim in which they present NCSA Symera, a 
distributed object and cluster-management system with application 
support libraries built on Microsoft's Distributed Component 
Object Model (DCOM). Our authors examine Symera, then convert a 
standalone Windows program into a Symera application that uses 
distributed resources.

File: CORBEAN.TXT
Title: A CORBA BEAN FRAMEWORK
Author: David Houlding
Keywords: NOV98   CORBA   JAVABEANS    
Description: Published source code accompanying the article by 
David Houlding in which he presents a framework based on the 
JavaBeans standard that provides a layer of abstraction over 
CORBA--and in particular the CORBA Dynamic Invocation Interface 
(DII)--to encapsulate its complexity and facilitate visual rapid 
application development. Also see CORBABEAN.EXE.

File: CORBABEA.JAR
Title: A CORBA BEAN FRAMEWORK
Author: David Houlding
Keywords: NOV98   CORBA   JAVABEANS    
Description: Unpublished code and related files accompanying the 
article by David Houlding in which he presents a framework based 
on the JavaBeans standard that provides a layer of abstraction 
over CORBA--and in particular the CORBA Dynamic Invocation 
Interface (DII)--to encapsulate its complexity and facilitate 
visual rapid application development. This file is the CORBA 
Beans Java Archive (JAR). The DynamicRequest bean customizer GUI may 
be invoked as follows: 
>c:\jdk1.1.x\bin\java -classpath
>c:\jdk1.1.x\lib\classes.zip;CORBABeans.jar corbabeans.DynamicRequestEditor
For more detailed information, including demos, tutorials, and documentation, see 
http://www.trcinc.com/corbabeans.
 
File:  MICO.TXT
Title: THE MICO CORBA-COMPLIANT SYSTEM
Author: Arno Puder
Keywords: NOV98   CORBA    C++   DISTRIBUTED COMPUTING
Description: Published source code accompanying the article by 
Arno Puder in which he presents MICO, a freely-available CORBA 
implementation that supports IDL-to-C++ mapping, Dynamic 
Invocation Interface (DII), IIOP as native protocol, nested 
method invocations, and more. Also see MICO-2_2.ZIP.

File:  MICO221.ZIP
Title: THE MICO CORBA-COMPLIANT SYSTEM
Author: Arno Puder
Keywords: NOV98   CORBA    C++   DISTRIBUTED COMPUTING
Description: Unpublished source code and related files 
accompanying the article by Arno Puder in which he presents MICO, 
Version 2-2-1, a freely-available CORBA implementation that 
supports IDL-to-C++ mapping, Dynamic Invocation Interface (DII), 
IIOP as native protocol, nested method invocations, and more. Requires 
UNZIP/PKUNIP to extract.

File: FBTS.TXT
Title: CREATING ELECTRONIC MARKETS
Author: Ming Fan, Jan Stallaert, Andrew B. Whinston
Keywords:  NOV98   E-COMMERCE   WEB   INTERNET
Description: Published source code accompanying the article by by 
Ming Fan, Jan Stallaert, and Andrew B. Whinston in which they 
describe a web-based Financial Bundle Trading System that lets 
you access financial markets using Java applets embedded in web 
browsers. 

File: GEF.TXT
Title: THE GEF GENERAL EXCEPTION-HANLDING LIBRARY
Author: Bruce W. Bigby
Keywords:  NOV98  C   EXCEPTION HANDLING   CONTRACT PROGRAMMING
Description: Published source code accompanying the article by 
Bruce W. Bigby in which he presents GEF, a general exception-
handling and contract-programming facility for C programmers. 
With GEF, its special control macros, and other support 
functions, you can separate the main purpose of a function from 
its exception-handling, contract-validation, and resource 
reclamation code. Also see GEF1.ZIP.

File: GEF1.ZIP
Title: THE GEF GENERAL EXCEPTION-HANLDING LIBRARY
Author: Bruce W. Bigby
Keywords:  NOV98  C   EXCEPTION HANDLING   CONTRACT PROGRAMMING
Description: Unpublished source code, binaries, and related file 
accompanying the article by Bruce W. Bigby in which he presents 
GEF, a general exception-handling and contract-programming 
facility for C programmers. With GEF, its special control macros, 
and other support functions, you can separate the main purpose of 
a function from its exception-handling, contract-validation, and 
resource reclamation code. Requires UNZIP/PKUNZIP to extract.

File: WINCEDD.TXT
Title: WINDOWS CE DEVICE DRIVER DEVELOPMENT, PART II
Author: James Y. Wilson 
Keywords: NOV98    WINDOWS CE    DEVICE DRIVERS
Description: Published source code accompanying the article by 
James Y. Wilson in which he identififies the basic skills you 
need to develop Windows CE device drivers, and implements a 
driver for an onboard peripheral device. 

File: DFR.TXT
Title: FILE FORMATS & AUTOMOTIVE DATA ACQUISITION
Author: Lee R. Copp
Keywords: NOV98    FILE FORMATS    DATA ACQUISITION  C++
Description: Published source code accompanying the article by by 
Lee R. Copp in which he presents a C++ tool which enables 
viewing, filtering, or analysis of disparate data. Also see 
DFR.ZIP.

File: DFR.ZIP
Title: FILE FORMATS & AUTOMOTIVE DATA ACQUISITION
Author: Lee R. Copp
Keywords: NOV98    FILE FORMATS    DATA ACQUISITION  C++
Description: Unpublished source code and related files 
accompanying the article by by Lee R. Copp in which he presents a 
C++ tool which enables viewing, filtering, or analysis of 
disparate data. Requires UNZIP/PKUNZIP to extract.

File: WIDL.TXT
Title: THE WIDL SPECIFICATION
Author: Lynn Monson
Keywords: NOV98   INTERNET   WEB   IDL
Description: Published source code accompanying the article by 
Lynn Monson in which he examines WIDL, short for "Web Interface 
Definition Language," is an XML file format for describing 
programmatic interfaces to the web. Borrowing from the object 
community's ORB ideas, WIDL describes an abstract interface to a 
"service" existing on the web. Also see WIDL.ZIP.

File: WIDL.ZIP
Title: THE WIDL SPECIFICATION
Author: Lynn Monson
Keywords: NOV98   INTERNET   WEB   IDL
Description: Unpublished source code and related files 
accompanying the article by Lynn Monson in which he examines 
WIDL, short for "Web Interface Definition Language," is an XML 
file format for describing programmatic interfaces to the web. 
Borrowing from the object community's ORB ideas, WIDL describes 
an abstract interface to a "service" existing on the web. 
Requires UNZIP/PKUNZIP to extract.

File: QDBUG.TXT
Title: EXAMINING THE WIN32 DEBUG API
Author: Fritz Lowrey
Keywords: NOV98   WIN32   DEBUGGING
Description: Published source code accompanying the article by 
Fritz Lowrey in which he examines the Win32 Debug API, a set of 
functions that provides a number of useful tools for both the 
debugger and the debugged. Since these functions are supported by 
the operating system, it doesn't matter whether the program being 
debugged has been compiled or optimized in Debug or Release mode, 
nor does it make any difference what language or tool you opt to 
use. Also see QDBUG.ZIP.

File: QDBUG.ZIP
Title: EXAMINING THE WIN32 DEBUG API
Author: Fritz Lowrey
Keywords: NOV98   WIN32   DEBUGGING
Description: Unpublished source code and related files 
accompanying the article by Fritz Lowrey in which he examines the 
Win32 Debug API, a set of functions that provides a number of 
useful tools for both the debugger and the debugged. Since these 
functions are supported by the operating system, it doesn't 
matter whether the program being debugged has been compiled or 
optimized in Debug or Release mode, nor does it make any 
difference what language or tool you opt to use. Requires 
UNZIP/PKUNZIP to extract.

File: SOLID.TXT
Title: BUILDING SOLID CODE
Author: Wes Faler
Keywords: NOV98   SOFTWARE ENGINEERING
Description: Published source code example accompanying the 
article by Wes Faler in which he describes the development 
process his company uses to produce well-structured, clean source 
code. 

File: CPROG118.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: NOV98  C++  UNDO   TEMPLATES
Description: Published source code accompanying the column by Al 
Stevens in which he updates a C++ class template library that 
implements undo operations of interactive programs. The library 
assumes that the user modifies a document class object and might 
want to undo those modifications in reverse order.

File: JQA118.TXT 
Title: JAVA Q&A
Author: Keywords: NOV98   JAVA    JFC   WFC  DRAG-AND-DROP
Description: Published source code accompanying the article by 
Jason Purdy in which he examines the drag-and-drop (DnD) 
capabilities of both JavaSoft's Java Foundation Classes (JFC) and 
Microsoft's Windows Foundation Classes (WFC). Also see 
JQA118.ZIP.

File: JQA118.ZIP
Title: JAVA Q&A
Author: Keywords: NOV98   JAVA    JFC   WFC  DRAG-AND-DROP
Description: Unpublished source code and related files 
accompanying the article by Jason Purdy in which he examines the 
drag-and-drop (DnD) capabilities of both JavaSoft's Java 
Foundation Classes (JFC) and Microsoft's Windows Foundation 
Classes (WFC). Requires UNZIP/PKUNZIP to extract.

File: AA118.TXT
Title: ALGORITHM ALLEY 
Author: Jon Bentley and Robert Sedgewick
Keywords: NOV98   ALGORITHMS   SORTING
Description: Published source code accompanying the column by Jon 
Bentley and Robert Sedgewick in which they describe a new 
algorithm for sorting strings that combines the best of quicksort 
and radix sort. Also see AA118.ZIP.

File: AA118.ZIP
Title: ALGORITHM ALLEY 
Author: Jon Bentley and Robert Sedgewick
Keywords: NOV98   ALGORITHMS   SORTING
Description: Unpublished source code and related files 
accompanying the column by Jon Bentley and Robert Sedgewick in 
which they describe a new algorithm for sorting strings that 
combines the best of quicksort and radix sort. Requires 
UNZIP/PKUNZIP to extract.




