July 1998
Dr. Dobb's Journal 
 
File: REACTIVE.TXT
Title: COMPOSING REACTIVE ANIMATIONS
Author: Conal Elliott
Keywords: JUL98   GRAPHICS  HASKELL  ANIMATION  FUNCTIONAL PROGRAMMING
Description: Source code accompanying the article by Conal Elliott in
which he discusses Fran, short for "functional reactive animation"--a
high-level vocabulary that lets you describe the essential nature of
an animated model, while omitting details of presentation. Fran is
included with the HUGS implementation of the Haskell programming
language.

File: Q2M.TXT
Title: A WINDOWS 3D MODEL VIEWER FOR OPENGL
Author: Jawed Karim 
Keywords:  JUL98  GRAPHICS  OPENGL  WIN32   QUAKE
Description: Published source code accompanying the article by Jawed
Karim in which he presents a model viewer for use with OpenGL on
Windows 95/NT. Also see Q2M-BIN.ZIP and Q2M-SRC.ZIP.

File: Q2M-SRC.ZIP
Title: A WINDOWS 3D MODEL VIEWER FOR OPENGL
Author: Jawed Karim 
Keywords:  JUL98  GRAPHICS  OPENGL  WIN32   QUAKE
Description: Unpublished source files accompanying the article by
Jawed Karim in which he presents a model viewer for use with OpenGL on
Windows 95/NT. Also see Q2M.TXT and Q2M-BIN.ZIP. Requires
UNZIP/PKUNZIP to extract.

File: Q2M-BIN.ZIP
Title: A WINDOWS 3D MODEL VIEWER FOR OPENGL
Author: Jawed Karim 
Keywords:  JUL98  GRAPHICS  OPENGL  WIN32   QUAKE
Description: Unpublished binary files accompanying the article by
Jawed Karim in which he presents a model viewer for use with OpenGL on
Windows 95/NT. Also see Q2M.TXT and Q2M-SRC.ZIP. Requires
UNZIP/PKUNZIP to extract.

File: GGIDEMO.ZIP
Title: THE KERNEL GRAPHICS INTERFACE 
Author: Andreas Beck
Keywords: JUL98     GRAPHICS  LINUX    GGI
Description: Unpublished files accompanying the article by Andreas
Beck in which he discusses the Kernel Graphics Interface (KGI). This
archive includes General Graphics Interface (GGI) demo diskimage
1.44MB 3.5-inch drives and utilities (executables and source code) for
writing the image to disk. Requires UNZIP/PKUNZIP to extract.

File: TMAPPER.TXT
Title: AFFINE TEXTURE MAPPING
Author: Andre LaMothe
Keywords: JUL98  GRAPHICS  TEXTURE MAPPING  3D
Description: Published source code accompanying the article by Andre
LaMothe in which he discusses affine texture mapping, which is
fundamental to many forms of 3D rendering, including light
interpolation and other sampling type operations. Also see TMAPSRC.ZIP

File: TMAPSRC.ZIP
Title: AFFINE TEXTURE MAPPING
Author: Andre LaMothe
Keywords: JUL98  GRAPHICS  TEXTURE MAPPING  3D
Description: Unpublished source code and related files accompanying
the article by Andre LaMothe in which he discusses affine texture
mapping, which is fundamental to many forms of 3D rendering, including
light interpolation and other sampling type operations. Requires
UNZIP/PKUNZIP to extract.

File: DVD.TXT
Title: INSIDE DVD
Author: Linden deCarmo
Keywords: JUL98    DVD   VIDEO   STORAGE
Description: Published source code accompanying the article by Linden
deCarmo in which he focuses in on the DVD-Video specificaiton, and
presents a DVD-Video player. Also see DVD.ZIP.

File: DVD.ZIP
Title: INSIDE DVD
Author: Linden deCarmo
Keywords: JUL98    DVD   VIDEO   STORAGE
Description: Unpublished source code accompanying the article by
Linden deCarmo in which he focuses in on the DVD-Video specificaiton,
and presents a DVD-Video player. Requires UNZIP/PKUNZIP to extract.

File: CALLERID.ZIP
Title: 68HC05-BASED PERIPHERAL DEVICES: PART 2 
Author: Derrick B. Forte and Hai T. Nguyen
Keywords: JUL98   TELEPHONY   68HC05  WIN32
Description: Unpublished source code accompanying the article by
Derrick B. Forte and Hai T. Nguyen in which they design a Windows
95-based Caller ID peripheral device built around Motorola's
MC68HC(7)05P9 microcontroller. Requires UNZIP/PKUNZIP to extract.

File: SCHEM.ZIP
Title: 68HC05-BASED PERIPHERAL DEVICES: PART 2 
Author: Derrick B. Forte and Hai T. Nguyen
Keywords: JUL98   TELEPHONY   68HC05  WIN32
Description: Schematics for the Keyboard Caller ID board in .EPS
format. Requires UNZIP/PKUNZIP to extract.

File: XSL.TXT
Title: RENDERING XML DOCUMENTS USING XSL
Author: Sean McGrath
Keywords: JUL98    XML   XSL   WWW   INTERNET   MSXSL
Description: Published source code accompanying the article by Sean
McGrath in which he presents an overview of XSL and illustrates how it
can be used with MSXSL, Microsoft's XSL implementation.

File: SPEECH.TXT
Title: EXAMINING THE DRAGON SPEECH-RECOGNITION SYSTEM
Author: Al Williams
Keywords: JUL98    ACTIVEX   SPEECH RECOGNITION  VISUAL BASIC  
Description: Published source code accompanying the article by Al
Williams in which he uses Visual Basic 5 and Dragon Systems'
DragonXTools toolkit to build a voice-activated autodialer. Since the
custom controls are ActiveX controls, however, you can use most any
language with them. Also see SPEECH.ZIP.

File: SPEECH.ZIP
Title: EXAMINING THE DRAGON SPEECH-RECOGNITION SYSTEM
Author: Al Williams
Keywords: JUL98    ACTIVEX   SPEECH RECOGNITION  VISUAL BASIC  
Description: Unpublished source code and related files accompanying
the article by Al Williams in which he uses Visual Basic 5 and Dragon
Systems' DragonXTools toolkit to build a voice-activated autodialer.
Since the custom controls are ActiveX controls, however, you can use
most any language with them. Requires UNZIP/PKUNZIP to extract.

File: JQA798.TXT 
Title: JAVA Q&A
Author: Aaron Michael Cohen
Keywords: JUL98   JAVA   IMAGE PROCESSING
Description: Published source code accompanying the article by Aaron
Cohen in which he examines the Java abstract imaging model which can
be used to display and manipulate both static images and sequences of
images. Also see JQA798.ZIP.

File: JQA798.ZIP
Title: JAVA Q&A
Author: Aaron Michael Cohen
Keywords: JUL98   JAVA   IMAGE PROCESSING
Description: Unpublished source code accompanying the article by Aaron
Cohen in which he examines the Java abstract imaging model which can
be used to display and manipulate both static images and sequences of
images. Requires UNZIP/PKUNZIP to extract.

File: AA798.TXT
Title: ALGORITHM ALLEY 
Author: Lee Kamentsky
Keywords: JUL98  IMAGE SEGMENTATION  GRAPHICS  ALGORITHMS
Description: Published source code accompanying the column by Lee
Kamentsky in which he presents an algorithm that separates images into
clearly-defined regions. Also see AA798.ZIP.


File: AA798.ZIP
Title: ALGORITHM ALLEY 
Author: Lee Kamentsky
Keywords: JUL98  IMAGE SEGMENTATION  GRAPHICS  ALGORITHMS
Description: Unpublished source code accompanying the column by Lee
Kamentsky in which he presents an algorithm that separates images into
clearly-defined regions. Requires UNZIP/PKUNZIP to extract. 


