February 1998
Dr. Dobb's Journal 
 
File: SWIG.TXT
Title: SWIG AND AUTOMATED C/C++ SCRIPTING EXTENSIONS
Author: David Beazley
Keywords: FEB98    SCRIPTING    C/C++ 
Description: Published source code accompanying the article by 
David Beazley in which he discusses SWIG, short for "Simplified 
Wrapper and Interface Generator"--a freely-available tool that 
lets you generate interfaces to a variety of scripting languages 
from a common interface description. Also see SWIG1_1.ZIP.

File: SWIG1_1.ZIP 
Title: SWIG AND AUTOMATED C/C++ SCRIPTING EXTENSIONS
Author: David Beazley 
Keywords: FEB98    SCRIPTING    C/C++ 
Description: Unpublished source code and related files for SWIG. 
Accompanies the article by David Beazley in which he discusses 
SWIG, short for "Simplified Wrapper and Interface Generator"--a 
freely-available tool that lets you generate interfaces to a 
variety of scripting languages from a common interface 
description. Requires UNZIP/PKUNZIP to extract. 

File: BOILER.TXT
Title: TEMPLATE PROCESSING CLASSES FOR PYTHON
Author: Brad Howes
Keywords:  FEB98    PYTHON    HTML 
Description: Published source code accompanying the article by 
Brad Howes in which he shows how you can embed Python objects in 
HTML pages using boilerplate template processing classes. Also 
see BOILER.ZIP. 
 
File: BOILER.ZIP
Title: TEMPLATE PROCESSING CLASSES FOR PYTHON
Author: Brad Howes
Keywords:  FEB98    PYTHON    HTML 
Description: Unpublished source code accompanying the article by 
Brad Howes in which he shows how you can embed Python objects in 
HTML pages using boilerplate template processing classes. 
Requires UNZIP/PKUNZIP to extract. 

File: TCLBLEND.TXT
Title: TCLBLEND: BLENDING TCL AND JAVA
Author: Scott Stanton
Keywords: FEB98  JAVA  TCL   SCRIPTING
Description: Published source code accomanying the article by 
Scott Stanton in which he discusses TclBlend, a scripting 
language based on Tcl and Java, introduces new Tcl commands that 
let you directly manipulate Java objects without having to write 
any Java code. TclBlend also provides access to the Tcl 
interpreter interfaces through a set of Java classes. Also see 
TCLBLEND.ZIP and TCLBLEND.EXE.

File: TCLBLEND.ZIP
Title: TCLBLEND: BLENDING TCL AND JAVA
Author: Scott Stanton
Keywords: FEB98  JAVA  TCL   SCRIPTING
Description: TclBlend 1.0a1 source code  release for Windows NT. 
Accompanies the article by Scott Stanton in which he discusses TclBlend, a scripting 
language based on Tcl and Java, introduces new Tcl commands that 
let you directly manipulate Java objects without having to write 
any Java code. This archive contains the source code for  
TclBlend version 1.5 TclBlend also provides access to the Tcl 
interpreter interfaces through a set of Java classes. Requires 
UNZIP/PKUNZIP to extract. 

File: TCLBLEND.EXE
Title: TCLBLEND: BLENDING TCL AND JAVA
Author: Scott Stanton
Keywords: FEB98  JAVA  TCL   SCRIPTING
Description: TclBlend 1.0a1 binary  release for Windows NT. Accompanies the article by 
Scott Stanton in which he discusses TclBlend, a scripting 
language based on Tcl and Java, introduces new Tcl commands that 
let you directly manipulate Java objects without having to write 
any Java code. 

File: PERLFILE.TXT
Title: AUTOMATIC FILE CONVERIONS WITH PERL
Author: Tim Kientzle
Keywords:  FEB98    PERL   SCRIPTING    
Description: Published source code files accompanying the article 
by Tim Kientzle in which he uses Perl to write a smart print 
filter that recognizes the type of data it is being fed and 
invokes the appropriate conversion.

File: ADC.TXT
Title: A DATA-ACQUISITION SYSTEM FOR LINUX
Author: Dhananjay V. Gadre and Sunu Engineer
Keywords: FEB98    LINUX   DATA ACQUISITION   DRIVERS
Description: Published source code accompanying the article by 
Dhananjay V. Gadre and Sunu Engineer in which they present a 
general-purpose data-acquisition system for Linux that can be 
connected to the PC's parallel port to record eight channels of 
analog voltage. Also see ADC.ZIP.

File: ADC.ZIP
Title: A DATA-ACQUISITION SYSTEM FOR LINUX
Author: Dhananjay V. Gadre and Sunu Engineer
Keywords: FEB98    LINUX   DATA ACQUISITION   DRIVERS
Description: Unpublished source code accompanying the article by 
Dhananjay V. Gadre and Sunu Engineer in which they present a 
general-purpose data-acquisition system for Linux that can be 
connected to the PC's parallel port to record eight channels of 
analog voltage. Requires UNZIP/PKUNZIP to extract.

File: MVCL.TXT
Title: FLEXIBLE SYSTEM CONTROL AND SPECIAL-PURPOSE PROGRAMMING 
LANGUAGES
Author: Russell W. Mello
Keywords: FEB98   EMBEDDED SYSTEM   REAL-TIME CONTROL
Description: Published source code accompanying the article by 
Russell W. Mello in which he discusses Mvcl, a programming 
language Russell designed to do a particular job. Also see 
MVCL.ZIP. 

File: MVCL.ZIP
Title: FLEXIBLE SYSTEM CONTROL AND SPECIAL-PURPOSE PROGRAMMING 
LANGUAGES
Author: Russell W. Mello
Keywords: FEB98   EMBEDDED SYSTEM   REAL-TIME CONTROL
Description: Unpublished source code accompanying the article by 
Russell W. Mello in which he discusses Mvcl, a programming 
language Russell designed to do a particular job. Requires 
UNZIP/PKUNZIP to extract.
 
File: PXML.TXT
Title: XML PROGRAMMING IN PYTHON
Author: Sean McGrath
Keywords: FEB98   PYTHON    SCRIPTING   XML
Description: Published source code accompanying the article by 
Sean McGrath in which he shows how you can Python as a 
development platform for XML programming

File: OPENTOOL.TXT
Title: THE DELPHI OPEN TOOLS API
Author: Ray Lischner
Keywords: FEB98   DELPHI   SCRIPTING
Description: Published source code accompanying the article by 
Ray Lischner in which he discusses Borland's Delphi Open Tools 
API, a set of classes for extending and customizing the IDE. Also 
see OPENTOOL.ZIP.

File: OPENTOOL.ZIP
Title: THE DELPHI OPEN TOOLS API
Author: Ray Lischner
Keywords: FEB98   DELPHI   SCRIPTING
Description: Unpublished source code accompanying the article by 
Ray Lischner in which he discusses Borland's Delphi Open Tools 
API, a set of classes for extending and customizing the IDE. 
Requires UNZIP/PKUNZIP to extract.

File: LEGO.TXT
Title: AN ACTIVEX CONTROL FOR REAL-TIME CONTROL
Author: Charles H. Huddleston and Douglas A. Troy
Keywords: FEB98  REAL-TIME  ACTIVEX   HTML  LEGO   C++
Description: Published source code accompanying the article by 
Charles Huddleston and Douglas Troy in which they present an 
ActiveX control which enables real-time computer control of 
external devices and sensors of various kinds in automated 
control applications. The control is written in C++, while the 
control system is built using the Lego Dacta Control Lab. Also 
see LEGO.ZIP.

File: LEGO.ZIP
Title: AN ACTIVEX CONTROL FOR REAL-TIME CONTROL
Author: Charles H. Huddleston and Douglas A. Troy
Keywords: FEB98  REAL-TIME  ACTIVEX   HTML  LEGO  C++
Description: Unpublished source code accompanying the article by 
Charles Huddleston and Douglas Troy in which they present an 
ActiveX control which enables real-time computer control of 
external devices and sensors of various kinds in automated 
control applications. The control is written in C++, while the 
control system is built using the Lego Dacta Control Lab. 
Requires UNZIP/PKUNZIP to extract.

File: CPROG298.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: FEB98   C   C++
Description: Published source-code examples accompanying the 
article by Al Stevens in which he examines C++ ANSI/ISO Standard.

File: UD0298.TXT
Title: UNDOCUMENTED CORNER COLUMN
Author: George Shepherd and Scot Wingo
Keywords: FEB98 WIN32   MFC   UNDOCUMENTED  ATL
Description: Published source code accompanying the column by 
George Shepherd and and Scot Wingo as they continue their 
examination of Microsoft's Active Template Library, this month 
focusing on ATL's ActiveX Control architecture. 

File: AA0298.TXT 
Title: ALGORITHM ALLEY 
Author: Karl-Dietrich Neubert
Keywords: FEB98   ALGORITHMS    SORTING
Description: Published source code accompanying the article  by 
Karl-Dietrich Neubert in which he discusses "classification 
sorts" which are much faster than Quicksort or Heap Sort on large 
amounts of data. 

File: JQ&A298.TXT 
Title: JAVA Q&A
Author: Cliff Berg
Keywords: FEB98  JAVA   SECURITY  NETWORKING   CLIENT-SERVER   ENCRYPTION
Description: Source code accompanying the article by 
Cliff Berg in which he shows how to implement security using 
Phaos Technology's SSLava Toolkit.


