January 1998
Dr. Dobb's Journal 
 
File: JAVA_COM.TXT
Title: JAVA AND COM AUTOMATION
Author: Kenneth Bandes             
Keywords: JAN98    JAVA   COM   ACTIVEX 
Description: Published source code accompanying the article by Kenneth Bandes in which he examines the ActiveX technology called Automation (formerly "OLE Automation"), and shows how you can be implement it in Java. Also see JAVA_COM.ZIP.

File: JAVA_COM.ZIP
Title: JAVA AND COM AUTOMATION
Author: Kenneth Bandes             
Keywords: JAN98    JAVA   COM   ACTIVEX 
Description: Unpublished source code and related files accompanying the article by Kenneth Bandes in which he examines the ActiveX technology called Automation (formerly "OLE Automation"), and shows how you can be implement it in Java. 
Requires UNZIP/PKUNZIP to extract. 

File: REFLECT.TXT
Title: JAVA REFLECTION
Author: Paul Tremblett
Keywords:  JAN98    JAVA    REFLECTION    API
Description: Published source code accompanying the article by Paul Tremblett in which he discussesthe JDK 1.1 Reflection API. This API lets you discover the fields, methods and constructors of loaded classes but also, dynamically manipulate them within the basic security framework. 
 
File: ASSERT.TXT
Title: IMPLEMENTING ASSERTIONS FOR JAVA
Author: Jeffery E. Payne, Michael A. Schatz, Matthew Schmid
Keywords:  JAN98    JAVA   DEBUGGING    
Description: Published source code files accompanying the article by 
Jeffery E. Payne, Michael A. Schatz, and Matthew Schmid in which they discuss assertions which act like watchdogs that assist you in finding bugs earlier in the development process. 

File: CLASS.TXT
Title: INSIDE JAVA CLASS FILES
Author: Matt T. Yourst
Keywords: JAN98    JAVA     PORTABILITY    DEBUGGING    CLASS
Description: Published source code accompanying the article by Matt Yourst in which he explores the class file format--the key to Java's binary portability. He then presents JavaDump, a program that documents structures in class files, and StripDebug, which removes extra debug information from classes. Also see INSIDEJC.ZIP.

File: INSDIEJC.ZIP
Title: INSIDE JAVA CLASS FILES
Author: Matt T. Yourst
Keywords: JAN98    JAVA     PORTABILITY    DEBUGGING    CLASS
Description: Unpublished source code and related files accompanying the article by Matt Yourst in which he explores the class file format--the key to Java's binary portability. He then presents JavaDump, a program that documents structures in class files, and StripDebug, which removes extra debug information from classes. Requires UNZIP/PKUNZIP to extract. 
 
File: GLOBAL.TXT
Title: THE JAVA INTERNATIONALIZATION API
Author: Carol A. Jones
Keywords: JAN98   JAVA   INTERNATIONALIZATION
Description: Published source code accompanying the article by Carol Jones in which she examines the Java Internationalization, API which lets you prepare programs that run in other languages. Also see GLOBAL.ZIP.

File: GLOBAL.ZIP
Title: THE JAVA INTERNATIONALIZATION API
Author: Carol A. Jones
Keywords: JAN98   JAVA   INTERNATIONALIZATION
Description: Unpublished source code and related files accompanying the article by Carol Jones in which she examines the Java Internationalization, API which lets you prepare programs that run in other languages. Requires UNZIP/PKUNZIP to extract. 
 
File: XSYNC.TXT
Title: MUTUAL EXCLUSION AND SYNCHRONIZATION IN JAVA
Author: Dan Ford
Keywords: JAN98   JAVA   SYNCHRONIZATION
Description: Published source code accompanying the article by Dan Ford in which he discusses Java's concurrency features, presenting classes for mutual exclusion and synchronization that mimic the behavior and interfaces of the synchronization mechanisms available in the Win32 API. 

File: PEER.TXT
Title: DEVELOPING PEER-TO-PEER APPLICATIONS FOR THE INTERNET
Author: Louis Thomas, Sean Suchter, Adam Rifkin
Keywords: JAN98   JAVA   EDITOR     OBJECTS  INTERNET
Description: Published source code accompanying the article by Louis Thomas, Sean Suchter, and Adam Rifkin which presents SimulEdit, a text editor that lets groups of people edit the same file at the same time. Enabling this application are generic network data objects (NDOs) which are shared among multiple processes communicating over a network. Also see INFONET.ZIP and NDO_SE.ZIP.

File: INFONET.ZIP
Title: DEVELOPING PEER-TO-PEER APPLICATIONS FOR THE INTERNET
Author: Louis Thomas, Sean Suchter, Adam Rifkin
Keywords: JAN98   JAVA   EDITOR     OBJECTS  INTERNET
Description: Unpublished source code accompanying the article by Louis Thomas, Sean Suchter, and Adam Rifkin which presents SimulEdit, a text editor that lets groups of people edit the same file at the same time. Enabling this application are generic network data objects (NDOs) which are shared among multiple processes communicating over a network. Also see NDO_SE.ZIP. Requires UNZIP/PKUNZIP to extract.

File: NDO_SE.ZIP
Title: DEVELOPING PEER-TO-PEER APPLICATIONS FOR THE INTERNET
Author: Louis Thomas, Sean Suchter, Adam Rifkin
Keywords: JAN98   JAVA   EDITOR     OBJECTS  INTERNET
Description: Unpublished source code accompanying the article by Louis Thomas, Sean Suchter, and Adam Rifkin which presents SimulEdit, a text editor that lets groups of people edit the same file at the same time. Enabling this application are generic network data objects (NDOs) which are shared among multiple processes communicating over a network. Also see INFONET.ZIP. Requires UNZIP/PKUNZIP to extract.

File: JDIRECT.TXT
Title: EXAMINING MICROSOFT'S J/DIRECT
Author: Andrew Wilson
Keywords: JAN98      JAVA   WINDOWS 95/NT    IE 4.0
Description: Published source code accompanying the article by Andrew Wilson in which he discusses Microsoft's J/Direct, which ships as part of Internet Explorer 4.0 (and with future versions of Windows 95/NT and Internet Information Server) simplifies the Java native code calling process almost to the point where a DLL function can be directly called from within a Java applet or application.  Also see JDIRECT.ZIP.

File: JDIRECT.ZIP
Title: EXAMINING MICROSOFT'S J/DIRECT
Author: Andrew Wilson
Keywords: JAN98      JAVA   WINDOWS 95/NT    IE 4.0
Description: Unpublished source code and related files accompanying the article by Andrew Wilson in which he discusses Microsoft's J/Direct, which ships as part of Internet Explorer 4.0 (and with future versions of Windows 95/NT and Internet Information Server) simplifies the Java native code calling process almost to the point where a DLL function can be directly called from within a Java applet or application. Requires UNZIP/PKUNZIP to extract.

File: AA0198.TXT 
Title: ALGORITHM ALLEY 
Author: John Boyer
Keywords: JAN98  ALGORITHMS   VISUAL BASIC   DECISION TREES
Description: Published source code accompanying the article by John Boyer in which he discusses pits the flexibility of resizable data structures with the speed of array-based structures. Also see AA0198.ZIP. 
 
File: AA0198.ZIP
Title: ALGORITHM ALLEY 
Author: John Boyer
Keywords: JAN98  ALGORITHMS   VISUAL BASIC   DECISION TREES
Description: Unpublished source code accompanying the article by John Boyer in which he discusses pits the flexibility of resizable data structures with the speed of array-based structures. Requires UNZIP/PKUNZIP to extract. 

File: LETTERS.TXT
Title: LETTERS TO THE EDITOR
Author: Mike Courtney
Keywords: JAN98    ALGORITHMS   GRAPHICS   CUBIC SPINE
Description: Modifications to the source code accompanying Mike Courtney's April 1996 DDJ article entitled "A Cubic Spline Extrema Algorithm". Mike provides the modified code in the "Letters" column.

File: JAVAQ&A.ZIP 
Title: JAVA Q&A 
Author: Cliff Berg 
Keywords: JAN98      JAVA      PUSH TECHNOLOGY   CHANNELS      CASTENET
Description: Published source code accompanying the column by Cliff Berg in which he answers the question "How Do I Create a Signed Castanet Channel?" Cliff examines how you create a signed Castanet channel for distributing signed and trustworthy content to users.


