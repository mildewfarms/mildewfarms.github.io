March 1998
Dr. Dobb's Journal 
 
File: TRUSS.TXT
Title: TRACING BSD SYSTEM CALLS
Author: Sean Eric Fagan
Keywords: MAR98    UNIX   FREEBSD   
Description: Published source code accompanying the article by 
Sean Eric Fagan in which he discusses how you can debug a program 
that doesn't have source or debugging symbols. One way is to 
watch the system calls it makes. Sean's "truss" utility lets you 
do exactly this. Also see TRUSS.ZIP.

File: TRUSS.ZIP
Title: TRACING BSD SYSTEM CALLS
Author: Sean Eric Fagan
Keywords: MAR98    UNIX   FREEBSD   
Description: Unpublished source code accompanying the article by 
Sean Eric Fagan in which he discusses how you can debug a program 
that doesn't have source or debugging symbols. One way is to 
watch the system calls it makes. Sean's "truss" utility lets you 
do this. Requires UNZIP/PKUNZIP to extract.

File: BENCHMK.ZIP
Title: BENCHMARK BASICS
Author: Brian Butler
Keywords:  MAR98    BENCHMARKS    ODBC    DATABASE
Description: Unpublished source code, related files, and tutorial  
accompanying the article by Brian Butler (which was part of the 
article "Benchmarks: Fact, Fantasy, or Fiction?" by Robert 
Collins). The sample benchmark Brian presents consists of a single 
database table, and three transactions. He demonstrates how to 
create and load the table, and shows how a transaction can be 
coded using ODBC. Refer to the archived file README.TXT and 
http://www.benchmarkfactory.com or http://www.csrad.com for more
information. Requires UNZIP/PKUNZIP to extract. 

File: VISUALZ.TXT
Title: A REAL-TIME PERFORMANCE VISUALIZER FOR JAVA
Author: John Whaley and John J. Barton
Keywords:  MAR98    JAVA   JVM    PROFILER
Description: Published source code accompanying the article by 
John Whaley and John J. Barton in which they present a real-time 
performance visualizer which helps you find out where the 
performance bottlenecks in your Java programs. Also see VISUALZ.ZIP.

File: VISUALZ.ZIP
Title: A REAL-TIME PERFORMANCE VISUALIZER FOR JAVA
Author: John Whaley and John J. Barton
Keywords:  MAR98    JAVA   JVM    PROFILER
Description: Unpublished source code and related files 
accompanying the article by John Whaley and John J. Barton in 
which they present a real-time performance visualizer which helps 
you find out where the performance bottlenecks in your Java 
programs. Requires UNZIP/PKUNZIP to extract. 

File: CONTROL.TXT
Title: INTELLIGENT WEB-BASED CONTROL SYSTEMS
Author: Tom Milligan and Steve Coffin
Keywords: MAR98  EMBEDDED SYSTEMS   WORLD WIDE WEB   
Description: Published source code accomanying the article by Tom 
Milligan and Steve Coffin in which they automate a sprinkler 
system using the Embedded Micro Interface Technology (EMIT) 
toolkit, a system for embedding web servers onto embedded devices 
and developing web-based user interfaces. 

File: TRANS.TXT
Title: TRANSPARENT ATL CONTROLS
Author: Tom Armstrong and Mark Nelson
Keywords: MAR98   ACTIVEX   ATL    WORLD WIDE WEB   C++   HTML
Description: Published source code accompanying the article by 
Tom Armstrong and Mark Nelson in which they use Microsoft's 
Active Template Library to build an ActiveX control that displays 
a bitmap with a single transparent color. You can then use the 
control with Internet Explorer, Netscape Navigator, Visual Basic, 
and most other ActiveX containers. Also see TRANS.ZIP.

File: TRANS.ZIP
Title: TRANSPARENT ATL CONTROLS
Author: Tom Armstrong and Mark Nelson
Keywords: MAR98   ACTIVEX   ATL    WORLD WIDE WEB   C++   HTML
Description: Unpublished source code and related files 
accompanying the article by Tom Armstrong and Mark Nelson in 
which they use Microsoft's Active Template Library to build an 
ActiveX control that displays a bitmap with a single transparent 
color. You can then use the control with Internet Explorer, 
Netscape Navigator, Visual Basic, and most other ActiveX 
containers. Requires UNZIP/PKUNZIP to extract.

File: CALMACST.ZIP
Title: SOURCE-CODE PROFILERS FOR WIN32
Author: Ron van der Wal
Keywords: MAR98  WIN32   PROFILERS  C++
Description: Unpublished source code accompanying the article by 
Ron van der Wal in which he examines profiling tools that target 
Win32 C/C++ development. These tools include Intel's VTune, 
Microsoft's Visual C++ 5.0 profiling tools, Rational's Visual 
Quantify, TracePoint's HiProf, Watcom's C++ 11.0 tools, and those 
that come with the Win32 SDK. Also see MKDEP.ZIP. Requires 
UNZIP/PKUNZIP to extract.

File: MKDEP.ZIP
Title: SOURCE-CODE PROFILERS FOR WIN32
Author: Ron van der Wal
Keywords: MAR98  WIN32   PROFILERS  C++
Description: Unpublished source code accompanying the article by 
Ron van der Wal in which he examines profiling tools that target 
Win32 C/C++ development. These tools include Intel's VTune, 
Microsoft's Visual C++ 5.0 profiling tools, Rational's Visual 
Quantify, TracePoint's HiProf, Watcom's C++ 11.0 tools, and those 
that come with the Win32 SDK. Also see CALMACST.ZIP. Requires 
UNZIP/PKUNZIP to extract.

File: NTDD.TXT
Title: WINDOWS NT DEVICE DRIVER TOOLKITS
Author: Patrick Tennberg
Keywords:  MAR98    WINDOWS NT    DEVICE DRIVERS
Description: Published source code accompanying the article by 
Patrick Tennberg in which he examines the BlueWater System WinDK 
and Vireo Software Driver::Works toolkits for developing Windows 
NT device drivers. Also see NTDD.ZIP. 

File: NTDD.ZIP
Title: WINDOWS NT DEVICE DRIVER TOOLKITS
Author: Patrick Tennberg
Keywords:  MAR98    WINDOWS NT    DEVICE DRIVERS
Description: Unpublished source code and related files 
accompanying the article by Patrick Tennberg in which he examines 
the BlueWater System WinDK and Vireo Software Driver::Works 
toolkits for developing Windows NT device drivers. Requires 
UNZIP/PKUNZIP to extract.

Title: JAVABJ.ZIP
Author: Kelvin Nilsen
Keywords: MAR98   JAVA   EMBEDDED SYSTEMS
Description: Unpublished source-code examples accompanying the 
article by Kelvin Nilsen in which he discusses picoPERC, a small-
footprint Java implementation for embedded systems. Kelvin builds 
a Black Jack program using picoPERC to illustrate its use. 
Requires UNZIP/PKUNZIP to extract.

Title: CPRG398.TXT
Author: Al Stevens
Keywords: MAR98   C++
Description: Published source-code examples accompanying the 
article by Al Stevens in which launches a new project this month-
-the C++ Persistent Template Library, which adds persistence to 
containers. Also see PTL1.ZIP.

Title: PTL1.ZIP
Author: Al Stevens
Keywords: MAR98   C++
Description: Unpublished source-code examples accompanying the 
article by Al Stevens in which launches a new project this month-
-the C++ Persistent Template Library, which adds persistence to 
containers. Requires UNZIP/PKUNZIP to extract.

File: JQ&A398.TXT 
Title: JAVA Q&A
Author: Govind Seshadri 
Keywords: MAR98  JAVA   CALLBACKS   RMI
Description: Published source code accompanying the article by 
Govind Seshadri in which he examines the intricacies of enabling 
true peer-to-peer Java RMI interaction. He then presents a step-
by-step approach to implementing callbacks. 

File: VERCHECK.TXT 
Title: VERCHECK: DISCOVERING COMPONENT VERSION NUMBERS
Author: John Graham-Cumming
Keywords: MAR98    WIN32   VERSION CONTROL
Description: Published source code accompanying the article by 
John Graham-Cumming in which he presents a utility for listing 
the versions of all the components of relevance to your program.
Also see VERCHECK.ZIP.

File: VERCHECK.ZIP
Title: VERCHECK: DISCOVERING COMPONENT VERSION NUMBERS
Author: John Graham-Cumming
Keywords: MAR98    WIN32   VERSION CONTROL
Description: Executable version of the VerCheck utility which is 
the focus of the article by John Graham-Cumming. The utility provides
a list of the versions of all the components of relevance to your program.
Requires UNZIP/PKUNZIP to extract.
