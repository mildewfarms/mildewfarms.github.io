August 1998
Dr. Dobb's Journal 
 
File:  CPPINTR.TXT
Title: C++ INTERFACES
Author: Fred Wild
Keywords: AUG98   C++
Description: Published source code accompanying the article by 
Fred Wild in which he discusses "interfaces," which provide a 
convenient means of resolving the tension between what a class is 
and what it can do. Keeping interface and implementation separate 
in C++ programs keeps designs clean and fosters reuse. Also see 
CPPINTR.ZIP.

File:  CPPINTR.ZIP
Title: C++ INTERFACES
Author: Fred Wild
Keywords: AUG98   C++
Description: Unpublished source code accompanying the article by 
Fred Wild in which he discusses "interfaces," which provide a 
convenient means of resolving the tension between what a class is 
and what it can do. Keeping interface and implementation separate 
in C++ programs keeps designs clean and fosters reuse. Requires 
UNZIP/PKUNZIP to extract.

File: NOTIFIER.TXT
Title: C++ NOTIFIERS
Author: Dave Pomerantz
Keywords:  AUG98   C++
Description: Published source code accompanying the article by 
Dave Pomerantz in which he discusses "notifiers" (also called 
"events" or "messages") which are used to pass information 
anonymously between objects. Dave shows notifiers can work in 
C++, using a multithreaded application as an example. Also see 
NOTIFIER.ZIP.

File: NOTIFIER.ZIP
Title: C++ NOTIFIERS
Author: Dave Pomerantz
Keywords:  AUG98   C++
Description: Unpublished source code and related files 
accompanying the article by Dave Pomerantz in which he discusses 
"notifiers" (also called "events" or "messages") which are used 
to pass information anonymously between objects. Dave shows 
notifiers can work in C++, using a multithreaded application as 
an example. Requires UNZIP/PKUNZIP to extract.

File: SERIAL.ZIP
Title: OBJECT SERIALIZATION FOR C++ & JAVA
Author: Kevin Haverlock
Keywords:  AUG98  C++   JAVA
Description: Unpublished source files accompanying the article by 
Kevin Haverlock in which he presents a technique for exchanging 
data between Java and C++ using object serialization over a 
TCP/IP sockets connection. Requires UNZIP/PKUNZIP to extract.

File: REGISTER.TXT
Title: SELF-REGISTERING OBJECTS IN C++
Author: Jim Beveridge 
Keywords:  AUG98  C++
Description: Published source code and related files 
accompanying the article by Jim Beveridge in which he presents 
the "speciality store" that lets new classes be registered at run 
time, even if they live in a shared library or DLL. Once 
registered, these new classes are treated exactly like built-in 
classes. Also see REGISTER.ZIP.

File: REGISTER.ZIP
Title: SELF-REGISTERING OBJECTS IN C++
Author: Jim Beveridge 
Keywords:  AUG98  C++
Description: Unpublished source code and related files 
accompanying the article by Jim Beveridge in which he presents 
the "speciality store" that lets new classes be registered at run 
time, even if they live in a shared library or DLL. Once 
registered, these new classes are treated exactly like built-in 
classes. Requires UNZIP/PKUNZIP to extract.

File: LOCALES.TXT
Title: C++ LOCALES
Author: Nathan Myers
Keywords: AUG98     C++     INTERNATIONALIZATION
Description: Published source code accompanying the article by by 
Nathan Myers in which he discusses a feature of the Standard C++ 
library that supports internationalization is "locale"--where 
programs run and how they relate to user needs.

File: CPDQ.TXT
Title: C PREPROCESSING WITH TCL
Author: Jonathan Arney
Keywords: AUG98    C    TCL
Description: Published source code accompanying the article by 
Jonathan Arney in which he presents CPDQ, a utility that uses Tcl 
for more sophisticated preprocessing than CPP. CPDQ's C API makes 
it easy both to extend the language and embed the interpreter 
into other applications. Also see CPDQ.ZIP.

File: CPDQ.ZIP
Title: C PREPROCESSING WITH TCL
Author: Jonathan Arney
Keywords: AUG98    C    TCL
Description: Unpublished source code accompanying the article by 
Jonathan Arney in which he presents CPDQ, a utility that uses Tcl 
for more sophisticated preprocessing than CPP. CPDQ's C API makes 
it easy both to extend the language and embed the interpreter 
into other applications. Requires UNZIP/PKUNZIP to extract.

File: CEBUILD.TXT
Title: THE WINDOWS CE BUILD PROCESS
Author: Aspi Havewala
Keywords: AUG98   WINDOWS CE   EMBEDDED SYSTEMS
Description: Published source code accompanying the article by 
Aspi Havewala in which he shows how you can pick and choose among 
Windows CE components to build a "custom" version of Windows CE. 

File: EMBEDCPP.TXT
Title: EMBEDDED DEVELOPMENT COMPILERS
Author: Don Hair and Cesar Quiroz
Keywords: AUG98   C++   EMBEDDED SYSTEMS
Description: Published source code accompanying the article by 
Don Hair and Cesar Quiroz in which they examine the differences 
between native and embedded development systems, and discuss the 
features of embedded development compilers that make them 
different from native compilers.

File: ROUTER.ZIP
Title: FAST IP ROUTING WITH LC-TRIES
Author: Stefan Nilsson and Gunnar Karlsson
Keywords: AUG98    ROUTING   INTERNET 
Description: Unpublished source code and related files 
accompanying the article by Stefan Nilsson and Gunnar Karlsson in 
which they show how to perform the lookups efficiently with a 
simple data structure--a level-compressed trie. Requires 
UNZIP/PKUNZIP to extract.

File: ACTIVE.TXT
Title: THE ACTIVE EXPRESSIONS LIBRARY
Author: Mauricio de Simone and Gregory V. Wilson
Keywords: AUG98   C++    PARALLEL PROGRAMMING
Description: Source code accompanying the article by Mauricio de 
Simone and Gregory V. Wilson in which they describe the Active 
Expressions library, which combines the conciseness and 
checkability of language extensions with the portability and 
extensibility of a library. Also see ACTIVE.ZIP.

File: ACTIVE.ZIP
Title: THE ACTIVE EXPRESSIONS LIBRARY
Author: Mauricio de Simone and Gregory V. Wilson
Keywords: AUG98   C++    PARALLEL PROGRAMMING
Description: A *very* alpha implementation of the Active 
Expression library described in the article by Mauricio de Simone 
and Gregory V. Wilson. The Active Expressions library combines 
the conciseness and checkability of language extensions with the 
portability and extensibility of a library. Requires 
UNZIP/PKUNZIP to extract.

File: MFCPLUG.TXT
Title: PLUG-IN COMPONENTS FOR MFC
Author: by Stefan Hoenig
Keywords: AUG98    MFC    C++
Description: Published source code accompanying the article by 
Stefan Hoenig in which he presents a technique for encapsulating 
user actions into separate objects that support MFC message maps. 
Also see MFCPLUG.ZIP.

File: MFCPLUG.ZIP
Title: PLUG-IN COMPONENTS FOR MFC
Author: by Stefan Hoenig
Keywords: AUG98    MFC    C++
Description: Unpublished source code and related files 
accompanying the article by Stefan Hoenig in which he presents a 
technique for encapsulating user actions into separate objects 
that support MFC message maps. Requires UNZIP/PKUNZIP to extract.

File: JQA898.TXT 
Title: JAVA Q&A
Author: Cliff Berg
Keywords: AUG98   JAVA    SECURITY     ENCRYPTION
Description: Published source code accompanying the article by 
Cliff Berg in which he shows how you can use encryption to 
protect data at its point of origin or destination. Also see 
JQA898.ZIP.

File: JQA898.ZIP
Title: JAVA Q&A
Author: Cliff Berg
Keywords: AUG98   JAVA    SECURITY     ENCRYPTION
Description: Unpublished source code accompanying the article by 
Cliff Berg in which he shows how you can use encryption to 
protect data at its point of origin or destination. Requires 
UNZIP/PKUNZIP to extract.

File: AA898.TXT
Title: ALGORITHM ALLEY 
Author: Sergei Savchenko
Keywords: AUG98   ALGORITHMS   DATABASE    
Description: Published source code accompanying the column by 
Sergei Savchenko in which he discusses mathematical algorithms 
known as "automated theorem provers" which efficiently resolve 
database queries. Also see AA898.ZIP.

File: AA898.ZIP
Title: ALGORITHM ALLEY 
Author: Sergei Savchenko
Keywords: AUG98   ALGORITHMS   DATABASE    
Description: Unpublished source code and examples accompanying 
the column by Sergei Savchenko in which he discusses mathematical 
algorithms known as "automated theorem provers" which efficiently 
resolve database queries. Requires UNZIP/PKUNZIP to extract.


