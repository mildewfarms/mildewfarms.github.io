March 1988 
Dr. Dobb's Journal 

MATHEWS.LST
Threaded Binary Trees 
by James Mathews

CHALK.LST
Self-Adjusting Data Structure 
by Andrew Chalk

KRUTE.LST
To the Macs
by Stan Krute 

PORTER.LST
Structured Programming Column 
by Kent Porter