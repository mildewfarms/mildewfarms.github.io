February 2000  
Dr. Dobb's Journal   
  
File: GJ.TXT  
Title: GJ: A GENERIC JAVA
Author: Philip Wadler
Keywords: FEB00     JAVA    GENERIC PROGRAMMING
Description: Published source code accompanying the article by Philip Wadler in
which he presents GJ, short for "Generic Java," which adds generic types to the
Java language. GJ is compatible with Java, the Java Virtual Machine, and
existing libraries. It is also efficient, in that information about generic
types is maintained only at compile time, not run time. 
  
File: JSDT.TXT
Title: COLLABORATIVE APPLICATIONS AND THE JAVA SHARED DATA TOOLKIT
Author: Joshua Fox
Keywords: FEB00     JAVA   DISTRIBUTED COMPUTING
Description: Published source code accompanying the article by Joshua Fox in
which he discusses the Java Shared Data Toolkit which is designed to help you
write distributed collaborative applications so that groups of users can work
simultaneously on a common task. Also see JSDT.ZIP.
 
File: JSDT.ZIP
Title: COLLABORATIVE APPLICATIONS AND THE JAVA SHARED DATA TOOLKIT
Author: Joshua Fox
Keywords: FEB00     JAVA   DISTRIBUTED COMPUTING
Description: Unpublished source code and related files accompanying the article
by Joshua Fox in which he discusses the Java Shared Data Toolkit which is
designed to help you write distributed collaborative applications so that groups
of users can work simultaneously on a common task. Requires UNZIP/PKUNZIP to
extract.   

File: JREFER.TXT   
Title: JAVA REFERENCES
Author: Jonathan Amsterdam
Keywords: FEB00     JAVA   MEMORY MANAGEMENT
Description: Published source code accompanying the article by Jonathan
Amsterdam in which he explains how Java references work, and presents some
useful abstractions that make working with them easier.
 
File:  PSP2.TXT 
Title: PYTHON SERVER PAGES: PART II 
Author: Kirby W. Angell
Keywords: FEB00    PYTHON   ASP    JAVA   SCRIPTING
Description: Published source code accompanying the article by  Kirby Angell in
which he discusses Python Server Pages (PSP) is a server-side scripting engine
designed along the lines of Microsoft's Active Server Pages (ASP) and Sun's Java
Server Pages (JSP) specification. 
  
File: LITJAVA.TXT  
Title: JAVA, XML, & LITERATE PROGRAMMING
Author: Andrew Dwelly
Keywords:  FEB00   JAVA   XML   LITERATE PROGRAMMING
Description: Published source code accompanying the article by Andrew Dwelly in
which he presents Marius, a system which implements some of Donald Knuth's ideas
about literate programs, but uses Java as its programming language, with HTML as
the output. In the process, Marius leverages the power of XML. Also see
LITJAVA.ZIP.

File: LITJAVA.ZIP
Title: JAVA, XML, & LITERATE PROGRAMMING
Author: Andrew Dwelly
Keywords:  FEB00   JAVA   XML   LITERATE PROGRAMMING
Description: Unpublished source code and related files accompanying the article
by Andrew Dwelly in which he presents Marius, a system which implements some of
Donald Knuth's ideas about literate programs, but uses Java as its programming
language, with HTML as the output. This archive includes the Weave and Comb
programs. In the process, Marius leverages the power of XML. Requires
UNZIP/PKUNZIP to extract. 

File: OCFJAVA.TXT
Title: OPENCARD FRAMEWORK APPLICATION DEVELOPMENT
Author: Vesna Hassler and Oliver Fodor
Keywords: FEB00  JAVA   SMARTCARD   WIN32
Description: Published source code accompanying the article by Vesna Hassler and
Oliver Fodor in which they discuss the Personal Computer/Smart Card Interface
(PC/SC) and OpenCard Framework, which emphasize the interoperability of
smartcards and card terminals, and the integration of those card terminals into
Microsoft Windows. Also see OCFJAVA.ZIP.

File: OCFJAVA.ZIP
Title: OPENCARD FRAMEWORK APPLICATION DEVELOPMENT
Author: Vesna Hassler and Oliver Fodor
Keywords: FEB00  JAVA   SMARTCARD   WIN32
Description: Unpublished source code and related files accompanying the article
by Vesna Hassler and Oliver Fodor in which they discuss the Personal
Computer/Smart Card Interface (PC/SC) and OpenCard Framework, which emphasize
the interoperability of smartcards and card terminals, and the integration of
those card terminals into Microsoft Windows. Requires UNZIP/PKUNZIP to extract. 

File: RTJAVA.TXT
Title: THE REAL-TIME SPECFICIATION FOR JAVA
Author: David Hardin
Keywords: FEB00   JAVA   REAL-TIME
Description: Published source code accompanying the article by David Hardin in
which he discusses the Real-Time Specification for Java which promises to bring
the benefits of Java to real-time software developers. David examines the
requirements and design decisions that led to the Real-Time Specification for
Java, as well as provide practical examples of its use.

File: WEBRELAY.TXT
Title: WEBRELAY: A MULTITHREADED HTTP RELAY SERVER
Author: Peter Zhang 
Keywords: FEB00  JAVA   HTTP    SERVER
Description: Published source code accompanying the article by Peter Zhang in
which he presents Webrelay, a freely available multithreaded HTTP relay server
which authenticates that clients are legitimate users before they are connected
to vendors' webservers. Also see WEBRELAY.ZIP.

File: WEBRELAY.ZIP
Title: WEBRELAY: A MULTITHREADED HTTP RELAY SERVER
Author: Peter Zhang 
Keywords: FEB00  JAVA   HTTP    SERVER
Description: Unpublished source code and related files accompanying the article
by Peter Zhang in which he presents Webrelay, a freely available multithreaded
HTTP relay server which authenticates that clients are legitimate users before
they are connected to vendors' webservers. Requires UNZIP/PKUNZIP to extract. 

File: VISIOVIZ.TXT
Title: VISUALIZING NETWORK RESOURCES USING VISIO
Author: Chris Trueman
Keywords: FEB00   VISIO   SIMULATION   NETWORKS
Description: Published source code accompanying the article by Chris Trueman in
which he examines Visio, a generic diagram construction tool that just happens
to include a powerful visualization engine. Chris uses that engine to write a
C++ tool that generates diagrams to represent all the available resources on a
Windows network. Also see VISIOVIZ.ZIP.

File: VISIOVIZ.ZIP
Title: VISUALIZING NETWORK RESOURCES USING VISIO
Author: Chris Trueman
Keywords: FEB00   VISIO   SIMULATION   NETWORKS
Description: Unpublished source code and related files accompanying the article
by Chris Trueman in which he examines Visio, a generic diagram construction tool
that just happens to include a powerful visualization engine. Chris uses that
engine to write a C++ tool that generates diagrams to represent all the
available resources on a Windows network. Requires UNZIP/PKUNZIP to extract. 

File: JQA220.TXT   
Title: JAVA Q&A  
Author: Ethan Henry and Ed Lycklama 
Keywords: FEB00   JAVA     MEMORY MANAGEMENT
Description: Published source code accompanying the article by Ethan Henry and
Ed Lycklama in which they show what you can do when Java exhibits classic memory
leak behavior--unbounded memory growth leading to poor performance and
eventually crashing. 

File: AA220.TXT 
Title: ALGORITHM ALLEY  
Author: Michael J. Wiener
Keywords: FEB00   ALGORITHM    RSA   OPTIMIZATION   SECURITY
Description: Published source code accompanying the article by Michael Wiener in
which he presents some key optimizations (with source code examples) that can be
made to make RSA algorithm as fast as possible.
 
File: CPROG220.TXT
Title: C PROGRAMMING 
Author: Al Stevens 
Keywords: FEB00   C++    C   INTERPRETER
Description: Published source code accompanying the column by Al Stevens in
which he implements the S interpreter in C++.

File: SI.ZIP
Title: C PROGRAMMING
Author: Al Stevens
Keywords: FEB00   C++    C   INTERPRETER
Description: Unpublished source code and related files accompanying the
column by Al Stevens in which he implements the S interpreter in C++.
Requires UNZIP/PKUNZIP to extract.








2


