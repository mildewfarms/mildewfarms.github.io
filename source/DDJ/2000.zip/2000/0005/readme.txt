May 2000  

Dr. Dobb's Journal   

  

File: VOYEUR.TXT

Title: A WIN32 NETWORK CRAWLER

Author: Jawed Karim 

Keywords: MAY00     NETWORK   MP3    LAN   WIN32

Description: Published source code accompanying the article by Jawed Karim in which he discusses MP3 Voyeur, a freely-available Win32 program that automates the task of finding MP3 files on the shared folders of local area networks. It works like a network crawler, querying each computer on the network and traversing each computer's hierarchy of shared folders to find MP3 files. Also see VOYEUR.ZIP.



File: VOYEUR.ZIP

Title: A WIN32 NETWORK CRAWLER

Author: Jawed Karim 

Keywords: MAY00     NETWORK   MP3    LAN   WIN32

Description: Unpublished source code and related files accompanying the article by Jawed Karim in which he discusses MP3 Voyeur, a freely-available Win32 program that automates the task of finding MP3 files on the shared folders of local area networks. It works like a network crawler, querying each computer on the network and traversing each computer's hierarchy of shared folders to find MP3 files. Requires UNZIP/PKUNZIP to extract.



File: LDAPSRCH.TXT

Title: LDAP SEARCH FILTERS

Author: Marcelo A. F. Calbucci

Keywords: MAY00     LDAP   FILTERS   NETWORK

Description: Published source code accompanying the article by Marcelo A. F. Calbucci in which he examines the Lightweight Directory Access Protocol (LDAP) transport mechanism for Directory Service transactions. Marcelo focuses on the search filter that's part of LDAP search functionality. Also see LDAPSRCH.ZIP.



File: LDAPSRCH.ZIP

Title: LDAP SEARCH FILTERS

Author: Marcelo A. F. Calbucci

Keywords: MAY00     LDAP   FILTERS   NETWORK

Description: Unpublished source code and related files accompanying the article by Marcelo A. F. Calbucci in which he examines the Lightweight Directory Access Protocol (LDAP) transport mechanism for Directory Service transactions. Marcelo focuses on the search filter that's part of LDAP search functionality. Requires UNZIP/PKUNZIP to extract. 

  

File: GUTENBG.TXT

Title: MARGINATION AND PROJECT GUTENBERG

Author: William Fishburne

Keywords:  MAY00     PROJECT GUTENBERG   TEXT FORMATTING

Description: Published source code accompanying the article  by William Fishburne in which he discusses Project Gutenberg and some unusual requirements on the margins of the lines. Also see GUTENBG.ZIP.



File: GUTENBG.ZIP

Title: MARGINATION AND PROJECT GUTENBERG

Author: William Fishburne

Keywords:  MAY00     PROJECT GUTENBERG   TEXT FORMATTING

Description: Unpublished source code and related files accompanying the article by William Fishburne in which he discusses Project Gutenberg and some unusual requirements on the margins of the lines. Requires UNZIP/PKUNZIP to extract. 



File: PS_CPU.TXT

Title: PREDICATION, SPECULATION, & MODERN CPUs

Author: Andrew Chasin

Keywords: MAY00  CPU  COMPILER

Description: Published source code accompanying the article 

by Andrew Chasin in which he examines the topics of predication and speculation which are viable techniques for improving software performance, and the emerging class of processors and compilers are supporting it. 



File: INFRARED.TXT

Title: INFRARED CONTROL OF YOUR PC

Author: Gavin Smyth

Keywords: MAY00  INFRARED   WIRELESS   REMOTE CONTROL

Description: Published source code accompanying the article by Gavin Smyth in which he shows how you can remotely control your PC like other consumer electronic devices using infrared devices. Also see INFRARED.ZIP.



File: INFRARED.ZIP

Title: INFRARED CONTROL OF YOUR PC

Author: Gavin Smyth

Keywords: MAY00  INFRARED   WIRELESS   REMOTE CONTROL

Description: Unpublished source code and other files accompanying the article by Gavin Smyth in which he shows how you can remotely control your PC like other consumer electronic devices using infrared devices. Requires UNZIP/PKUNZIP to extract. 



File: CECESH.TXT

Title: WINDOW CE'S CESH UTILITY

Author: Andrew Tucker

Keywords: MAY00   WINDOWS CE

Description: Published source code accompanying the article by Andrew Tucker in which he examines CESH, a utility included with the Windows CE development tools. CESH lets you automate test suites to download and run on a device, while logging results on the desktop machine. Also see CECESH.ZIP.



File: CECESH.ZIP

Title: WINDOW CE'S CESH UTILITY

Author: Andrew Tucker

Keywords: MAY00   WINDOWS CE

Description: Unpublished source code and related files accompanying the article by Andrew Tucker in which he examines CESH, a utility included with the Windows CE development tools. CESH lets you automate test suites to download and run on a device, while logging results on the desktop machine. Requires UNZIP/PKUNZIP to extract. 



File: FCAST.ZIP

Title: SCALABLE MULTICAST FILE DISTRIBUTION 

Author: Jim Gemmell

Keywords: MAY00   INTERNET     MULTICAST   VBSCRIPT    HTML

Description: Unpublished source code and related files accompanying the article by Jim Gemmell. FCast, the file distribution mechanism Jim presents here, uses IP multicast and forward error correction (FEC) to serve extremely large numbers of clients with minimal loads for servers and networks. Requires UNZIP/PKUNZIP to extract. 



File: JQA500.TXT

Title: JAVA Q&A  

Author: David Reilly

Keywords: MAY00   JAVA     SERVLETS

Description: Published source code accompanying the 

article by David Reilly in which he shows how you use Servlets for state and session management.



File: JQA500.ZIP

Title: JAVA Q&A  

Author: David Reilly

Keywords: MAY00   JAVA     SERVLETS

Description: Unpublished source code and related files accompanying the 

article by David Reilly.



File: AA500.ZIP

Title: ALGORITHM ALLEY  

Author: by Moheb Missaghi

Keywords: MAY00   ALGORITHM    C  JAVA

Description: Unpublished source code and related files accompanying the article by Moheb Missaghi in which presents and implements an algorithm that determines how many ISP subscribers should share a modem. Requires UNZIP/PKUNZIP to extract. 















3





