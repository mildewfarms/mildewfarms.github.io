April 2000  
Dr. Dobb's Journal   
  
File: MC.TXT
Title: MONTE CARLO METHODS 
Author: Matthew Ginsberg
Keywords: APR00     ALGORITHM    BRIDGE    GAMES   
SIMULATION
Description: Published source code accompanying the 
article by Matthew Ginsberg in which he discuses GIB, a 
Bridge program he wrote, that is a worthy competitor to 
championship play. Matt focuses on the Monte Carlo 
methods used in the program.

File: FASTSORT.TXT
Title: THE FASTEST SORTING ALGORITHM?
Author: Stefan Nilsson
Keywords: APR00     SORTING   ALGORITHM
Description: Published source code accompanying the 
article by Stefan Nilsson in which he presents his 
solution to the question "Which sorting algorithm is 
the fastest?" Also see FASTSORT.ZIP.
 
File: FASTSORT.ZIP
Title: THE FASTEST SORTING ALGORITHM?
Author: Stefan Nilsson
Keywords: APR00     SORTING   ALGORITHM
Description: Unpublished source code and related files 
accompanying the article by Stefan Nilsson in which he 
presents his solution to the question "Which sorting 
algorithm is the fastest?" Requires UNZIP/PKUNZIP to 
extract. 
  
File: MAG.TXT  
Title: AN EFFICIENT ALGORITHM FOR MAGNITUDE OPERATION
Author: S. Manivannan
Keywords:  APR00     ALGORITHM    DSP
Description: Published source code accompanying the 
article by S. Manivannan in which he discusses 
magnitude operation, which is widely used in signal and 
data processing for signal detection and power 
estimation, including systems such as real-time 
displays for sensors, radars, sonars, and scanners for 
medical imaging systems.

File: FILTER.TXT
Title: DIGITAL FILTERING AND OVERSAMPLING
Author: Jim Ledin
Keywords: APR00  REAL-TIME   DIGITAL FILTERS   
ALGORITHM
Description: Published source code accompanying the 
article by Jim Ledin in which he examines digital 
filtering, which can provide higher overall system 
performance and reduce circuit complexity. Jim examines 
the technique of oversampling, which can be used to 
gain these seemingly contradictory benefits. Also see 
FILTER.ZIP.

File: FILTER.ZIP
Title: DIGITAL FILTERING AND OVERSAMPLING
Author: Jim Ledin
Keywords: APR00  REAL-TIME   DIGITAL FILTERS   
ALGORITHM
Description: Unpublished source code and related files 
accompanying the article by Jim Ledin in which he 
examines digital filtering, which can provide higher 
overall system performance and reduce circuit 
complexity. Jim examines the technique of oversampling, 
which can be used to gain these seemingly contradictory 
benefits. Requires UNZIP/PKUNZIP to extract. 

File: LORE.TXT
Title: LORE: A DATABASE MANAGEMENT SYSTEM FOR XML
Author: Roy Goldman, Jason McHugh, Jennifer Widom
Keywords: APR00   XML   DMBS   SQL
Description: Published source code accompanying the 
article by Roy Goldman, Jason McHugh, and Jennifer 
Widom in which they discuss Lore, a DBMS designed 
specifically for XML. In the same way that SQL queries 
relational DBMSs, Lore provides the query language 
Lorel for issuing expressive queries over XML data. 

File: PYGTK.TXT
Title: EXAMINING THE PYGTK TOOLKIT
Author: Mitch Chapman and Brian Kelley 
Keywords: APR00   PYTHON   TCL   GUI 
Description: Published source code accompanying the 
article by Mitch Chapman and Brian Kelley in which they 
discuss PyGtk, which brings the benefits of a high-
level programming language to Gtk+ developers, and 
gives Python programmers access to a modern, high-
performance GUI toolkit. Also see PYGTK.ZIP.

File: PYGTK.ZIP
Title: EXAMINING THE PYGTK TOOLKIT
Author: Mitch Chapman and Brian Kelley 
Keywords: APR00   PYTHON   TCL   GUI 
Description: Unpublished source code and related files 
accompanying the article by Mitch Chapman and Brian 
Kelley in which they discuss PyGtk, which brings the 
benefits of a high-level programming language to Gtk+ 
developers, and gives Python programmers access to a 
modern, high-performance GUI toolkit. Requires 
UNZIP/PKUNZIP to extract. 

File: JQA400.TXT
Title: JAVA Q&A  
Author: John Motil and David Epstein 
Keywords: APR00   JAVA     JJ
Description: Published source code accompanying the 
article by John Motil and David Epstein in which they 
discuss JJ, a Java implementation originally designed 
as a educational programming language and environment. 
Although a subset of Java, JJ includes advanced 
programming features such as support for Design by 
Contract.

File: AA400.TXT 
Title: ALGORITHM ALLEY  
Author: Jon Bentley
Keywords: APR00   ALGORITHM    CACHING
Description: Published source code accompanying the 
article by Jon Bentley in which he examines caching, 
which often works well, but sometimes fails utterly. In 
this column, Jon examines why that happens, and what 
you can do about it.





3


