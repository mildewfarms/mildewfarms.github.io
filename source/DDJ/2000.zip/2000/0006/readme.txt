June 2000  
Dr. Dobb's Journal   
  
File: STATEPAT.TXT
Title: STATE PATTERNS & C++
Author: Julian MaCri
Keywords: JUN00     C++   OBJECT-ORIENTED    PATTERNS
Description: Published and unpublished source code accompanying the article by Julian Macri, in which he uses C++ to implement State patterns two different ways. 

File: XMLJAVA.TXT
Title: XML, REFLECTIVE PATTERN MATCHING, AND JAVA
Author: Andrew Dwelly
Keywords: JUN00     PATTERN MATCHING   JAVA   XML
Description: Published source code accompanying the article by Andrew Dwelly in which he presents Hex, a relatively simple program that is still powerful enough to perform some very sophisticated processing of XML documents. Also see MARIUS05.ZIP.

File: MARIUS05.ZIP
Title: XML, REFLECTIVE PATTERN MATCHING, AND JAVA
Author: Andrew Dwelly
Keywords: JUN00     XML   PATTERN MATCHING    JAVA
Description: Unpublished source code for the MARIUS system, a set of programs that accepts as input an XML source document containing Java code. One of the programs, Comb, extracts the Java and reassembles it into files that can be compiled. For more information, see "Java, XML, & Literate Programming" (dDJ, February 2000). Requires UNZIP/PKUNZIP to extract.

File: PERLOOUI.TXT
Title: AN OBJECT-ORIENTED UI FOR PERL
Author: Robert Kiesling
Keywords: JUN00     PERL    UI   OBJECT-ORIENTED
Description: Published source code accompanying the article by 
Robert Kiesling in which he shows one way Perl's features can contribute to it's usefulness in object-oriented projects. Also see WORKSP.ZIP.

File: WORKSP.ZIP
Title: AN OBJECT-ORIENTED UI FOR PERL
Author: Robert Kiesling
Keywords: JUN00     PERL    UI   OBJECT-ORIENTED
Description: Unpublished source code accompanying the article by 
Robert Kiesling in which he shows one way Perl's features can contribute to it's usefulness in object-oriented projects. Requires UNZIP/PKUNZIP to extract. 
  
File: WIN32VER.TXT
Title: WIN32 VERSION CONTROL
Author: Ping Ni and Mark Nelson
Keywords:  JUN00     WIN32   VERSION CONTROL  PERL  C++
Description: Published source code accompanying the article by Ping Ni and Mark Nelson in which they use Perl and C++ to add more power to the Visual Source Safe source-code version control system.

File: OODESIGN.TXT
Title: OBJECT-ORIENTED DESIGN IN PROCEDURAL ENVIRONMENTS
Author: Thomas E. Davis
Keywords: JUN00   DESIGN   PAGER    OBJECT-ORIENTED
Description: Published source code accompanying the article 
by Thomas E. Davis in which he shows how you can apply some of the inherent cleanliness of object-oriented design into your procedural language projects. To illustrate, he designs an application for Motorola's PageWriter two-way pager. 

File: JAVALOAD.TXT
Title: JAVA CUSTOM CLASS LOADERS
Author: Brian Roelofs
Keywords: JUN00    JAVA   LOADER   VM
Description: Published source code accompanying the article by Brian Roelofs in which he discusses how you can create your own class loader to read and load classes into the Java VM from any data source. Also see JAVALOAD.ZIP.

File: JAVALOAD.ZIP
Title: JAVA CUSTOM CLASS LOADERS
Author: Brian Roelofs
Keywords: JUN00    JAVA   LOADER   VM
Description: Unpublished source code and related files accompanying the article by Brian Roelofs in which he discusses how you can create your own class loader to read and load classes into the Java VM from any data source. Requires UNZIP/PKUNZIP to extract. 

File: PARSE.TXT
Title: PARSING COMPLEX TEXT STRUCTURES
Author: by Ian E. Gorman
Keywords: JUN00   PATTERNS    PATTERN MATCHING    SCRIPTING
Description: Published source code accompanying the article by Ian E. Gorman in which he uses the OmniMark pattern language from OmniMark Technologies to do a job that might otherwise be done with tools like lex and yacc. Also see PARSE.ZIP.

File: PARSE.ZIP
Title: PARSING COMPLEX TEXT STRUCTURES
Author: by Ian E. Gorman
Keywords: JUN00   PATTERNS    PATTERN MATCHING    SCRIPTING
Description: Unpublished source code and related files accompanying the article by Ian E. Gorman in which he uses the OmniMark pattern language from OmniMark Technologies to do a job that might otherwise be done with tools like lex and yacc. Requires UNZIP/PKUNZIP to extract. 

File: JQA600.TXT
Title: JAVA Q&A  
Author: Jacob Gsoedl
Keywords: JUN00   JAVA     COM
Description: Published source code accompanying the 
article by Jacob Gsoedl in which he shows how you can implement COM components using Java.

File: AA600.TXT
Title: ALGORITHM ALLEY  
Author: John Keogh
Keywords: JUN00   ALGORITHM   WINDOWING   RESIZING
Description: Published source code accompanying the article by John Keogh in which he presents and implements an algorithm for scaling child windows when the parent is resized. Although the example runs under the Win32 API, the algorithm and data structure are generally useful for scaling child windows on other platforms. Also see AA600.ZIP.

File: AA600.ZIP
Title: ALGORITHM ALLEY  
Author: John Keogh
Keywords: JUN00   ALGORITHM   WINDOWING   RESIZING
Description: Unpublished source code and related files accompanying the article by John Keogh in which he presents and implements an algorithm for scaling child windows when the parent is resized. Although the example runs under the Win32 API, the algorithm and data structure are generally useful for scaling child windows on other platforms. Requires UNZIP/PKUNZIP to extract. 




3


