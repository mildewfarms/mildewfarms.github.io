January 2000    
Dr. Dobb's Journal     
    
File: PNUTS.TXT    
Title: SCRIPTING FOR PNUTS  
Author: John H. McCoy  
Keywords: JAN00     JAVA   SCRIPTING   
Description: Published source code accompanying the article by   
John H. McCoy in which he examines Pnuts--a language, API, and   
interpreter that provides a thin procedural wrapper with an   
interactive interface for manipulating Java objects. Also see   
PNUTDEMO.ZIP.   
    
File: PNUTDEMO.ZIP   
Title: Title: SCRIPTING FOR PNUTS  
Author: John H. McCoy  
Keywords: JAN00     JAVA   SCRIPTING   
Description: Unpublished source code accompanying the article by   
John H. McCoy in which he examines Pnuts--a language, API, and   
interpreter that provides a thin procedural wrapper with an   
interactive interface for manipulating Java objects. Requires   
UNZIP/PKUNZIP to extract.   
  
File:   
Title: REBOL.TXT
Author: Michael Swaine  
Keywords: JAN00     REBOL   SCRIPTING   INTERNET  
Description: Published source code accompanying the article by    
Michael Swaine in which he looks at Rebol. Michael found it is   
easier to use than many other scripting tools, and the kinds of   
tasks it makes easy are those involving Internet programming.  
   
File: DSELECT.TXT     
Title: A DYNAMIC SELECT COMPONENT FOR JAVASCRIPT  
Author: Steve Johnson  
Keywords: JAN00     JAVASCRIPT   GUI   COMPONENTS  
Description: Published source code accompanying the article by   
Steve Johnson in which he uses Javascript to design a GUI   
component in Javascript. Also see DSELECT.ZIP.   
   
File: DSELECT.ZIP  
Title: A DYNAMIC SELECT COMPONENT FOR JAVASCRIPT  
Author: Steve Johnson  
Keywords: JAN00     JAVASCRIPT   GUI   COMPONENTS  
Description: Unpublished source code accompanying the article by   
Steve Johnson in which he uses Javascript to design a GUI   
component in Javascript. Requires UNZIP/PKUNZIP to extract.     
   
File:  PSP1.TXT   
Title: PYTHON SERVER PAGES: PART 1  
Author: Kirby W. Angell  
Keywords: JAN00    PYTHON   ASP    JAVA   SCRIPTING  
Description: Published source code accompanying the article by    
Kirby Angell in which he discusses Python Server Pages (PSP) is a   
server-side scripting engine designed along the lines of   
Microsoft's Active Server Pages (ASP) and Sun's Java Server Pages   
(JSP) specification. Also see PSP100.JAR. 
 
File:  PSP100.JAR   
Title: PYTHON SERVER PAGES: PART 1  
Author: Kirby W. Angell  
Keywords: JAN00    PYTHON   ASP    JAVA   SCRIPTING  
Description: Unpublished source code accompanying the article by    
Kirby Angell in which he discusses Python Server Pages (PSP) is a   
server-side scripting engine designed along the lines of   
Microsoft's Active Server Pages (ASP) and Sun's Java Server Pages   
(JSP) specification. PSP requires that your web server support Java  
Servlets. If your web server does not support servlets natively (most  
don't) then you might try JRun from Live Software.  PSP has been tested  
extensively with JRun on the Solaris, Linux, and Windows 98/NT platforms  
using the Netscape, Apache, andInternet Information Server. 
 
File: FLEXSCRP.TXT    
Title: TOOLS FOR FLEXIBLE SCRIPTING  
Author: Sergei Savchenko  
Keywords:  JAN00   C++   SCRIPTING   DATABASES  
Description: Published source code accompanying the article by   
Sergi Savenchenko in which he presents flexible tools for creating   
scripting languages. Also see FLEXSCRP.ZIP.   
  
File: FLEXSCRP.ZIP  
Title: TOOLS FOR FLEXIBLE SCRIPTING  
Author: Sergei Savchenko  
Keywords:  JAN00   C++   SCRIPTING   DATABASES  
Description: Unpublished source code accompanying the article by   
Sergi Savenchenko in which he presents flexible tools for creating   
scripting languages. Also see FLEXSCRP.ZIP.   
   
File: PALMEURO.ZIP   
Title: EC: A EURO CALCULATOR FOR THE PALM PLATFORM  
Author: Michael Yam  
Keywords:  JAN00   PALM   C/C++  PORTABILITY  MACINTOSH   WIN32  
Description: Unpublished source code accompanying the article by    
Michael Yam in which he presents the EC Euro calculator for the   
Palm platform. Requires UNZIP/PKUNZIP to extract.   
    
File: ECOS.TXT  
Title: ECOS: AN OPERATING SYSTEM FOR EMBEDDED SYSTEMS  
Author: Gary Thomas  
Keywords: JAN00  EMBEDDED SYSTEMS  OPEN SOURCE   REAL-TIME  
Description: Published source code accompanying the article by   
Gary Thomas in which he discusses the Embedded Configurable   
Operating System (ECOS) is a royalty-free, open source, real-time   
kernel, targeted at high-performance small embedded systems. As   
such, eCos has been specifically designed and tuned to run on 32-   
and 64-bit microprocessors.   
  
File: JUKEBOX.TXT  
Title: THE ULTIMATE HOME JUKEBOX  
Author: Charlie Munro and Mark Nelson  
Keywords: JAN00   MP3   DATABASE   JAVASCRIPT   
Description: Published source code accompanying the article by   
Charlie Munro and Mark Nelson in which they describe how they used   
MP3 to encode and store on hard disk nearly 300 audio CDs, then   
networked the music server to create the ultimate home jukebox.   
  
File: PERLCOM.TXT  
Title: EXAMINING PERLCOM  
Author: Mike McMillan  
Keywords: JAN00  PERL   DATABASE   VISUAL BASIC  
Description: Published source code accompanying the article by   
Mike McMillan in which he examines PerlCOM, from O'Reilly &   
Associates, which lets you use Perl in any language or application   
that supports Microsoft Component Object Model (COM) objects. Mike   
shows you how to use it to extend Visual Basic.  
  
File: JQA120.TXT     
Title: JAVA Q&A    
Author: Michael Travers  
Keywords: JAN00   JAVA     SCRIPTING   SCHEME  
Description: Published source code accompanying the article by    
Michael Travers in which he looks at interactive scripting and   
Java Michael presents Skij, an interactive scripting language for   
the Java environment.   
   
File: AA120.TXT   
Title: ALGORITHM ALLEY    
Author: Timothy Rolfe  
Keywords: JAN00   ALGORITHM    SHUFFLING    RANDOM  
Description: Published source code accompanying the article by   
Timothy Rolfe in which he examines a couple of "randomizing"   
algorithms--one that does not generate all permutations with equal   
probability, and another that does.    
   
File: AA120.ZIP  
Title: ALGORITHM ALLEY    
Author: Timothy Rolfe  
Keywords: JAN00   ALGORITHM    SHUFFLING    RANDOM  
Description: Unpublished source code accompanying the article by   
Timothy Rolfe in which he examines a couple of "randomizing"   
algorithms--one that does not generate all permutations with equal   
probability, and another that does. Requires UNZIP/PKUNZIP to   
extract.   
   
File: CPROG120.ZIP   
Title: C PROGRAMMING   
Author: Al Stevens   
Keywords: JAN00   C++  FRAMEWORK   
Description: Unpublished source code to the file TESTGL.ZIP which   
accompanies the column by Al Stevens in which he continues to   
build a C++-based generic, platform-independent graphics. This   
month, he an ellipse shape to the library implemented as a   
template class in ellipse.h. Requires UNZIP/PKUNZIP to extract.   
   
3  
  

