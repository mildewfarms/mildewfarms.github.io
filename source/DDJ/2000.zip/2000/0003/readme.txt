March 2000  
Dr. Dobb's Journal   
  
File: WBOXTEST.TXT  
Title: WHITE-BOX TESTING
Author: Oliver Cole
Keywords: MAR00     SOFTWARE TESTING
Description: Published source code accompanying the article by Oliver Cole in
which he examines white-box testing strategies, which include designing tests
such that every source line of code is executed at least once, and requiring
every function to be individually tested.  

File: DBGMULTI.TXT
Title: DEBUGGING MULTITHREADED APPLICATIONS
Author: Peter Horwood, Shlomo Wygodny, and Martin Zardecki
Keywords: MAR00     DEBUGGING   MULTITASKING
Description: Published source code accompanying the article by Peter Horwood,
Shlomo Wygodny, and Martin Zardecki, in which they describe problems with
multithreaded applications and discuss common debugging techniques. 
 
File: TESTPONT.TXT
Title: BUILDING A TESTPOINT FRAMEWORK
Author: Noam Cohen 
Keywords: MAR00     SOFTWARE TESTING   
Description: Published source code accompanying the article by Noam Cohen in
which he presents a framework for creating and using testpoints. He originally
designed and implemented this framework while developing VideoClick, a video
distribution and management system. Also see TESTPONT.ZIP.
 
File:  TESTPONT.ZIP
Title: BUILDING A TESTPOINT FRAMEWORK
Author: Noam Cohen 
Keywords: MAR00     SOFTWARE TESTING   
Description: Unpublished source code and related files accompanying the article
by Noam Cohen in which he presents a framework for creating and using
testpoints. He originally designed and implemented this framework while
developing VideoClick, a video distribution and management system. Requires
UNZIP/PKUNZIP to extract. 
  
File: RECURS.TXT  
Title: CONSIDERING RECURSION
Author: Arch D. Robison
Keywords:  MAR00   RECURSION
Description: Published source code accompanying the article by Arch D. Robison
in which he examines some of the problems with recursion, including entangled
control flow, which hurts readability, reuse, and optimization.

File: RTLINUX.TXT
Title: INSIDE REAL-TIME LINUX
Author: Jerry Epplin
Keywords: MAR00  REAL-TIME   LINUX
Description: Published source code accompanying the article by Jerry Epplin in
which he examines Real-Time Linux. To illustrate how you can use RTLinux, Jerry
presents a data-acquisition application. Also see RTLINUX.ZIP.

File: RTLINUX.ZIP
Title: INSIDE REAL-TIME LINUX
Author: Jerry Epplin
Keywords: MAR00  REAL-TIME   LINUX
Description: Unpublished source code accompanying the article by Jerry Epplin in
which he examines Real-Time Linux. To illustrate how you can use RTLinux, Jerry
presents a data-acquisition application. Requires UNZIP/PKUNZIP to extract. 

File: NETPERF.TXT
Title: MEASURING NETWORK SOFTWARE PERFORMANCE
Author: James K. Yun
Keywords: MAR00   NETWORKING    PERFORMANCE   NETPERF
Description: Published source code accompanying the article by James K. Yun in
which he examines the network performance measurement techniques that especially
useful in projects where the network interface is encapsulated in a class
library or network middleware. Also see NETPERF.ZIP.

File: NETPERF.ZIP
Title: MEASURING NETWORK SOFTWARE PERFORMANCE
Author: James K. Yun
Keywords: MAR00   NETWORKING    PERFORMANCE   NETPERF
Description: Unpublished source code accompanying the article by James K. Yun in
which he examines the network performance measurement techniques that especially
useful in projects where the network interface is encapsulated in a class
library or network middleware. Requires UNZIP/PKUNZIP to extract.

File: SOURCEMONITOR.ZIP
Title: SOURCEMONITOR: EXPOSING YOUR CODE
Author: James F. Wanner
Keywords: MAR00    SOURCE CODE METRICS   C++    WIN32
Description: Unpublished source code accompanying the article by James F. Wanner
in which he presents SourceMonitor, a programmer's metrics tool that he wrote to
expose the size and quality of his source code. To parse source code, Jim used
Sandstone's Visual Parse++; to create reports, he turned to Stingray's Objective
Chart. Requires UNZIP/PKUNZIP to extract. Also see SOURCEMONITORV0163.EXE.

File: SOURCEMONITORV0163.EXE
Title: SOURCEMONITOR: EXPOSING YOUR CODE
Author: James F. Wanner
Keywords: MAR00    SOURCE CODE METRICS   C++    WIN32
Description: Executable program the article by James F. Wanner in which he
presents SourceMonitor, a programmer's metrics tool that he wrote to expose the
size and quality of his source code. To parse source code, Jim used Sandstone's
Visual Parse++; to create reports, he turned to Stingray's Objective Chart.
Self-extracting zip archive. Also see SOURCEMONITOR.ZIP.

File: JQA300.TXT
Title: JAVA Q&A  
Author: Mike Jennings
Keywords: MAR00   JAVA     NT   
Description: Published source code accompanying the article by Mike Jennings in
which he shows how to write NT services in Java. Also see JQA300.ZIP.

File: JQA300.ZIP
Title: JAVA Q&A  
Author: Mike Jennings
Keywords: MAR00   JAVA     NT   
Description: Unpublished source code and related files accompanying the article
by Mike Jennings in which he shows how to write NT services in Java. Requires
UNZIP/PKUNZIP to extract. 

File: AA300.TXT 
Title: ALGORITHM ALLEY  
Author: Mingfu Gong
Keywords: MAR00   ALGORITHM    SORTING
Description: Published source code accompanying the article by Mingfu Gong in
which he examines group sorting algorithms, which are well-suited for
applications where recursion is either not allowed or inefficient. Mingfu
presents an N*logN adaptive group sort algorithm.










