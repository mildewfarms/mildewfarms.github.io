October 1996
Dr. Dobb's Journal

MIDELPHI.ASC
Title: MULTIPLE INHERITANCE FOR DELPHI
Keywords: OCT96   DELPHI    UI  OOP   INHERITANCE
Published source code examples accompanying Roland Kaufmann's 
article on providing multiple inheritance for Borland's Delphi 
2.0 development environment. Also see MIDELPHI.ZIP

MIDELPHI.ZIP
Title: MULTIPLE INHERITANCE FOR DELPHI
Keywords: OCT96   DELPHI    UI  OOP   INHERITANCE
Complete source code examples accompanying Roland Kaufmann's 
article on providing multiple inheritance for Borland's Delphi 
2.0 development environment. Requires PKUNZIP.EXE or UNZIP.EXE to 
extract.

VISITOR.ASC
Title: EXTENDING THE VISITOR DESIGN PATTERN
Keywords: OCT96    OOP   PATTERNS   C++
Published source code accompanying Matthew Nguyen's article on 
extending the Gamma/Helm Visitor design pattern. Matthew extends 
the Visitor pattern by adding conditional intelligence. 

DSOM.ASC
Title: COMPONENT OBJECTS AND DISTRIBUTED COMPUTING 
Keywords: OCT96    C++   OS/2   DSOM    COMPONENT   
DISTRIBUTED COMPUTING
Published source code accompanying the article by Jeff Rush on 
interoperable, component objects for distributed computing. Jeff 
uses IBM's SOM to create desktop objects for the OS/2 Workplace 
Shell that use Distributed SOM (DSOM) to invoke methods on remote 
objects--implemented in C++. Also see DSOM.ZIP.

DSOM.ZIP
Title: COMPONENT OBJECTS AND DISTRIBUTED COMPUTING 
Keywords: OCT96    C++   OS/2   DSOM    COMPONENT   
DISTRIBUTED COMPUTING
Complete code accompanying the article by Jeff Rush on 
interoperable, component objects for distributed computing. Jeff 
uses IBM's SOM to create desktop objects for the OS/2 Workplace 
Shell that use Distributed SOM (DSOM) to invoke methods on remote 
objects--implemented in C++. Requires PKUNZIP.EXE or UNZIP.EXE to 
extract.

CPPPER.ASC
Title: PERSISTENCE FOR C++
Keywords: OCT96    C++    OOP   PERSISTENCE   DATABASE
Published source code accompanying the article by David Channon
on persistent objects are data elements that can live after the 
program which created them has stopped. David implements a 
persistent layer for C++, which does not include persistence as a 
language feature. 

ATM.ASC
Title: ATM SOFTWARE ANALYSIS AND DESIGN
Keywords: OCT96      ATM    C++    NETWORK
Published source code accompanying Derek Cheung's article where 
he examines how you can apply OMT for analyzing and developing 
software for a simple Asynchronous Transfer Mode (ATM) switch. 

LABOBJX.ASC
Title: EXAMINING THE LABOBJX REAL-TIME CHART CONTROL
Keywords: OCT96   VISUAL BASIC   WINDOWS    REAL-TIME   VBX
Published source code accompanying the article by Jonathan 
Williams in which he develops the GUI for a real-time monitoring 
system that can display up to five channels at one time, allow 
users to scroll through large data sets, and more. He selected 
Scientific Software Tools' LabOBJX Real-Time Chart, a custom 
control (VBX) that can be used with Visual Basic, C++, and 
Delphi. 

AA1096.ASC
Title: ALGORITHM ALLEY
Keywords: OCT96     ALGORITHMS     NUMERICS   OOP
Published source code in the article by Dann Corbit in which he 
approximates the value of an integral is an important kind of 
calculation that's not nearly as you think. Dann shows how simple 
it is to get good results, then discusses some new techniques 
that offer even better accuracy. Also see AA1096.ZIP.

AA1096.ZIP
Title: ALGORITHM ALLEY
Keywords: OCT96     ALGORITHMS     NUMERICS   OOP
Complete source code in the article by Dann Corbit in which he 
approximates the value of an integral is an important kind of 
calculation that's not nearly as you think. Dann shows how simple 
it is to get good results, then discusses some new techniques 
that offer even better accuracy. Requires PKUNZIP.EXE or 
UNZIP.EXE to extract.

UD1096.ASC
Title: UNDOCUMENTED CORNER
Keywords: OCT96     
Published source code accompanying the Undocumented Corner column 
by Scot Wingo and George Shepherd Understanding how drag-and-drop 
works at the Common Object Model (COM) level and how MFC 
implements drag-and-drop illustrates the power of COM, 
underscoring the kinds of things you can do by programming in 
COM.  

JAVAQ&A.ASC
Title: JAVA Q&A COLUMN
Keywords: OCT96   JAVA     NETSCAPE     FILE FORMAT
Published source code accompanying Cliff Berg's column on how you 
can display media formats that Netscape does not support. 
Also see JAVAQ&A.ZIP.

JAVAQ&A.ZIP
Title: JAVA Q&A COLUMN
Keywords: OCT96   JAVA   NETSCAPE     FILE FORMAT
Unpublished source code accompanying Cliff Berg's column on how you 
can display media formats that Netscape does not support. 
Requires PKUNZIP 2.0 or UNZIP.EXE to extract.

CPROG.ASC
Title: C PROGRAMMING COLUMN  
Keywords: OCT96  C   C++   WINDOWS 95   INSTALL
Published source code accompanying Al Stevens column on topics 
ranging from Setup versus Uninstall programs, Registry versus 
.INI files, and the Kevorkian algorithm. He then returns to 
MidiFitz, a MIDI program that reads an 88-key keyboard, parses 
the notes into chords in real time, and plays a matching bass 
line. 

