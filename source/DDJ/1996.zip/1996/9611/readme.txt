November 1996
Dr. Dobb's Journal

SQL.ZIP
Title: OPTIMIZING CLIENT/SERVER DATABASE APPLICATIONS
Keywords: NOV96     SQL   C++    DATABASE   CLIENT/SERVER
Unpublished source code accompanying the article by Gary Bist in 
which he examines two coding methods--the Compound SQL statement 
and stored procedures--to reduce and reuse embedded SQL code to 
increase performance and productivity. Requires PKUNZIP.EXE to 
extract.

SQL.ASC
Title: OPTIMIZING CLIENT/SERVER DATABASE APPLICATIONS
Keywords: NOV96     SQL   C++    DATABASE   CLIENT/SERVER
Published source code examples accompanying the article by Gary Bist in 
which he examines two coding methods--the Compound SQL statement 
and stored procedures--to reduce and reuse embedded SQL code to 
increase performance and productivity. Also see SQL.ZIP.

3TIER.ASC
Title: MIDDLEWARE AND THREE-TIER CLIENT/SERVER DEVELOPMENT
Keywords: NOV96    C++    ORACLE   DATABASE   CLIENT/SERVER   
Published source code accompanying Timothy Carone's article in 
which he develops a three-tier, client/server system, using 
Novell's Tuxedo as the transaction manager, and the Oracle 
Database Server as a resource manager. Also see 3TIER.ZIP.

3TIER.ZIP
Title: MIDDLEWARE AND THREE-TIER CLIENT/SERVER DEVELOPMENT
Keywords: NOV96    C++    ORACLE   DATABASE   CLIENT/SERVER   
Unpublished source code accompanying Timothy Carone's article in 
which he develops a three-tier, client/server system, using 
Novell's Tuxedo as the transaction manager, and the Oracle 
Database Server as a resource manager. Requires PKUNZIP.EXE to extract.

DBPERL.ASC
Title: THE DBPERL RELATIONAL DATABASE API
Keywords: NOV96  PERL   DATABASE  CLIENT/SERVER
Published source code accompanying Perry Scherer's article on 
DBperl, a Perl 5 package which implements a relational database 
API for a variety of database engines, including Oracle, 
Informix, Ingres, Interbase, Postgres, Sybase, and Unify 5.0. 

WAVGL.ASC
Title: SPEECH RESEARCH WITH WAVE-GL
Keywords: NOV96    C++   AUDIO    WAV
Published source code accompanying the 
article by Petra Lutter, Michael Muller-Wernhart, Jurgen 
Ramharter, Frank Rattay, and Peter Slowik, in which they present 
WAVE-GL, short for "Wave Generation Language." WAVE-GL is a 
system designed to generating new sounds from mathematical 
descriptions. Also see WAVGL.ZIP.

WAVGL.ZIP
Title: SPEECH RESEARCH WITH WAVE-GL
Keywords: NOV96    C++   AUDIO    WAV
Unpublished source code and related files that accompany the 
article by Petra Lutter, Michael Muller-Wernhart, Jurgen 
Ramharter, Frank Rattay, and Peter Slowik, in which they present 
WAVE-GL, short for "Wave Generation Language." WAVE-GL is a 
system designed to generating new sounds from mathematical 
descriptions. Requires PKUNZIP.EXE to extract.

SYSTOOL.ASC
Title: INSIDE THE SYSTEM<TOOL> LIBRARY
Keywords: NOV96    C++    CLIENT/SERVER
Published source accompanying Michael Vilot's article in which he 
uses Systems<ToolKit>, a library that builds on the expressive 
foundation of the C++ Standard Library, to develop a pair of 
distributed client/server applications for environments such as 
the Internet. 

AA1196.ASC
Title: ALGORITHM ALLEY
Keywords: NOV96     ALGORITHMS     LISP
Published source code accompanying John Swartz's article in which 
he uses LISP when needing a simple solution to complex 
combination problems.

UD1196.ASC
Title: UNDOCUMENTED CORNER
Keywords: NOV96     PENTIUM      CPUID
Published source code accompanying Robert Collins' column in 
which he presents a processor-detection algorithm that doesn't 
use Intel's CPUID instruction. 

CPROG116.ASC
Title: C PROGRAMMING COLUMN  
Keywords: NOV96  C   C++   WINDOWS 95   
Published source code accompanying Al Stevens column in which he 
builds a Property Page Dialog-based application for Windows 95. 
Also see CPROG116.ZIP

CPROG116.ZIP
Title: C PROGRAMMING COLUMN  
Keywords: NOV96  C   C++   WINDOWS 95   
Unpublished source code and related files accompanying Al Stevens 
column in which he builds a Property Page Dialog-based 
application for Windows 95. Requires PKUNZIP.EXE to extract.

RESTART.ASC
Title: RESTARTING EMBEDDED SYSTEMS
Keywords: NOV96   EMBEDDED SYSTEMS    OPERATING SYSTEMS
Published source code accompanying the article by Fredrik 
Bredberg, Ola Liljedahl, and Bengt Eliasson, in which they 
discuss the OSE RTOS from Enea Data which allows a computer 
system to pick up at exactly the spot where it was before a 
system crash occurred. 

NTNCP.ASC
Title: UNDOCUMENTED WINDOWS NT AND THE NETWARE CORE PROTOCOL
Keywords:  NOV96  WINDOWS NT   NOVELL NCP    UNDOCUMENTED
Published source code accompanying the article by Sven Schreiber 
in which he discusses Windows NT's support of the NetWare client 
API. Sven focuses on undocumented features of the NT NetWare 
redirector to send and receive NetWare Core Protocol (NCP) 
packets. Also see NTNCP.ZIP.

NTNCP.ZIP
Title: UNDOCUMENTED WINDOWS NT AND THE NETWARE CORE PROTOCOL
Keywords:  NOV96  WINDOWS NT   NOVELL NCP    UNDOCUMENTED
Unpublished source code and related files accompanying the 
article by Sven Schreiber in which he discusses Windows NT's 
support of the NetWare client API. Sven focuses on undocumented 
features of the NT NetWare redirector to send and receive NetWare 
Core Protocol (NCP) packets. Includes TABLES.DOC, the NCP 
function-code reference. Requires PKUNZIP.EXE to extract.

JSECURE.ASC
Title: JAVA AND WEB-EXECUTABLE OBJECT SECURITY
Keywords: NOV96  JAVA   SECURITY  APPLET
Unpublished source code example accompanying the article by 
Michael Shoffner and Merlin Hughes. This examples is an applet 
which exploits Java's unprotected execution space. When 
the program runs, it kills all other active applets while protecting 
itself against being killed. (Netscape Navigator 3.0 does not 
solve this problem.) 

