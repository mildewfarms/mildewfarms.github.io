September 1996
Dr. Dobb's Journal

CUSTOPEN.ZIP
Title: CUSTOMIZING THE EXPLORER OPEN DIALOG
Keywords: SEP96   WINDOWS 95    DELPHI    UI
Unpublished source code accompanying Al Williams' article on the 
Windows 95 special open dialog that allows users to rename files, 
create directories, and (of course) open files. Al shows how to 
customize this dialog, using a Delphi 2.0 component. Requires 
PKUNZIP.EXE to extract. Use -d option.

JCHAT.ASC
Title: JAVA, JFACTORY, AND NETWORK DEVELOPMENT
Keywords: SEP96    JAVA   OBJECT-ORIENTED   GUI    WORLD WIDE WEB
VISUAL DEVELOPMENT    AWT    CLIENT/SERVER
Published source code accompanying the article by Eldon Metz in 
which he uses Rogue Wave's JFactory, a cross-platform screen 
painter, prototyper, and code generator for Java, to an Internet-
based client/server Java application. Also see JCHAT.ZIP.

JCHAT.ZIP
Title: JAVA, JFACTORY, AND NETWORK DEVELOPMENT
Keywords: SEP96    JAVA   OBJECT-ORIENTED   GUI    WORLD WIDE WEB
VISUAL DEVELOPMENT    AWT    CLIENT/SERVER
Complete source code accompanying the article by Eldon Metz in 
which he uses Rogue Wave's JFactory, a cross-platform screen 
painter, prototyper, and code generator for Java, to an Internet-
based client/server Java application. Requires PKUNZIP 2.0 to 
extract (long filenames). 

SHAPEWND.ASC
Title: CREATING SHAPED UI OBJECTS
Keywords: SEP96    C++   JAVA    IPC    OBJECT-ORIENTED  SOCKETS
Published source code accompanying Steve Sipes article in which 
he presents CShape, a C++ class that lets you create and manage 
custom windows, custom controls, and shaped dialog boxes. He then 
uses the class to build sticky-note and stellar calculator user 
interfaces. Also see SHAPEWND.ASC.

SHAPEWND.ZIP
Title: CREATING SHAPED UI OBJECTS
Keywords: SEP96    C++   JAVA    IPC    OBJECT-ORIENTED  SOCKETS
Unpublished source code accompanying Steve Sipes article in which 
he presents CShape, a C++ class that lets you create and manage 
custom windows, custom controls, and shaped dialog boxes. He then 
uses the class to build sticky-note and stellar calculator user 
interfaces. Requires PKUNZIP.EXE to extract. Use -d option.

UDGUI.ZIP
Title: WRITING USER-DEFINABLE GUIs
Keywords: SEP96    VISUAL BASIC  
Unpublished source code and data files accompanying Troy A. 
Schauls's article on user-defined screens. This ability is 
possible if you use Visual Basic forms that are created, parsed, 
and compiled into a proprietary format, with only a "system form" 
in the app's executable file. Requires PKUNZIP.EXE to extract.

MINICART.ASC
Title: IMPLEMENTING A WEB SHOPPING CART
Keywords: WORLD WIDE WEB   PERL    UI
Published source code accompanying the article by Chris Baron and 
Bob Weil in which they examine the components of an online 
catalog, focusing on a virtual shopping-cart system and ways 
around the shortcomings of HTTP. They then present an online-
catalog system implemented in Perl. Also see MINICART.ZIP.

MINICART.ZIP
Title: IMPLEMENTING A WEB SHOPPING CART
Keywords: WORLD WIDE WEB   PERL    UI
Complete system accompanying the article by Chris Baron and Bob 
Weil in which they examine the components of an online catalog, 
focusing on a virtual shopping-cart system and ways around the 
shortcomings of HTTP. They then present an online-catalog system 
implemented in Perl. Requires PKUNZIP.EXE to extract.

JTXTEDIT.ASC
Title: THE JAVA ABSTRACT WINDOW TOOLKIT
Keywords: SEP96    JAVA   AWT   GUI   
Published source code examples accompanying Anil Hemrajani's article in 
which he examines the Java Abstract Window Toolkit (AWT), a 
portable GUI class library for developing applications and 
applets. He then builds a text-editor application for Windows 95 
and Solaris, along with an applet for Windows 95. Also see JTXTEDIT.ZIP. 

JTXTEDIT.ZIP
Title: THE JAVA ABSTRACT WINDOW TOOLKIT
Keywords: SEP96    JAVA   AWT   GUI   
Unpublished source code accompanying Anil Hemrajani's article in 
which he examines the Java Abstract Window Toolkit (AWT), a 
portable GUI class library for developing applications and 
applets. He then builds a text-editor application for Windows 95 
and Solaris, along with an applet for Windows 95. Requires 
PKUNZIP 2.0 to extract.

INSTALL.ZIP
Title: EXAMINING THE INSTALLSHIELD SDK EDITION
Keywords:  SEP96   INSTALL    WINDOWS 
Unpublished source code and binaries accompanying Joe Hlavaty's 
article which builds a standardize installation/distribution 
methodolgy using the InstallShield integrated 
installation/distribution program. Requires PKUNZIP.EXE to 
extract. Use -d option.

PGM.ASC
Title: A PROCESS GROUP MANAGER FOR OS-9
Keywords: SEP96  OS-9   REAL-TIME   I/O    EMBEDDED SYSTEM
Source code accompanying Peter C. Dibble's article in 
which he presents a file manager that lets you adapt the OS-9 
real-time operating system's I/O system to provide non-I/O 
services. 

AA996.ZIP
Title: ALGORITHM ALLEY
Keywords: SEP96     ALGORITHMS     
Published source code in the article by Edward Sitarski in which  
Edward overcomes the limitations of variable-length arrays by 
creating a data structure which has fast constant access time 
like an array, but mostly avoids copying elements when it grows. 
He calls this structure a "Hashed-Array Tree" (HAT) because it 
combines some of the features of hash tables, arrays, and trees. 
Requires PKUNZIP.EXE to extract.

UD996.ASC
Title: UNDOCUMENTED CORNER
Keywords: SEP96     PENTIUM    CPU   UNDOCUMENTED 
Published source code accompanying Robert R. Collins's article 
which examines the ways in which your program knows which Intel 
processor is the current system CPU? 

JAVAQ&A.996
Title: JAVA Q&A COLUMN
Keywords: SEP96   JAVA   GUI  LAYOUT MANAGER  AWT
Published source code accompanying Cliff Berg's column on how you 
can write your own Java layout manager when the AWT's won't let 
you build the kind of UI you need. Also see JAVAQ&A.ZIP.

JAVAQ&A.ZIP
Title: JAVA Q&A COLUMN
Keywords: SEP96   JAVA   GUI   LAYOUT MANAGER   AWT
Unpublished source code accompanying Cliff Berg's column on how 
you can write your own Java layout manager when the AWT's won't 
let you build the kind of UI you need. Requires PKUNZIP 2.0 to 
extract.

BWT.ASC
Title: DATA COMPRESSION WITH THE BURROWS-WHEELER TRANSFORM
Keywords: SEP96    DATA COMPRESSION   ALGORITHM
Published examples by Mark R. Nelson in his article which 
examines the Burrows-Wheeler Transform--an algorithm that takes a 
block of data and rearranges it using a sorting algorithm. The 
resulting output block contains exactly the same data elements 
that it started with, differing only in their ordering. 




