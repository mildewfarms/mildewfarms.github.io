April 1989 
Dr. Dobb's Journal 

KIMK.LST   
More Memory for DOS EXEC
by Kim Kokkonen

NICOMAK.LST
SWAP
by Nico Mak

PETERSON.LST
A Memory Allocation Compaction System
by Steve Peterson

STEVENS.LST
C Programming Column
by Al Stevens

PORTER.LST
Graphics Programming Column
by Kent Porter

DUNTEMAN.LST
Structured Programming Column
by Jeff Duntemann

GETTYS.LST.
Implementing the LRU Algorithm
(sidebar to "Demand Paged Virtual Memory" by Kent Dahlgren) 
by Tom Gettys

