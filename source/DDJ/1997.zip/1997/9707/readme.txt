July 1997
Dr. Dobb's Journal

IMPLICIT.TXT
Title: IMPLICIT SURFACES AND REAL-TIME GRAPHICS
Keywords: JUL97    3-D   GRAPHICS   MODELING   
Published source code accompanying the article by Kyle Lussier 
in which he discusses implicit surfaces, which are used in 
molecular modeling, animation, geo-physical systems, weather 
analysis, and the like. They're also at the heart of Silly Space, 
the modeling application Kyle describes here. 

IMAGEPRO.TXT
Title: A MEMORY-CONSTRAINED IMAGE-PROCESSING ARCHITECTURE
Keywords: JUL97    GRAPHICS   IMAGE PROCESSING
Published source code accompanying the article by Mayur Patel in 
which he presents an image-processing architecture that lets you 
control memory consumption for high-performance image processing.
Also see IMAGEPRO.ZIP.

IMAGEPRO.ZIP
Title: A MEMORY-CONSTRAINED IMAGE-PROCESSING ARCHITECTURE
Keywords: JUL97    GRAPHICS   IMAGE PROCESSING
Unpublished source code and related files accompanying the 
article by Mayur Patel in which he presents an image-processing 
architecture that lets you control memory consumption for high-
performance image processing. Requires UNZIP to extract.

RAVEKIT.TXT
Title: RAVEKIT: A PORTABLE 3-D FRAMEWORK
Keywords: JUL97    GRAPHICS  3-D  PORTABLE    CROSS-PLATFORM 
Published source code accompanying the article by Mark Carolan in 
which he presents RaveKit, a general-purpose, cross-platform 
framework that lets you create interactive 3-D environments that 
provide an alternative way of presenting graphical data and 
obtaining user input. Also see RAVEKIT.ZIP.

RAVEWIN.ZIP
Title: RAVEKIT: A PORTABLE 3-D FRAMEWORK
Keywords: JUL97    GRAPHICS  3-D  PORTABLE    CROSS-PLATFORM 
Visual C++ RaveKit project for Win32. Accompanies the article 
by Mark Carolan in which he presents RaveKit, a general-purpose, 
cross-platform framework that lets you create interactive 3-D 
environments that provide an alternative way of presenting 
graphical data and obtaining user input. Requires UNZIP to extract.

RAVEKIT.SEA
Title: RAVEKIT: A PORTABLE 3-D FRAMEWORK
Keywords: JUL97    GRAPHICS  3-D  PORTABLE    CROSS-PLATFORM   MACINTOSH
Complete source code and related file accompanying the article 
by Mark Carolan in which he presents RaveKit, a general-purpose, 
cross-platform framework that lets you create interactive 3-D 
environments that provide an alternative way of presenting 
graphical data and obtaining user input. Requires UNSTUFFIT for the Macintosh
to extract the compressed files.

BLUR.TXT
Title: MOTION BLUR EFFECTS
Keywords: JUL97    GRAPHICS   SPECIAL EFFECTS
Published source code accompanying the article by Tim Wittenberg 
in which he shows you how to alter the appearance of "moving" 
objects by using blurring techniques to add realism and 
excitement to graphic images. 

TREAPS.TXT
Title: TREAPS IN JAVA
Keywords: JUL97   JAVA    DATA STRUCTURES   SEARCH TREES
Published source code accompanying the article by Stefan Nilsson 
in which he discusses "treaps"--the randomized search trees 
discovered by C.R. Aragon and R. Seidel, provides the 
functionality of a general-purpose sorting routine, priority 
queue, hash-table, stack, or standard queue. Stefan shows you how 
to implement treaps in Java. Also see TREAPS.ZIP.

TREAPS.ZIP
Title: TREAPS IN JAVA
Keywords: JUL97   JAVA    DATA STRUCTURES   SEARCH TREES
Unpublished source code accompanying the article by Stefan 
Nilsson in which he discusses "treaps"--the randomized search 
trees discovered by C.R. Aragon and R. Seidel, provides the 
functionality of a general-purpose sorting routine, priority 
queue, hash-table, stack, or standard queue. Stefan shows you how 
to implement treaps in Java. Requires UNZIP to extract.

ATMEL.TXT
Title: PROGRAMMING THE ATMEL AT89C2051
Keywords: JUL97    8051   EMBEDDED SYSTEM    BASIC
Published source code accompanying the article by Dhananjay V. 
Gadre in which he presents a simple programmer for AT89C2051 that 
is hosted on a 8052-based circuit running a BASIC interpreter. He 
then uses the system to build a 12-bit multichannel ADC to 
connect to PCs.

PING.TXT
Title: THREAD POOLS AND SERVER PERFORMANCE
Keywords: JUL97    SERVERS    INTERNET
Published source code accompanying the article by John Calcote in 
which he uses thread pools to improve server performance. Also 
see PING.ZIP.

PING.ZIP
Title: THREAD POOLS AND SERVER PERFORMANCE
Keywords: JUL97    SERVERS    INTERNET
Unpublished source code and related files accompanying the 
article by John Calcote in which he uses thread pools to improve 
server performance. Requires UNZIP to extract.

WAVSPNR.TXT
Title: SOUNDING OFF WITH THE RSX LIBRARY
Keywords: JUL97  AUDIO   3-D   RSX   WAV FILES
Publishes source code accompanying the article by Steve Durham in 
which he examines Intel's Realistic Sound Experience (RSX) library.
Steve presents WaveSpinner, an RSX-based tool that reads a script, 
animates and spatializes all the sounds using RSX, and writes the result 
to a .WAV file. Also see WAVSPNR.ZIP.

WAVSPNR.ZIP
Title: SOUNDING OFF WITH THE RSX LIBRARY
Keywords: JUL97  AUDIO   3-D   RSX   WAV FILES
Complete source code and related files accompanying the article 
by Steve Durham in which he examines Intel's Realistic Sound 
Experience (RSX) library. Steve presents WaveSpinner, an RSX-based 
tool that reads a script, animates and spatializes all the sounds 
using RSX, and writes the result to a .WAV file. Requires
UNZIP to extract.

TECATE.TXT
Title: TECATE AND INTERACTIVE 3-D
Keywords: JUL97     3-D GRAPHICS    WORLD WIDE WEB
Published and unpublished source code accompanying the article by 
Peter D. Kochevar in which he examines Tecate, a system for 
describing animated 3-D scenes and their interaction with end 
users. The Tecate system enables the description of interactive, 
animated 3-D scenes, interfaces to existing applications and data 
sources such as the World Wide Web and remote collaboration.

JQA797.TXT
Title: JAVA Q&A
Keywords: JUL97     JAVA     HTML   MULTILINGUAL    JDK 1.1
Published source code accompanying Cliff Berg's column in which
he implements a multilingual calculate (in German and English) using
the JDK 1.1's multilingual-support features. Also see JQA797.ZIP.

JQA797.ZIP
Title: JAVA Q&A
Keywords: JUL97     JAVA    MULTILINGUAL
Unpublished source code to calculator.java which accompanies 
Cliff Berg's column in which he implements a multilingual calculate 
(in German and English) using the JDK 1.1's multilingual-support 
features. Requires UNZIP to extract.

AA797.TXT
Title: ALGORITHM ALLEY
Keywords: JUL97      3-D   GRAPHICS    VRML
Published source code accompanying the article by Will Schroeder 
and Tom Citriniti in which they discuss how polygon decimation 
algorithms can reduce the number of polygons in a mesh while 
maintaining a good approximation to the original data, leading to 
faster, more realistic 3-D graphics. Will and Tim show how these 
algorithms are used, and create a VRML file that is decimated.


