May 1997
Dr. Dobb's Journal

CABINET.TXT
Title: INSIDE WINDOWS CABINET FILES
Keywords: MAY97     WINDOWS    FILE FORMAT   COMPRESSION
Published source code accompanying the article by Sven B. Schreiber 
about the Windows Cabinet file format, an archive file format for 
compressed installation disks, is used in Office 95, Internet 
Explorer, and MSDN Library CD. Also see CABINET.ZIP.

CABINET.ZIP
Title: DIFFERENTIAL EVOLUTION
Keywords: MAY97     WINDOWS    FILE FORMAT   COMPRESSION
Unpublished source code accompanying the article by Sven B. 
Schreiber about the Windows Cabinet file format, an archive file 
format for compressed installation disks, is used in Office 95, 
Internet Explorer, and MSDN Library CD. Requires PKUNZIP/UNZIP to 
extract because of long filenames.

META2JAV.TXT
Title: CONVERTING WINDOWS METAFILES TO JAVA
Keywords: MAY97    JAVA   WINDOWS     FILE FORMAT
Published source code accompanying the article by Carmen Delessio 
in which he presents a program that converts Microsoft Windows 
Metafile Format (WMF) files into Java source code. The generated 
Java code references classes provided with Sun's JDK.  

JAVADB.TXT
Title: DATABASE MANAGEMENT AND JAVA
Keywords: MAY97  JAVA  C++  DBMS
Published source code accompanying the article by Art Sulger
in which he presents a single a Java class file that provides a 
single interface to multiple file formats. Also see JAVADB.ZIP.

JAVADB.ZIP
Title: DATABASE MANAGEMENT AND JAVA
Keywords: MAY97  JAVA  C++  DBMS
Unpublished source code accompanying the article by Art Sulger
in which he presents a single a Java class file that provides a 
single interface to multiple file formats. Requirews 
PKUNZIP/UNZIP to extract.

ROMSCAN.ZIP
Title: PLUG-AND-PLAY OPTION ROMs AND THE BIOS BOOT SPECIFICATION
Keywords: MAY97   PLUG-N-PLAY    PnP  BIOS   
Unpublished source code accompanying the article by Tom Roden and 
Scott Townsend in which  they discuss the PnP BIOS Specification 
which ushers in the notion of boot priority, making multiple boot 
devices a reality. In examining the Boot Specification, Tom and 
Scott examine a PnP OPROM data structure called the "$PnP 
Header." Requires UNZIP/PKUNZIP to extract.

COOKIES.ZIP
Title: JAVASCRIPT COOKIES
Keywords: MAY97   JAVASCRIPT  JAVA   COOKIES   
Unpublished source code accompanying the article by Charles B. 
Tichenor in which he discusses the JavaScript document cookie 
which enables browser-side persistence. The JavaScript methods 
Charles describes lets you create web pages with long-term 
memory, pages that replace CGI scripts, or pages that communicate 
with each other. Requires UNZIP/PKUNZIP to extract.

OBJFF.TXT
Title: OBJECT FILE FORMATS
Keywords: MAY97    OBJECT FILES   COFF   IEEE695  FILE FORMATS
Published source code accompanying the article by Rand Gray and 
Deepak Mulchandani in which they discuss object files, which 
provide a concise and efficient representation for a compiled 
application, providing all the information needed to represent 
the state of the entire application at a point in time. In 
particular, they explore the structure the COFF and IEEE695 
object file formats.

NTPRTCTL.TXT
Title: WINDOWS NT PRINTER CONTROL
Keywords: MAY97    WINDOWS NT   PRINTER    NETWORKS
Published source code accompanying the article by Paul Trout
in which he examines Windows NT network printing mechanisms, 
explains how to move a print job from one printer to another, and 
present a function library to perform this and other tasks. Also 
see NTPRTCTL.ZIP

NTPRTCTL.ZIP
Title: WINDOWS NT PRINTER CONTROL
Keywords: MAY97    WINDOWS NT   PRINTER    NETWORKS
Unpublished source code accompanying the article by Paul Trout
in which he examines Windows NT network printing mechanisms, 
explains how to move a print job from one printer to another, and 
present a function library to perform this and other tasks. 
Requires UNZIP/PKUNZIP to extract.

TAWK.TXT
Title: EXAMINING THE TAWK COMPILER
Keywords: MAY97   AWK    SCRIPTING    COMPILERS
Published source code accompanying the article by James K. 
Lawless in which he examines Thompson Automation's "TAWK" 
compiler family. This is a set of compilers--based on the AWK 
languages--for UNIX, OS/2, Windows 95/NT, and Solaris. Jim finds 
TAWK to be a powerful programming tool, particularly when you use 
it as scripting tool to quickly implement batch-oriented 
software. Also see TAWK.zip

TAWK.ZIP
Title: EXAMINING THE TAWK COMPILER
Keywords: MAY97   AWK    SCRIPTING    COMPILERS
Unpublished source code accompanying the article by James K. 
Lawless in which he examines Thompson Automation's "TAWK" 
compiler family. This is a set of compilers--based on the AWK 
languages--for UNIX, OS/2, Windows 95/NT, and Solaris. Jim finds 
TAWK to be a powerful programming tool, particularly when you use 
it as scripting tool to quickly implement batch-oriented 
software. Requires UNZIP/PKUNZIP to extract.

CUSTAPPW.TXT
Title: EXTENDING VISUAL C++
Keywords: MAY97   VISUAL C++   C++   DLL  WINDOWS 95/NT
Published source code examples accompanying the article by John 
Roberts in which he shows how you to create a custom AppWizard, 
using as an example a custom AppWizard to create extension DLLs 
to the Microsoft Exchange e-mail client (also known as the 
"Windows 95 Inbox"). Also see CUSTAPPW.ZIP.

CUSTAPPW.ZIP
Title: EXTENDING VISUAL C++
Keywords: MAY97   VISUAL C++   C++   DLL  WINDOWS 95/NT
Published source code accompanying the article by John 
Roberts in which he shows how you to create a custom AppWizard, 
using as an example a custom AppWizard to create extension DLLs 
to the Microsoft Exchange e-mail client (also known as the 
"Windows 95 Inbox"). Requires PKUNZIP/UNZIP to extract.

AA597.TXT
Title: ALGORITHM ALLEY
Keywords: MAY97     SPLINES   GRAPHICS   ALGORITHMS
Published source code accompanying the article by Robert F. 
Kauffmann in which he shows how trigonometric functions can be 
used to create spline curves that are in many ways superior to 
the more common cubic splines. Also see AA597.ZIP.

AA597.ZIP
Title: ALGORITHM ALLEY
Keywords: MAY97     SPLINES   GRAPHICS   ALGORITHMS
Unpublished source code accompanying the article by Robert F. 
Kauffmann in which he shows how trigonometric functions can be 
used to create spline curves that are in many ways superior to 
the more common cubic splines. Requires PKUNZIP/UNZIP to extract.

CPR0G597.TXT
Title: C PROGRAMMING
Keywords: MAY97   C++   C++BUILDER
Published source code accompanying Al Stevens column in which he 
examines Borland's C++Builder. Also see CPROG597.ZIP.

CPR0G597.ZIP
Title: C PROGRAMMING
Keywords: MAY97   C++   C++BUILDER
Unpublished source code accompanying Al Stevens column in which 
he examines Borland's C++Builder. Requires PKUNZIP/UNZIP to 
extract.

JQA597.TXT
Title: JAVA Q&A
Keywords: MAY97     JAVA    MARIMBA    PUSH
Published source code accompanying Cliff Berg's column in which 
he implements "push" technology using Marimba's Castanet toolset.
Also see JQA597.ZIP.

JQA597.ZIP
Title: JAVA Q&A
Keywords: MAY97     JAVA    MARIMBA    PUSH
Unpublished source code accompanying Cliff Berg's column in which 
he implements "push" technology using Marimba's Castanet toolset.
Requires PKUNZIP/UNZIP to extract.

UD597.TXT
Title: UNDOCUMENTED CORNER
Keywords: MAY96   PENTIUM
Published source code accompanying the column by Robert R. 
Collins in which he continues his examination of the Pentium's 
System Management Mode, this month discussing the caveats of SMM 
and details that you have never gleaned by reading Intel's 
documentation.  




