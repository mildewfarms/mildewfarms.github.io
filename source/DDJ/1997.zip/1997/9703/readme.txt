March 1997
Dr. Dobb's Journal

ATCL.TXT
Title: AGENT TCL
Keywords: MAR97     TCL    AGENTS    AI    INTERNET   WEB
Published source code accompanying the article by Robert S. Gray
in which he discusses Agent Tcl, a mobile agent system that 
migrates under its own control from machine to machine in a 
heterogeneous network. 

DAO.TXT
Title: DISTRIBUTED ACTIVE OBJECTS
Keywords: MAR97    OBLIQ     DISTRIBUTED OBJECTS   INTERNET
Published source code accompanying the article by Marc H. Brown 
and Marc A. Najork in which they discuss distributed active 
objects, which communicate with other active objects located on 
different machines across the Internet.

RPCNT.TXT
Title: RPC FOR WINDOWS 95/NT 
Keywords: MAR97   NETWORKING   WINDOWS 95/NT   CLIENT/SERVER
Published source code accompanying the article by Steve Sipe in 
which he discusses Remote Procedure Call programming under 
Windows 95/NT. Also see RPCNT.ZIP.

RPCNT.ZIP
Title: RPC FOR WINDOWS 95/NT 
Keywords: MAR97   NETWORKING   WINDOWS 95/NT   CLIENT/SERVER
Unpublished source code and executables accompanying the article 
by Steve Sipe in which he discusses Remote Procedure Call 
programming under Windows 95/NT. Requires UNZIP/PKUNZIP to
extract.

KERTESY.TXT
Title: KERTESY: A REAL-TIME EVENT-DRIVEN MICROKERNEL
Keywords: MAR97    OPERATING SYSTEM   REAL-TIME    DSP
Published source code accompanying the article by B. Sain and 
Timothy A. Gonsalves in which they present "Kertesy," a real-time 
microkernel for embedded systems designed around Analog Devices' 
ADSP-21xx series of digital-signal processors. Also see 
KERTESY.ZIP.

KERTESY.ZIP
Title: KERTESY: A REAL-TIME EVENT-DRIVEN MICROKERNEL
Keywords: MAR97    OPERATING SYSTEM   REAL-TIME    DSP
Unpublished source code accompanying the article by B. Sain and 
Timothy A. Gonsalves in which they present "Kertesy," a real-time 
microkernel for embedded systems designed around Analog Devices' 
ADSP-21xx series of digital-signal processors. Requires 
UNZIP/PKUNZIP to extract.

WIN32CPP.ZIP
Title: EXAMINING WIN32 C++ COMPILERS
Keywords: MAR97    WINDOWS    C++  
Unpublished source code and executables accompanying the article 
by Ron van der Wal in which he examines C++ compilers for 
creating Win32 executables, including Borland C++, Visual C++, 
Symantec C++, Watcom C++, and VisualAge C++. Requires UNZIP/PKUNZIP 
to extract. Use -d option to maintain directory structure.

VB5AX.TXT
Title: VISUAL BASIC 5 AND ACTIVEX CONTROLS
Keywords: MAR97    VISUAL BASIC    ACTIVEX    WINDOWS
Published source code accompanying the article by Al Williams in 
which he shows how Microsoft's Visual Basic 5 lets you create 
controls as easily as creating form-based applications. 

AA397.TXT
Title: ALGORITHM ALLEY
Keywords: MAR97     C++   HASHING
Published source code accompanying Fred Wild's article on the I-
string mechanism, a hashing mechanism that provides both compact 
storage and fast equality tests. Also see AA397.ZIP.

AA397.ZIP
Title: ALGORITHM ALLEY
Keywords: MAR97     ALGORITHMS       HEAPS 
Unpublished source code accompanying Fred Wild's article on the 
I-string mechanism, a hashing mechanism that provides both 
compact storage and fast equality tests. Requires UNZIP/PKUNZIP
to extract.

CPROG397.TXT
Title: C PROGRAMMING COLUMN  
Keywords: MAR97  C   C++   WINDOWS     COMMUNICATIONS
Published source code accompanying Al Stevens column in which he
develops a data-scope program called "DScope." Al focuses on the 
Windows communications API. Also see CPROG397.ZIP.

CPROG397.ZIP
Title: C PROGRAMMING COLUMN  
Keywords: MAR97  C   C++   WINDOWS     COMMUNICATIONS
Unpublished source code accompanying Al Stevens column in which 
he develops a data-scope program called "DScope." Al focuses on 
the Windows communications API. Requires UNZIP/PKUNZIP to extract.

JQA397.TXT
Title: JAVA Q&A
Keywords: MAR97  JAVA   CLIENT/SERVER  DISTRIBUTED OBJECTS
Published source code accompanying Cliff Berg's column in which 
he examines the Java Remote Method Invocations API. Also see 
JQA397.ZIP.

JQA397.ZIP
Title: JAVA Q&A
Keywords: MAR97  JAVA   CLIENT/SERVER  DISTRIBUTED OBJECTS
Unpublished source code accompanying Cliff Berg's column in which 
he examines the Java Remote Method Invocations API. Requires 
UNZIP/PKUNZIP to extract.

UD397.TXT
Title: UNDOCUMENTED CORNER
Keywords: MAR96  PENTIUM 
Published source code accompanying Robert R. Collins' column on 
the Pentium state save map, AutoHALT feature, I/O Restart 
feature, and interrupt servicing within system-management mode. 


LETTERS.TXT
Title: LETTERS TO THE EDITOR
Keywords: MAR97   C++
Letters to the editor by Poul Costinsky and Edward Sitarski in 
which they discuss Edward's September 1996 "Algorithm Alley."




