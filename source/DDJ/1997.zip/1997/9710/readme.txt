October 1997
Dr. Dobb's Journal

File: TIMECAST.TXT
Title: INTERNET MULTICASTING
Author: Bob Quinn
Keywords: OCT97    INTERNET   WORLD WIDE WEB   WINSOCK
Description: Published source code accompanying the article by 
Bob Quinn in which he shows how multicasting can let you deliver 
content from a single sender to multiple receivers. Bob uses the 
multicast-enabled WinSock API to present TimeCast, a one-to-many 
application that multicasts the time of day to multiple clients. 
Also see TIMECAST.ZIP.

File: TIMECAST.ZIP
Title: INTERNET MULTICASTING
Author: Bob Quinn
Keywords: OCT97    INTERNET    WORLD WIDE WEB     WINSOCK
Description: Unpublished source code accompanying the article by 
Bob Quinn in which he shows how multicasting can let you deliver 
content from a single sender to multiple receivers. Bob uses the 
multicast-enabled WinSock API to present TimeCast, a one-to-many 
application that multicasts the time of day to multiple clients. 
Requires UNZIP/PKUNZIP to extract.

File: INTRAPP.TXT
Title: JAVA AND INTER-APPLET COMMUNICATION
Author: Andrew Meckler
Keywords: OCT97   JAVA    HTML   
Description: Published source code accompanying the article by 
Andrew Meckler in which he shows you can enable inter-applet 
communication among multiple HTML pages displayed in the browser 
at one time.

File: CIPHER.ZIP
Title: THE BLOCK CIPHER ENCRYPTION ALGORITHM
Author: Joan Daemen, Lars R. Knudsen, Vincent Rijmen
Keywords: OCT97    SECURITY   ENCRYPTION   CIPHER
Description: Unpublished source code accompanying the article 
by Joan Daemen, Lars R. Knudsen, Vincent Rijmen in which they 
present Square, a new fast block cipher that encrypts data in 
blocks of 128 bits, using a 128-bit key. Square's structure has 
been carefully chosen to allow very efficient implementations on 
a wide range of processors. Requires UNZIP/PKUNZIP to extract.

File: WIN32NCP.TXT
Title: WIN32 NETWARE CORE PROTOCOL REVISITED
Author: Sven B. Schreiber
Keywords: OCT97    WIN32    NETWARE   NETWORK    UNDOCUMENTED
Description: Published source code accompanying the article by 
Sven Schreiber in which he examines Microsoft's NetWare clients 
for Windows 95/NT. Sven explores those undocumented NetWare Core 
Protocol and other interfaces. Also see WIN32NCP.ZIP.

File: WIN32NCP.ZIP
Title: WIN32 NETWARE CORE PROTOCOL REVISITED
Author: Sven B. Schreiber
Keywords: OCT97    WIN32    NETWARE   NETWORK    UNDOCUMENTED
Description: Unpublished source code accompanying the article by 
Sven Schreiber in which he examines Microsoft's NetWare clients 
for Windows 95/NT. Sven explores those undocumented NetWare Core 
Protocol and other interfaces. Requires UNZIP/PKUNZIP to extract.

File: SPIN.TXT
Title:THE SPIN MODEL-CHECKING TOOL
Author: Gerard J. Holzmann
Keywords: OCT97    TESTING    PROTOTYPING
Description: Source code accompanying the article  by Gerard 
Holzmann in which he examines Spin, a freely-available software 
package that supports the formal verification of distributed 
systems. Gerard explains how Spin works, and what types of errors 
it can help you find.

File: LUCA.TXT
Title: LUCA: THE LANGNER UNVERISAL COMMUNICATIONS API
Author: Bennett Griffin
Keywords: OCT97    COMMUNICATIONS     C++
Description: Published source code accompanying the article by 
Bennett Griffin in which he uses the Langner Universial 
Communications API (LUCA) to build a portable terminal emulator.

File: EPP.TXT
Title: THE ENHANCED PARALLEL PRINTER PORT
Author: Dhananjay V. Gadre and Larry A. Stein
Keywords: OCT97    ENHANCED PARALLEL PORT    EPP
Description: Published source code accompanying the article by 
Dhananjay V. Gadre and Larry A. Stein in which they discussed the 
Enhanced Parallel Printer Port protocol, which was developed to 
provide a high-performance parallel-port link compatible with 
existing parallel-port peripherals and interfaces. Our authors 
examine this specification, and present routines for implementing 
high-speed digital I/O using EPP BIOS calls. 

File: AUCTION.TXT
Title: BUILDING AND RUNNING ONLINE AUCTIONS
Author: Brent Gorda and Gregory V. Wilson
Keywords: OCT97    WORLD WIDE WEB     HTML
Description: Published code accompanying the by Brent Gorda and 
Gregory V. Wilson in which they describe a web-site toolkit 
called "Webalog" which is being used to construct on-line 
auctions and similar Web-based applications.  

File: CPROG107.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: OCT97    C++   INDEXING
Description: Published source code accompanying the article by Al 
Stevens in which he presents a Windows 95 program that lets you 
create the index to a book or other document quickly and easily. 
Also see INDEXER.ZIP. 

File: INDEXER.ZIP
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: OCT97    C++   INDEXING
Description: Unpublished source code and related files 
accompanying the article by Al Stevens in which he presents a 
Windows 95 program that lets you create the index to a book or 
other document quickly and easily. Requires UNZIP/PKUNZIP to 
extract.

File: JQA1097.TXT
Title: JAVA Q&A
Author: Cliff Berg
Keywords: OCT97      JAVA      SERVLET
Description: Published source code accompanying the column by 
Cliff Berg in which he shows how you can write a Java servlet.
Also see JQA1097.ZIP.

File: JQA1097.ZIP
Title: JAVA Q&A
Author: Cliff Berg
Keywords: OCT97      JAVA      SERVLET
Description: Unpublished source code accompanying the column by 
Cliff Berg in which he shows how you can write a Java servlet.
Requires UNZIP/PKUNZIP to extract.

File: AA107.TXT
Title: ALGORITHM ALLEY
Author: Lynn Monson
Keywords: OCT97      ALGORITHMS    HASH FUNCTIONS 
Description: Source code accompanying the article by Lynn Monson 
in which he shows how to use the ID3 and C4.5 classification 
algorithms with text. The result is a tool that can learn how to 
classify text based on a few examples. Also see AA107.ZIP.

File: AA107.ZIP
Title: ALGORITHM ALLEY
Author: Lynn Monson
Keywords: OCT97      ALGORITHMS    
Description: Unpublished source code accompanying the article by 
Lynn Monson in which he shows how to use the ID3 and C4.5 
classification algorithms with text. The result is a tool that 
can learn how to classify text based on a few examples. Requires 
UNZIP/PKUNZIP to extract.

UD107.TXT
Title: UNDOCUMENTED CORNER
Author: George Shepherd and Scot Wingo
Keywords: OCT97   MFC    WINDOWS CE
Published source code accompanying the column by George Shepherd 
and Scot Wingo in which they examine Visual C++ for Windows CE, a 
VC++ 5.0 add-in, includes its own unique version of MFC--a small 
footprint system called "Mini MFC."  

