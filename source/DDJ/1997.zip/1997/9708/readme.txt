August 1997
Dr. Dobb's Journal

SGISTL.TXT
Title: THE SGI STANDARD TEMPLATE LIBRARY
Keywords: AUG97    STL    C++    SGI
Published source code accompanying the article by Matthew Austern 
in which he examines the Silicon Graphics release of the STL. 

EMPTY.TXT
Title: THE EMPTY MEMBER C++ OPTIMIZATION
Keywords: AUG97    STL   C++
Published source code accompanying the article by Nathan Myers in 
which he asks the question "Although the STL is flexible, does it 
use too much memory?" Nathan shows how the STL--and you--can use 
empty subobjects without bloating your data requirements.

UTHASH.TXT
Title: DESIGNING C++ INTERFACES TO C-LANGUAGE LIBRARIES
Keywords: AUG97    C    C++    HASHING    TEMPLATES
Published source code accompanying the article by Larry E. Baker, 
Jr. in which he presents a C hash-table library and a C++ 
template wrapper that takes it into the world of C++. See 
the subdirectory UTHASH for uncompressed source code and related 
files, and UTHASH.ZIP for compressed versions.

UTHASH.ZIP
Title: DESIGNING C++ INTERFACES TO C-LANGUAGE LIBRARIES
Keywords: AUG97    C    C++    HASHING    TEMPLATES
Unpublished source code accompanying the article by Larry 
Baker, Jr. in which he presents a C hash-table library and a C++ 
template wrapper that takes it into the world of C++. Requires 
UNZIP/PKUNZIP to extract.

OBJECTC.TXT
Title: DYNAMIC DESIGN PATTERNS IN OBJECTIVE-C
Keywords: AUG97    C++   OBJECTIVE-C    PATTERNS
Published source code accompanying the article by William Grosso 
in which he examines patterns often used with Objective-C, but 
not commonly used (or are used differently) with C++. 

JAVANMI.TXT
Title: THE JAVA NATIVE METHOD INTERFACE AND WINDOWS
Keywords: AUG97    JAVA   C++   JNI    WINDOWS
Source code accompanying the article by Andrew Wilson in which he 
examines how the JDK 1.1 implements a native calling convention--
the Java Native Method Interface (JNI)--which makes it possible 
for the stub library to do more than just convert types between 
Java and C++. With JDK 1.1, you can create new instances of Java 
classes, call Java methods, and interact with the VM from within 
the native system library. See the subdirectory JAVANMI for 
uncompressed source code and related files, and JAVANMI.ZIP for 
compressed versions.

JAVANMI.ZIP
Title: THE JAVA NATIVE METHOD INTERFACE AND WINDOWS
Keywords: AUG97    JAVA   C++   JNI    WINDOWS
Unpublished source code and related files accompanying the 
article by Andrew Wilson in which he examines how the JDK 1.1 
implements a native calling convention--the Java Native Method 
Interface (JNI)--which makes it possible for the stub library to 
do more than just convert types between Java and C++. With JDK 
1.1, you can create new instances of Java classes, call Java 
methods, and interact with the VM from within the native system 
library. Requires UNZIP/PKUNZIP to extract.

DAN0411.ZIP
Title: INSIDE THE PENTIUM INTEGER BUG
Keywords: AUG97    PENTIUM    MATH   BUGS
Unpublished source code and executables accompanying the article 
by Robert R. Collins in which he discusses the Dan-0411 math bug 
associated with the Pentium Pro and Pentium II. Requires 
UNZIP/PKUNZIP to extract. See the subdirectory DAN-0411 for 
uncompressed source code and related files.

RCSC.TXT
Title: RETARGETABLE CONCURRENT SMALL C
Keywords: AUG97   C   SMALL C      CONCURRENCY    8051
Published source code accompanying the article by Andy Yuen in 
which he implements "Retargetable CSC" (RCSC), a retargetable 
version of his Concurrent Small C. This port targets the 8051 
microcontroller. See the subdirectory RCSC for uncompressed 
source code and related files, and RCSC.ZIP for compressed versions.

RCSC.ZIP
Title: RETARGETABLE CONCURRENT SMALL C
Keywords: AUG97   C   SMALL C      CONCURRENCY    8051
Complete source code and related files accompanying the article 
by Andy Yuen in which he implements "Retargetable CSC" (RCSC), a 
retargetable version of his Concurrent Small C. This port targets 
the 8051 microcontroller. Requires UNZIP/PKUNZIP to extract.

ISERVER.TXT
Title: WRITING ACTIVEX ISAPI EXTENSIONS
Keywords: AUG97   ACTIVEX   C++   VISUAL BASIC   INTERNET  
Published source code accompanying the article by Al Williams in 
which he discusses how you can use an ISAPI DL to create active 
web pages for Microsoft's Internet Information Server (IIS). Al 
mixes up C++ and Visual Basic to create an ISAPI module that lets 
you write ActiveX ISAPI extensions. See the subdirectory ISERVER for 
uncompressed source code and related files, and ISERVER.ZIP 
for compressed versions.

ISERVER.ZIP
Title: WRITING ACTIVEX ISAPI EXTENSIONS
Keywords: AUG97   ACTIVEX   C++   VISUAL BASIC   INTERNET  
Complete source code and related files accompanying the article 
by Al Williams in which he discusses how you can use an ISAPI DL 
to create active web pages for Microsoft's Internet Information 
Server (IIS). Al mixes up C++ and Visual Basic to create an ISAPI 
module that lets you write ActiveX ISAPI extensions. Requires 
UNZIP/PKUNZIP to extract.

DYNACE.TXT
Title: ADVANCED OBJECT-ORIENTED FEATURES FOR C/C++
Keywords: AUG97    C++   
Published source code accompanying the article by Blake McBride 
in which he presents Dynace, a development tool that to C or C++ 
object-oriented capabilities previously only available in 
languages such as Smalltalk and CLOS--but without the overhead 
normally associated with those environments. See the subdirectory 
DYN401 for uncompressed source code and related files, and 
DYN401.ZIP for compressed versions.

DYN401.ZIP
Title: ADVANCED OBJECT-ORIENTED FEATURES FOR C/C++
Keywords: AUG97    C++   
Complete source code and related files accompanying the article 
by Blake McBride in which he presents Dynace, a development tool 
that to C or C++ object-oriented capabilities previously only 
available in languages such as Smalltalk and CLOS--but without 
the overhead normally associated with those environments. 
Requires UNZIP/PKUNZIP to extract.

CCDBMS.TXT
Title: CONCURRENT DATABASE COMMANDS AND C++
Keywords: AUG97  C++  DBMS    ORACLE   
Published source code accompanying the article by Harold 
Kasperink and John Dekker in which they use Oracle ProC as an 
embedded database command language to resolve multithreaded 
porting problems using design patterns. See the subdirectory 
CCDBMS for uncompressed source code and related files, and 
CCDBMS.ZIP for compressed versions.

CCDBMS.ZIP
Title: CONCURRENT DATABASE COMMANDS AND C++
Keywords: AUG97  C++  DBMS    ORACLE   
Unpublished source code and related files accompanying the 
article by Harold Kasperink and John Dekker in which they 
use Oracle ProC as an embedded database command language to 
resolve multithreaded porting problems using design patterns. 
Requires UNZIP/PKUNZIP to extract.

JQA897.TXT
Title: JAVA Q&A
Keywords: AUG97      JAVA    JAR
Published source code accompanying the column by Cliff Berg in 
which he discusses how to create a JAR file.

AA897.TXT
Title: ALGORITHM ALLEY
Keywords: AUG97      SORTING    ALGORITHMS
Published source code accompanying the article by Jonathan Pincus 
and Jerry Schwarz in which they present a technique for 
topological sorting. See the subdirectory AA897
for uncompressed source code and related files, and 
AA897.ZIP for compressed versions.

AA897.ZIP
Title: ALGORITHM ALLEY
Keywords: AUG97      SORTING    ALGORITHMS
Unpublished source code accompanying the article by Jonathan 
Pincus and Jerry Schwarz in which they present a technique for 
topological sorting. Requires UNZIP/PKUNZIP to extract.

UD897.TXT
Title: UNDOCUMENTED CORNER
Keywords: AUG97   MFC    ATL    VISUAL C++   WINDOWS
Published source accompanying the column by George Shepherd and 
Scot Wingo in which they continue their examination of 
Microsoft's Active Template Library, this month looking at the 
heart of ATL, including its support for multithreading and its 
various implementations of IUnknown.


