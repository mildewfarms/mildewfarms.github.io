April 1997
Dr. Dobb's Journal

DE.TXT
Title: DIFFERENTIAL EVOLUTION
Keywords: APR97     GENETIC ALGORITHMS   NUMERICS   OPTIMIZATION
Published source code accompanying the article by Kenneth Price 
and Rainer Storn that describe one branch of genetic algorithms--
Evolution Strategies--that are significantly faster at numerical 
optimization than traditional genetic algorithms. Also see DE.ZIP.

DE.ZIP
Title: DIFFERENTIAL EVOLUTION
Keywords: APR97     GENETIC ALGORITHMS   NUMERICS   OPTIMIZATION
Unpublished source code accompanying the article by Kenneth Price 
and Rainer Storn that describe one branch of genetic algorithms--
Evolution Strategies--that are significantly faster at numerical 
optimization than traditional genetic algorithms. Requires
PKUNZIP 2.0/UNZIP52/WINZIP95 to extract because of long filenames.

ELS.TXT
Title: A RAPID ENTROPY-CODING ALGORITHM
Keywords: APR97    COMPRESSION   ENTROPY   ALGORITHMS
Published source code accompanying the article by Wm. Douglas 
Withers in which he presents an algorithm for rapid encoding and 
decoding. Also see ELS.ZIP.

ELS.ZIP
Title: A RAPID ENTROPY-CODING ALGORITHM
Keywords: APR97    COMPRESSION   ENTROPY   ALGORITHMS
Unpublished source code and demo programs accompanying the 
article by Wm. Douglas Withers in which he presents an algorithm 
for rapid encoding and decoding. Requires PKUNZIP/UNZIP to extract.

2DDDA.TXT
Title: A 2-D DDA ALGORITHM FOR FAST IMAGE SCALING
Keywords: APR97   GRAPHICS   IMAGE SCALING
Published source code accompanying the article by Dean Clark in 
which he presents an algorithm based on the "digital differential 
analyzer" (DDA) technique but works on 2-D images rather then 1-D 
lines.

JBEANS.TXT
Title: JAVA BEANS AND THE NEW EVENTS MODEL
Keywords: APR97   JAVA   COMPONENTS  JAVA BEANS
Published source code accompanying the article 
by Eric Giguere in which he examines Java Beans, a component 
model for building and using Java-based components. Eric examines 
the Java Beans specification and describes the event model that 
lets you glue components together. Also see JBEANS.ZIP.

JBEANS.ZIP
Title: JAVA BEANS AND THE NEW EVENTS MODEL
Keywords: APR97   JAVA   COMPONENTS  JAVA BEANS
Unpublished source code accompanying the article 
by Eric Giguere in which he examines Java Beans, a component 
model for building and using Java-based components. Eric examines 
the Java Beans specification and describes the event model that 
lets you glue components together. Requires 
PKUNZIP 2.0/UNZIP52/WINZIP95 to extract because of long filenames.

TCL.TXT
Title: BUILDING GRAPHICAL REAL-TIME SYSTEM
Keywords: APR97    REAL-TIME   TCL   GUIs
Published source code accompanying the article by Harry Beker
in which he describes how he uses VME-based distributed embedded 
microprocessors to read data from transparently-interfaced 
instrumentation busses when developing data-acquisition systems 
for high-energy physics experiments. Also see TCL.ZIP.

TCL.ZIP
Title: BUILDING GRAPHICAL REAL-TIME SYSTEM
Keywords: APR97    REAL-TIME   TCL   GUIs
Unpublished source code accompanying the article by Harry Beker
in which he describes how he uses VME-based distributed embedded 
microprocessors to read data from transparently-interfaced 
instrumentation busses when developing data-acquisition systems 
for high-energy physics experiments. Requires PKUNZIP/UNZIP to 
extract.

VALIDATE.TXT
Title: SOFTWARE SECURITY AND THE DIRECTPLAY API
Keywords: APR97    WINDOWS 95   SECURITY   NETWORKS   GAMES
Published source code accompanying the article by Andrew Wilson 
in which he uses the Windows 95 DirectX game SDK to implement 
network-based security measures. Also see VALIDATE.ZIP.

VALIDATE.ZIP
Title: SOFTWARE SECURITY AND THE DIRECTPLAY API
Keywords: APR97    WINDOWS 95   SECURITY   NETWORKS   GAMES
Unpublished source code and related files accompanying the 
article by Andrew Wilson in which he uses the Windows 95 DirectX 
game SDK to implement network-based security measures. 
Requires PKUNZIP 2.0/UNZIP52/WINZIP95 to extract because 
of long filenames. 

QTMM.TXT
Title: QUICKTIME AND CROSS-PLATFORM MULTIMEDIA
Keywords: APR97  CROSS-PLATFORM  MULTIMEDIA   QUICKTIME  
Published source code accompanying the article by Mark Carolan
in which he uses MetroWerks CodeWarrior Gold 10 development 
system to build a cross-platform reusable framework for preparing 
and presenting high-performance multimedia based on Apple's 
QuickTime multimedia engine. Also see QTMM.BIN.

QTMM.BIN
Title: QUICKTIME AND CROSS-PLATFORM MULTIMEDIA
Keywords: APR97  CROSS-PLATFORM  MULTIMEDIA   QUICKTIME  
Unpublished source code and related files accompanying the article 
by Mark Carolan in which he uses MetroWerks CodeWarrior Gold 10 
development system to build a cross-platform reusable framework 
for preparing and presenting high-performance multimedia based on 
Apple's QuickTime multimedia engine. Requires Stuffit for the 
Macintosh to extract.

CHANNEL.TXT
Title: PIPES, CHANNELS, AND PERL-WIN32
Keywords: APR97   PERL   WIN32  
Published source code accompanying the article by Jean-Louis 
Leroy Perl-Win32, HIP Communications' Win32 port of the Perl 
language, provides just the tool Jean-Louis needs to write a 
multifile search-and-replace extension. Also see CHANNEL.ZIP.

CHANNEL.ZIP
Title: PIPES, CHANNELS, AND PERL-WIN32
Keywords: APR97   PERL   WIN32  
Unpublished source code accompanying the article by Jean-Louis 
Leroy Perl-Win32, HIP Communications' Win32 port of the Perl 
language, provides just the tool Jean-Louis needs to write a 
multifile search-and-replace extension. Requires
PKUNZIP 2.0/UNZIP52/WINZIP95 to extract because of long filenames.


AA497.TXT
Title: ALGORITHM ALLEY
Keywords: APR97     CRC   ERROR DETECTION
Published source code accompanying Tim Kientzle's article on the 
cyclic redundancy check (CRC) error-detecting signature. 

CPROG497.TXT
Title: C PROGRAMMING COLUMN  
Keywords: APR97  C   C++   JAVASCRIPT   WORLD WIDE WEB
Published source code accompanying Al Stevens column in which he 
uses JavaScript and C to build an order-entry system for his web 
page.
 
JQA497.TXT
Title: JAVA Q&A
Keywords: APR97  JAVA    PERSISTENCE
Published source code accompanying Cliff Berg's column in which 
he describes how you can build persistent Java objects. Also see 
JQA497.ZIP.

JQA497.ZIP
Title: JAVA Q&A
Keywords: APR97  JAVA   PERSISTENCE 
Unpublished source code accompanying Cliff Berg's column in which 
he describes how you can build persistent Java objects. Requires 
PKUNZIP/UNZIP to extract.

UD497.TXT
Title: UNDOCUMENTED CORNER
Keywords: MAR96   MFC   WINDOWS
Published source code accompanying the column by George Shepherd 
and Scot Wingo in which the look at how two COM objects can set 
up a communication scheme whereby an object calls back to a 
client. They first examine how Connections work, then look at how 
MFC implements it. 



