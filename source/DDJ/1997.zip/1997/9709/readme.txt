September 1997
Dr. Dobb's Journal

File: EMACSPK.TXT
Title: EMACSPEAK: A SPEECH-ENABLING INTERFACE
Author: T.V. Raman
Keywords: SEP97    LISP    EMACS   SPEECH  UI
Description: Published source code example accompanying the article by T.V. 
Raman in which he discusses Emacspeak, an audio output subsystem. 

File: TASKBAR.TXT
Title: CONVERTING MFC TOOLBARS INTO WINDOWS 95 TASKBARS
Author: Mark Janczura 
Keywords: SEP97   WINDOWS 95  USER INFTERFACE   WINDOWS 3.1   MFC
Description: Published source code accompanying the article by Mark Janczura 
in which he shows you how to undock a taskbar from the shell, 
giving users the option of docking the taskbar to the Windows 95 
shell or to the application window. Also see TASKBAR.ZIP. 

File: TASKBAR.ZIP
Title: CONVERTING MFC TOOLBARS INTO WINDOWS 95 TASKBARS
Author: Mark Janczura 
Keywords: SEP97   WINDOWS 95  USER INFTERFACE   WINDOWS 3.1   MFC
Description: Complete source code and related files accompanying the article 
by Mark Janczura in which he shows you how to undock a taskbar 
from the shell, giving users the option of docking the taskbar to 
the Windows 95 shell or to the application window. Requires 
PKUNZIP/UNZIP to extract.

File: TREECTRL.TXT
Title: CUSTOMIZING COMMON CONTROLS
Author: Jason Clark
Keywords: SEP97    C++    WINDOWS 95
Description: Published source code accompanying the article by Jason Clark in 
which he describes how you can customize common controls, using a 
customized tree-view control as an example. Also see TREECTRL.ZIP.

File: TREECTRL.ZIP
Title: CUSTOMIZING COMMON CONTROLS
Author: Jason Clark
Keywords: SEP97    C++    WINDOWS 95
Description: Complete source code and related files accompanying the article 
by Jason Clark in which he describes how you can customize common 
controls, using a customized tree-view control as an example. 
Requires PKUNZIP/UNZIP to extract.

File: JAVATUI.TXT
Title: A TEXT UI FOR THE JAVA AWT
Author: Stuart D. Gathman
Keywords: SEP97    JAVA   UI    MULTIUSER
Description: Published source code accompanying the article by Stuart D. 
Gathman in which he presents a text user-interface toolkit for 
the Java AWT that allows ASCII terminals to run Java applications 
on UNIX servers. In addition, the toolkit enables a multiuser 
Virtual Machine (VM). Also see JAVATUI.ZIP.

File: JAVATUI.ZIP
Title: A TEXT UI FOR THE JAVA AWT
Author: Stuart D. Gathman
Keywords: SEP97    JAVA   UI    MULTIUSER
Description: Complete source code accompanying the article by Stuart D. 
Gathman in which he presents a text user-interface toolkit for 
the Java AWT that allows ASCII terminals to run Java applications 
on UNIX servers. In addition, the toolkit enables a multiuser 
Virtual Machine (VM). Requires PKUNZIP/UNZIP to extract.

File: TAGGED.TXT
Title: TAGGED DATA STORAGE ARCHITECTURES
Author: Jeremy Vineyard
Keywords: SEP97    C++  UI
Description: Published source code accompanying the article by Jeremy 
Vineyard in which he presents a tagged data storage technique 
which improves the efficiency and robustness of your data-storage 
architecture and decreases the time you spend writing code to 
store and restore data. Also see TAGGED.ZIP.

File: TAGGED.ZIP
Title: TAGGED DATA STORAGE ARCHITECTURES
Author: Jeremy Vineyard
Keywords: SEP97    C++  UI
Description: Complete source code accompanying the article by 
by Jeremy Vineyard in which he presents a tagged data storage 
technique which improves the efficiency and robustness of your 
data-storage architecture and decreases the time you spend 
writing code to store and restore data. Requires PKUNZIP/UNZIP to extract.

File: JDEAD.TXT
Title: JAVA DEADLOCK
Author: Allan Vermeulen
Keywords: SEP97    JAVA   C++   DEADLOCK  MULTITHREADED
Description: Published code accompanying the by Allan Vermeulen in which he 
discuses Java deadlock--a nasty problem where a program simply 
stops executing because all threads are waiting for a resource 
that will never become available. Allan examines Java deadlock, 
and shows how it can be prevented. Also see JDEAD.ZIP.

File: JDEAD.ZIP
Title: JAVA DEADLOCK
Author: Allan Vermeulen
Keywords: SEP97    JAVA   C++   DEADLOCK  MULTITHREADED
Description: Unpublished code accompanying the by Allan Vermeulen in which he 
discuses Java deadlock--a nasty problem where a program simply 
stops executing because all threads are waiting for a resource 
that will never become available. Allan examines Java deadlock, 
and shows how it can be prevented. Requires PKUNZIP/UNZIP to extract.

File: SNAPSHOT.TXT
Title: FIREWIRE: THE IEEE 1394 HIGH-SPEED SERIAL BUS
Author: Thomas Tewell 
Keywords: SEP97   CONSUMER ELECTRONICS   WIN32   
Description: Published source code accompanying the article by Thomas Tewell 
in which he discusses FireWire (also known as IEEE 1394) which 
may pave the way for a true convergence of consumer electronics 
and computers. Thomas presents a fully functional Win32 console 
application that takes a snapshot from the CCM-DS250 digital 
camera, converts it from a YUV format to a 24-bit device 
independent bitmap (DIB), and writes the DIB to a file. 
Also see SNAPSHOT.ZIP.

File: SNAPSHOT.ZIP
Title: FIREWIRE: THE IEEE 1394 HIGH-SPEED SERIAL BUS
Author: Thomas Tewell 
Keywords: SEP97   CONSUMER ELECTRONICS   WIN32   
Description: Unpublished source code accompanying the article by Thomas Tewell 
in which he discusses FireWire (also known as IEEE 1394) which 
may pave the way for a true convergence of consumer electronics 
and computers. Thomas presents a fully functional Win32 console 
application that takes a snapshot from the CCM-DS250 digital 
camera, converts it from a YUV format to a 24-bit device 
independent bitmap (DIB), and writes the DIB to a file. 
Requires PKUNZIP/UNZIP to extract.

File: SNAPSHOT.TXT
Title: FIREWIRE: THE IEEE 1394 HIGH-SPEED SERIAL BUS
Author: Thomas Tewell
Keywords: SEP97   CONSUMER ELECTRONICS   WIN32   
Description: Published source code accompanying the article by Thomas Tewell 
in which he discusses FireWire (also known as IEEE 1394) which 
may pave the way for a true convergence of consumer electronics 
and computers. Thomas presents a fully functional Win32 console 
application that takes a snapshot from the CCM-DS250 digital 
camera, converts it from a YUV format to a 24-bit device 
independent bitmap (DIB), and writes the DIB to a file. Also see SNAPSHOT.ZIP.

File: SSS_VB.TXT
Title: SERVER-SIDE SCRIPTING IN VISUAL BASIC
Author: Al Williams
Keywords: SEP97   VISUAL BASIC   HTML   ACTIVEX   WORLD WIDE WEB
Description: Published source code accompanying the article by Al Williams in 
which he shows how you can transform a boring web page into an 
interactive powerhouse using Visual Basic, IIS 3.0, VBScript, and 
server-side ActiveX components. Also see SSS_VB.ZIP.

File: SSS_VB.ZIP
Title: SERVER-SIDE SCRIPTING IN VISUAL BASIC
Author: Al Williams
Keywords: SEP97   VISUAL BASIC   HTML   ACTIVEX   WORLD WIDE WEB
Description: Unpublished source code and related files accompanying the 
article by Al Williams in which he shows how you can transform a 
boring web page into an interactive powerhouse using Visual 
Basic, IIS 3.0, VBScript, and server-side ActiveX components. 
Requires PKUNZIP/UNZIP to extract.

File: STEREO.TXT
Title: STEREOSCOPIC IMAGING
Author: Andy Ramm
Keywords: SEP97   IMAGING  3-D
Description: Published source code accompanying the article by Andy Ramm in 
which he discusses stereoscopic imaging which gives you the 
ability to deliver a natural 3-D view of an object or scene 
dramatically increases technical proficiency and the ability to 
interpret multidimensional data.

File: OPO.TXT
Title: LEVERAGING ORACLE POWER OBJECTS 2.1
Author: Douglas McArthur
Keywords: SEP97   ORACLE   VISUAL DEVELOPMENT  CLIENT/SERVER   DATABASE
Description: Published source code accompanying the article by Douglas C. 
McArthur in which he describes how Oracle's visual development 
Power Objects 2.1 tool was used to develop MDLSCREEN, an Oracle-
based client/server data-management system for automated drug 
discovery and high-throughput screening.

File: CPROG997.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: SEP97    C++  
Description: Published source code accompanying the article by Al Stevens in 
which he discusses the proposed C++ standardization process.

File: JQA997.TXT
Title: JAVA Q&A
Author: Cliff Berg
Keywords: SEP97      JAVA      JAVA BEANS
Description: Published source code accompanying the column by Cliff Berg in 
which he discusses how to write a Java Bean. Also see JQA997.ZIP.

File: JQA997.ZIP
Title: JAVA Q&A
Author: Cliff Berg
Keywords: SEP97      JAVA      JAVA BEANS
Description: Unpublished source code accompanying the column by Cliff Berg in 
which he discusses how to write a Java Bean. Requires UNZIP/PKUNZIP to extract.

File: AA997.TXT
Title: ALGORITHM ALLEY
Author: Bob Jenkins
Keywords: SEP97      ALGORITHMS    HASH FUNCTIONS 
Description: Source code accompanying the article by Bob Jenkins in which he 
designs a new hash function.


