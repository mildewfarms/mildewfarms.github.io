February 1997
Dr. Dobb's Journal

UNITEST.TXT
Title: UNIT AND REGRESSION TESTING
Keywords: FEB97     TESTING    DEBUGGING
Published source code accompanying the article by Adrian McCarthy 
in which he describes how to build effective units tests and 
automate regression testing.

DEBUG.TXT
Title: A DEBUG/TRACE TOOL
Keywords: FEB97    DEBUGGING   C/C++
Published source code accompanying the article by Rainer Storn in 
which he presents a tool that is both useful when you don't have 
a powerful debugger at hand, and when you need to build trace 
functionality into your code for error-spotting support at the 
client's site. Also see DEBUG.ZIP

DEBUG.ZIP
Title: A DEBUG/TRACE TOOL
Keywords: FEB97    DEBUGGING   C/C++
Unpublished source code and executables accompanying the article 
by Rainer Storn in which he presents a tool that is both useful 
when you don't have a powerful debugger at hand, and when you 
need to build trace functionality into your code for error-
spotting support at the client's site. Requires UNZIP/PKUNZIP to 
extract.

JHARNESS.ZIP
Title: JAVA GUI TESTING
Keywords: FEB97   JAVA   TESTING   GUI
Unpublished source code accompanying Alan Walworth's article in 
which  he examines Java GUI testing issues and presents a test 
harness written in and for Java. Requires PKUNZIP 2.0 or compatible
to extract. Use -d option to preserve directory structure.

DISPERL.TXT
Title: A DISASSEMBLER WRITTEN IN PERl
Keywords: FEB97    DEBUGGING   DISASSEMBLY    PERL
Published source code accompanying the article by Tony Zhang in 
which he presents the core subroutines of a disassembler written 
in Perl. Although designed for Intel x86 instruction set, you can 
easily modify or customize the disassembler for your own 
applications. Also see DISPERL.ZIP.

DISPERL.ZIP
Title: A DISASSEMBLER WRITTEN IN PERl
Keywords: FEB97    DEBUGGING   DISASSEMBLY    PERL
Unpublished source code accompanying the article by Tony Zhang in 
which he presents the core subroutines of a disassembler written 
in Perl. Requires UNZIP/PKUNZIP to extract.

NTFILE.TXT
Title: EXAMINING THE WINDOWS NT FILESYSTEM
Keywords: FEB97    WINDOWS NT   FILESYSTEM 
Published source code accompanying the article by Mark 
Russinovich and Bryce Cogswell in which they open up the inner 
workings of the NT filesystem by describing how a file-system 
request originates in a user's program and ends up as a disk 
access. Also see FILEMON.ZIP.

FILEMON.ZIP
Title: EXAMINING THE WINDOWS NT FILESYSTEM
Keywords: FEB97    WINDOWS NT   FILESYSTEM 
Unpublished source code and executables accompanying the article 
by Mark Russinovich and Bryce Cogswell in which they open up the 
inner workings of the NT filesystem by describing how a file-
system request originates in a user's program and ends up as a 
disk access. Requires UNZIP/PKUNZIP to extract; use the -d option 
to preserve directory structure.

ROBOTS.TXT
Title: ROBOTS AND FINITE-STATE MACHINES
Keywords: FEB97   ROBOTS  FINITE-STATE MACHINES   FORTH
Published source code accompanying the article by Everett F. 
Carter, Jr. in which he describes the high-level processing he 
implemented in designing a robot-control systems. Also see ROBOTS.ZIP.

ROBOTS.ZIP
Title: ROBOTS AND FINITE-STATE MACHINES
Keywords: FEB97   ROBOTS  FINITE-STATE MACHINES   FORTH
Unpublished source code accompanying the article by Everett F. 
Carter, Jr. in which he describes the high-level processing he 
implemented in designing a robot-control systems. Requires
UNZIP/PKUNZIP to extract.

INODE.ZIP
Title: UNIX FILESYSTEMS WITHOUT I-NODES
Keywords: FEB97   UNIX  LINUX  I-NODE  FILESYSTEM
Unpublished source code and related files accompanying the 
article by Volker Lendecke in which he presents a workaround for 
limitations of the Linux kernel. Requires UNZIP/PKUNZIP to extract.

CPPANLYZ.TXT
Title: EXAMINING C++ PROGRAM ANALYZERS
Keywords: FEB97    C++   DEBUGGING    TESTING   ANALYSIS
Published source code accompanying the article by Scott Meyers 
and Martin Klaus in which they examine off-the-shelf tools that 
parse and analyze C++ source code, enabling you to detect 
troublesome C++ code via static analysis. Also see CPPANLYZ.ZIP.

CPPANLYZ.ZIP
Title: EXAMINING C++ PROGRAM ANALYZERS
Keywords: FEB97  C++   DEBUGGING    TESTING   ANALYSIS
Unpublished source code accompanying the article by Scott Meyers 
and Martin Klaus in which they examine off-the-shelf tools that 
parse and analyze C++ source code, enabling you to detect 
troublesome C++ code via static analysis. Requires UNZIP/PKUNZIP to 
extract.

TESTERS.ZIP
Title: TESTING TESTERS
Keywords: FEB97    TESTING   WINDOWS   DEBUGGING
Unpublished source code accompanying Ron van der Wal's 
article in which he examines a collection of commercially-
available automated testing tools which helps in ferreting out 
those errors. Requires UNZIP/PKUNZIP to extract; use -d option to
preserve directory structure. 

AA297.TXT
Title: ALGORITHM ALLEY
Keywords: FEB97     ALGORITHMS       SCHEDULING
Published source code accompanying Oleg Kiselyov's article in 
which he examines scheduling algorithms and NP-Complete problems. 
Also see AA297.ZIP.

AA297.ZIP
Title: ALGORITHM ALLEY
Keywords: FEB97     ALGORITHMS       SCHEDULING
Unpublished source code accompanying Oleg Kiselyov's article in 
which he examines scheduling algorithms and NP-Complete problems. 
Requires UNZIP/PKUNZIP to extract.

CPROG.TXT
Title: C PROGRAMMING COLUMN  
Keywords: FEB97  C   C++   WINDOWS     MIDI
Published source code accompanying Al Stevens column in which he 
presents MIDI Xchg, a program that tests the MIDI data stream by 
sending event messages from one device to another as fast as 
possible. Also see MIDIXCHG.ZIP.

MIDIXCHG.ZIP
Title: C PROGRAMMING COLUMN  
Keywords: FEB97  C   C++   WINDOWS     MIDI
Unpublished source code and related files accompanying Al Stevens 
column in which he presents MIDI Xchg, a program that tests the 
MIDI data stream by sending event messages from one device to 
another as fast as possible. Requires UNZIP/PKUNZIP or compatible 
to extract. Use -d option to preserve directory structure.

JQA297.TXT
Title: JAVA Q&A
Keywords: FEB97  JAVA   SQL
Published source code accompanying Cliff Berg's column in which 
he shows how you can use Java's distributed programming model and 
access an SQL database from a Java applet. Also see JQA297.ZIP.

JQA297.ZIP
Title: JAVA Q&A
Keywords: FEB97  JAVA   SQL
Unpublished source code accompanying Cliff Berg's column in which 
he shows how you can use Java's distributed programming model and 
access an SQL database from a Java applet. Requires UNZIP/PKUNZIP 
to extract.

UD297.TXT
Title: UNDOCUMENTED CORNER
Keywords: FEB97   WINDOWS   MFC   UNDOCUMENTED
Published source code accompanying the column by George Shepherd 
and Scot Wingo in which they examine the CSplitterWnd class. Also 
see UD297.ZIP.

UD297.ZIP
Title: UNDOCUMENTED CORNER
Keywords: FEB97   WINDOWS   MFC   UNDOCUMENTED
Unpublished source code and related file accompanying the column 
by George Shepherd and Scot Wingo in which they examine the 
CSplitterWnd class. Requires UNZIP/PKUNZIP to extract.




