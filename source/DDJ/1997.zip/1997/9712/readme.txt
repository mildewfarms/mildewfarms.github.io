December 1997 
Dr. Dobb's Journal 
 
File: OBJMODEL.TXT 
Title: OBJECT MODELS AND JAVA
Author: Jean-Marie Chauvet and Marc Lerman
Keywords: DEC97    JAVA   CORBA   ACTIVEX
Description: Published source code accompanying the article by Jean-Marie Chauvet and Marc Lerman in which they show how you can use Java to glue together Microsoft's ActiveX controls and the OMG's CORBA objects.

File: AFSTL.TXT 
Title: IMPLEMENTING ABSTRACT FACTORY AS AN STL CONTAINER
Author: Jason Shankel
Keywords:  DEC97    C++   PATTERNS  
Description: Published source code accompanying the article by Jason Shankel in which he implements the Abstract Factory pattern using C++ and the Standard Template Library. The Abstract Factory design pattern provides an abstract interface for object creation. This allows applications to select object implementation at run time. Also see AFSTL.ZIP.
 
File: AFSTL.ZIP 
Title: IMPLEMENTING ABSTRACT FACTORY AS AN STL CONTAINER
Author: Jason Shankel
Keywords:  DEC97    C++   PATTERNS  
Description: Unpublished source code and related files accompanying the article by Jason Shankel in which he implements the Abstract Factory pattern using C++ and the Standard Template Library. The Abstract Factory design pattern provides an abstract interface for object creation. This allows applications to select object implementation at run time. Requires UNZIP/PKUNZIP to extract. 
 
File: GARBAGE.TXT 
Title: C++ AND GARBAGE COLLECTION
Author: Mike Spertus
Keywords: DEC97    C++   MEMORY MANAGEMENT   GARBAGE COLLECTION
Description: Published source code accompanying the article by Mike Spertus in which he examines automatic garbage collection and C++. 
 
File: QMOODCPP.ZIP 
Title: AUTOMATED METRICS AND OBJECT-ORIENTED DEVELOPMENT
Author: Jagdish Bansiya and Carl Davis
Keywords: DEC97   OBJECT-ORIENTED   METRICS   
Description: Unpublished source code accompanying the 
article by Jagdish Bansiya and Carl Davis in which they present QMOOD++, an automated tool that supports a suite of 30+ object-oriented metrics. In addition to making it easy to collect metrics data, QMOOD++ has a repository in which metric data of analyzed projects can be stored and retrieved later for comparisons. Requires UNZIP/PKUNZIP to extract. 
 
File: JAVAZIP.TXT 
Title: JAVA AND THE ZIP FILE FORMAT
Author: Mark R. Nelson 
Keywords: DEC97   JAVA   ZIP   COMPRESSION
Description: Published source code accompanying the article by Mark R. Nelson in which he looks at Sun's java.util.zip package which speeds up the process of loading of applet components across the Internet. Mark examines this package and shows you how to avoid some common mistakes the library overlooks. Also see JAVAZIP.ZIP.

File: JAVAZIP.ZIP
Title: JAVA AND THE ZIP FILE FORMAT
Author: Mark R. Nelson 
Keywords: DEC97   JAVA   ZIP   COMPRESSION
Description: Unpublished source code accompanying the article by Mark R. Nelson in which he looks at Sun's java.util.zip package which speeds up the process of loading of applet components across the Internet. Mark examines this package and shows you how to avoid some common mistakes the library overlooks. Requires UNZIP/PKUNZIP to extract.

File: ASPIEMU.TXT
Title: WRITING PORTABLE WIN32 SCSI APPLICATIONS
Author: Thomas Tewell
Keywords: DEC97      SCSI   WIN32   WINDOWS 95/NT
Description: Published source code accompanying the article by Thomas Tewell in which he presents ASPIEMU, a WinASPI 32-bit DLL emulator module for portable Win32 SCSI programming. Also see ASPIEMU.ZIP.
 
File: ASPIEMU.ZIP
Title: WRITING PORTABLE WIN32 SCSI APPLICATIONS
Author: Thomas Tewell
Keywords: DEC97      SCSI   WIN32   WINDOWS 95/NT
Description: Unpublished source code accompanying the article by Thomas Tewell in which he presents ASPIEMU, a WinASPI 32-bit DLL emulator module for portable Win32 SCSI programming. Requires UNZIP/PKUNZIP to extract. 

File: ASSERTS.TXT
Title: IMPROVE YOUR PROGRAMMING WITH ASSERTS
Author: Bruce D. Rosenblum
Keywords: DEC97    ASSERTS   DEBUGGING
Description: Published source code accompanying the article by Bruce D. Rosenblum in which he shows how you can use asserts to tack and fix bugs faster. Also see ASSERTS.ZIP.

File: ASSERTS.ZIP
Title: IMPROVE YOUR PROGRAMMING WITH ASSERTS
Author: Bruce D. Rosenblum
Keywords: DEC97    ASSERTS   DEBUGGING
Description: Unpublished source code accompanying the article by Bruce D. Rosenblum in which he shows how you can use asserts to tack and fix bugs faster. Requires UNZIP/PKUNZIP to extract.

File: SVIDEO.TXT
Title: BUILDING SMART ONLINE VIDEO SERVERS
Author: Robin Rowe
Keywords: DEC97   INTERNET    VIDEO   
Description: Source code accompanying the article by Robin Rowe in which he describes an application which integrates disparate technologies for presentation on the web. 

File: GNATADA.TXT
Title: GNAT: THE GNU NEW YORK UNIVERSITY ADA TRANSLATOR
Author: Gavin Smyth
Keywords: DEC97  ADA   
Description: Published source code accompanying the article by Gavin Smyth in which he examines the GNU New York University Ada Translator, a high-quality, low-cost Ada 95 (and Ada 83) compiler that supports DOS, Windows, and various flavors of UNIX. Also see GNATADA.ZIP.

File: GNATADA.ZIP
Title: GNAT: THE GNU NEW YORK UNIVERSITY ADA TRANSLATOR
Author: Gavin Smyth
Keywords: DEC97  ADA   
Description: Unpublished source code and related files accompanying the article by Gavin Smyth in which he examines the GNU New York University Ada Translator, a high-quality, low-cost Ada 95 (and Ada 83) compiler that supports DOS, Windows, and various flavors of UNIX. Requires UNZIP/PKUNZIP to extract.

File: INCRECPP.TXT
Title: CODESTORE AND INCREMENTAL C++
Author: Lee R. Nackman
Keywords: DEC97   C++   
Description: Published source code accompanying the article by Lee R. Nackman in which he describes the technology behind IBM's CodeStore which promises fast builds by taking the source code, the previous build's target files, and any other state the system chooses to save to produce the desired target files. For "incremental" builds such as these, build time is proportional to the impact of the source code changed since the last build. 

File: JQA1297.ZIP 
Title: JAVA Q&A 
Author: Cliff Berg 
Keywords: DEC97      JAVA      RMI
Description: Unpublished source code accompanying the column by Cliff Berg in which he shows how to dynmically invoke remote objects. Requires UNZIP/PKUNZIP to extract. 
 
File: AA1297.TXT 
Title: ALGORITHM ALLEY 
Author: Rod Stephens
Keywords: DEC97  ALGORITHMS   VISUAL BASIC   DECISION TREES
Description: Source code accompanying the article by Rod Stephens in which he shares generic techniques that can accelerate a range of complex decision problems when you are using decision trees. Also see AA1297.ZIP. 
 
File: AA1297.ZIP
Title: ALGORITHM ALLEY 
Author: Rod Stephens
Keywords: DEC97  ALGORITHMS   VISUAL BASIC   DECISION TREES
Description: Unpublished source code accompanying the article by Rod Stephens in which he shares generic techniques that can accelerate a range of complex decision problems when you are using decision trees. Requires UNZIP/PKUNZIP to extract. 

File: UD1297.TXT
Title: UNDOCUMENTED CORNER
Author: George Shepherd and Scot Wingo
Keywords: DEC97   COM   ATL   MFC
Description: Published source code accompanying the column by George Shepherd and Scot Wingo in which they examine Microsoft's Active Template Library which provides template implementations of most of the most common COM idioms. 




