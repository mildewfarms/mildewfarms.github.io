ovember 1997 
Dr. Dobb's Journal 
 
File: CCPFOR.TXT 
Title: SCIENTIFIC COMPUTING: C++ VERSUS FORTRAN 
Author: Todd Veldhuizen  
Keywords: NOV97    C++   FORTRAN    SCIENTIFIC    NUMERICS  
Description: Published source code accompanying the article 
by Todd Veldhuizen in which he describes how the performance 
of C++ programs is outpacing Fortran counterparts in 
scientific and numeric computing.  
 
File: MINT.TXT 
Title: EXTENDED-PRECISION NATIVE INTEGERS FOR JAVA 
Author: Lou Grinzo 
Keywords:  NOV97  JAVA   INTEGERS 
Description: Published source code accompanying the article 
by Lou Grinzo in which he presents his "monster" integer 
library, an alternative to the JDK 1.1 BigInteger class. The 
main difference between Lou's mInts and BigInteger is that 
BigInteger is arbitrary precision, while Lou's provides 
signed integers fixed at 256 bits. Also see MINT.ZIP. 
 
File: MINT.ZIP 
Title: EXTENDED-PRECISION NATIVE INTEGERS FOR JAVA 
Author: Lou Grinzo 
Keywords:  NOV97  JAVA   INTEGERS 
Description: Unpublished source code and related files 
accompanying the article by Lou Grinzo in which he presents 
his "monster" integer library, an alternative to the JDK 1.1 
BigInteger class. The main difference between Lou's mInts 
and BigInteger is that BigInteger is arbitrary precision, 
while Lou's provides signed integers fixed at 256 bits. 
Requires UNZIP/PKUNZIP to extract. 
 
File: ERROR.TXT 
Title: CONVOLUTIONAL ERROR-CONTROL CODES 
Author: Hugo Lyppens 
Keywords: NOV97    ERROR CORRECTION   C++ 
Description: Published source code accompanying the article 
by Hugo Lyppens in which he discusses convolutional codes--
error-correction codes which can encode an unlimited number 
of message symbols into one codeword and support "soft-
decision" decoding. Hugo presents a C++ template class which 
implements both the encoder and decoder. Also see ERROR.ZIP. 
 
File: ERROR.ZIP 
Title: CONVOLUTIONAL ERROR-CONTROL CODES 
Author: Hugo Lyppens 
Keywords: NOV97    ERROR CORRECTION   C++ 
Description: Unpublished source code accompanying the 
article by Hugo Lyppens in which he discusses convolutional 
codes--error-correction codes which can encode an unlimited 
number of message symbols into one codeword and support 
"soft-decision" decoding. Hugo presents a C++ template class 
which implements both the encoder and decoder. Requires 
UNZIP/PKUNZIP to extract. 
 
File: GROUSE.TXT 
Title: HIGH-SPEED FINITE-STATE MACHINES 
Author: Brenton Hoff 
Keywords: NOV97   FINITE-STATE MACHINES   VIRTUAL MACHINES    
Description: Published source code accompanying the article 
by Brenton Hoff in which he presents a technique for 
implementing a virtual machine, using text-processing as an 
example application. Also see GROUSE.ZIP. 
 
File: GROUSE.ZIP 
Title: HIGH-SPEED FINITE-STATE MACHINES 
Author: Brenton Hoff 
Keywords: NOV97 FINITE-STATE MACHINES VIRTUAL MACHINES GREP  
HUFFMAN ENCODING 
Description: Unpublished source code accompanying the 
article by Brenton Hoff in which he presents a technique for 
implementing a virtual machine, using text-processing as an 
example application. Includes the archives ggrep101.zip, 
ghuff100.zip, and wc102.zip. Requires UNZIP/PKUNZIP to 
extract. 
 
File: M37735.TXT 
Title: OPTIMIZING MICROCONTROLLER PERFORMANCE 
Author: James Flynn 
Keywords: NOV97  EMBEDDED SYSTEMS  M37735 MICROCONTROLLER  
OPTIMIZATION 
Description: Published source code accompanying the article 
by James Flynn in which he describes a situation he 
encountered when developing control software for a 
Mitsubishi M37735-based cellular phone.       
 
File: DYNADD.TXT 
Title: TEMPLATE-DRIVEN WEB PAGES 
Author: Jay Johansen 
Keywords: NOV97    CGI   HTML    WEB SITES   INTERNET 
Description: Published source code accompanying the article 
by Jay Johansen in which he presents "dynadd," a general-
purpose, template-driven CGI application that automatically 
updates web sites. Also see DYNADD.ZIP. 
 
File: DYNADD.ZIP 
Title: TEMPLATE-DRIVEN WEB PAGES 
Author: Jay Johansen 
Keywords: NOV97    CGI   HTML    WEB SITES   INTERNET 
Description: Unpublished source code accompanying the 
article by Jay Johansen in which he presents "dynadd," a 
general-purpose, template-driven CGI application that 
automatically updates web sites. Requires UNZIP/PKUNIP to 
extract. 
 
File: MATLAB.TXT 
Title: MODELING WITH MATLAB 
Author: Mark Weaver 
Keywords: NOV97    MATLAB   COMMUNCIATIONS    MODELING 
Description: Published source code accompanying the article 
by Mark Weaver in which he describes how he uses MatLab, a 
mathematical tool from MathWorks, as a a system-level 
programming tool for modeling communications systems. 
 
File: MATHMAT.TXT 
Title: DIFFERENCE EQUATIONS AND CHAOS IN MATHEMTICA 
Author: Robert Knapp and Mark Sofroniou 
Keywords: NOV97   CHAOS  NUMERIC PROGRAMMING  MATHEMATICA 
Description: Source code accompanying the article by Robert 
Knapp and Mark Sofroniou in which the use Mathematica to set 
up programs and use links to external programs to 
demonstrate Mathematica's dynamical properties. 
 
File: CPROG107.ZIP 
Title: C PROGRAMMING COLUMN 
Author: Al Stevens 
Keywords: NOV97    C++   WINDOWS 95   MIDIFITZ   HELP 
Description: Unpublished source code and related files 
accompanying the article by Al Stevens in which he uses 
Windows 95 Wizard dialog box and WinHelp database to build 
an automated tech-support help desk. Requires UNZIP/PKUNZIP 
to extract. 
 
File: JQA1197.TXT 
Title: JAVA Q&A 
Author: Cliff Berg 
Keywords: NOV97      JAVA      PRINTING 
Description: Published source code accompanying the column 
by Cliff Berg in which he shows how to make the most of the 
JDK 1.1's printing facilities it provides. Also see 
JQA1197.ZIP. 
 
File: JQA1197.ZIP 
Title: JAVA Q&A 
Author: Cliff Berg 
Keywords: NOV97      JAVA      PRINTING 
Description: Unpublished source code accompanying the column 
by Cliff Berg in which he shows how to make the most of the 
JDK 1.1's printing facilities it provides. Requires 
UNZIP/PKUNZIP to extract. 
 
File: AA1197.TXT 
Title: ALGORITHM ALLEY 
Author: Tim Kientzle 
Keywords: NOV97  ALGORITHMS  AUDIO COMPRESSION   IMA ADPCM  
Description: Source code accompanying the article by Tim 
Kientzle in which he goes inside the IMA ADPCM audio 
compression format and examines how it is implemented by 
Microsoft and Apple. Also see AA1197.ZIP. 
 
File: AA1197.ZIP 
Title: ALGORITHM ALLEY 
Author: Tim Kientzle 
Keywords: NOV97  ALGORITHMS  AUDIO COMPRESSION   IMA ADPCM  
Description: Unpublished source code accompanying the 
article by Tim Kientzle in which he goes inside the IMA 
ADPCM audio compression format and examines how it is 
implemented by Microsoft and Apple. Requires UNZIP/PKUNZIP 
to extract. 
 
 

