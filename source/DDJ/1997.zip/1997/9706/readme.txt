June 1997
Dr. Dobb's Journal

LITERATE.TXT
Title: LITERATE PROGRAMMING AND CODE REUSE
Keywords: JUN97  KNUTH   LITERATE PROGRAMMING   C++  CLiP  PATTERNS
Published source code--including the "text"--accompanying the 
article by Sverre Hendseth on "Literate Programming," a concept 
introduced by Donald Knuth. The CLiP system which Sverre uses 
lets you mix code and documentation in the layout of a program. 
In this article, which is in itself a literate program, Sverre 
implements the Singleton and State patterns to combine a macro 
processor with literate programming techniques. Also see 
LITERATE.ZIP.

LITERATE.ZIP
Title: Title: LITERATE PROGRAMMING AND CODE REUSE
Keywords: JUN97  KNUTH   LITERATE PROGRAMMING   C++  CLiP  PATTERNS
Unpublished source code--including the "text"--and related files 
accompanying the article by Sverre Hendseth on "Literate 
Programming," a concept introduced by Donald Knuth. The CLiP 
system which Sverre uses lets you mix code and documentation in 
the layout of a program. In this article, which is in itself a 
literate program, Sverre implements the Singleton and State 
patterns to combine a macro processor with literate programming 
techniques. Requires PKUNZIP/UNZIP to extract. Use the -d option 
to preserve directory structure.

WORKER.TXT
Title: DESIGN PATTERNS, JAVA, AND WEB DEVELOPMENT
Keywords: JUN97    JAVA    PATTERNS   HTML  JAVASCRIPT   
Published source code accompanying the article by Martin Remy in 
which he presents Worker applets--nonvisual components that labor 
unseen behind the flashy facades of web pages. Using Java, 
JavaScript, and HTML, Martin three design patterns for 
incorporating worker applets into web projects.

ISA.TXT
Title: DESIGN GUIDELINES FOR IS-A HIERARCHIES
Keywords: JUN97    SOFTWARE DESIGN   OBJECT MODELS
Published source code accompanying the article by John A. 
Grosberg in which he discusses developing object-oriented 
designs. John focuses on the modeling approach to design, which 
is particularly useful in early development phases. In doing so, 
he works with Venn diagrams and Object Models.

TESTING.TXT
Title: DESIGNING FOR TESTABILITY
Keywords: JUN97    PERL   TESTING   
Published source code accompanying the article by Fred Wild in 
which he discusses regression testing. Fred shows how Perl 
scripts can be use to automate the regression testing process. 
Also see TESTING.ZIP.

TESTING.ZIP
Title: DESIGNING FOR TESTABILITY
Keywords: JUN97    PERL   TESTING   
Unpublished Perl code accompanying the article by Fred Wild in 
which he discusses regression testing. Fred shows how Perl 
scripts can be use to automate the regression testing process.
Requires UNZIP/PKUNZIP to extract.

IDLDOC.TXT
Title: IDLDOC: AUTOMATIC DOCUMENTATION FOR CORBA IDL
Keywords: JUN97   CORBA  IDL   OMG    OBJECT-ORIENTED
Published source code accompanying the article by Ernest J. 
Friedman-hill and Robert A. Whiteside in which they present 
Idldoc. Idldoc reads in IDL, the OMG's "Interface Description 
Language", source and generates a set of HTML pages that document 
the interfaces described in the IDL. Because idldoc understands 
the entire IDL language, its output reflects an understanding of 
the all entities.

SBI.TXT
Title: SBI: THE SMALL BASIC INTERPRETER
Keywords: JUN97    BASIC   INTERPRETER   SCRIPTING
Published source code accompanying the article by Steve 
Reichenthal and Tom Bennett in which they present SBI (short for 
the "Small Basic Interpreter"), an engine that implements a 
useful a subset of Visual Basic. As such, SBI is a powerful 
scripting language that you and your users can instantly put to 
work. Also see SBI.ZIP.

SBI.ZIP
Title: SBI: THE SMALL BASIC INTERPRETER
Keywords: JUN97    BASIC   INTERPRETER   SCRIPTING
Complete source code and related files that implement the Small 
Basic Interpreter, written by Steve Reichenthal and Tom Bennett.
This engine implements a useful a subset of Visual Basic. As 
such, SBI is a powerful scripting language that you and your 
users can instantly put to work. Requires UNZIP/PKUNZIP to 
extract.

WATCHDOG.TXT
Title: WATCHDOGS FOR INTERRUPT MONITORING
Keywords: JUN97    INTERRUPTS   EMBEDDED SYSTEMS
Published source code accompanying the article by Rolf V. 
Oestergaard in which he presents IntMon and WdMon, a set of 
verification and "problem-spotting" tools he wrote to ensure that 
interrupts are not missed, watchdogs are serviced, and process 
don't run too long. Also see WATCHDOG.ZIP.

WATCHDOG.ZIP
Title: WATCHDOGS FOR INTERRUPT MONITORING
Keywords: JUN97    INTERRUPTS   EMBEDDED SYSTEMS
Unpublished source code accompanying the article by Rolf V. 
Oestergaard in which he presents IntMon and WdMon, a set of 
verification and "problem-spotting" tools he wrote to ensure that 
interrupts are not missed, watchdogs are serviced, and process 
don't run too long. Requires UNZIP/PKUNZIP to extract.

FASTCGI.TXT
Title: WEB EXTENSIONS AND APPLICATIONS USING FASTCGI
Keywords: JUN97   FASTCGI   CGI   WORLD WIDE WEB   C   SCRIPTING
Published source code accompanying the article by Scott Dybiec 
and Philip Rousselle in which they discuss Open Market's FastCGI 
protocol which addresses many of the shortcomings of both 
conventional CGI and server APIs. Our authors discuss the FastCGI 
protocol, describe the OpenMarket C programming library for 
FastCGI, and develop example applications using the OpenMarket 
library. Also see FASTCGI.ZIP.

FASTCGI.ZIP
Title: WEB EXTENSIONS AND APPLICATIONS USING FASTCGI
Keywords: JUN97   FASTCGI   CGI   WORLD WIDE WEB   C   SCRIPTING
Unpublished source code accompanying the article by Scott Dybiec 
and Philip Rousselle in which they discuss Open Market's FastCGI 
protocol which addresses many of the shortcomings of both 
conventional CGI and server APIs. Our authors discuss the FastCGI 
protocol, describe the OpenMarket C programming library for 
FastCGI, and develop example applications using the OpenMarket 
library. Requires UNZIP/PKUNZIP to extract.

UNDOREDO.ZIP
Title: AN UNLIMITED UNDO/REDO STACK PATTERN FOR POWERBUILDER
Keywords: JUN97   VISUAL PROGRAMMING   PATTERNS  POWERBUILDER
Unpublished source code accompanying the article by David Van 
Camp in which he presents a technique for providing unlimited 
undo and redo capabilities to windows developed using 
PowerBuilder. In doing so, he uses design patterns to provide a 
simple, standardized approach which is easily understood and 
highly adaptable to a variety of specific problems. Requires 
UNZIP/PKUNZIP to extract.

CPR0G697.ZIP
Title: C PROGRAMMING
Keywords: JUN97   C++   OPTIMA++  VISUAL TOOLS
Unpublished source code accompanying Al Stevens column in which 
he examines PowerSoft's Optima++ 1.5. Requires PKUNZIP/UNZIP to 
extract.

JQA697.TXT
Title: JAVA Q&A
Keywords: JUN97     JAVA    SECURITY
Published source code accompanying Cliff Berg's column in which 
he discusses Java's built-in security features and explains how 
you create a security manager for your applications. Also see 
JQA697.ZIP.

JQA697.ZIP
Title: JAVA Q&A
Keywords: JUN97     JAVA    
Unpublished source code accompanying Cliff Berg's column in which 
he discusses Java's built-in security features and explains how 
you create a security manager for your applications. Requires 
PKUNZIP/UNZIP to extract.

UD697.TXT
Title: UNDOCUMENTED CORNER
Keywords: JUN97   ATL  ACTIVEX
Published source code accompanying the column by George Shepherd 
and Scot Wingo in which they discuss the ActiveX Template Library 
(included with Visual C++ 5.0), a framework for creating COM 
components, takes care of things such as class object and server 
lifetime issues, COM identity, and implementing IDispatch. 

AA697.ZIP
Title: ALGORITHM ALLEY
Keywords: JUN97     SPLINES   GRAPHICS   ALGORITHMS
Unpublished source code accompanying the article by John Swartz 
in which he examines a technique for symbolic integration 
proposed by James Slagle over 30 years ago. In doing so, he uses 
CLIPS (short for "C Language Integrated Production System"), a 
non-procedural language which supports system development across 
and among three distinct programming paradigms--rule-based, 
object-oriented, and procedural. Requires PKUNZIP/UNZIP to 
extract.

LETTER.TXT
Title: LETTERS 
Keywords: JUN97  ADA
Unpublished source code accompanying the letter from 
Glen Shipley in which he implements a linked list using Ada95.


