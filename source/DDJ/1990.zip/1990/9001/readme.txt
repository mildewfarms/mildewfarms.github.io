January 1990 
Dr. Dobb's Journal 

RAHNER.EXE
SPRITE.EXE
JAMES.ASC
Real-Time Animation
by Rahner James 

NOLAN.ASC
NOLAN.ZIP
Real-Time Data Acquisition Using DMA
by Tom Nolan

ZEN.ACR
TRACY.ASC
Zen for Embedded Systems
by Martin Tracy

DOUGLAS.ASC
Error Message Management
by Rohan T. Douglas

STOUT.ASC
S-Coder for Data Encryption
by Robert B. Stout

LOCATE.EXE
NELSON.ASC
Location Is Everything
by Mark Nelson 

LADD.ASC
ZGTEST.C
ZG_LWLVL.C
ZG_LWLVL.H
ZG_LWLVL.DOC
Examining Zortech C++ 2.0
by Scott Robert Ladd

SCHULMAN.ASC
Stalking General Protection Faults: Part I
by Andrew Schulman

STEVENS.ASC
C Programming Column
by Al Stevens

DUNTEMAN.ASC
Structured Programming Column
by Jeff Duntemann
