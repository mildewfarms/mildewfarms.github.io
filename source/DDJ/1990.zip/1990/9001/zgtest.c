#include "zg_lwlvl.h"

int main(void);

int main(void)
    {
    int x, y, c;

    if (ZG_Init())
        return 1;

    if (ZG_SetMode(ZG_MOD_BESTRES))
        return 2;

    for (x = 0; x < ZG_VideoInfo.Xwidth; ++x)
        for (y = 0; y < ZG_VideoInfo.Ylength; ++y)
            ZG_PlotPixel(x, y, (x % ZG_VideoInfo.NoColors));

    ZG_SetPixelMode(ZG_PXL_XOR);

    for (x = 0; x < ZG_VideoInfo.Xwidth; ++x)
        for (y = 0; y < ZG_VideoInfo.Ylength; ++y)
            ZG_PlotPixel(x, y, ZG_VideoInfo.NoColors - (x % ZG_VideoInfo.NoColors));

    for (x = 0; x < ZG_VideoInfo.Xwidth; ++x)
        for (y = 0; y < ZG_VideoInfo.Ylength; ++y)
            ZG_PlotPixel(x, y, ZG_VideoInfo.NoColors - (x % ZG_VideoInfo.NoColors));

    if (ZG_SetMode(ZG_MOD_MOSTCOLOR))
        return 3;

    ZG_SetPixelMode(ZG_PXL_SET);

    for (x = 0; x < ZG_VideoInfo.Xwidth; ++x)
        for (y = 0; y < ZG_VideoInfo.Ylength; ++y)
            ZG_PlotPixel(x, y, (x % ZG_VideoInfo.NoColors));

    ZG_SetPixelMode(ZG_PXL_XOR);

    for (x = 0; x < ZG_VideoInfo.Xwidth; ++x)
        for (y = 0; y < ZG_VideoInfo.Ylength; ++y)
            ZG_PlotPixel(x, y, ZG_VideoInfo.NoColors - (x % ZG_VideoInfo.NoColors));

    for (x = 0; x < ZG_VideoInfo.Xwidth; ++x)
        for (y = 0; y < ZG_VideoInfo.Ylength; ++y)
            ZG_PlotPixel(x, y, ZG_VideoInfo.NoColors - (x % ZG_VideoInfo.NoColors));

    ZG_PlotPixel(10, 10, ZG_VideoInfo.NoColors - 1);

    c = ZG_ReadPixel(10, 10);

    ZG_Done();

    if (c != (ZG_VideoInfo.NoColors - 1))
        return 4;

    return 0;
    }
