December 1999  
Dr. Dobb's Journal   
  
File: MMPC.TXT  
Title: MMPC: AN ALGORITHM FOR ENCRYPTING MULTIPLE MESSAGES 
Author: Jim Shapiro and David Shapiro 
Keywords: DEC99     CRYPTOGRAPHY   SECURITY   ALGORITHM 
Description: Published source code accompanying the article by Jim  
Shapiro and David Shapiro which implements Ron Rivest's chaffing  
and package transform. This technique is optimized to minimize  
memory usage, while making as few passes through the data as  
possible. Also see MMPC.ZIP. 
  
File: MMPC.ZIP  
Title: MMPC: AN ALGORITHM FOR ENCRYPTING MULTIPLE MESSAGES 
Author: Jim Shapiro and David Shapiro 
Keywords: DEC99     CRYPTOGRAPHY   SECURITY   ALGORITHM 
Description: Unpublished source code and related files  
accompanying the article by Jim Shapiro and David Shapiro which  
implements Ron Rivest's chaffing and package transform. This  
technique is optimized to minimize memory usage, while making as  
few passes through the data as possible. Requires UNZIP/PKUNZIP to  
extract. 
  
File: ELLIP.ZIP 
Title: ELLIPTIC CURVE CRYPTOGRAPHY 
Author: Andrew D. Fernandes 
Keywords: DEC99     CRYPTOGRAPHY     SECURITY 
Description: Unpublished source code accompanying the article by  
Andrew D. Fernandes in which he compares elliptic-curve  
cryptography to other cryptosystems. In the process, he shows how  
elliptic-curves cryptosystems are built. Requires UNZIP/PKUNZIP to  
extract. 
 
File: 1394WDM.TXT   
Title: A WDM IEEE 1394 CONFIGURATION ROM DECODER 
Author: William F. Alexander 
Keywords: DEC99     1394   FIREWIRE    WINDOWS 2000 
Description: Published source code accompanying the article by  
William F. Alexander in which he updates his DUMPROM utility by  
presenting a WDM version that runs on Windows 98 and Windows 2000.  
DUMPROM lets you examine the configuration ROM of any 1394 device.  
Also see 1394WDM.ZIP. 
 
File: 1394WDM.ZIP 
Title: A WDM IEEE 1394 CONFIGURATION ROM DECODER 
Author: William F. Alexander 
Keywords: DEC99     1394   FIREWIRE    WINDOWS 2000 
Description: Unpublished source code and related files  
accompanying the article by William F. Alexander in which he  
updates his DUMPROM utility by presenting a WDM version that runs  
on Windows 98 and Windows 2000. DUMPROM lets you examine the  
configuration ROM of any 1394 device. Requires UNZIP/PKUNZIP to  
extract.   
 
File:  XFDL.TXT 
Title: XFDL: THE EXTENSIBLE FORMS DESCRIPTION LANGUAGE 
Author: John Boyer 
Keywords: DEC99    XML   INTERNET   E-COMMERCE 
Description: Published source code accompanying the article by  
John Boyer in which he describes XFDL, a Extensible Forms  
Description Language is an XML extension language that addresses  
key problems involved with doing electronic commerce on the web.  
  
File: SPICE.TXT  
Title: PORTING THE SPICE LIBRARY 
Author: Ed Wright 
Keywords:  DEC99   FORTRAN  PERL  C/C++  SCIENTIFIC COMPUTING    
Description: Published source code accompanying the article by Ed  
Wright in which he shares his experiences in porting the SPICE  
Fortran library, which consists of 952 portable Fortran routines  
with 79,369 lines of executable code and 153,649 comment lines, to  
C. Also see DOC2C.ZIP. 
 
File: DOC2C.ZIP 
Title: PORTING THE SPICE LIBRARY 
Author: Ed Wright 
Keywords:  DEC99   FORTRAN  PERL  C/C++  SCIENTIFIC COMPUTING    
Description: Unpublished source code accompanying the article by  
Ed Wright in which he shares his experiences in porting the SPICE  
Fortran library, which consists of 952 portable Fortran routines  
with 79,369 lines of executable code and 153,649 comment lines, to  
C. Requires UNZIP/PKUNZIP to extract. 
  
File: JQA1299.TXT   
Title: JAVA Q&A  
Author: Paul Tremblett 
Keywords: DEC99   JAVA    JSP   DHTML 
Description: Published source code accompanying the article by  
Paul Tremblett in which he discusses one way to deliver dynamic  
data content to otherwise static HTML pages--by leveraging the  
power of Java and JavaServer Pages. Also see JQA1299.ZIP. 
 
File: JQA1299.ZIP 
Title: JAVA Q&A  
Author: Paul Tremblett 
Keywords: DEC99   JAVA    JSP   DHTML 
Description: Unpublished source code accompanying the article by  
Paul Tremblett in which he discusses one way to deliver dynamic  
data content to otherwise static HTML pages--by leveraging the  
power of Java and JavaServer Pages. Requires UNZIP/PKUNZIP to  
extract. 
  
File: AA1299.TXT 
Title: ALGORITHM ALLEY  
Author: Jon Bentley 
Keywords: DEC99   ALGORITHM   SORTING 
Description: Publish source code accompanying the article by Jon  
Bentley in which he examines the Merge Sort and similar  
algorithms. 
 
File: CPRO1299.ZIP 
Title: C PROGRAMMING 
Author: Al Stevens 
Keywords: DEC99   C++  FRAMEWORK 
Description: Unpublished source code to the file TESTGL.ZIP which 
accompanys the column by Al Stevens in which he continues to build a 
C++-based generic, platform-independent graphics library. Requires 
UNZIP/PKUNZIP to extract. 
 
 
 
3 
 

