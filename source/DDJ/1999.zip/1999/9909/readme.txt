September 1999
Dr. Dobb's Journal 

File: JAVA2GRA.TXT
Title: JAVA 2 GRAPHICS RENDERING
Author:  Torpum Jannak
Keywords: SEP99    JAVA 2     GRAPHICS
Description: Published source code accompanying the article by Torpum Jannak in which he presents an optimized graphics-rendering pipeline that addresses the performance concerns you may have when developing scientific visualization, action-based games, and similar resource-demanding applications. Also see JAVA2GRA.ZIP.

File: JAVA2GRA.ZIP
Title: JAVA 2 GRAPHICS RENDERING
Author:  Torpum Jannak
Keywords: SEP99    JAVA 2     GRAPHICS
Description: Unpublished source code and related files accompanying the article by Torpum Jannak in which he presents an optimized graphics-rendering pipeline that addresses the performance concerns you may have when developing scientific visualization, action-based games, and similar resource-demanding applications. Requires UNZIP/PKUNZIP to extract.

File:  GAMMA.TXT
Title: GAMMA CORRECTION
Author: Angus Dorbie
Keywords: SEP99    GRAPHICS    
Description: Published source code accompanying the article by Angus Dorbie
in which he discusses gamma correction, which is essential for good quality
image generation. Angus examines the problems associated with gamma
correction, focusing on why it is important to simulation in particular.
Also see GAMMA.ZIP.

File:  GAMMA.ZIP
Title: GAMMA CORRECTION
Author: Angus Dorbie
Keywords: SEP99    GRAPHICS    
Description: Unpublished source code and related files accompanying the
article by Angus Dorbie in which he discusses gamma correction, which is
essential for good quality image generation. Angus examines the problems
associated with gamma correction, focusing on why it is important to
simulation in particular. Requires UNZIP/PKUNZIP to extract.

File: MMX.TXT
Title: MMX TECHNOLOGY CODE OPTIMIZATION
Author: Max I. Fomitchev
Keywords:  SEP99     MMX     OPTIMIZATION     GRAPHICS
Description: Published source code files accompanying the article by Max I.
Fomitchev, in which he examines MMX-code optimization techniques and shows
how you can achieve maximum speed on the Intel Pentium II and AMD K6-2
processors. Also see MMX.ZIP.

File: MMX.ZIP
Title: MMX TECHNOLOGY CODE OPTIMIZATION

Author: Max I. Fomitchev
Keywords:  SEP99     MMX   OPTIMIZATION   GRAPHICS
Description: Unpublished source code files and related files accompanying
the article by Max I. Fomitchev, in which he examines MMX-code optimization
techniques and shows how you can achieve maximum speed on the Intel Pentium
II and AMD K6-2 processors. Requires UNZIP/PKUNZIP to extract.

File: JAVACOMP.TXT
Title: WRITING HIGH-PERFORMANCE GRAPHICAL JAVA COMPONENTS
Author: Harold Shinsato
Keywords: SEP99     JAVA      GRAPHICS  
Description: Published source code accompanying the article by Harold
Shinsato in which he presents tips and tricks for writing high-performance,
computationally-intensive, graphical Java components. 

File: PORTWCE.TXT
Title: PORTING COMMUNICATIONS SOFTWARE TO WINDOWS CE
Author: Oliver Diener
Keywords: SEP99     WINDOWS CE   PORTING    WIN32
Description: Published source code accompanying the article by Oliver
Diener in which he shares some of the hard-won secrets he discovered when
porting the LUCA data communications framework from Windows 95/NT to CE.

FILE: NETPROT.TXT
Title: DEVELOPING CUSTOM NETWORK PROTOCOLS
Author: Curtis Schwaderer 
Keywords: SEP99      PROTOCOLS    NETWORKS    REAL-TIME
Description: Published source code accompanying the article by Curtis
Schwaderer in which he presents a standard framework and create protocols
that are interoperable with other protocols written for the same framework.
Also see NETPROT.ZIP.

FILE: NETPROT.ZIP
Title: DEVELOPING CUSTOM NETWORK PROTOCOLS
Author: Curtis Schwaderer 
Keywords: SEP99      PROTOCOLS    NETWORKS    REAL-TIME
Description: Unpublished source code and related files accompanying the
article by Curtis Schwaderer in which he presents a standard framework and
create protocols that are interoperable with other protocols written for
the same framework. Requires UNZIP/PKUNZIP to extract.

FILE: TCLSERV.TXT
Title: EVENT-BASED SERVERS IN TCL
Author: Stephen Uhler
Keywords: SEP99      TCL     NETWORK SERVERS
Description: Published source code accompanying the article by Stephen
Uhler in which he Stephen implements a web server in Tcl that is based on
events and callbacks. Also see TCLSERV.ZIP.

FILE: TCLSERV.ZIP
Title: EVENT-BASED SERVERS IN TCL
Author: Stephen Uhler
Keywords: SEP99      TCL     NETWORK SERVERS
Description: Unpublished source code and related files accompanying the
article by Stephen Uhler in which he Stephen implements a web server in Tcl

that is based on events and callbacks. Requires UNZIP/PKUNZIP to extract.

FILE: HOPTREE.TXT
Title: WiT & HIERACHICAL TREES
Author: Frank Hoewing
Keywords: SEP99      VISUAL PROGRAMMING   VISUAL BASIC
Description: Published source code accompanying the article by Frank
Hoewing in which he discusses WiT--a visual-programming package from
Logical Vision originally designed for developing image-processing
algorithms and applications. Frank uses it to create HopTree, a Visual
Basic app that recursively scans a file and creates a tree view of the
hierarchical operators used. Also see HOPTREE.ZIP.

FILE: HOPTREE.ZIP
Title: WiT & HIERACHICAL TREES
Author: Frank Hoewing
Keywords: SEP99      VISUAL PROGRAMMING   VISUAL BASIC
Description: Unpublished files accompanying the article by Frank Hoewing in
which he discusses WiT--a visual-programming package from Logical Vision
originally designed for developing image-processing algorithms and
applications. Frank uses it to create HopTree, a Visual Basic app that
recursively scans a file and creates a tree view of the hierarchical
operators used. Requires UNZIP/PKUNZIP to extract.

File: JQA999.TXT 
Title: JAVA Q&A
Author: Andy Wilson
Description: Published source code accompanying the article by  Andy Wilson
in which he examines the Java Virtual Machine Profiler Interface (JVMPI), a
tool that lets you build tools that collect events about the state of the
virtual machine. These events, in turn, let you gather information about
how the VM and your Java application actually run. Also see JQA999.ZIP.

File: JQA999.ZIP 
Title: JAVA Q&A
Author: Andy Wilson
Description: Unpublished source code and related files accompanying the
article by  Andy Wilson in which he examines the Java Virtual Machine
Profiler Interface (JVMPI), a tool that lets you build tools that collect
events about the state of the virtual machine. These events, in turn, let
you gather information about how the VM and your Java application actually
run. Requires UNZIP/PKUNZIP to extract.

File: AA999.TXT
Title: ALGORITHM ALLEY
Author: Thomas E. Janzen
Keywords: SEP99   GRAPHICS   ALGORITHMS
Description: Published source code accompanying the article by Thomas E.
Janzen in which he examines a trio of algorithms for generating simple, yet
precise, line drawings from complicated and imprecise 3D models. Also see
AA999.ZIP.

File: AA999.ZIP
Title: ALGORITHM ALLEY
Author: Thomas E. Janzen

Keywords: SEP99   GRAPHICS   ALGORITHMS
Description: Unpublished source code and related files accompanying the
article by Thomas E. Janzen in which he examines a trio of algorithms for
generating simple, yet precise, line drawings from complicated and
imprecise 3D models. Requires UNZIP/PKUNZIP to extract.

File: STORCH.ZIP
Title: C PROGRAMMING COLUMN
Author: Al Stevens 
Keywords: SEP99   C++
Description: Unpublished source code and related files accompanying the
column by Al Stevens in which he introduces Storch, a software machine that
plays back .WAV files and includes an audio record function. Requires
UNZIP/PKUNZIP to extract.







4


1


