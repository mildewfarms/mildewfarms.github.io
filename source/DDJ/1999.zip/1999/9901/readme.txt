January 1999
Dr. Dobb's Journal 

File: WEBL.TXT
Title: AUTOMATING THE WEB WITH WEBL
Author: Hannes Marais and Tom Rodeheffer
Keywords: JAN99    WEB   INTERNET    SCRIPTING
Description: Published source code accompanying the article by Hannes Marais and
Tom Rodeheffer in which they discuss WebL, a freely-available scripting language
written in Java that's ideal for prototyping web applications. Hannes and Tom
describe WebL, then show how you can use by implementing a meta-search engine
that combines search results from the AltaVista and HotBot public search
services. 

File: SLIDE.TXT
Title: LITTLE LANGUAGES WITH LEX, YACC, AND MFC
Author: Jason Shankel
Keywords: JAN99   MFC   LEX  YACC   SCRIPTING 
Description: Published source code accompanying the article by Jason Shankel in
which he shows how to use lex, yacc, and MFC to create integrated Win32
development environments for little languages. In doing so, he develops "Slide,"
short for "Small Language Integrated Development Environment," and integrates it
with lex and yacc. Also see SLIDE1.ZIP.

File: SLIDE1.ZIP
Title: LITTLE LANGUAGES WITH LEX, YACC, AND MFC
Author: Jason Shankel
Keywords: JAN99   MFC   LEX  YACC   SCRIPTING 
Description: Unpublished source code and related files accompanying the article
by Jason Shankel in which he shows how to use lex, yacc, and MFC to create
integrated Win32 development environments for little languages. In doing so, he
develops "Slide," short for "Small Language Integrated Development Environment,"
and integrates it with lex and yacc. Requires UNZIP/PKUNZIP to extract.
 
File:  PERLSRCH.TXT
Title: FULL-TEXT SEARCHING IN PERL
Author: Tim Kientzle
Keywords: JAN99   DATABASE   PERL   SEARCHING
Description: Published source code accompanying the article by Tim Kientzle in
which he shows how you can build a fast full-text search capability using Perl's
built-in database support. Also see PERLSRCH.ZIP.

File:  PERLSRCH.ZIP
Title: FULL-TEXT SEARCHING IN PERL
Author: Tim Kientzle
Keywords: JAN99   DATABASE   JAVA   PERL   SEARCHING
Description: Unpublished source code and related files accompanying the article
by Tim Kientzle in which he shows how you can build a fast full-text search
capability using Perl's built-in database support. Requires UNZIP/PKUNZIP to
extract.

File: JSTEST.TXT
Title: EXTENDING JSCRIPT
Author: Paul Butcher
Keywords:  JAN99    JAVA   JSCRIPT   JAVASCRIPT    TESTING
Description: Published source code accompanying the article by Paul Butcher in
which he extends Microsoft's JScript scripting engine by adding support for
constructors and arrays. In the process, he presents JScriptTest, a program
which displays a UI that lets you type and execute JScript source. Also see
JSTEST.ZIP.

File: JSTEST.ZIP
Title: EXTENDING JSCRIPT
Author: Paul Butcher
Keywords:  JAN99    JAVA   JSCRIPT   JAVASCRIPT    TESTING
Description: Unpublished source code and related files accompanying the article
by Paul Butcher in which he extends Microsoft's JScript scripting engine by
adding support for constructors and arrays. In the process, he presents
JScriptTest, a program which displays a UI that lets you type and execute
JScript source. Requires UNZIP/PKUNZIP to extract.

File: JPARSER.TXT
Title: YOUR OWN JAVA EXPRESSION PARSER
Author: Cliff Berg
Keywords:  JAN99    JAVA      PARSER  
Description: Published source code accompanying the article by Cliff Berg in
which he presents a Java expression parser that complements the tokenizer
classes that are already built into the language. Also see JPARSER.ZIP.

File: JPARSER.ZIP
Title: YOUR OWN JAVA EXPRESSION PARSER
Author: Cliff Berg
Keywords:  JAN99    JAVA      PARSER  
Description: Unpublished source code and related files accompanying the article
by Cliff Berg in which he presents a Java expression parser that complements the
tokenizer classes that are already built into the language. Requires
UNZIP/PKUNZIP to extract.

File: PJIA1.TXT
Title: PERSONALJAVA & INFORMATION APPLIANCES, PART I
Author: Jaison Dolvane and Kumanan Yogaratnam
Keywords: JAN99    JAVA   PERSONALJAVA    EMBEDDED SYSTEMS
Description: Published source code accompanying the article by Jaison Dolvane
and Kumanan Yogaratnam in which they discuss PersonalJava, the Java Application
Environment designed specifically for low-resource environments and diverse
visual displays. Our authors share some of the lessons they learned when
developing Kalos Espresso, a lightweight Java UI toolkit optimized for
PersonalJava environments. 

File: FICL.TXT
Title: FICL: AN EMBEDDABLE EXTENSION LANGUAGE INTERPRETER
Author: John Sadler
Keywords: JAN99    FORTH   EMBEDDED SYSTEMS     LITTLE LANGUAGES
Description: Published source code accompanying the article by John Sadler in
which he presents Ficl, short for "Forth-Inspired Command Language," an
interpreter that has a system interface similar in spirit to Tcl, but
specifically designed for embedded systems with minimal resources. Also see
FICL105.ZIP.

File: FICL202.ZIP
Title: FICL: AN EMBEDDABLE EXTENSION LANGUAGE INTERPRETER
Author: John Sadler
Keywords: JAN99    FORTH   EMBEDDED SYSTEMS     LITTLE LANGUAGES
Description: Unpublished source code and related files accompanying the article
by John Sadler in which he presents Ficl, short for "Forth-Inspired Command
Language," an interpreter that has a system interface similar in spirit to Tcl,
but specifically designed for embedded systems with minimal resources. Requires
UNZIP/PKUNZIP to extract.

File: CPROFILE.ZIP
Title: DYNAMICALLY RECONFIGURABLE SERVERS
Author: Ron Klatchko
Keywords: JAN99    PYTHON    INTERNET    SERVER
Description: Unpublished source code and related files accompanying the article
by Ron Klatchko in which he presents a dynamically reconfigurable server he 
implemented in Python, a portable, interpreted, extensible object-oriented
programming language. Requires UNZIP/PKUNZIP to extract.

File: WSH.TXT
Title: SCRIPTS FOR THE WINDOWS SCRIPTING HOST
Author: John Goalby
Keywords: JAN99    WINDOWS   SCRIPTING
Description: Published source code accompanying the article by John Goalby in
which he discusses Microsoft's Windows Scripting Host (WSH), a
language-independent batch-processing language for Win32. John presents a number
of useful self-contained scripts that are useful to software developers, not
just system adminstrators. Also see WSH.ZIP.

File: WSH.ZIP
Title: SCRIPTS FOR THE WINDOWS SCRIPTING HOST
Author: John Goalby
Keywords: JAN99    WINDOWS   SCRIPTING
Description: Unpublished source code and related files accompanying the article
by John Goalby in which he discusses Microsoft's Windows Scripting Host (WSH), a
language-independent batch-processing language for Win32. John presents a number
of useful self-contained scripts that are useful to software developers, not
just system adminstrators. Requires UNZIP/PKUNZIP to extract.

File: MATLAB.TXT
Title: MATLAB AS A SCRIPTING LANGUAGE
Author: Peter Webb and Gregory V. Wilson 
Keywords: JAN99    MATLAB   SCRIPTING   NUMERICS 
Description: Published source code example accompanying the article by Peter
Webb and Gregory V. Wilson in which they discuss the Matlab programming
language.

File: CPRO199.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: JAN99  C++   QUINCY 99   D-FLAT 2000
Description: Published source code accompanying the column by Al Stevens in
which he introduces a programmer editor that adresses some of the deficiencies
of the Win32 CEdit control. Quincy 99 is a Windows 95-hosted integrated
development environment for C/C++ DOS text-mode programming. Also see
CPRO199.ZIP.

File: CPRO199.ZIP
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: JAN99  C++   QUINCY 99   D-FLAT 2000
Description: Unpublished source code accompanying the column by Al Stevens in
which he introduces a programmer editor that adresses some of the deficiencies
of the Win32 CEdit control. Quincy 99 is a Windows 95-hosted integrated
development environment for C/C++ DOS text-mode programming. Requires
UNZIP/PKUNZIP to extract.

File: JQA199.TXT 
Title: JAVA Q&A
Author: Kenneth Hittleman and Ted Leung
Keywords: JAN99    JAVA   JDK 1.2   PORTING
Description: Published source code accompanying the article by Kenneth Hittleman
and Ted Leung in which they discuss what's involved in moving from JDK 1.1 to
JDK 1.2.

File: AA199.TXT
Title: ALGORITHM ALLEY
Author: Sasha Gontmakher and Ilan Horn
Keywords: JAN99   ALGORITHM   MEMORY MANAGEMENT
Description: Publishing source code accompanying the article by Sasha Gontmakher
and Ilan Horn in which they discuss common patterns of memory usage, and uses
that to develop a practical memory manager. Also see AA199.ZIP.

File: AA199.ZIP
Title: ALGORITHM ALLEY
Author: Sasha Gontmakher and Ilan Horn
Keywords: JAN99   ALGORITHM   MEMORY MANAGEMENT
Description: Unpublishing source code accompanying the article by Sasha
Gontmakher and Ilan Horn in which they discuss common patterns of memory usage,
and uses that to develop a practical memory manager. Requires UNZIP/PKUNZIP to
extract.

File: LET199.TXT
Title: LETTERS TO THE EDITOR
Author: Justin Gale, Robert Stafford, Oleg Kiselyov
Keywords: JAN99   LETTERS   ALGORITHM  VISUAL BASIC   DATE
Description: Published source code accompanying the Letters to the Editor
section of the January 1999 issue of DDJ. Letters and code written by Justin
Gale, Robert Stafford, and Oleg Kiselyov.





5



