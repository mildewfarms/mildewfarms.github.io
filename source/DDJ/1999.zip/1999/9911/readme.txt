November 1999 
Dr. Dobb's Journal  
 
File: LINUXIPC.TXT 
Title: LINUX, REAL-TIME LINUX, & IPC 
Author: Frederick M. Proctor  
Keywords: NOV99     LINUX       REAL-TIME      IPC 
Description: Published source code accompanying the article by Frederick M.
Proctor in which he examines two of the best IPC mechanisms available under
Linux--FIFO and shared memory. Alse see SHMEM.ZIP and SHMEX.ZIP.
 
File: SHMEM.ZIP 
Title: LINUX, REAL-TIME LINUX, & IPC 
Author: Frederick M. Proctor  
Keywords: NOV99     LINUX       REAL-TIME      IPC 
Description: Unpublished source code accompanying the article by Frederick
M. Proctor in which he examines two of the best IPC mechanisms available
under Linux--FIFO and shared memory. Requires UNZIP/PKUNZIP to extract.
 
File: SHMEX.TGZ 
Title: LINUX, REAL-TIME LINUX, & IPC 
Author: Frederick M. Proctor  
Keywords: NOV99     LINUX       REAL-TIME      IPC 
Description: Unpublished source code accompanying the article by Frederick
M. Proctor in which he examines two of the best IPC mechanisms available
under Linux--FIFO and shared memory. Same as SHMEM.ZIP, but in a gzip'd tar
archive.

File: NTINFO.TXT  
Title: INSIDE WINDOWS NT SYSTEM DATA  
Author: Sven B. Schreiber   
Keywords: NOV99     WINDOWS NT  
Description: Published source code accompanying the article by Sven B. Schreiber in which he  
examines the WIndows NT NtQuerySystemInformation function. Also see NTINFO.ZIP.  
  
File: NTINFO.ZIP
Title: INSIDE WINDOWS NT SYSTEM DATA  
Author: Sven B. Schreiber   
Keywords: NOV99     WINDOWS NT  
Description: Unpublished source code and releated files accompanying the article by Sven B. Schreiber in which he  examines the WIndows NT NtQuerySystemInformation function. Requires  UNZIP/PKUNZIP to extract.  

File:  PALMOS.ZIP  
Title: EXTENDING THE PALM OS 
Author: Greg Winton  
Keywords: NOV99    PALM    LIBRARIES    OPERATING SYSTEMS 
Description: Unpublished source code accompanying the article by Greg
Winton in which he takes a look at the Palm shared library model and
presents a shared library you can use. Requires UNZIP/PKUNZIP to extract.
 
File:  PTVOS.ZIP 
Title: THE POWERTV OPERATING SYSTEM 
Author: Morgan Woodson 
Keywords: NOV99    SET-TOP    OPERATING SYSTEMS     
Description: Unpublished source code accompanying the article by Morgan
Woodson in which he presents a weather/traffic camera viewer application
for the PowerTV operating system. Requires UNZIP/PKUNZIP to extract.
 
File: BERAYS.TXT 
Title: THE BERAYS RAY TRACER 
Author: Regan Russell
Keywords:  NOV99     BEOS    GRAPHICS   RAY TRACE    OPERATING SYSTEM 
Description: Published source code accompanying the article by Regan
Russell in which he presents BeRays, an object-oriented ray-tracer
application for the Be operating system that makes it easy to plug in new
rendering ideas. Also see RAYS-X86.ZIP.
 
File: RAYS-X86.ZIP 
Title: THE BERAYS RAY TRACER 
Author: Regan Russell
Keywords:  NOV99     BEOS    GRAPHICS   RAY TRACE    OPERATING SYSTEM 
Description: Unpublished source code accompanying the article by Regan
Russell in which he presents BeRays, an object-oriented ray-tracer
application for the Be operating system that makes it easy to plug in new
rendering ideas. Requires UNZIP/PKUNZIP to extract.
 
File: JBED.TXT 
Title: JBED: JAVE FOR REAL-TIME SYSTEMS 
Author: Jorgen Tryggvesson, Torbjorn Mattsson, Hansruedi Heeb  
Keywords:  NOV99     JAVA    REAL-TIME   
Description: Published source code files accompanying the article by Jorgen
Tryggvesson, Torbjorn Mattsson, and Hansruedi Heeb in which they describe
Jbed, a small, fast Java Virtual Machine for embedded real-time systems,
includes a complete real-time operating system.

File: JBED.ZIP 
Title: JBED: JAVE FOR REAL-TIME SYSTEMS 
Author: Jorgen Tryggvesson, Torbjorn Mattsson, Hansruedi Heeb  
Keywords:  NOV99     JAVA    REAL-TIME   
Description: Unpublished source code files accompanying the article by
Jorgen Tryggvesson, Torbjorn Mattsson, and Hansruedi Heeb in which they
describe Jbed, a small, fast Java Virtual Machine for embedded real-time
systems, includes a complete real-time operating system. Requires
UNZIP/PKUNZIP to extract.
 
File: MLE.TXT 
Title: MACHINE LEARNING & AGENT-BASED COMPUTING 
Author: Zhimin Ding and Li Liu 
Keywords: NOV99    MACHINE LEARNING   AGENTS    INTERNET  AI 
Description: Published source code accompanying the article Zhimin Ding and
Li Liu in which they discuss the application of machine-learning technology
to control software agents, and presents MLEngine--a general-purpose AI
engine with real-time learning capability. Also see MLE.ZIP.
 
File: MLE.ZIP 
Title: MACHINE LEARNING & AGENT-BASED COMPUTING 
Author: Zhimin Ding and Li Liu 
Keywords: NOV99    MACHINE LEARNING   AGENTS    INTERNET  AI 
Description: Unpublished source code accompanying the article Zhimin Ding
and Li Liu in which they discuss the application of machine-learning
technology to control software agents, and presents MLEngine--a
general-purpose AI engine with real-time learning capability. Requires
UNZIP/PKUNZIP to extract.
 
File: XMLCORBA.TXT 
Title: XML & CORBA 
Author: Dirk Hamstra 
Keywords: NOV99   XML    CORBA 
Description: Published source code and related files accompanying the
article by Dirk Hamstra in which he discusses the XML|IT toolkit from
CareFlow lets you automatically tag results returned from calls to CORBA
services, then format them using XML.
 
File: JQA1199.TXT  
Title: JAVA Q&A 
Author: Krishnan Rangaraajan 
Keywords: NOV99   JAVA    DESIGN BY CONTRACT   
Description: Published source code accompanying the article by Krishnan
Rangaraajan in which he discusses how Java can support Design-by-Contract.
 
File: AA1199.ZIP 
Title: ALGORITHM ALLEY 
Author: Tim Kientzle 
Keywords: NOV99   ALGORITHM   GRAPHICS  
Description: Unpublished source code accompanying the article by Tim
Kientzle in which he examines unsharp masking, a photographic technique
that increases the sharpness of photographic images. Requires UNZIP/PKUNZIP
to extract.

File: CPRO1199.ZIP
Title: C PROGRAMMING
Author: Al Stevens
Keywords: NOV99   C++  FRAMEWORK
Description: Unpublished source code accompanying the column by Al Stevens
in which he presents TYFC, a class framework for C++ developers. Requires
UNZIP/PKUNZIP to extract.
  
 
 
 
 
 
 
 
 
 
 
 

