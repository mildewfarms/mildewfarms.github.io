August 1999
Dr. Dobb's Journal 

File: FORMLATE.TXT
Title: THE FORUMLATE VISUAL PROGRAMMING LANGUAGE
Author: Allen Ambler
Keywords: AUG99    VISUAL PROGRAMMING    DATA
Description: Published source code accompanying the article by Allen Ambler in
which he discusses Formulate, a distributed visual programming language designed
for dealing with structured data.

File:  LEGOCPP.TXT
Title: MINDSTORM ROBOTICS AND VISUAL C++
Author: David Wendt
Keywords: AUG99  MINDSTORMS   ROBOTICS   C++
Description: Published source code accompanying the article by David Wendt in
which he a Visual C++ MFC program that combines Mindstorm Robotics RCX code with
C++ code to achieve a control robot's behavior. Also see LEGOCPP.ZIP.

File:  LEGOCPP.ZIP
Title: MINDSTORM ROBOTICS AND VISUAL C++
Author: David Wendt
Keywords: AUG99  MINDSTORMS   ROBOTICS   C++
Description: Unpublished source code and related files accompanying the article
by David Wendt in which he a Visual C++ MFC program that combines Mindstorm
Robotics RCX code with C++ code to achieve a control robot's behavior. Requires
UNZIP/PKUNZIP to extract.

File: SIMGRAPH.TXT
Title: SIMULATING GRAPHS AS PHYSICAL SYSTEMS
Author: Arne Frick, Georg Sander, and Kathleen Wang
Keywords:  AUG99     GRAPH     SIMULATION   ALGORITHM
Description: Published source code accompanying the article by  Arne Frick,
Georg Sander, and Kathleen Wang, in which they describe an algorithm based on a
physical system of springs for drawing a useful and aesthetically pleasing graph
from a large data set.

File: 1394ROM.TXT
Title: IEEE 1394 CONFIGURATION ROM DECODER
Author: William F. Alexander
Keywords:  AUG99     IEEE 1394    FIREWIRE   DEBUGGING 
Description: Published source code files accompanying the article by William F.
Alexander in which he presents the DUMPROM utility that lets you examine the
configuration ROM of any 1394 device. In the process, he examines the 1394
addressing scheme and other issues. Also see 1394ROM.ZIP

File: 1394ROM.ZIP
Title: IEEE 1394 CONFIGURATION ROM DECODER
Author: William F. Alexander
Keywords:  AUG99     IEEE 1394    FIREWIRE   DEBUGGING 
Description: Unpublished source code files accompanying the article by William
F. Alexander in which he presents the DUMPROM utility that lets you examine the
configuration ROM of any 1394 device. In the process, he examines the 1394
addressing scheme and other issues. Requires UNZIP/PKUNZIP to extract.

File: DISPATCH.TXT
Title: A TASK DISPATCHER FOR EMBEDDED SYSTEMS
Author: Ron Kreymborgi 
Keywords: AUG99    EMBEDDED SYSTEMS    C
Description: Published source code accompanying the article by Ron Kreymborgi in
which he presents a dispatcher implemented in C that's small enough to be
reliably implemented in the assembly language of the destination processor. Also
see DISPATCH.ZIP.

File: DISPATCH.ZIP
Title: A TASK DISPATCHER FOR EMBEDDED SYSTEMS
Author: Ron Kreymborgi 
Keywords: AUG99    EMBEDDED SYSTEMS    C
Description: Unpublished source code and related files accompanying the article
by Ron Kreymborgi in which he presents a dispatcher implemented in C that's
small enough to be reliably implemented in the assembly language of the
destination processor. Requires UNZIP/PKUNZIP to extract.

File: HTMLPARS.TXT
Title: USING INTERNET EXPLORER'S HTML PARSER
Author: Andrew Tucker
Keywords: AUG99    HTML   INTERNET EXPLORER    PARSING    COM
Description: Published source code accompanying the article by Andrew Tucker in
which he discusses Microsoft's Internet Explorer 4.0 browser provides COM
interfaces that lets you easily load and parse HTML without actually having to
display it. Andrew describes these interfaces and implement a C++ class that
lets you take advantage of them. Also see HTMLPARS.ZIP

File: HTMLPARS.ZIP
Title: USING INTERNET EXPLORER'S HTML PARSER
Author: Andrew Tucker
Keywords: AUG99    HTML   INTERNET EXPLORER    PARSING    COM
Description: Unpublished source code and related files by Andrew Tucker in which
he discusses Microsoft's Internet Explorer 4.0 browser provides COM interfaces
that lets you easily load and parse HTML without actually having to display it.
Andrew describes these interfaces and implement a C++ class that lets you take
advantage of them.  Requires UNZIP/PKUNZIP to extract.

FILE: SQLEXD.TXT
Title: EXTENDERS, UDFs, AND STORED PROCEDURES
Author: Ken North
Keywords: AUG99    SQL   DATABASE   UDF
Description: Published source code accompanying the article by Ken North in
which he discusses the emerging generation of feature-rich applications require
multimedia, geo-spatial data, and types that are more complex than traditional
SQL rows and columns. 

File: JQA899.TXT 
Title: JAVA Q&A
Author: W. David Pitt
Description: Published source code accompanying the article by  David Pitt in
which he examines Java's ability to handle exception handling. Also see
JQA899.ZIP

File: JQA899.ZIP 
Title: JAVA Q&A
Author: W. David Pitt
Keywords: AUG99    JAVA   EXCEPTION HANDLING
Description: Unpublished source code and related files accompanying the article
by David Pitt in which he examines Java's ability to handle exception handling.
Requires UNZIP/PKUNZIP to extract.

File: AA899.TXT
Title: ALGORITHM ALLEY
Author: Steven Pigeon
Keywords: AUG99   WAVELETS    IMAGE MANIPULATION   ALGORITHM
Description: Published source code accompanying the article by Steven Pigeon in
which he discusses wavelets which offer an attractive alternative when it comes
to image compression. Also see AA899.ZIP.

File: AA899.ZIP
Title: ALGORITHM ALLEY
Author: Steven Pigeon
Keywords: AUG99   WAVELETS    IMAGE MANIPULATION   ALGORITHM
Description: Unpublished source code and related files accompanying the article
by Steven Pigeon in which he discusses wavelets which offer an attractive
alternative when it comes to image compression. Requires UNZIP/PKUNZIP to
extract.

File: CPRG899.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens 
Keywords: AUG99   C++
Description: Published examples accompanying the column by Al Stevens in which
he discusses C++ arguments.



4


