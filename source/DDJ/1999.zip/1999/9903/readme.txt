March 1999
Dr. Dobb's Journal 

File: PROVIDER.TXT
Title: THE JAVA PROVIDER ARCHITECTURE
Author: Paul Tremblett
Keywords: MAR99    JAVA    CRYPTOGRAPHY    SIMULATION
Description: Published source code accompanying the article by Paul Tremblett in
which he uses the JDK's Java Cryptography Extension to implement a cipher
algorithm that simulates the Enigma machine made famous by Germany in World War
II. Also see PROVIDER.ZIP.

File: PROVIDER.ZIP
Author: Paul Tremblett
Keywords: MAR99    JAVA    CRYPTOGRAPHY    SIMULATION
Description: Unpublished source code and related files accompanying the article
by Paul Tremblett in which he uses the JDK's Java Cryptography Extension to
implement a cipher algorithm that simulates the Enigma machine made famous by
Germany in World War II. Requires UNZIP/PKUNZIP to extract.

File:  DIGITCL.TXT
Title: HIERARCHICAL LOGIC SIMULATION
Author: Donald C. Craig
Keywords: MAR99   SIMULATION   C++    TCL
Description: Published source code accompanying the article by Donald Craig in
which presents an approach by which hardware components can be represented and
simulated hierarchically using C++. His simulation strategy is completely
asynchronous, meaning that the concept of global time has been abandoned in
favor of each component maintaining its own concept of local time. Also see
DIGITCL.ZIP.

File:  DIGITCL.ZIP
Title: HIERARCHICAL LOGIC SIMULATION
Author: Donald C. Craig
Keywords: MAR99   SIMULATION   C++    TCL
Description: Unpublished source code and related files accompanying the article
by Donald Craig in which presents an approach by which hardware components can
be represented and simulated hierarchically using C++. His simulation strategy
is completely asynchronous, meaning that the concept of global time has been
abandoned in favor of each component maintaining its own concept of local time.
Requires UNZIP/PKUNZIP to extract.

File: WOOKIE.TXT
Title: WOOKIE: A 68HC11 EMULATOR
Author: Kalle Anderson, Jason Buttron, Paul Clarke, Matt Enwald
Keywords:  MAR99   EMULATOR    68HC11
Description: Published source code accompanying the article by Kalle Anderson,
Jason Buttron, Paul Clarke, and Matt Enwald in which they present WOOKIE, short
for the "Wireless Object-Oriented Kindly Interfaced Emulator," a Win32 emulator
for 68HC11-based software development. Our authors discuss both its development
and use. Wilbert Bilderbeek, Harry Broeders, and Alex van Rooijen then introduce
the THRSim11 68HC11 simulator which they designed and built. Also see
WOOKCODE.ZIP, WOOKEXE.ZIP, WOOKDEMO.ZIP, and THRSIM11.ZIP.

File: WOOKCODE.ZIP
Title: WOOKIE: A 68HC11 EMULATOR
Author: Kalle Anderson, Jason Buttron, Paul Clarke, Matt Enwald
Keywords:  MAR99   EMULATOR    68HC11
Description: Unpublished source code and related files accompanying the article
by Kalle Anderson, Jason Buttron, Paul Clarke, and Matt Enwald in which they
present WOOKIE, short for the "Wireless Object-Oriented Kindly Interfaced
Emulator," a Win32 emulator for 68HC11-based software development. Our authors
discuss both its development and use. Requires UNZIP/PKUNZIP to extract.

File: WOOKDEMO.ZIP
Title: WOOKIE: A 68HC11 EMULATOR
Author: Kalle Anderson, Jason Buttron, Paul Clarke, Matt Enwald
Keywords:  MAR99   EMULATOR    68HC11
Description: Unpublished demo programs and data accompanying the article by
Kalle Anderson, Jason Buttron, Paul Clarke, and Matt Enwald in which they
present WOOKIE, short for the "Wireless Object-Oriented Kindly Interfaced
Emulator," a Win32 emulator for 68HC11-based software development. Our authors
discuss both its development and use. Requires UNZIP/PKUNZIP to extract.

File: WOOKEXE.ZIP
Title: WOOKIE: A 68HC11 EMULATOR
Author: Kalle Anderson, Jason Buttron, Paul Clarke, Matt Enwald
Keywords:  MAR99   EMULATOR    68HC11
Description: Executable version of WOOKIE emulator  accompanying the article by
Kalle Anderson, Jason Buttron, Paul Clarke, and Matt Enwald in which they
present WOOKIE, short for the "Wireless Object-Oriented Kindly Interfaced
Emulator," a Win32 emulator for 68HC11-based software development. Our authors
discuss both its development and use. Requires UNZIP/PKUNZIP to extract.

File: THRSIM11.ZIP 
Title: THE THRSIM11 68HC11 SIMULATOR
Author: Wilbert Bilderbeek, Harry Broeders, and Alex van Rooijen
Keywords:  MAR99   EMULATOR    68HC11
Description: Unpublished source code and related files accompanying the sidebar
by Wilbert Bilderbeek, Harry Broeders, and Alex van Rooijen in which they
present the THRSIM11 68HC11 Simulator. This information is part of the article
"WOOKIE: A 68HC11 EMULATOR" by Kalle Anderson, Jason Buttron, Paul Clarke, and
Matt Enwald. Requires UNZIP/PKUNZIP to extract.

File: CEEMUL.TXT
Title: THE WINDOWS CE EMULATOR
Author: Aspi Havewala
Keywords: MAR99   WINDOWS CE   WIN32    EMULATOR
Description: Published source code accompanying the article by Aspi Havewala in
which he examines the Windows CE SDK's functional emulation shell that mimics a
Windows CE Handheld PC (HPC) shell. 

File: MCORE.TXT
Title: LOW-LEVEL APIS FOR EMBEDDED SYSTEMS
Author: Tom Cunningham and Chad Peckham
Keywords:  MAR99    M-CORE   API   
Description: Published source code accompanying the article by Tom Cunningham
and Chad Peckham in which they APIs for embedded and real-time systems tackle
debugger interfacing, task management, low-level device I/O, and the like. Tom
and Chad examine a pair of APIs that are typical of low-level programming
interfaces in embedded environments, focusing on the Motorola M-CORE
architecture.

File: LDAP.TXT
Title: UNDERSTANDING LDAP
Author: Basit Hussain
Keywords:  MAR99    LDAP   NETWORKING   
Description: Published source code accompanying the article by Basit Hussain in
which he examines LDAP, short for "Lightweight Directory Access Protocol," a
platform-independent mechanism of searching, storing, and replicating
information. Basit examines LDAP and presents examples of how you can use it.
Also see LDAP.ZIP.

File: LDAP.ZIP
Title: UNDERSTANDING LDAP
Author: Basit Hussain
Keywords:  MAR99    LDAP   NETWORKING   
Description: Unpublished source code and related files accompanying the article
by Basit Hussain in which he examines LDAP, short for "Lightweight Directory
Access Protocol," a platform-independent mechanism of searching, storing,
and replicating information. Basit examines LDAP and presents examples of how
you can use it. 
Requires UNZIP/PKUNZIP to extract.

File: ANTLR.TXT
Title: COMPILER CONSTRUCTION WITH ANTLR AND JAVA
Author: Gary L. Schaps
Keywords: MAR99    JAVA   ANTLR   COMPILERS
Description: Published source code accompanying the article by Gary L. Schaps in
which he discusses ANTLR, short for "Another Tool for Language Recognition." It
is a language tool that gives you a framework for constructing recognizers,
compilers, and translators for C, C++, and Java. Also see ANTLR.ZIP.

File: ANTLR.ZIP
Title: COMPILER CONSTRUCTION WITH ANTLR AND JAVA
Author: Gary L. Schaps

Keywords: MAR99    JAVA   ANTLR   COMPILERS
Description: Unpublished source code accompanying the article by Gary L. Schaps
in which he discusses ANTLR, short for "Another Tool for Language Recognition."
It is a language tool that gives you a framework for constructing recognizers,
compilers, and translators for C, C++, and Java. Requires UNZIP/PKUNZIP to
extract.

File: MOTION.TXT
Title: CONTROLLING MOTION-TRACKING DEVICES
Author: Mike Harrington
Keywords: MAR99   VR    C++    3D
Description: Published source code accompanying the article by Mike Harrington
in which he discusses motion-tracking devices--those which report on an object's
position and/or orientation in real-time as it moves, are necessary to navigate
3D simulated worlds. 

File: JQA399.TXT 
Title: JAVA Q&A
Author: Andy Wilson
Keywords: MAR99    JAVA     DELEGATE    MICROSOFT   
Description: Published source code accompanying the article by Andy Wilson in
which he discusses how you can use the Microsoft Java keyword "delegate." Also
see JQA399.ZIP.

File: JQA399.ZIP 
Title: JAVA Q&A
Author: Andy Wilson
Keywords: MAR99    JAVA     DELEGATE    MICROSOFT   
Description: Unpublished source code and related files accompanying the article
by Andy Wilson in which he discusses how you can use the Microsoft Java keyword
"delegate." Requires UNZIP/PKUNZIP to extract.

File: AA399.TXT
Title: ALGORITHM ALLEY
Author: Tim Kientzle
Keywords: MAR99   ALGORITHM   
Description: Published source code accompanying the article by Tim Kientzle in
which he discusses the Discrete Cosine Transform (DCT) which is a crucial part
of modern image and sound compression. Tim discusses several fast algorithms for
computing the 8-point DCT and IDCT. Also see AA399.ZIP.

File: AA399.ZIP
Title: ALGORITHM ALLEY
Author: Tim Kientzle
Keywords: MAR99   ALGORITHM   
Description: Unpublished source code accompanying the article by Tim Kientzle in
which he discusses the Discrete Cosine Transform (DCT) which is a crucial part
of modern image and sound compression. Tim discusses several fast algorithms for
computing the 8-point DCT and IDCT. Requires UNZIP/PKUNZIP to extract.










6


