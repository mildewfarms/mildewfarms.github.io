February 1999
Dr. Dobb's Journal 

File: LIGHTWEI.TXT
Title: JAVA AND LIGHTWEIGHT COMPONENTS
Author: David K. Perelman-Hall
Keywords: FEB99    JAVA    COMPONENTS
Description: Published source code accompanying the article by David K.
Perelman-Hall in which he discusses JDK 1.1 lightweight components that let you
give programs exactly the same look-and-fell--no matter which platform hosts the
VM. To examine lightweight component development, David presents his
dph.awt.lightweight package. Also see LIGHTWEI.ZIP.

File: LIGHTWEI.ZIP
Title: JAVA AND LIGHTWEIGHT COMPONENTS
Author: David K. Perelman-Hall
Keywords: FEB99    JAVA    COMPONENTS
Description: Unpublished source code accompanying the article by David K.
Perelman-Hall in which he discusses JDK 1.1 lightweight components that let you
give programs exactly the same look-and-fell--no matter which platform hosts the
VM. To examine lightweight component development, David presents his
dph.awt.lightweight package. Requires UNZIP/PKUNZIP to extract.

File:  JSEARCH.TXT
Title: A JAVA APPLET SEARCH ENGINE
Author: Tim Kientzle
Keywords: FEB99   DATABASE   JAVA   PERL   SEARCHING
Description: Published source code accompanying the article by Tim Kientzle in
which presents a Java search engine designed for use on HTML-based CD-ROMs as
well as web sites. 
Also see JSEARCH.ZIP.

File:  JSEARCH.ZIP
Title: A JAVA APPLET SEARCH ENGINE
Author: Tim Kientzle
Keywords: FEB99   DATABASE   JAVA   PERL   SEARCHING
Description: Unpublished source code and related files accompanying the article
by Tim Kientzle in which presents a Java search engine designed for use on
HTML-based CD-ROMs as well as web sites. Requires UNZIP/PKUNZIP to extract.

File: J2D.TXT
Title: THE JAVA 2D API
Author: Bill Loeb
Keywords:  FEB99    JAVA     AWT   GRAPHICS
Description: Published source code accompanying the article by Bill Loeb in
which he discusses the Java 2D API, a set of functions that is a much more
flexible and full-featured rendering package than previous versions of the
Abstract Windowing Toolkit (AWT). It provides enhanced graphics, text, and image
handling, supports color definition and composition, and is extensible. 

File: PROPEDIT.TXT
Title: WRITING JAVABEAN PROPERTY EDITORS
Author: Morgan Kinne
Keywords:  FEB99    JAVA      JAVABEANS   
Description: Published source code accompanying the article by Morgan Kinne in
which he shows how you build JavaBean property editors, focusing on the
relationships between the visual tool, property editor, and bean. Also see
PROPEDIT.ZIP.

File: PROPEDIT.ZIP
Title: WRITING JAVABEAN PROPERTY EDITORS
Author: Morgan Kinne
Keywords:  FEB99    JAVA      JAVABEANS   
Description: Unpublished source code and related files accompanying the article
by Morgan Kinne in which he shows how you build JavaBean property editors,
focusing on the relationships between the visual tool, property editor, and
bean. Requires UNZIP/PKUNZIP to extract.

File: PJPHONE.TXT
Title: PERSONALJAVA & INFORMATION APPLIANCES, PART II
Author: Jaison Dolvane and Kumanan Yogaratnam
Keywords: FEB99    JAVA   PERSONALJAVA    EMBEDDED SYSTEMS
Description: Published source code accompanying the article by Jaison Dolvane
and Kumanan Yogaratnam in which they discuss PersonalJava, the Java Application
Environment designed specifically for low-resource environments and diverse
visual displays. In this installment, they develop a phone directory application
for a web-phone appliance. Also see PJPHONE.ZIP.

File: PJPHONE.ZIP
Title: PERSONALJAVA & INFORMATION APPLIANCES, PART II
Author: Jaison Dolvane and Kumanan Yogaratnam
Keywords: FEB99    JAVA   PERSONALJAVA    EMBEDDED SYSTEMS
Description: Unpublished source code and related files accompanying the article
by Jaison Dolvane and Kumanan Yogaratnam in which they discuss PersonalJava, the
Java Application Environment designed specifically for low-resource environments
and diverse visual displays. In this installment, they develop a phone directory
application for a web-phone appliance. Requires UNZIP/PKUNZIP to extract.

File: JPERL.TXT
Title: JPERL: ACCESSING PERL FROM JAVA
Author: S. Balamurugan
Keywords: FEB99    JAVA    PERL  
Description: Published source code accompanying the article by S. Balamurugan in
which he presents Jperl, a package (written in C++) that provides an interface
to Perl from Java. Jperl's API also makes accesing Perl from C++ simple. Also
see JPERL.ZIP.

File: JPERL.ZIP
Title: JPERL: ACCESSING PERL FROM JAVA
Author: S. Balamurugan
Keywords: FEB99    JAVA    PERL  
Description: Unpublished source code and related files accompanying the article
by S. Balamurugan in which he presents Jperl, a package (written in C++) that
provides an interface to Perl from Java. Jperl's API also makes accesing Perl
from C++ simple. Requires UNZIP/PKUNZIP to extract.

File: JCARD.TXT
Title: JAVA CARD APPLICATION DEVELOPMENT
Author: Darryl Barnes
Keywords: FEB99    JAVA   EMBEDDED SYSTEMS     JAVA CARD 
Description: Published source code accompanying the article by Darryl Barnes in
which he examines the Java Card specificiation, a subset of Java designed for
smart-card applications. Darryl discusses Java Card and presents a typical
smart-card applet.

File: PERSIST.TXT
Title: CREATING SIGNED, PERSISTENT JAVA APPLETS
Author: Paul Brigner
Keywords: FEB99     JAVA     SECURITY
Description: Published source code accompanying the article by Paul Brigner in
which he examines the facilities that both Netscape and Microsoft have
facilities for signed, persistent applet deployment, thereby extending the Java
security framework.  Also see PERSIST.ZIP.

File: PERSIST.ZIP
Title: CREATING SIGNED, PERSISTENT JAVA APPLETS
Author: Paul Brigner
Keywords: FEB99     JAVA     SECURITY
Description: Unpublished source code and related files accompanying the article
by Paul Brigner in which he examines the facilities that both Netscape and
Microsoft have facilities for signed, persistent applet deployment, thereby
extending the Java security framework. Requires UNZIP/PKUNZIP to extract.

File: RELAY.TXT
Title: COMPARING WFC AND JFC 
Author: David M. Johnson
Keywords: FEB99    JAVA   JFC   WFC   WINDOWS  
Description: Published source code accompanying the article by David M. Johnson
in which he compares Microsoft's Windows Foundation Classes (WFC) with Sun's
Java Foundation Classes (JFC) framework by developing an Internet Relay Chat
(IRC) chat-client called "Relay." Also see RELAY.ZIP.

File: RELAY.ZIP
Title: COMPARING WFC AND JFC 
Author: David M. Johnson
Keywords: FEB99    JAVA   JFC   WFC   WINDOWS  
Description: Unpublished source code and related files accompanying the article
by David M. Johnson in which he compares Microsoft's Windows Foundation Classes
(WFC) with Sun's Java Foundation Classes (JFC) framework by developing an
Internet Relay Chat (IRC) chat-client called "Relay." Requires UNZIP/PKUNZIP to
extract.

File: JQA299.TXT 
Title: JAVA Q&A
Author: Dave Angel and Andy Wilson
Keywords: FEB99    JAVA     SECURITY   ENCRYPTION   
Description: Published source code accompanying the article by Dave Angel and
Andy Wilson in which they show how you can store a Java app in a self-executing
encrypted file. In doing so, they present CodePacker, a custom loader that is
both easy to install--it's self-extracting--and secure. Also see JQA299.ZIP.

File: JQA299.ZIP
Title: JAVA Q&A
Author: Dave Angel and Andy Wilson
Keywords: FEB99    JAVA     SECURITY   ENCRYPTION   
Description: Unpublished source code and related files accompanying the article
by Dave Angel and Andy Wilson in which they show how you can store a Java app in
a self-executing encrypted file. In doing so, they present CodePacker, a custom
loader that is both easy to install--it's self-extracting--and secure. Requires
UNZIP/PKUNZIP to extract.

File: AA299.TXT
Title: ALGORITHM ALLEY
Author: Andrew Colin
Keywords: FEB99   ALGORITHM   
Description: Published source code accompanying the article by Andrew Colin in
which he presents the analytic hierarchy process (AHP), a decision-making tool
reducing complex decisions to a series of comparisons and rankings. The results
are then combined to give a single, unequivocal result. 

File: DESIGN.TXT
Title: DESIGN BY INTERFACE
Author: Robb Shecter
Keywords: FEB99   ALGORITHM   OBJECT ORIENTED    DESIGN
Description: Published source code accompanying the article by Robb Shecter in
which he presents step-by-step instructions for making applications both
reusable and independent using a technique called "design by interface" and the
NetComponents class library from ORO.

File: PARADIGM.TXT
Title: PROGRAMMING PARADIGMS 
Author: Michael Swaine
Keywords: FEB99     REBOL   
Description: Published source code accompanying the article by  by Michael
Swaine in which he examines Rebol, a messaging-based programming language
designed for networks and the Internet.

File: ECCO118.ZIP
Title: DR. ECCO'S OMNIHEURIST CORNER
Author: Dennis E. Shasha
Keywords: FEB99     PERL
Description: Unpublished source code accompanying the article by  by Dennis
Shasha in which he presents Perl code that solves the "Directed Evolution"
problem published in the November 1998 issue of Dr. Dobb's Journal. This code
was written and submitted by Eric Haines (erich@acm.org).






5


