June 1999
Dr. Dobb's Journal 

File: FACTORY.TXT
Author: John J. Rofrano
Title: JAVA PORTABILITY BY DESIGN
Keywords: JUN99    JAVA    E-COMMERCE
Description: Published source code accompanying the article by 
John J. Rofrano in which he uses Factory classes to ensure that 
application code remains unaware of the platform it's running on. 
John describes how his team used factory classes when building an 
e-commerce catalog search engine written entirely in Java. 

File:  XPLAT.TXT
Title: CROSS-PLATFORM DESIGN STRATEGIES
Author: Bob Krause
Keywords: C++    DESIGN   CROSS-PLATFORM   PORTABILITY
Description: Published source code accompanying the article by 
Bob Krause in which discusses the cross-platform architecture his 
company uses when building applications that run on multiple 
platforms. In doing so, he presents a set of thread classes 
developed for use on both Macintosh and Windows.

File: SEQUENCE.TXT
Title: A DNA SEQUENCE CLASS IN PERL
Author: Lincoln Stein
Keywords:  JUN99     DNA   PERL   HUMAN GENOME PROJEC
Description: Published source code accompanying the article by 
Lincoln Stein in which he describes some of Perl's object-
oriented features in his Sequence library, which manipulates DNA 
sequences. This code was developed as part of the Human Genome 
Project, a multinational project to determine the entire human 
DNA sequence by the year 2003. Also see SEQUENCE.ZIP.

File: SEQUENCE.ZIP
Title: A DNA SEQUENCE CLASS IN PERL
Author: Lincoln Stein
Keywords:  JUN99     DNA   PERL   HUMAN GENOME PROJEC
Description: Unpublished source code and related files 
accompanying the article by Lincoln Stein in which he describes 
some of Perl's object-oriented features in his Sequence library, 
which manipulates DNA sequences. This code was developed as part 
of the Human Genome Project, a multinational project to determine 
the entire human DNA sequence by the year 2003. Requires 
UNZIP/PKUNZIP to extract.

File: TCLEXTEN.TXT
Title: EXTENSIBILITY IN TCL
Author: John Ousterhout
Keywords: JUN99     TCL    SCRIPTING
Description: Published source code accompanying the article by 
John Ousterhout in which he describes the design decisions he 
made to ensure that the Tcl scripting language would be highly 
extensible.

File: WIN32DV.TXT
Title: WIN32 DRIVERS FOR DIGITAL/VIDEO CAMCORDERS
Author: Thomas Tewell
Keywords:  JUN99    IEEE 1394     DIGITAL/VIDEO
Description: Published source code accompanying the article by 
Thomas Tewell in which he presents a complete IEEE 1394 class 
driver package for Windows 98 and his Sony DCR-PC10 digital/video 
camcorder. Also see WIN32DV.ZIP.

File: WIN32DV.ZIP
Title: WIN32 DRIVERS FOR DIGITAL/VIDEO CAMCORDERS
Author: Thomas Tewell
Keywords:  JUN99    IEEE 1394     DIGITAL/VIDEO
Description: Unpublished source code, binaries, and utilities 
accompanying the article by Thomas Tewell in which he presents a 
complete IEEE 1394 class driver package for Windows 98 and his 
Sony DCR-PC10 digital/video camcorder. Requires UNZIP/PKUNZIP to 
extract.

File: MAP.TXT
Title: ROTATING A WEATHER MAP
Author: Robert D. Grappel
Keywords:  JUN99     ALGORITHM    GRAPHICAL   ROTATION
Description: Published source code accompanying the article by 
Robert D. Grappel in which he describes and implements an 
algorithm he developed to efficiently perform rotation of 
graphical weather maps used by airplane pilots. He then suggests 
techniques you can use to optimize other time-limited computer 
applications.

File: VFWCNTRL.TXT
Title: A VIDEO FOR WINDOWS ACTIVEX CONTROL
Author: Ofer Laor
Keywords: JUN99      VIDEO FOR WINDOWS   ACTIVEX   VISUAL BASIC
Description: Published source code accompanying the article by 
Ofer Laor in which he presents oVFW, an ActiveX control that 
encapsulates the Video for Windows API so that Visual Basic 
applications can easily interact with video-capture cards. Also 
see VFWCNTRL.ZIP.

File: VFWCNTRL.ZIP
Title: Title: A VIDEO FOR WINDOWS ACTIVEX CONTROL
Author: Ofer Laor
Keywords: JUN99      VIDEO FOR WINDOWS   ACTIVEX   VISUAL BASIC
Description: Unpublished source code and related files 
accompanying the article by Ofer Laor in which he presents oVFW, 
an ActiveX control that encapsulates the Video for Windows API so 
that Visual Basic applications can easily interact with video-
capture cards. Requires UNZIP/PKUNZIP to extract.

File: CPRG699.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: JUN99   C++    MIDI
Description: Published source code accompanying the article by Al 
Stevens in which he builds a MIDI jukebox. Also see JUKEBOX.ZIP. 

File: JUKEBOX.ZIP
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: JUN99   C++    MIDI
Description: Unpublished source code and related files 
accompanying the article by Al Stevens in which he builds a MIDI 
jukebox.  Requires UNZIP/PKUNZIP to extract.

File: JQA699.TXT 
Title: JAVA Q&A
Author: James Begole, Philip L. Isenhour, and Clifford A. Shaffer
Keywords: JUN99    JAVA     JAVABEANS
Description: Published source code accompanying the article by 
James Begole, Philip L. Isenhour, and Clifford A. Shaffer, in 
which they ask the question "Can JavaBeans be shared?" Our 
authors show you how. Their approach is based on a replicated 
architecture, where each collaborator maintains a copy of the 
shared data. Also see JQA699.ZIP.

File: JQA699.ZIP
Title: JAVA Q&A
Author: James Begole, Philip L. Isenhour, and Clifford A. Shaffer
Keywords: JUN99    JAVA     JAVABEANS
Description: Unpublished source code and related files 
accompanying the article by James Begole, Philip L. Isenhour, and 
Clifford A. Shaffer, in which they ask the question "Can 
JavaBeans be shared?" Our authors show you how. Their approach is 
based on a replicated architecture, where each collaborator 
maintains a copy of the shared data. Requires UNZIP/PKUNZIP to 
extract.

File: AA699.TXT
Title: ALGORITHM ALLEY
Author: Bill McDaniel   
Keywords: JUN99   ALGORITHM   SORTING
Description: Published source code accompanying the article by 
Bill McDaniel in which he presents a variation of the Merge Sort 
algorithm that addresses weaknesses in traditional sorting 
algorithms.







