October 1999
Dr. Dobb's Journal 

File: DATASTRU.TXT
Title: DATA STRUCTURES AS OBJECTS
Author: Jiri Soukup 
Keywords: OCT99     C++    DATA STRUCTURES
Description: Published source code accompanying the article by Jiri Soukup in
which he discusses what's involved in writing complex programs, which include a
complex interaction among objects and employ many data structures and design
patterns. 

File:  SMARTPTR.TXT
Title: IMPLEMENTING OPERATOR->* FOR SMART POINTERS
Author: Scott Meyers
Keywords: OCT99    C++    
Description: Published source code accompanying the article by Scott Meyers in
which he examines how you can make smart pointers as behaviorally compatible
with built-in pointers as possible, you should support operator->*--just like
built-in pointers do. Also see SMARTPTR.ZIP.

File:  SMARTPTR.ZIP
Title: IMPLEMENTING OPERATOR->* FOR SMART POINTERS
Author: Scott Meyers
Keywords: OCT99    C++    
Description: Unpublished source code accompanying the article by Scott Meyers
in which he examines how you can make smart pointers as behaviorally compatible
with built-in pointers as possible, you should support operator->*--just like
built-in pointers do. Requires UNZIP/PKUNZIP to extract.

File: CPPPERF.TXT
Title: IMPROVING C++ PROGRAM PERFORMANCE
Author: Stanley Lippman
Keywords:  OCT99     C++    PERFORMANCE
Description: Published source code accompanying the article by  Stanley Lippman
in which he examines the three most common strategies for C++ program speedup,
then points out that it often enough to simply review the code for
inappropriate C++ programming idioms. 

File: LINKING.TXT
Title: PSEUDO-INCREMENTAL LINKING FOR C/C++ 
Author: William A. Hoffman and Rupert W. Curwen
Keywords:  OCT99     C++    LINKING
Description: Published source code files accompanying the article by William A.
Hoffman and Rupert W. Curwen in which they describe a method for managing
link/run time which provides fast link/run time during development, without
sacrificing run time in the final product, and without the use of customized,
non-standard linking software. Also see LINKING.ZIP

File: LINKING.ZIP
Title: PSEUDO-INCREMENTAL LINKING FOR C/C++ 
Author: William A. Hoffman and Rupert W. Curwen
Keywords:  OCT99     C++    LINKING
Description: Unpublished source code files accompanying the article by William
A. Hoffman and Rupert W. Curwen in which they describe a method for managing
link/run time which provides fast link/run time during development, without
sacrificing run time in the final product, and without the use of customized,
non-standard linking software. Requires UNZIP/PKUNZIP to extract.

File: WAP.TXT
Title: THE WIRELESS APPLICATION PROTOCOL
Author: Steve Mann
Keywords: OCT99    C++   WIRELESS     PROTOCOL
Description: Published source code accompanying the article by Steve Mann in
which he discusses WAP, short for "Wireless Application Protocol," a
multi-layer communications architecture that borrows heavily from existing
Internet standards while solving problems specific to wireless networks. Also
see WAP.ZIP.

File: WAP.ZIP
Title: THE WIRELESS APPLICATION PROTOCOL
Author: Steve Mann
Keywords: OCT99    C++   WIRELESS     PROTOCOL
Description: Unpublished source code and related files accompanying the article
by Steve Mann in which he discusses WAP, short for "Wireless Application
Protocol," a multi-layer communications architecture that borrows heavily from
existing Internet standards while solving problems specific to wireless
networks. Requires UNZIP/PKUNZIP to extract.

File: SMALL.TXT
Title: THE SMALL SCRIPTING LANGUAGE
Author: Thiadmer Riemersma
Keywords: OCT99    C    SMALL-C     SCRIPTING
Description: Published source code accompanying the article by Thiadmer
Riemersma in which he discusses Small--a "Small-C" without the "C." Small is a
typeless, 32-bit extension language with a C-like syntax that features fast
execution speed, stability, simplicity, and a small footprint. Also see
SMALLKIT.ZIP.

File: SMALLKIT.ZIP
Title: THE SMALL SCRIPTING LANGUAGE
Author: Thiadmer Riemersma
Keywords: OCT99    C    SMALL-C     SCRIPTING
Description: Unpublished source code and related files accompanying the article
by Thiadmer Riemersma in which he discusses Small--a "Small-C" without the "C."
Small is a typeless, 32-bit extension language with a C-like syntax that
features fast execution speed, stability, simplicity, and a small footprint.
Requires UNZIP/PKUNZIP to extract.

File: HTMLTHIN.TXT
Title: HTML THIN CLIENT AND TRANSACTIONS
Author: Jean-Francois Touchette 
Keywords: OCT99    HTML   E-COMMERCE   JAVA   JSP  
Description: Published source code accompanying the article by Jean-Francois
Touchette in which he shows how you can implement reliable, non-repeatable
transactions using a technique that is applicable to any Java Sever Development
Kit-based architecture.  Also see HTMLTHIN.ZIP.


File: HTMLTHIN.ZIP
Title: HTML THIN CLIENT AND TRANSACTIONS
Author: Jean-Francois Touchette 
Keywords: OCT99    HTML   E-COMMERCE   JAVA   JSP  
Description: Unpublished source code accompanying the article by Jean-Francois
Touchette in which he shows how you can implement reliable, non-repeatable
transactions using a technique that is applicable to any Java Sever Development
Kit-based architecture. Requires UNZIP/PKUNZIP to extract.

File: PETE.TXT
Title: PETE: THE PORTABLE EXPRESSION TEMPLATE ENGINE
Author: Scott Haney, James Crotinger, Steve Karmesin, Stephen Smith
Keywords: OCT99   C++    Templates 
Description: Published source code accompanying the article by Scott Haney,
James Crotinger, Steve Karmesin, and Stephen Smith in which they present PETE,
short for "Portable Expression Template Engine"--a C++ framework that lets
users easily add expression-template functionality to container classes and
perform complex expression manipulations. Also see PETE.ZIP.

File: PETE-2_0.ZIP
Title: PETE: THE PORTABLE EXPRESSION TEMPLATE ENGINE
Author: Scott Haney, James Crotinger, Steve Karmesin, Stephen Smith
Keywords: OCT99   C++    Templates  Win32
Description: Win32 version of the unpublished source code and related files
accompanying the article by Scott Haney, James Crotinger, Steve Karmesin, and
Stephen Smith in which they present PETE, short for "Portable Expression
Template Engine"--a C++ framework that lets users easily add
expression-template functionality to container classes and perform complex
expression manipulations. Requires UNZIP/PKUNZIP to extract.

File: PETE-2_0.SIT
Title: PETE: THE PORTABLE EXPRESSION TEMPLATE ENGINE
Author: Scott Haney, James Crotinger, Steve Karmesin, Stephen Smith
Keywords: OCT99   C++    Templates  Macintosh 
Description: Macintosh version of the unpublished source code and related files
accompanying the article by Scott Haney, James Crotinger, Steve Karmesin, and
Stephen Smith in which they present PETE, short for "Portable Expression
Template Engine"--a C++ framework that lets users easily add
expression-template functionality to container classes and perform complex
expression manipulations. Requires STUFFIT to extract.

File: PETE-2_0.TGZ
Title: PETE: THE PORTABLE EXPRESSION TEMPLATE ENGINE
Author: Scott Haney, James Crotinger, Steve Karmesin, Stephen Smith
Keywords: OCT99   C++    Templates  UNIX
Description: UNIX version of the unpublished source code and related files
accompanying the article by Scott Haney, James Crotinger, Steve Karmesin, and
Stephen Smith in which they present PETE, short for "Portable Expression
Template Engine"--a C++ framework that lets users easily add
expression-template functionality to container classes and perform complex
expression manipulations. 

File: PARADIGM.TXT
Title: PROGRAMMING PARADIGMS
Author: Michael Swaine
Keywords:  OCT99   Macintosh  HyperCard   Java
Description: Published source code accompany the column by Michael Swaine in
which he a HyperCard stack that looks like a Java applet. This stack produces a
two-pixel bevel on both button and field produces a strong moat effect.

File: JQA1099.TXT 
Title: JAVA Q&A
Author: Evan Easton
Keywords: OCT99   JAVA    ENUM   
Description: Published source code accompanying the article by  Evan Easton in
which he presents in Java a C/C++ like enum that lets you define a constrained
set of options for an API parameter. Also see JQA1099.ZIP

File: JQA1099.ZIP 
Title: JAVA Q&A
Author: Evan Easton
Keywords: OCT99    JAVA   ENUM
Description: Unpublished source code and related files accompanying the article
by Evan Easton in which he presents in Java a C/C++ like enum that lets you
define a constrained set of options for an API parameter. Requires
UNZIP/PKUNZIP to extract.

File: AA1099.TXT
Title: ALGORITHM ALLEY
Author: Wesley Bylsma
Keywords: OCT99   ALGORITHM   DSP     FILTERS
Description: Published source code accompanying the article by Wesley Bylsma in
which he examines median filters which are useful tools in digital signal
processing. Wesley examines their use for removing impulsive signal noise while
maintaining signal trends.











