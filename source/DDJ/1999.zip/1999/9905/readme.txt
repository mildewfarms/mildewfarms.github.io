May 1999
Dr. Dobb's Journal 

File: PERSIST.TXT
Title:OBJECT PERSISTENCE: BEYOND SERIALIZATION
Author: Timo Salo, Justin Hill, Scott Rich, Chuck Bridgham, Daniel
Berg
Keywords: MAY99      JAVA   INTERNET    OBJECTS   DATABASE
Description: Published source code accompanying the article by Timo
Salo, Justin Hill, Scott Rich, Chuck Bridgham, and Daniel Berg in
which they describe techniques and frameworks necessary to
successfully implement scalable object persistence for complex
database systems. Much of the technology they examine has been
incorporated in development tools ranging from VisualAge for Java,
to EJB tools for WebSphere.

File:  JPROXY.TXT
Title: JAVA PROXIES FOR DATABASE OBJECTS
Author: Paul Lipton
Keywords: MAY99   JAVA    DATABASE   
Description: Published source code accompanying the article by Paul
Lipton in which he discusses Java proxy technology, which lets you
define database object schema using the database ODL. To illustrate
how such a technology might be implemented, Paul provides examples
based on the Jasmine object-oriented database.

File: VBSQL.TXT
Title: VBSCRIPT AND SQL CALENDARS
Author: John Donovan Lambert
Keywords:  MAY99   VISUAL BASIC   SQL   CALENDARS  E-COMMERCE
Description: Published source code accompanying the article by John
Donovan Lambert in which he presents the VBScripts he uses for in
putting SQL results into a web calendar, and discusses how you can
port these scripts to Java, Perl, Cold Fusion, or whatever language
you prefer. Also see VBSQL.ZIP.

File: VBSQL.ZIP
Title: VBSCRIPT AND SQL CALENDARS
Author: John Donovan Lambert
Keywords:  MAY99   VISUAL BASIC   SQL   CALENDARS  E-COMMERCE
Description: Unpublished source code and related files accompanying
the article by John Donovan Lambert in which he presents the
VBScripts he uses for in putting SQL results into a web calendar,
and discusses how you can port these scripts to Java, Perl, Cold
Fusion, or whatever language you prefer. Requires UNZIP/PKUNZIP to
extract.

File: CVS.TXT
Title: THE CVS DATA FORMAT
Author: Cesar A. Gonzalez Perez
Keywords: MAY99     GIS     FILE FORMAT
Description: Published source code accompanying the article by Cesar
A. Gonzalez Pirez in which he presents the CVS data format which
stores cartographic data for a specific geographic area into a
single file. Cesar examines the format, then presents a tool for
converting CVS files into DXF format. Also see CVS.ZIP.

File: CVS.ZIP
Title: THE CVS DATA FORMAT
Author: Cesar A. Gonzalez Perez
Keywords: MAY99     GIS     FILE FORMAT
Description: Unpublished source code and related files accompanying
the article by Cesar A. Gonzalez Pirez in which he presents the CVS
data format which stores cartographic data for a specific geographic
area into a single file. Cesar examines the format, then presents a
tool for converting CVS files into DXF format. Requires
UNZIP/PKUNZIP to extract.

File: AGENT.TXT
Title: AGENT ITINERARIES
Author: Russell P. Lentini, Goutham P. Rao, and Jon N. Thies
Keywords:  MAY99    AGENTS    FINITE STATE MACHINE
Description: Published source code accompanying the article by
Russell P. Lentini, Goutham P. Rao, and Jon N. Thies, in which they
treat itineraries as meta-programs--a way of programming an agent
and inadvertently its goal. To illustrate, they'll present an
itinerary that performs a database query. Also see FINITEST.ZIP.

File: FINITEST.ZIP
Title: AGENT ITINERARIES
Author: Russell P. Lentini, Goutham P. Rao, and Jon N. Thies
Keywords:  MAY99    AGENTS    FINITE STATE MACHINE
Description: Unpublished source code and related files accompanying
the article by Russell P. Lentini, Goutham P. Rao, and Jon N. Thies,
in which they treat itineraries as meta-programs--a way of
programming an agent and inadvertently its goal. To illustrate,
they'll present an itinerary that performs a database query.
Requires UNZIP/PKUNZIP to extract.

File: SNAPSHOT.TXT
Title: JAVA AND DIGITAL IMAGES
Author: David Martin and Johnny Martin
Keywords:  MAY99    JAVA      DIGITAL IMAGES 
Description: Published source code accompanying the article by David
Martin and Johnny Martin which examines capturing, storing, and
retrieving images. David and Johnny describe "Grabber for Java," an
API that encapsulates the functionality necessary for video capture.
Also see SNAPSHOT.ZIP.

File: SNAPSHOT.ZIP
Title: JAVA AND DIGITAL IMAGES
Author: David Martin and Johnny Martin
Keywords:  MAY99    JAVA      DIGITAL IMAGES 
Description: Unpublished source code accompanying the article by
David Martin and Johnny Martin which examines capturing, storing,
and retrieving images. David and Johnny describe "Grabber for Java,"
an API that encapsulates the functionality necessary for video
capture. Requires UNZIP/PKUNZIP to extract.

File: SPARK.TXT
Title: THE SPARK REAL-TIME KERNEL
Author: Anatoly Kotlarsky 
Keywords:  MAY99    REAL-TIME   EMBEDDED SYSTEMS
Description: Published source code accompanying the article by
Anatoly Kotlarsky in which he discusses SPARK, short for "Small
Portable Adjustable Real-time Kernel." SPARK is a royalty free,
fast, tiny, portable real-time kernel. Anatoly describes how he used
it to build a video bar-code scanner.

File: WEBTEST.TXT
Title: AUTOMATED TESTING FOR WEB APPLICATIONS
Author: M. Selvakumar
Keywords: MAY99  TESTING   WEB  HTML  JAVASCRIPT   CGI 
Description: Published source code accompanying the article by M.
Selvakumar in which he presents a technique for automated web
user-interface testing that's based on HTML, JavaScript, and CGI,
and implemented for Netscape Communicator 4.04 and Apache 1.2. 

File: CPROG.TXT
Title: C PROGRAMMING COLUMN
Author: Al Stevens
Keywords: MAY99    C++
Description: Published source code accompanying the article by 
by Al Stevens in which he examines C++'s argv.

File: JQA599.TXT 
Title: JAVA Q&A
Author: Lou Grinzo
Keywords: MAY99    JAVA      SECURITY
Description: Published source code accompanying the article by 
Lou Grinzo in which he examines Java and the topic of untrusted
classes. Also see JQA599.ZIP.

File: JQA599.ZIP
Title: JAVA Q&A
Author: Lou Grinzo
Keywords: MAY99    JAVA      SECURITY
Description: Unpublished source code accompanying the article by 
Lou Grinzo in which he examines Java and the topic of untrusted
classes. Requires UNZIP/PKUNZIP to extract.

File: AA599.ZIP
Title: ALGORITHM ALLEY
Author: Jon Bentley
Keywords: MAY99    ALGORITHMS  
Description: Unpublished source code and related files accompanying
the column by Jon Bentley in which he examines how code-tuning
techniques speed up the various algorithms. Requires UNZIP/PKUNZIP
to extract.



2


