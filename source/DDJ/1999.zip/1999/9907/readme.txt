July 1999
Dr. Dobb's Journal 

File: JINI.TXT
Author: Hinkmond Wong
Title: JINI AND NETWORK-ENABLED DEVICES
Keywords: JUL99    JAVA    JINI   NETWORKS
Description: Published source code accompanying the article by 
Hinkmond Wong in which he discusses Jini, a technology designed 
lets anyone connect any device to any network in a 
straightforward manner. Hinkmond uses shows how you can use Sun's 
EmbeddedJava tools to build a system that incorporates Jini 
technology into small memory footprint, network-enabled devices.
Also see JINI.ZIP.

File: JINI.ZIP
Author: Hinkmond Wong
Title: JINI AND NETWORK-ENABLED DEVICES
Keywords: JUL99    JAVA    JINI   NETWORKS
Description: Unpublished source code and related files 
accompanying the article by Hinkmond Wong in which he discusses 
Jini, a technology designed lets anyone connect any device to any 
network in a straightforward manner. Hinkmond uses shows how you 
can use Sun's EmbeddedJava tools to build a system that 
incorporates Jini technology into small memory footprint, 
network-enabled devices. Requires UNZIP/PKUNZIP to extract.

File:  X509.TXT
Title: X.509 CERTIFICATES
Author: Paul Tremblett
Keywords: JUL99  SECURITY   DIGITAL CERTIFICATES
Description: Published source code accompanying the article by 
Paul Tremblett in which he unravels X.509 certificates, one of 
the most popular computer security standards specifying the 
contents of digital certificate, by showing how you can decode 
and display them in a readable form. Also see X509.ZIP.

File:  X509.ZIP
Title: X.509 CERTIFICATES
Author: Paul Tremblett
Keywords: JUL99  SECURITY   DIGITAL CERTIFICATES   JAVA
Description: Unpublished source code accompanying the article by 
Paul Tremblett in which he unravels X.509 certificates, one of 
the most popular computer security standards specifying the 
contents of digital certificate, by showing how you can decode 
and display them in a readable form. Requires UNZIP/PKUNZIP to extract.

File: HTTPSYNC.TXT
Title: THE HTTPSYNC INCREMENTAL UPDATE UTILITY
Author: Forrest J. Cavalier III 
Keywords:  JUL99     HTTP   CLIENT/SERVER   PROTOCOL
Description: Published source code accompanying the article by 
Forrest J. Cavalier III in which he presents HTTPsync, client-
side-only software that performs fast and efficient incremental 
updates to synchronize collections of files. And only the 
standard features of HTTP are used. Also see HTTPSYNC.ZIP.

File: HTTPSYNC.ZIP
Title: THE HTTPSYNC INCREMENTAL UPDATE UTILITY
Author: Forrest J. Cavalier III 
Keywords:  JUL99     HTTP   CLIENT/SERVER   PROTOCOL
Description: Unpublished source code and related files 
accompanying the article by Forrest J. Cavalier III in which he 
presents HTTPsync, client-side-only software that performs fast 
and efficient incremental updates to synchronize collections of 
files. And only the standard features of HTTP are used. Requires 
UNZIP/PKUNZIP to extract.

File: SYNCBULD.TXT
Title: JAVA, SYNCHRONIZATION, & THE PALMPILOT
Author: Tilo Christ
Keywords:  JUL99     JAVA   PALMPILOT
Description: Published source code files accompanying the article 
by Tilo Christ in which he presents the SyncBuilder framework 
which lets you write Java applications that communicate with the 
Palm Computing devices and that run on any platform. Also see 
SYNCBULD.ZIP.

File: SYNCBULD.ZIP
Title: JAVA, SYNCHRONIZATION, & THE PALMPILOT
Author: Tilo Christ
Keywords:  JUL99     JAVA   PALMPILOT
Description: Unpublished source code and related files files 
accompanying the article by Tilo Christ in which he presents the 
SyncBuilder framework which lets you write Java applications that 
communicate with the Palm Computing devices and that run on any 
platform. Requires UNZIP/PKUNZIP to extract.

File: NAN.TXT
Title: PROTOCOLS FOR NICHE AREA NETWORKS
Author: Jaromir Chocholac
Keywords: JUL99  NETWORKS  PROTOCOL  EMBEDDED SYSTEMS
Description: Published source code accompanying the article by 
Jaromir Chocholac in which he discusses 
SimpleChat, a Niche Area Network protocol designed for 
applications where cost efficiency is more important than very 
high data rates.

File: CORBEAN.TXT
Title: AN ARCHITECTURE FOR WEB SERVICES
Author: David Houlding
Keywords:  JUL99  JAVA  CORBA   DISTRIBUTED COMPUTING
Description: Published source code accompanying the article by 
David Houlding in which he discusses an architecture that 
facilitates both the publication of distributed object services 
on the web and the subsequent reuse of these web services by 
application developers. For an interactive demo, see 
http://www.trcinc.com/corbabeans/.

File: SPSDK.TXT
Title: EXAMINING MICROSOFT'S SPEECH SDK
Author: Pete Davis
Keywords:  JUL99     WINDOWS  SPEECH
Description: Published source code accompanying the article by 
Pete Davis in which he shows how you can voice-enable your 
Windows applications by adding command-and-control voice 
recognition to applications by using the Microsoft Speech SDK. 
Also see SPSDK.ZIP.

File: SPSDK.ZIP
Title: EXAMINING MICROSOFT'S SPEECH SDK
Author: Pete Davis
Keywords:  JUL99     WINDOWS  SPEECH
Description: Unpublished source code and related files 
accompanying the article by Pete Davis in which he shows how you 
can voice-enable your Windows applications by adding command-and-
control voice recognition to applications by using the Microsoft 
Speech SDK. Requires UNZIP/PKUNZIP to extract.

File: JQA799.TXT 
Title: JAVA Q&A
Author: Krishnan Rangaraajan
Keywords: JUL99    JAVA     TESTING 
Description: Published source code accompanying the article by  
Krishnan Rangaraajan in which he examines conventional software 
testing techniques, then presents an alternate approach which he 
feels is superior in many ways.

File: JQA799.ZIP 
Title: JAVA Q&A
Author: Krishnan Rangaraajan
Keywords: JUL99    JAVA     TESTING 
Description: Unpublished source code and related files 
accompanying the article by Krishnan Rangaraajan in which he 
examines conventional software testing techniques, then presents 
an alternate approach which he feels is superior in many ways. 
Requires UNZIP/PKUNZIP to extract.

File: AA799.TXT
Title: ALGORITHM ALLEY
Author: Ron Gutman
Keywords: JUL99   DATABASES  B-TREE   ALGORITHM
Description: Published source code accompanying the article by 
Ron Gutmann in which he shows how Hilbert curves can be used to 
efficiently manage multi-dimensional data, with no changes to the 
underlying database.







