/*
 * (C) Copyright Pablo Aguilar 2005
 * (C) Copyright Christopher Diggins 2005
 * (C) Copyright Kevlin Henney 2001
 *
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)  
 */

#ifndef CDIGGINS_ANY_HPP
#define CDIGGINS_ANY_HPP

#include <stdexcept>
#include <typeinfo>
#include <algorithm>

#include <boost/type_traits/alignment_of.hpp>
#include <boost/type_traits/type_with_alignment.hpp>
#include <boost/type_traits/has_nothrow_constructor.hpp>

namespace cdiggins
{
	struct bad_any_cast
		: std::bad_cast 
	{
		bad_any_cast(
			  std::type_info const& src
			, std::type_info const& dest
		)
		  : from(src)
		  , to	(dest)
		{
		}

		virtual char const* what() const
		{ 
			return "bad cast"; 
		}

		std::type_info const& from;
		std::type_info const& to;
	};

namespace any_detail
{
	#ifndef ANY_BUFFER_SIZE
	enum
	{
		any_buffer_elements	= 1
	};
	#else
	enum
	{
		any_buffer_elements
			= (ANY_BUFFER_SIZE / sizeof(boost::detail::max_align))			// Integer part
			+ ((ANY_BUFFER_SIZE % sizeof(boost::detail::max_align)) ? 1 : 0)// round upwards
	};
	#endif

	enum
	{
		any_buffer_size = sizeof(boost::detail::max_align[any_buffer_elements])
	};

    // used to reset any values
	struct empty { };
    
  // used to hold an object or a pointer to an object
	union object_holder
	{
		// fields
		char						buffer[any_buffer_size];
		void*						pointer;

		boost::detail::max_align	alignment_dummy_[any_buffer_elements];
	};	      

  // function pointer table
  struct fxn_ptr_table
	{
		std::type_info const& (*type)();
		void (*destructor)(object_holder&);
		void (*static_delete)(object_holder&);
		void (*clone)(object_holder&, const object_holder&);
		void (*assign)(object_holder&, const object_holder&);
		bool (*is_optimized)();
		void (*swap)(object_holder&, object_holder&);
  };

	// static functions for small value-types 
	template<bool optimized>
	struct fxns
	{
		template<typename T>
		struct impl
		{
			static const std::type_info& type()
			{
				return typeid(T);
			}
			static void destructor(object_holder& x)
			{
				reinterpret_cast<T*>(x.buffer)->~T(); 
			}
			static void static_delete(object_holder& x)
			{
				destructor(x);
			}
			static void clone(
				  object_holder&		lvalue
				, object_holder const&	rvalue
			)
			{
				new(lvalue.buffer) T(
					*reinterpret_cast<T const*>(rvalue.buffer)
				);
			}
			static void assign(
				  object_holder&		lvalue
				, object_holder const&	rvalue)
			{
				*reinterpret_cast<T*>(lvalue.buffer) = *reinterpret_cast<T const*>(rvalue.buffer);
			}
			static bool is_optimized()
			{
				return true;
			}
			static void swap(object_holder& lhs, object_holder& rhs)
			{
				std::swap(
					  *reinterpret_cast<T*>(lhs.buffer)
					, *reinterpret_cast<T*>(rhs.buffer)
				);
			}
		};
	};

    // static functions for big value-types (bigger than a void*)
	template<>
	struct fxns<false>
	{
		template<typename T>
		struct impl
		{
			static const std::type_info& type()
			{ 
				return typeid(T); 
			}
			static void destructor(object_holder& x)
			{
				reinterpret_cast<T*>(x.pointer)->~T(); 
			}
			static void static_delete(object_holder& x)
			{
				delete reinterpret_cast<T*>(x.pointer);
			}
			static void clone(
				  object_holder&		lvalue
				, object_holder const&	rvalue
			)
			{ 
				lvalue.pointer = new T(*reinterpret_cast<T const*>(rvalue.pointer)); 
			}
			static void assign(
				  object_holder&		lvalue
				, object_holder const&	rvalue
			)
			{ 
				*reinterpret_cast<T*>(lvalue.pointer) = *reinterpret_cast<T const*>(rvalue.pointer);
			}
			static bool is_optimized()
			{
				return false;
			}
			static void swap(object_holder& lhs, object_holder& rhs)
			{
				std::swap(
					  *reinterpret_cast<T*>(lhs.pointer)
					, *reinterpret_cast<T*>(rhs.pointer)
				);
			}
		};
	};

	template<typename T>
	struct optimize
	{
		enum
		{
			  T_size_		= sizeof(T)
			, base_size_	= sizeof(object_holder)
			, size_ok_		= (T_size_ <= base_size_)

			, T_align_		= boost::alignment_of<T>::value
			, base_align_	= boost::alignment_of<object_holder>::value
			, align_ok_		= ((base_align_ % T_align_) == 0)

			, value			= size_ok_ && align_ok_
		};

		// Either the T doesn't fit, or it fits and is properly aligned
		// that's what max_align is supposed to guarantee isn't it?
		// No such thing as too much paranoia.
		BOOST_STATIC_ASSERT((!size_ok_ || align_ok_));
	};

  template<typename T>
  struct table
  {
	  enum { optimized = optimize<T>::value };

	  static fxn_ptr_table* get()
	  {
		  static fxn_ptr_table static_table = {
				&fxns<optimized>::template impl<T>::type
			, &fxns<optimized>::template impl<T>::destructor
			, &fxns<optimized>::template impl<T>::static_delete
			, &fxns<optimized>::template impl<T>::clone
			, &fxns<optimized>::template impl<T>::assign
			, &fxns<optimized>::template impl<T>::is_optimized
			, &fxns<optimized>::template impl<T>::swap
		  };
		  return &static_table;
	  }
  };

} // namespace any_detail

struct any
{
	// structors
	template <typename T>
	any(T const& x)
	{
		table = any_detail::table<T>::get();
		if( any_detail::optimize<T>::value )
		{
			new(held.buffer) T(x);
		}
		else
		{        
			held.pointer = new T(x); 
		}
	}

	any()
		: table(get_empty_table())
	{
	}

	any(any const& x)
		: table(get_empty_table())
	{
		assign(x);
	}

	~any()
	{
		table->static_delete(held);
	}

    // assignment
    template <typename T>
    any& assign(T const& x)
    {
		// are we copying between the same type?
		any_detail::fxn_ptr_table* x_table = any_detail::table<T>::get();
		if (table == x_table)
		{
			// I believe assignment would be better than
			// destryoing & contructing given that construction might fail
			// and leave us with a non existing object
			if( any_detail::optimize<T>::value )
			{
				*reinterpret_cast<T*>(held.buffer) = x;
			}
			else
			{
				*reinterpret_cast<T*>(held.pointer) = x;
			}
		}
		else
		{
			reset();
			if( any_detail::optimize<T>::value )
			{
				// create copy on-top of buffer
				new(held.buffer) T(x);
			}
			else
			{
				held.pointer = new T(x);
			}

			// update table pointer 
			table = x_table;
		}

		return *this;
	}

	any& assign(any const& x)
	{
		// are we copying between the same type?
		if (table == x.table)
		{
			// if so, we can avoid reallocation
			table->assign(held, x.held);
		}
		else
		{
			reset();
			x.table->clone(held, x.held);
			table = x.table;
		}

		return *this;
	}

    // assignment operator 
	template<typename T>
	any& operator=(T const& x)
	{
		return assign(x);
	}

	any& operator=(any const& x)
	{
		return assign(x);
	}

  // utility functions
  any& swap(any& x)
	{
		if( table == x.table )
		{
			// both values are of the same type
			if( !table->is_optimized() && !x.table->is_optimized() )
			{
				// both values are heap allocated on the heap
				// we can just swap pointers
				std::swap(held.pointer, x.held.pointer);
			}
			else
			{
				// use std::swap with proper type information
				table->swap(held, x.held);
			}
		}
		else if( !table->is_optimized() && !x.table->is_optimized() )
		{
			// both values are allocated on the heap
			// just swap function table and pointer
			std::swap(table, x.table);
			std::swap(held.pointer, x.held.pointer);
		}
		else
		{
		  any tmp = x;
		  x = *this;
		  *this = x;
		}

		return *this;
    }

    std::type_info const& type() const
	{
		return table->type();
    }

    template<typename T>
    T& cast()
	{
		if (this_->type() != typeid(T))
		{
			throw bad_any_cast(this_->type(), typeid(T));
		}

		if( any_detail::optimize<T>::value )
		{
			return reinterpret_cast<T*>(this_->held.buffer);
		}
		else
		{
			return reinterpret_cast<T*>(this_->held.pointer);
		}
  }

	// implicit casting is disabled by default for compatibility with boost::any 
	#ifdef ANY_IMPLICIT_CASTING
	// automatic casting operator
	template<typename T>
	operator T() const
	{
		return cast<T>();
	}
	#endif // implicit casting

	static any_detail::fxn_ptr_table* get_empty_table()
	{
		return any_detail::table<any_detail::empty>::get();
	}
    
	bool empty() const
	{
		return table == get_empty_table();
	}

	void reset()
	{
		if( !empty() )
		{
			table->static_delete(held);
			table = get_empty_table();
		}
	}
	  	  
	// points to function pointer table
	any_detail::fxn_ptr_table*	table;
	// holds either a small object or a pointer to an object. 
	any_detail::object_holder	held;
};

	/////////////////////////////////////////////////////////////////////////
	// boost::any-like casting
	/////////////////////////////////////////////////////////////////////////
	template<typename T>
	T* any_cast(any* this_)
	{
		if (this_->type() != typeid(T))
		{
			throw bad_any_cast(this_->type(), typeid(T));
		}

    #ifdef __BORLANDC__
    #   pragma warn -8008   // Condition is always true
    #   pragma warn -8066   // Unreachable code
    #endif
		if( any_detail::optimize<T>::value )
		{
			return reinterpret_cast<T*>(this_->held.buffer);
		}
		else
		{
			return reinterpret_cast<T*>(this_->held.pointer);
		}
    #ifdef __BORLANDC__
    #   pragma warn .8008   // Condition is always true
    #   pragma warn .8066   // Unreachable code
    #endif
	}

	template<typename T>
	T const* any_cast(any const* this_)
	{
		return any_cast<T>(const_cast<any*>(this_));
	}

	template<typename T>
	T const& any_cast(any const& this_)
	{
		return *any_cast<T>(const_cast<any*>(&this_));
	}
}

#endif // CDIGGINS_ANY_HPP
