// synopsis of template class multimap

template <class Key, class Ty,
  class Pr = std::less<Key>,
  class Alloc = std::allocator<std::pair<const Key, Ty> > >
class multimap { // ordered container holding (Key, Ty) pairs
public:
    // NESTED TYPES
    typedef Key key_type;
    typedef Ty mapped_type;
    typedef Pr key_compare;
    typedef Alloc allocator_type;
    typedef std::pair<const Key, Ty> value_type;
    class value_compare;
    typedef Alloc::pointer pointer;
    typedef Alloc::const_pointer const_pointer;
    typedef Alloc::reference reference;
    typedef Alloc::const_reference const_reference;
    typedef T0 size_type;
    typedef T1 difference_type;
    typedef T2 iterator;
    typedef T3 const_iterator;
    typedef std::reverse_iterator<iterator> reverse_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

    // CONSTRUCTORS
    multimap();
    explicit multimap(const Pr& pr);
    multimap(const Pr& pr, const Alloc& al);
    multimap(const multimap& right);
    template <class InIt>
    multimap(InIt first, InIt last);
    template <class InIt>
    multimap(InIt first, InIt last, const Pr& pr);
    template <class InIt>
    multimap(InIt first, InIt last, const Pr& pr, const Alloc& al);

    // MODIFICATION
    iterator insert(const value_type& val);
    iterator insert(iterator hint, const value_type& val);
    template <class InIt>
    void insert(InIt first, InIt last);

    iterator erase(iterator pos);
    iterator erase(iterator first, iterator last);
    iterator erase(cosnt Key& key);
    void clear();

    void swap(multimap& right);
  
    // CONTAINER ITERATORS
    iterator begin();
    const_iterator begin() const;
    iterator end();
    const_iterator end() const;
    reverse_iterator rbegin();
    const_reverse_iterator rbegin() const;
    reverse_iterator rend();
    const_reverse_iterator rend() const;

    // ELEMENT ACCESS
    iterator find(const Key& key);
    const_iterator find(const Key& key) const;
    size_type count(const Key& key) const;
    iterator lower_bound(const Key& key);
    const_iterator lower_bound(const Key& key) const;
    iterator upper_bound(const Key& key);
    const_iterator upper_bound(const Key& key) const;
    pair<iterator, iterator> equal_range(const Key& key);
    pair<const_iterator, const_iterator> equal_range(const Key& key) const;

    // QUERIES
    size_type size() const;
    size_type max_size() const;
    bool empty() const;
    Alloc get_allocator() const;
    key_compare key_comp() const;
    value_compare value_comp() const;
};

template <class Key, class Ty, class Pr, class Alloc>
bool operator==(
  const multimap<Key, Ty, Pr, Alloc>&,
  const multimap<Key, Ty, Pr, Alloc>&);
/* analogous template functions for !=, <, <=, >, and >= */

template <class Key, class Ty, class Pr, class Alloc>
void swap(
  const multimap<Key, Ty, Pr, Alloc>&,
  const multimap<Key, Ty, Pr, Alloc>&);
