// the TR1 header <unordered_set>

namespace std {     // C++ Standard Library
 namespace tr1 {    // TR1 additions

    // TEMPLATE CLASS unordered_set
template <class Key,
    class Hash, class Pred, class Alloc> class unordered_set;

    // TEMPLATE CLASS unordered_multiset
template <class Key,
    class Hash, class Pred, class Alloc> class unordered_multiset;

    // TEMPLATE FUNCTIONS swap
template <class Key, class Hash, class Pred, class Alloc>
void swap(unordered_set(Key, Hash, Pred, Alloc>& left,
    unordered_set(Key, Hash, Pred, Alloc>& right);
template <class Key, class Hash, class Pred, class Alloc>
void swap(unordered_multiset(Key, Hash, Pred, Alloc>& left,
    unordered_multiset(Key, Hash, Pred, Alloc>& right);

} }
