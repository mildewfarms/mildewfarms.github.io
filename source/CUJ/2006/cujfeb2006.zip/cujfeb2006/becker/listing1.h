// the TR1 header <unordered_map>

namespace std {     // C++ Standard Library
 namespace tr1 {    // TR1 additions

    // TEMPLATE CLASS unordered_map
template <class Key, class Ty,
    class Hash, class Pred, class Alloc> class unordered_map;

    // TEMPLATE CLASS unordered_multimap
template <class Key, class Ty,
    class Hash, class Pred, class Alloc> class unordered_multimap;

    // TEMPLATE FUNCTIONS swap
template <class Key, class Ty, class Hash, class Pred, class Alloc>
void swap(unordered_map(Key, Ty, Hash, Pred, Alloc>& left,
    unordered_map(Key, Ty, Hash, Pred, Alloc>& right);
template <class Key, class Ty, class Hash, class Pred, class Alloc>
void swap(unordered_multimap(Key, Ty, Hash, Pred, Alloc>& left,
    unordered_multimap(Key, Ty, Hash, Pred, Alloc>& right);

} }
