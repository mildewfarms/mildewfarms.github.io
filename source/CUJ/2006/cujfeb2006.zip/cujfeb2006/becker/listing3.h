// partial synopsis of TR1 header <functional>

namespace std {     // C++ Standard Library
 namespace tr1 {    // TR1 additions

    // TEMPLATE CLASS hash
template <class Ty> struct hash;

    // TEMPLATE CLASS hash SPECIALIZATIONS
template <> struct hash<bool>;
template <> struct hash<char>;
template <> struct hash<signed char>;
template <> struct hash<unsigned char>;
template <> struct hash<wchar_t>;
template <> struct hash<short>;
template <> struct hash<unsigned short>;
template <> struct hash<int>;
template <> struct hash<unsigned int>;
template <> struct hash<long>;
template <> struct hash<unsigned long>;
template <> struct hash<float>;
template <> struct hash<double>;
template <> struct hash<long double>;

template <class Ty> struct hash<Ty*>;

template <> struct hash<std::string>;
template <> struct hash<std::wstring>;

} }
