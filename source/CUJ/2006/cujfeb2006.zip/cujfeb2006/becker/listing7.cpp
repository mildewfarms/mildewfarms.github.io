// demonstrate unordered container construction and insertion
#include <unordered_map>
#include <array>
#include <iomanip>
#include <iostream>
#include <ostream>
#include <iterator>
#include <string>
#include <utility>
using std::tr1::unordered_multimap; using std::tr1::array;
using std::string; using std::ostream_iterator;
using std::pair; using std::make_pair;
using std::basic_ostream; using std::cout; using std::setw;

typedef unordered_multimap<int, string> table;
typedef table::iterator iter;
typedef table::value_type elt;

array<elt, 5> values =
    { // initial values for unordered containers
    elt(1, "first"),
    elt(2, "second"),
    elt(3, "third"),
    elt(4, "fourth"),
    elt(5, "fifth")
    };

namespace std { // put inserter in namespace std
template <class Elem, class Traits>
basic_ostream<Elem, Traits>& operator<<(
  basic_ostream<Elem, Traits>& os, const elt& val)
  { // insert elt into stream
  return os << '[' << val.first << ',' << val.second << ']';
  }
}

void show(const char * title, iter first, iter last)
    { // show title and contents of range [first, last)
    cout << title << ":\n  ";
    copy(first, last, ostream_iterator<elt>(cout, " "));
    cout << '\n';
    }

int main()
    { // demonstrate use of std::tr1::unordered_multimap
    table t0(values.begin(), values.end());
    show("initialized table", t0.begin(), t0.end());
    table t1;
    show("empty table", t1.begin(), t1.end());
    t1.insert(values.begin(), values.end());
    show("insert range", t1.begin(), t1.end());
    t1.insert(make_pair(4, "other fourth"));
    show("insert element", t1.begin(), t1.end());
    t1.erase(3);
    show("erase element", t1.begin(), t1.end());
    pair<iter, iter> res = t1.equal_range(4);
    show("equal range", res.first, res.second);
    t1.erase(res.first, res.second);
    show("erase range", t1.begin(), t1.end());
    return 0;
    }
