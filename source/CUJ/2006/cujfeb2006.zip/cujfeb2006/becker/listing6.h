// synopsis of template class unordered_multimap

template <class Key, class Ty,
  class Hash = std::tr1::hash<Key>,
  class Pred = std::equal_to<Key>,
  class Alloc = std::allocator<Key> >
class unordered_multimap { // unordered container holding (Key, Ty) pairs
public:
    // NESTED TYPES
    typedef Key key_type;
    typedef Ty mapped_type;
    typedef std::pair<const Key, Ty> value_type;
    typedef Hash hasher;
    typedef Pr key_equal;
    typedef Alloc allocator_type;

    typedef Alloc::pointer pointer;
    typedef Alloc::const_pointer const_pointer;
    typedef Alloc::reference reference;
    typedef Alloc::const_reference const_reference;

    typedef T0 size_type;
    typedef T1 difference_type;
    typedef T2 iterator;
    typedef T3 const_iterator;
    typedef T4 local_iterator;
    typedef T5 const_local_iterator;

    // CONSTRUCTORS
    unordered_multimap(size_type nbuckets = N0,
        const Hash& hfn = Hash(),
        const Pred& pr = Pred(),
        const Alloc& al = Alloc());
    template <class InIt>
    unordered_multimap(InIt first, InIt last,
        size_type nbuckets = N0,
        const Hash& hfn = Hash(),
        const Pred& pr = Pred(),
        const Alloc& al = Alloc());
    unordered_multimap(const unordered_multimap& right);

    // MODIFICATION
    iterator insert(const value_type& val);
    iterator insert(iterator pos, const value_type& val);
    template <class InIt>
        void insert(InIt first, InIt last);

    iterator erase(iterator pos);
    iterator erase(iterator first, iterator last);
    size_type erase(const key_type& key);
    void clar();

    void swap(unordered_multimap& right);

    // CONTAINER ITERATORS
    iterator begin();
    const_iterator begin() const;
    iterator end();
    const_iterator end() const;

    // ELEMENT ACCESS
    const_iterator find(const key_type& key) const;
    size_type count(const key_type& key) const;
    std::pair<iterator, iterator>
        equal_range(const key_type& key);
    std::pair<const_iterator, const_iterator>
        equal_range(const key_type& key) const;

    // QUERIES
    size_type size() const;
    size_type max_size() const;
    bool empty() const;

    allocator_type get_allocator() const;
    key_type key_eq() const;
    hasher hash_function() const;

    // TUNING
    local_iterator begin(size_type nbucket);
    const_local_iterator begin(size_type nbucket) const;
    local_iterator end(size_type nbucket);
    const_local_iterator end(size_type nbucket) const;

    size_type bucket_count() const;
    size_type max_bucket_count() const;
    size_type bucket_size(size_type nbucket) const;
    size_type bucket(const key_type& key) const;

    float load_factor() const;
    float max_load_factor() const;
    float max_load_factor(float f);
    void rehash(size_type nbuckets);
};
