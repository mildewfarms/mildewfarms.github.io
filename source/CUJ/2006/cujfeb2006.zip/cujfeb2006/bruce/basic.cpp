// spc: this code demonstrates the basic idea behind
//      associative chains (viz. to extend the pointer-to-member
//      to more complex associations)


#include "chains.hpp"
#include <assert.h>
#include <iostream>
#include <vector>
#include <string>


// spc: some geographical location.. here it identifies
//      the birthplace of a human
class Place
{
public:
  Place(const char *_name)
    :
    name(_name)
  {}
  std::string name;      
};


// spc: domestic quadruped, owned by humans
class Dog
{
private:
  unsigned int age_yrs;

public:
  Dog(const char *_name = "Trotsky",
      unsigned int _age_yrs = 13)
    :
    age_yrs(_age_yrs),
    name(_name)
  {
  }
  std::string name;

  const unsigned int &get_age_yrs(void) const
  {
    return age_yrs;
  }
};


// spc: biped; apparent owner of canids..
//      purports to have a lucky number;
//      certainly was born somewhere
class Human
{
public:
  Human(const Place &pob,
	unsigned int ln,
	const Dog &dog)
    :
    place_of_birth(pob),
    lucky_number(ln),
    dogs(1, dog)
  {}
  Place place_of_birth;
  unsigned int lucky_number;
  std::vector<Dog> dogs;
};


int main()
{
  // making some places, dogs, and humans..
  Place p1("Scranton"),
    p2("Kyrgyzstan");

  Dog d1("Genevieve"),
    d2("Elvira"),
    d3("Grettle"),
    d4("Moonbeam");

  Human h1(p1, 23, d1);
  h1.dogs.push_back(d2);
  Human h2(p2, 16, d3);
  h2.dogs.push_back(d4);
  h2.dogs.push_back(d1);

  Get_Link<Dog, const unsigned int> age(&Dog::get_age_yrs);
  std::cout << age.traverse(d1) << std::endl;

  // all right, we have 2 humans, h1 and h2;
  // first we get a chain for their
  // respective lucky numbers
  Chain<Human, unsigned int> ln =
    Member_Link<Human, unsigned int>(&Human::lucky_number);
  // targets
  assert(ln.traverse(h1) == 23);
  assert(ln.traverse(h2) == 16);
  // distances
  assert(ln.get_distance(h1, Handle(h1)) == 0);
  assert(ln.get_distance(h1, Handle(h1.lucky_number)) == 1);

  // that was interesting.. or was it?  it could already be done
  // using pointers to members.  let's consider something
  // more peculiar.. for example, a second-order class-membership
  // relation
  Chain<Human, std::string> birth_place_name =
    Member_Link<Human, Place>(&Human::place_of_birth) +
    Member_Link<Place, std::string>(&Place::name);
  // targets..
  assert(birth_place_name.traverse(h1) == std::string("Scranton"));
  assert(birth_place_name.traverse(h2) == std::string("Kyrgyzstan"));
  // distances..
  assert(birth_place_name.get_distance(h1, Handle(h1)) == 0);
  assert(birth_place_name.get_distance(h1, Handle(h1.place_of_birth)) == 1);
  assert(birth_place_name.get_distance(h1, Handle(h1.place_of_birth.name)) == 2);

  // or how about the the name of the first dog?
  // (class membership + array member access +
  //  class membership)
  Chain<Human, std::string> name_1st_dog =
    Member_Link<Human, std::vector<Dog> >(&Human::dogs) +
    Array_Link<std::vector<Dog>, Dog>(0) +
    Member_Link<Dog, std::string>(&Dog::name);
  // targets..
  assert(name_1st_dog.traverse(h1) == std::string("Genevieve"));
  assert(name_1st_dog.traverse(h2) == std::string("Grettle"));
  // distances..
  assert(name_1st_dog.get_distance(h1, Handle(h1)) == 0);
  assert(name_1st_dog.get_distance(h1, Handle(h1.dogs)) == 1);
  assert(name_1st_dog.get_distance(h1, Handle(h1.dogs[0])) == 2);
  assert(name_1st_dog.get_distance(h1, Handle(h1.dogs[0].name)) == 3);

  return 0;
}

