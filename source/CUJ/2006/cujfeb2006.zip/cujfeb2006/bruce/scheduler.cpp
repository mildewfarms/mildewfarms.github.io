// spc: this is the scheduler application with a UI layer


#include "scheduler.hpp"
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <assert.h>


Users::Users(void)
{
  push_back(User(1, "woody"));
  push_back(User(2, "muddy"));
  push_back(User(3, "buddy"));
}


Users users;


void schedule(const Request &request,
	      std::list<Reservation> &reservations)
{
  // some bogus errors for variety
  switch (rand() % 7) {
  case 0:
    throw Error<Request, int>
      ("bad resource type",
       request,
       Member_Link<Request, std::list<Requisite> >(&Request::requisites) +
       Find_First_Link<std::list<Requisite>, Requisite>(*request.requisites.begin()) +
       Member_Link<Requisite, int>(&Requisite::resource_type));
    break;

  case 1:
    throw Error<Request, time_t>
      ("bad start time in last requisite",
       request,
       Member_Link<Request, std::list<Requisite> >(&Request::requisites) +
       Find_First_Link<std::list<Requisite>, Requisite>(request.requisites.back()) +
       Member_Link<Requisite, time_t[2]>(&Requisite::range) +
       Array_Link<time_t[2], time_t>(0));
    break;

  case 2:
    throw Error<Request, time_t>
      ("bad end time in first requisite",
       request,
       Member_Link<Request, std::list<Requisite> >(&Request::requisites) +
       Find_First_Link<std::list<Requisite>, Requisite>(request.requisites.front()) +
       Member_Link<Requisite, time_t[2]>(&Requisite::range) +
       Array_Link<time_t[2], time_t>(1));
    break;

  case 3:
    throw Error<Request, User>
      ("big problem",
       request,
       Member_Link<Request, int>(&Request::user_id) +
       User_Link());
    break;
    
  case 4:
    throw Error<Request, int>
      ("big problem",
       request,
       Member_Link<Request, int>(&Request::user_id));
    break;

  case 5:
    throw Error<Request, time_t[2]> 
      ("invalid time range",
       request,
       Member_Link<Request, std::list<Requisite> >(&Request::requisites) +
       Find_First_Link<std::list<Requisite>, Requisite>(request.requisites.front()) +
       Member_Link<Requisite, time_t[2]>(&Requisite::range));
    break;

  default:
    break;
  }      
}


int main(int argc, char** argv)
{ 
  srand(time(0));
  Request req;
  req.user_id = 2;
  req.requisites.push_back(Requisite());
  req.requisites.back().resource_type = 13;
  req.requisites.push_back(Requisite());
  req.requisites.back().resource_type = 26;
  std::list<Reservation> res;

  for (int i = 0; i < 12; ++i) {
    try {
      schedule(req, res);
      std::cout << "resource got scheduled" << std::endl;

    } catch (Error<Request, int> &e) {
      std::cout << "I got an error" << std::endl
		<< "  description = " << e.description  
		<< std::endl;
      assert(e.source == req);
      std::cout << "  target = " 
		<< e.chain.traverse(req) << std::endl;

    } catch (Error<Request, User> &e) {
      std::cout << "I got an error" << std::endl
		<< "  description = " << e.description << std::endl;
      assert(e.source == req);
      std::cout << "  user name = " 
		<< e.chain.traverse(req).name
		<< std::endl;

    } catch (Error<Request, time_t [2]> &e) {
      std::cout << "I got an error" << std::endl
		<< "  description = " << e.description << std::endl;
      assert(e.source == req);
      std::cout << "  array = { " 
		<< (e.chain.traverse(req))[0]
		<< ", "
		<< (e.chain.traverse(req))[1]
		<< " } " << std::endl;

    } catch (Error_Base<Request> &e) {
      std::cout << "I got an error" << std::endl
		<< "  description = " << e.description << std::endl;
      assert(e.source == req);
      // here we see which requisite might be closest
      // to the error site
      Chain<Request, Handle> c = e.get_link();
      std::list<Requisite>::iterator imax;
      int tmp, maxval = 0;
      for (std::list<Requisite>::iterator i = req.requisites.begin();
	   i != req.requisites.end(); ++i) {
	if ((tmp = c.get_distance(req, Handle(*i))) > maxval) {
	  maxval = tmp;
	  imax = i;
	}
      }
      if (imax != 0) {
	std::cout << "  apparently in requisite for type "
		  << (*imax).resource_type << std::endl;
      }

    } catch (...) {
      std::cout << "hey, how'd I get here?!?" << std::endl;
      return -1;

    }

    std::cout << std::endl;
  }

  return 0;
}
