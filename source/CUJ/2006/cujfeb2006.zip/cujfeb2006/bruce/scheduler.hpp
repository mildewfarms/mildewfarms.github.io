// here we define the basic classes for the scheduler
// as well as the scheduling function itself;
// we also define the error class as an associative chain


#ifndef _CHAINS_SCHEDULER_HPP_
#define _CHAINS_SCHEDULER_HPP_


#include "chains.hpp"
#include <assert.h>
#include <iostream>


// spc: a domain-level hominid that reserves resources
class User
{
public:
  User(void)
    :
    id(0),
    name()
  {}

  User(int _id, const char *_name)
    :
    id(_id),
    name(_name)
  {}

  int id;
  std::string name;
};


// spc: dummy list of users.. in a real application there would
//      be a table in a rdbs with the user records
class Users
  :
  public std::list<User>
{
public:
  Users(void);
};
extern Users users;


// spc: model of reservation;
//      a User (user_id) reserves
//      a particular resource (resource_id) of a
//      particular type (resource_type)
//      for a particular time (range)
class Reservation
{
public:
  int resource_type;
  int resource_id;
  int user_id;
  time_t range[2];
};


// spc: describing the needs of a User during
//      scheduling.. a resource type at given
//      time
class Requisite
{
public:
  bool operator==(const Requisite &r) const 
  {
    return resource_type == r.resource_type &&
      range[0] == r.range[0] &&
      range[1] == r.range[1];
  }
  int resource_type;
  time_t range[2];
};


// spc: a batch of requisites.. scheduling
//      then is the conversion of this batch
//      into a list of reservations
class Request
{
public:
  std::list<Requisite> requisites;
  int user_id;
  int event_type;
};


// spc: a virtual base class for scheduling errors;
//      contains a textual description and a handle to
//        the source that caused the error (useful when
//        there are several sources of the same type in the
//        function parameter list)
//      it doesn't specify the target class for reasons
//      explained in the paper
template<class Src>
class Error_Base
{
public:
  virtual Chain<Src,Handle> get_link(void) = 0;
  std::string description;
  Handle source;
  Error_Base(const char *_description,
	     const Handle &_source)
    :
    description(_description),
    source(_source)
  {
  }
  virtual ~Error_Base(void)
  {
  }
};


// spc: the special error class used by the scheduler;
//      extends Error_Base with an association chain
template<class Src, class Dst>
class Error
  :
  public Error_Base<Src>
{
public:
  Error(const char *_description,
	const Handle &_source,
	const Chain<Src, Dst> &_chain)
    :
    Error_Base<Src>(_description, _source),
    chain(_chain)
  { 
  }
  Chain<Src,Handle> get_link(void)
  {
    return chain + Handle_Link<Dst>();
  }
  Chain<Src, Dst> chain;
};


// spc: link that associates a user id with the corresponding
//        user object;
//      this is a dummy implementation that
//        would normally be implemented with an rdb access
class User_Link
  :
  public Typed_Link<int, User>
{
public:
  User &traverse(int &id) 
  {
    for (Users::iterator i = users.begin();
	 i != users.end(); ++i) {
      if (i->id == id) {
	return (*i);
      }
    }
    throw Clank(Handle(id));
  }

  Link *clone(void) const
  {
    return new User_Link();
  }
};


// spc: resource scheduler;
//      transforms request into reservations;
//      in case of error throws an exception of
//      an appropriate type Error
void schedule(const Request &request,
	      std::list<Reservation> &reservations);


#endif
