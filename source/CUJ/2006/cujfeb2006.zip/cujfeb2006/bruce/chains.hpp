#ifndef _CHAINS_CHAINS_HPP_
#define _CHAINS_CHAINS_HPP_


#include <list>
#include <algorithm>
#include <typeinfo>


// spc: a type-safe void pointer for comparison only
// use: 
//      Handle h1(foo);
//      Handle h2(bar);
//      Handle h3(bar);
//      ...
//      assert(h1 == h2);  // no!  types differ
//      assert(h2 == h3);  // ok
class Handle
{
private:
  // pointer to object
  const void *ptr;
  // typeid of object
  const std::type_info *tid;

public:
  Handle(void)
    :
    ptr(0),
    tid(0)
  {
  }
  template<class A>
  Handle(const A &a)
    :
    ptr(&a),
    tid(&typeid(a))
  {
  }
  Handle(const Handle &h)
    :
    ptr(h.ptr),
    tid(h.tid)
  {
  }
  bool operator==(const Handle &h) const
  {
    return ptr == h.ptr && tid == h.tid;
  }
};


// spc: a base class for associations; basically a
//      pimpl-type manipulator for the typed links
//      inside of a chain
class Link
{
protected:
  // spc: dangerous dereferencer protected from public
  //      access; applies association to the parameter
  //      object and returns the target; if association
  //      fails for the given source, a clank is thrown
  virtual void *v_traverse(void *) = 0;
  // spc: idem; also receives eof parameter; if during
  //      traversal we dereference some handle = eof, then
  //      a clank is thrown; this is exclusively used by
  //      the get_distance function in the chain class
  virtual void *v_traverse(void *, const Handle &eof) = 0;

  template<class Src, class Dst> friend class Chain;

public:
  virtual ~Link(void) { }
  virtual Link *clone(void) const = 0;
  // spc: virtual size method; indicates the number of
  //      links spanned by a link (does that make sense?);
  //      since a chain is a link and it may contain > 1
  //      link, this method is necessary when a chain
  //      gets downcast to a link
  virtual size_t get_size(void) const { return 1; }
};


// spc: error during dereferencing operation in all
//      association classes
class Clank
{
public:
  Clank(const Handle &h, size_t d = 0)
    :
    locus(h),
    distance(d)
  {}
  // handle to the object that caused the dereferencing
  // error; specifically, the source into the (simple) link
  // that failed during a call to traverse()
  Handle locus;
  // the number of objects dereferenced prior to locus
  // (i.e. = 0 when the first call to traverse fails)
  size_t distance;
};


// spc: typed version of Link; Src and Dst specify the
//      classes involved in the association; to implement
//      your own association, subclass this template with
//      appropriate parameters and implement the traverse()
//      and clone() methods
template<class Src, class Dst>
class Typed_Link
  :
  public Link
{
protected:
  // spc: cf. Link
  void *v_traverse(void *src)
  { 
    return (void *)&traverse(*(Src *)src);
  }
  
  // spc: cf. Link
  //      (we do the obvious implementation here)
  void *v_traverse(void *src, const Handle &eof)
  {
    void *tmp = (void *)&traverse(*(Src *)src);
    if (eof == Handle(*(Dst *)tmp)) {
      throw Clank(eof, 1);
    }
    return tmp;
  }

public:
  virtual Dst &traverse(Src &) = 0;
  virtual ~Typed_Link(void) { }
};


// spc: an association chain; maintains heap-allocated link
//      objects in list parent class
template<class Src, class Dst>
class Chain
  : 
  private std::list<Link *>,
  public Typed_Link<Src, Dst>
{
  void *v_traverse(void *src, const Handle &eof)
  {
    void *tmp = src;
    iterator i;
    try {
      for (i = begin(); i != end(); ++i) {
	tmp = (*i)->v_traverse(tmp, eof);
      }
    } catch (Clank &c) {
      for (iterator j = begin(); 
	   j != i && j != end(); ++j) {
	c.distance += (*j)->get_size();
      }
      throw c;
    }
    return tmp;
  }

public:
  virtual ~Chain(void)
  {
    for (iterator i = begin(); i != end(); ++i) {
      delete *i;
    }
  }
  
  Chain(const Chain<Src, Dst> &r)
    : std::list<Link *>(r)
  {
    for (iterator i = begin(); i != end(); ++i) {
      *i = (*i)->clone();
    }
  }

  Chain(const Typed_Link<Src,Dst> &r)
    : std::list<Link *>(1, r.clone())
  {
  }
  
  template<class Mid>
  Chain(const Typed_Link<Src,Mid> &a,
	const Typed_Link<Mid,Dst> &b)
    : std::list<Link *>(2, (Link *)0)
  {
    front() = a.clone();
    back() = b.clone();
  }

  size_t get_size(void) const
  {
    size_t ret = 0;
    for (const_iterator i = begin(); i != end(); ++i) {
      ret += (*i)->get_size();
    }
    return ret;
  }

  // spc: for getting distance from s to h
  // pos: returns -1 if h isn't dereferenced
  //      during chain traversal; distance
  //      from s otherwise
  int get_distance(Src &s, const Handle &h)
  {
    if (h == Handle(s)) {
      return 0;
    }
    try {
      v_traverse(&s, h);
    } catch (Clank &c) {
      if (c.locus == h) {
	return c.distance;
      }
    }
    return -1;
  }

  Dst &traverse(Src &s)
  {
    void *tmp = &s;
    iterator i;
    try {
      for (i = begin(); i != end(); ++i) {
	tmp = (*i)->v_traverse(tmp);
      }
    } catch (Clank &c) {
      for (iterator j = begin(); j != i && j != end(); ++j) {
	c.distance += (*j)->get_size();
      }
      throw c;
    }
    return *(Dst *)tmp;
  }
  
  Link *clone(void) const
  {
    return new Chain<Src, Dst>(*this);
  }
};


// spc: this simplifies the chain initialization
template<class Src, class Mid, class Dst>
class Chain<Src, Dst>
operator+(const Typed_Link<Src, Mid> &a,
	  const Typed_Link<Mid, Dst> &b)
{
  return Chain<Src, Dst>(a, b);
}


// spc: link that takes a source of any
//      type to a Handle; it therefore allows
//      any chain to have its target
//      typed converted to a Handle
template<class Src>
class Handle_Link
  :
  public Typed_Link<Src, Handle>
{
public:
  Handle &traverse(Src &id) 
  {
    static Handle h(id);
    return h = Handle(id);
  }
  Link *clone(void) const
  {
    return new Handle_Link<Src>();
  }
};


// spc: link that associates a C-style array with a member
template<class Src, class Dst>
class Array_Link
  :
  public Typed_Link<Src, Dst>
{
  unsigned int index;
public:
  Array_Link(unsigned int _index)
    :
    index(_index)
  {}
  Dst &traverse(Src &id) 
  {
    if (index >= sizeof(Src)/sizeof(Dst)) {
      throw Clank(id);
    }
    return id[index];
  }
  Link *clone(void) const
  {
    return new Array_Link<Src, Dst>(index);
  }
};


// spc: link from stl container to a contained element using
//      find_first algorithm
template<class Src, class Dst>
class Find_First_Link
  :
  public Typed_Link<Src, Dst>
{
  Dst val;
public:
  Find_First_Link(const Dst &_val)
    :
    val(_val)
  {
  };

  Dst &traverse(Src &id) 
  {
    typename Src::iterator i;
    i = std::find(id.begin(), id.end(), val);
    if (i == id.end()) {
      throw Clank(Handle(id));
    }
    return (*i);
  }

  Link *clone(void) const
  {
    return new Find_First_Link<Src, Dst>(val);
  }
};


// spc: C++ pointer-to-member implemented as link
template<class Src, class Dst>
class Member_Link
  :
  public Typed_Link<Src, Dst>
{
  Dst Src::*mptr;

public:
  Member_Link(Dst Src::*_mptr)
    :
    mptr(_mptr)
  {}

  Dst &traverse(Src &s)
  {
    return s.*mptr;
  }

  Link *clone(void) const 
  { 
    return new Member_Link<Src, Dst>(mptr); 
  }
};


// spc: link for class attributes accessed by get() method;
//      the Get template parameter allows for some tweaking
//      of the type of get() method (const, non-const, &c.)
template<class Src, class Dst, class Get = 
	 Dst &(Src::*)(void) const>
class Get_Link
  :
  public Typed_Link<Src, Dst>
{
  Get get;

public:
  Get_Link(Get _get)
    :
    get(_get)
  {}

  Dst &traverse(Src &s)
  {
    return (s.*get)();
  }

  Link *clone(void) const 
  { 
    return new Get_Link<Src, Dst, Get>(get); 
  }
};


#endif
