#include "StdAfx.h"

#include "ClassDefs.h"

#include <iostream>


// Implementation of the nontrivial class...

nontrivial::nontrivial()
{
}

nontrivial::nontrivial(const std::string& s)
   : s_(s)
{
}

nontrivial::nontrivial(const nontrivial& src)
   : s_(src.s_)
{
}

nontrivial::~nontrivial()
{
}

nontrivial& nontrivial::operator=(const nontrivial& src)
{
   if (&src != this)
   {
      nontrivial tmp(src);

      s_ = tmp.s_;
   }

   return *this;
}

void nontrivial::const_op() const
{
   std::cout << "nontrivial::const_op()" << std::endl;
}

void nontrivial::non_const_op(const std::string& s)
{
   std::cout << "nontrivial::non_const_op()" << std::endl;
   s_ += s;
}


// Implementation of the UsesAttorney class

UsesAttorney::UsesAttorney()
{
}

UsesAttorney::~UsesAttorney()
{
}

void UsesAttorney::ua_do_something()
{
   nt_.non_const_op("ua_do_something");
}

int UsesAttorney::ua_h(const nontrivial& nt)
{
   nt.const_op();
   nt_.non_const_op("ua_h");
   return 0;
}

int UsesAttorney::ua_i(nontrivial& nt)
{
   nt.non_const_op("ua_i");
   nt_.non_const_op("ua_i");
   return 1;
}

int UsesAttorney::ua_j(nontrivial nt)
{
   nt_ = nt;
   return 3;
}

int UsesAttorney::ua_k(const nontrivial& nt) const
{
   nt.const_op();
   nt_.const_op();
   return 4;
}

int UsesAttorney::ua_l(nontrivial& nt) const
{
   nt.non_const_op("ua_l");
   nt_.const_op();
   return 5;
}

int UsesAttorney::ua_m(nontrivial nt) const
{
   nt.const_op();
   nt.non_const_op("ua_m");
   nt_.const_op();
   return 6;
}

nontrivial UsesAttorney::ua_n()
{
   nt_.non_const_op("ua_n");
   return nt_;
}

nontrivial UsesAttorney::ua_o() const
{
   nt_.const_op();
   return nt_;
}


// Implementation of the DoesntUseAttorney class

DoesntUseAttorney::DoesntUseAttorney()
{
}

DoesntUseAttorney::~DoesntUseAttorney()
{
}

void DoesntUseAttorney::dua_do_something()
{
   nt_.non_const_op("dua_do_something");
}

int DoesntUseAttorney::dua_h(const nontrivial& nt)
{
   nt.const_op();
   nt_.non_const_op("dua_h");
   return 0;
}

int DoesntUseAttorney::dua_i(nontrivial& nt)
{
   nt.non_const_op("dua_i");
   nt_.non_const_op("dua_i");
   return 1;
}

int DoesntUseAttorney::dua_j(nontrivial nt)
{
   nt_ = nt;
   return 3;
}

int DoesntUseAttorney::dua_k(const nontrivial& nt) const
{
   nt.const_op();
   nt_.const_op();
   return 4;
}

int DoesntUseAttorney::dua_l(nontrivial& nt) const
{
   nt.non_const_op("dua_l");
   nt_.const_op();
   return 5;
}

int DoesntUseAttorney::dua_m(nontrivial nt) const
{
   nt.const_op();
   nt.non_const_op("dua_m");
   nt_.const_op();
   return 6;
}

nontrivial DoesntUseAttorney::dua_n()
{
   nt_.non_const_op("dua_n");
   return nt_;
}

nontrivial DoesntUseAttorney::dua_o() const
{
   nt_.const_op();
   return nt_;
}

//	The comments in the following two functions show the assembly code
//	for the calls being made to the Attorney or directly to the grantor
//	class in the Release configuration.


//	Testing access to UsesAttorney via Attorney

void Attorney_test()
{
   UsesAttorney usesAttorney;

   usesAttorney.ua_do_something();

   nontrivial nt;
   nontrivial nt2("hello");

   Attorney::ua_h(usesAttorney, nt);
   // 133:      Attorney::ua_h(usesAttorney, nt);
   // 004047A7   lea         ecx,[esp+38h]
   // 004047AB   push        ecx
   // 004047AC   lea         ecx,[esp+28h]
   // 004047B0   call        UsesAttorney::ua_h (00404110)

   Attorney::ua_i(usesAttorney, nt);
   // 134:      Attorney::ua_i(usesAttorney, nt);
   // 004047B5   lea         edx,[esp+38h]
   // 004047B9   lea         ecx,[esp+24h]
   // 004047BD   push        edx
   // 004047BE   call        UsesAttorney::ua_i (004041f0)

   Attorney::ua_j(usesAttorney, nt);
   // 135:      Attorney::ua_j(usesAttorney, nt);
   // 004047C3   sub         esp,14h
   // 004047C6   lea         eax,[esp+4Ch]
   // 004047CA   mov         ecx,esp
   // 004047CC   mov         dword ptr [esp+24h],esp
   // 004047D0   push        eax
   // 004047D1   call        nontrivial::nontrivial (00403b30)
   // 004047D6   lea         ecx,[esp+38h]
   // 004047DA   call        UsesAttorney::ua_j (00404360)

   Attorney::ua_k(usesAttorney, nt);
   // 136:      Attorney::ua_k(usesAttorney, nt);
   // 004047DF   lea         ecx,[esp+38h]
   // 004047E3   push        ecx
   // 004047E4   lea         ecx,[esp+28h]
   // 004047E8   call        UsesAttorney::ua_k (004043b0)

   Attorney::ua_l(usesAttorney, nt);
   // 137:      Attorney::ua_l(usesAttorney, nt);
   // 004047ED   lea         edx,[esp+38h]
   // 004047F1   lea         ecx,[esp+24h]
   // 004047F5   push        edx
   // 004047F6   call        UsesAttorney::ua_l (004043d0)

   Attorney::ua_m(usesAttorney, nt);
   // 138:      Attorney::ua_m(usesAttorney, nt);
   // 004047FB   sub         esp,14h
   // 004047FE   lea         eax,[esp+4Ch]
   // 00404802   mov         ecx,esp
   // 00404804   mov         dword ptr [esp+24h],esp
   // 00404808   push        eax
   // 00404809   call        nontrivial::nontrivial (00403b30)
   // 0040480E   lea         ecx,[esp+38h]
   // 00404812   call        UsesAttorney::ua_m (004044c0)

   nt2 = Attorney::ua_n(usesAttorney);
   // 139:
   // 140:      nt2 = Attorney::ua_n(usesAttorney);
   // 00404817   lea         ecx,[esp+24h]
   // 0040481B   lea         edx,[esp+60h]
   // 0040481F   push        ecx
   // 00404820   push        edx
   // 00404821   call        Attorney::ua_n (004048b0)
   // 00404826   add         esp,8
   // 00404829   push        eax
   // 0040482A   lea         ecx,[esp+50h]
   // 0040482E   mov         byte ptr [esp+80h],5
   // 00404836   call        nontrivial::operator= (00403cd0)
   // 0040483B   lea         ecx,[esp+60h]
   // 0040483F   mov         byte ptr [esp+7Ch],bl
   // 00404843   call        nontrivial::~nontrivial (00403c80)

   nt2 = Attorney::ua_o(usesAttorney);
   // 141:      nt2 = Attorney::ua_o(usesAttorney);
   // 00404848   lea         eax,[esp+24h]
   // 0040484C   lea         ecx,[esp+60h]
   // 00404850   push        eax
   // 00404851   push        ecx
   // 00404852   call        Attorney::ua_o (004048d0)
   // 00404857   add         esp,8
   // 0040485A   push        eax
   // 0040485B   lea         ecx,[esp+50h]
   // 0040485F   mov         byte ptr [esp+80h],6
   // 00404867   call        nontrivial::operator= (00403cd0)
   // 0040486C   lea         ecx,[esp+60h]
   // 00404870   call        nontrivial::~nontrivial (00403c80)
}

// Testing access to DoesntUseAttorney via Attorney

void NonAttorney_test()
{
   DoesntUseAttorney doesntUseAttorney;

   doesntUseAttorney.dua_do_something();

   nontrivial nt;
   nontrivial nt2("hello");

   doesntUseAttorney.dua_h(nt);
   // 225:      doesntUseAttorney.dua_h(nt);
   // 004050A4   lea         edx,[esp+3Ch]
   // 004050A8   lea         ecx,[esp+28h]
   // 004050AC   push        edx
   // 004050AD   mov         dword ptr [esp+20h],ebx
   // 004050B1   mov         dword ptr [esp+24h],ebx
   // 004050B5   mov         dword ptr [esp+28h],ebx
   // 004050B9   call        DoesntUseAttorney::dua_h (004049f0)

   doesntUseAttorney.dua_i(nt);
   // 226:      doesntUseAttorney.dua_i(nt);
   // 004050BE   lea         eax,[esp+3Ch]
   // 004050C2   lea         ecx,[esp+28h]
   // 004050C6   push        eax
   // 004050C7   call        DoesntUseAttorney::dua_i (00404ad0)

   doesntUseAttorney.dua_j(nt);
   // 227:      doesntUseAttorney.dua_j(nt);
   // 004050CC   sub         esp,14h
   // 004050CF   lea         edx,[esp+50h]
   // 004050D3   mov         ecx,esp
   // 004050D5   mov         dword ptr [esp+28h],esp
   // 004050D9   push        edx
   // 004050DA   call        nontrivial::nontrivial (00403b30)
   // 004050DF   lea         ecx,[esp+3Ch]
   // 004050E3   call        DoesntUseAttorney::dua_j (00404c40)

   doesntUseAttorney.dua_k(nt);
   // 228:      doesntUseAttorney.dua_k(nt);
   // 004050E8   lea         eax,[esp+3Ch]
   // 004050EC   lea         ecx,[esp+28h]
   // 004050F0   push        eax
   // 004050F1   call        DoesntUseAttorney::dua_k (00404c90)

   doesntUseAttorney.dua_l(nt);
   // 229:      doesntUseAttorney.dua_l(nt);
   // 004050F6   lea         ecx,[esp+3Ch]
   // 004050FA   push        ecx
   // 004050FB   lea         ecx,[esp+2Ch]
   // 004050FF   call        DoesntUseAttorney::dua_l (00404cb0)

   doesntUseAttorney.dua_m(nt);
   // 230:      doesntUseAttorney.dua_m(nt);
   // 00405104   sub         esp,14h
   // 00405107   lea         edx,[esp+50h]
   // 0040510B   mov         ecx,esp
   // 0040510D   mov         dword ptr [esp+28h],esp
   // 00405111   push        edx
   // 00405112   call        nontrivial::nontrivial (00403b30)
   // 00405117   lea         ecx,[esp+3Ch]
   // 0040511B   call        DoesntUseAttorney::dua_m (00404da0)

   nt2 = doesntUseAttorney.dua_n();
   // 231:
   // 232:      nt2 = doesntUseAttorney.dua_n();
   // 00405120   lea         eax,[esp+64h]
   // 00405124   lea         ecx,[esp+28h]
   // 00405128   push        eax
   // 00405129   call        DoesntUseAttorney::dua_n (00404e90)
   // 0040512E   push        eax
   // 0040512F   lea         ecx,[esp+54h]
   // 00405133   mov         byte ptr [esp+84h],5
   // 0040513B   call        nontrivial::operator= (00403cd0)
   // 00405140   lea         ecx,[esp+64h]
   // 00405144   mov         byte ptr [esp+80h],4
   // 0040514C   call        nontrivial::~nontrivial (00403c80)

   nt2 = doesntUseAttorney.dua_o();
   // 233:      nt2 = doesntUseAttorney.dua_o();
   // 00405151   lea         ecx,[esp+64h]
   // 00405155   push        ecx
   // 00405156   lea         ecx,[esp+2Ch]
   // 0040515A   call        DoesntUseAttorney::dua_o (00404f90)
   // 0040515F   push        eax
   // 00405160   lea         ecx,[esp+54h]
   // 00405164   mov         byte ptr [esp+84h],6
   // 0040516C   call        nontrivial::operator= (00403cd0)
   // 00405171   lea         ecx,[esp+64h]
   // 00405175   call        nontrivial::~nontrivial (00403c80)
}

