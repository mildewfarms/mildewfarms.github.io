// Grantor.cpp : Implementation of class Grantor.
//

#include "stdafx.h"

#include "Grantor.h"

#include <iostream>

Grantor::Grantor()
: x_(-1)
{
   std::cout << "Grantor::Grantor()" << std::endl;
}

Grantor::~Grantor()
{
   std::cout << "Grantor::~Grantor()" << std::endl;
}

void Grantor::foo(int x)
{
   std::cout << "Grantor::foo(" << x << ")" << std::endl;
   x_ = x;
}

int Grantor::bar() const
{
   std::cout << "Grantor::bar() returning " << x_ << std::endl;
   return x_;
}