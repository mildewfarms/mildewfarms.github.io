// ACDemo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "Grantor.h"
#include "ClassDefs.h"

int main(int argc, char* argv[])
{
   // These just exercise the
   // interface defined in Listing 1
   do_foo(5);

   Grantor g;
   do_bar(g);

   // This is where it gets interesting...
   // Build the program in Release mode and
   // step into the optimized assembly code

   Attorney_test();
   NonAttorney_test();

   return 0;
}
