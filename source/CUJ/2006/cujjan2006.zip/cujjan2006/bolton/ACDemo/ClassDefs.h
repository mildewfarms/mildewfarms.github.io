#ifndef __CLASSDEFS_H__
#define __CLASSDEFS_H__

#include <string>


// nontrivial is a class which cannot be copied as a POD (plain-old-data) type.
// It has a copy constructor, a virtual destructor, an assignment operator, and
// sample const and non-const operations. It will be included as a member in the
// two classes, UsesAttorney and DoesntUseAttorney, that we will be examining.

class nontrivial
{
public:
   nontrivial();
   nontrivial(const std::string& s);
   nontrivial(const nontrivial& src);

   virtual ~nontrivial();

   nontrivial& operator=(const nontrivial& src);

   void const_op() const;
   void non_const_op(const std::string& s);

private:
   std::string s_;
};

// The classes UsesAttorney and DoesntUseAttorney demonstrate passing
// around instances of a nontrivial object in numerous ways: as a
// const reference, as a non-const reference, and as a value. These
// instances are passed into both const and non-const members of both
// classes. In addition, each class has a pair of members (one const and
// the other non-const) that each return a copy of a nontrivial object.

// The major difference between UsesAttorney and DoesntUseAttorney is that
// DoesntUseAttorney declares its test function (NonAttorney_test) directly
// as a friend function, whereas UsesAttorney grants access to its test
// function (Attorney_test) via its attorney class, Attorney.

class UsesAttorney
{
public:
   UsesAttorney();
   ~UsesAttorney();

   void ua_do_something();

private:
   int ua_h(const nontrivial& nt);
   int ua_i(nontrivial& nt);
   int ua_j(nontrivial nt);

   int ua_k(const nontrivial& nt) const;
   int ua_l(nontrivial& nt) const;
   int ua_m(nontrivial nt) const;

   nontrivial ua_n();
   nontrivial ua_o() const;

   nontrivial nt_;

   friend class Attorney;
};

class Attorney
{
// private:
   static int ua_h(UsesAttorney& cl, const nontrivial& nt) {	return cl.ua_h(nt); }
   static int ua_i(UsesAttorney& cl, nontrivial& nt) {	return cl.ua_i(nt); }
   static int ua_j(UsesAttorney& cl, nontrivial& nt) {	return cl.ua_j(nt); }

   static int ua_k(const UsesAttorney& cl, const nontrivial& nt) {	return cl.ua_k(nt); }
   static int ua_l(const UsesAttorney& cl, nontrivial& nt) {	return cl.ua_l(nt); }
   static int ua_m(const UsesAttorney& cl, nontrivial& nt) {	return cl.ua_m(nt); }

   static nontrivial ua_n(UsesAttorney& cl) {	return cl.ua_n(); }
   static nontrivial ua_o(const UsesAttorney& cl) {	return cl.ua_o(); }

   friend void Attorney_test();
};

void Attorney_test();


class DoesntUseAttorney
{
public:
   DoesntUseAttorney();
   ~DoesntUseAttorney();

   void dua_do_something();

private:
   int dua_h(const nontrivial& nt);
   int dua_i(nontrivial& nt);
   int dua_j(nontrivial nt);

   int dua_k(const nontrivial& nt) const;
   int dua_l(nontrivial& nt) const;
   int dua_m(nontrivial nt) const;

   nontrivial dua_n();
   nontrivial dua_o() const;

   nontrivial nt_;

   friend void NonAttorney_test();
};


void NonAttorney_test();

#endif	//	__CLASSDEFS_H__
