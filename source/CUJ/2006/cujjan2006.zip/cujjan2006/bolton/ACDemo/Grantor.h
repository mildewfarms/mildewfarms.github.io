// Listing 1: The Grantor class, its attorney GrantorAttorney,
// and the free functions that are given controlled access to
// Grantor by way of GrantorAttorney

#ifndef __GRANTOR_H__
#define __GRANTOR_H__

class Grantor
{
public:
   Grantor();
   ~Grantor();

   /*

    ...

    */

private:
   // There's a lot in this class that we don't want anyone
   // else to see...
   /*

    ...

    */
   int x_;

   // But there are a couple of member functions we want
   // to expose to our friends
   void foo(int x);
   int bar() const;

   // Declare our "attorney" as a friend
   friend class GrantorAttorney;
};

// Definition of the GrantorAttorney class should be in the same
// header as Grantor's definition
class GrantorAttorney
{
private: // private is not actually necessary here, since there are no public members of this class
   static void foo(Grantor& g, int x)
   { g.foo(x); }

   static int bar(const Grantor& g)
   { return g.bar(); }

   // These are the only functions that will be able to access the
   // attorney's private members, and through them the private
   // members of the grantor. Class members or whole classes could
   // be declared friends as well:

   friend void do_foo(int x);
   friend int do_bar(const Grantor&);
};

// do_foo and do_bar would normally be defined somewhere else.
// They're just here for illustrative purposes.

inline void do_foo(int x)
{
   Grantor g;
   GrantorAttorney::foo(g, x);
}

inline int do_bar(const Grantor& g)
{
   return GrantorAttorney::bar(g);
}


#endif // __GRANTOR_H__
