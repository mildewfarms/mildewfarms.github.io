/*------------------------------------------------------------------------

Copyright (C) 1998, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;
using namespace System::IO;
using namespace System::Runtime::Serialization::Formatters::Binary;

int main() 
{
	Vector<int>^ v1a = gcnew Vector<int>(30);

	Vector<int>^ v2a = gcnew Vector<int>(10);
	v2a[0] = 5;
	v2a[9] = 7;

	Vector<int>^ v3a = gcnew Vector<int>(15);
	for (int i = 0; i < v3a->Length; ++i)
	{		
		v3a[i] = 255;
	}

	Vector<double>^ v4a = gcnew Vector<double>(10000);
	Vector<String^>^ v5a = gcnew Vector<String^>(5);
	v5a[0] = "ABC";
	v5a[2] = "HIJKL";
	v5a[4] = "XY";

	BinaryFormatter^ formatter = gcnew BinaryFormatter;

	Stream^ file = File::Open("Vector.ser", FileMode::Create);
	formatter->Serialize(file, v1a);
	formatter->Serialize(file, v2a);
	formatter->Serialize(file, v3a);
	formatter->Serialize(file, v4a);
	formatter->Serialize(file, v5a);
	file->Close();
	
	file = File::Open("Vector.ser", FileMode::Open);
	Vector<int>^ v1b = static_cast<Vector<int>^>(formatter->Deserialize(file));
	Vector<int>^ v2b = static_cast<Vector<int>^>(formatter->Deserialize(file));
	Vector<int>^ v3b = static_cast<Vector<int>^>(formatter->Deserialize(file));
	Vector<double>^ v4b = static_cast<Vector<double>^>(formatter->Deserialize(file));
	Vector<String^>^ v5b = static_cast<Vector<String^>^>(formatter->Deserialize(file));
	file->Close();
    
	Console::WriteLine("v1a: {0}", v1a);
	Console::WriteLine("v1b: {0}", v1b);
	Console::WriteLine("v2a: {0}", v2a);
	Console::WriteLine("v2b: {0}", v2b);
	Console::WriteLine("v3a: {0}", v3a);
	Console::WriteLine("v3b: {0}", v3b);
	Console::WriteLine("v4a: {0}", v4b);
	Console::WriteLine("v4b: {0}", v4b);
	Console::WriteLine("v5a: {0}", v5b);
	Console::WriteLine("v5b: {0}", v5b);
}