/*------------------------------------------------------------------------

Copyright (C) 2001, 2004, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
21 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;

generic <typename T>
[Serializable]
public ref class Vector
{
	int length;
/*1*/	array<T>^ vector;

public:

	property int Length
	{
		int get() { return length; }
	private:
		void set(int value) { length = value; }
	}

/*2*/	property T default[int]
	{
		T get(int index) { return vector[index]; }
		void set(int index, T value) { vector[index] = value; }
	}

	Vector(int vectorLength, T initValue)
	{
		Length = vectorLength;
		vector = gcnew array<T>(Length);
		for (int i = 0; i < Length; ++i)
		{
/*3*/			this[i] = initValue;
		}

/*4*/		//for each (T element in vector)
		//{
		//	element = initValue;
		//}
	}

	Vector(int vectorLength)
	{
		Length = vectorLength;
		vector = gcnew array<T>(Length);
		for (int i = 0; i < Length; ++i)
		{
/*5*/			this[i] = T();
		}
	}

	Vector()
	{
		Length = 0;
/*6*/		vector = gcnew array<T>(0);
	}

	~Vector()		// redundant
	{
/*7*/		vector = nullptr;
	}

	virtual String^ ToString() override
	{
		String^ s = "[";
		int i;
		for (i = 0; i < Length - 1; ++i)
		{
/*8*/			s = String::Concat(s, this[i], ":");
		}
/*9*/		s = String::Concat(s, this[i], "]");
		return s;
	}

	virtual bool Equals(Object^ obj) override
	{
		if (obj == nullptr)
		{
			return false;
		}

		if (this == obj)	// are we testing against ourselves?
		{
			return true;
		}

/*10*/		if (GetType() == obj->GetType())
		{
			Vector<T>^ v = static_cast<Vector^>(obj);
			if (Length != v->Length) // do vectors have different lengths
			{
				return false;
			}

			for (int i = 0; i < Length; ++i)
			{
/*11*/				//if (this[i] != v[i])
				if (this[i]->Equals(v[i]) == false)
				{
					return false;
				}
			}
			return true;
		}

		return false;
	}

/*12*/	virtual int GetHashCode() override
	{
		return 0; // what to return?
	}
};
