/*------------------------------------------------------------------------

Copyright (C) 1998, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;
using namespace System::IO;
using namespace System::Runtime::Serialization::Formatters::Binary;

/*1*/ [Serializable] 
ref class Employee { /* ... */};

int main() 
{
	Employee^ emp1 = gcnew Employee();
	Employee^ emp2 = gcnew Employee();
	Employee^ emp3 = emp2;
/*2a*/	Console::WriteLine("emp1 == emp2 is {0}", (emp1 == emp2));
/*2b*/	Console::WriteLine("emp2 == emp3 is {0}", (emp2 == emp3));
/*2c*/	Console::WriteLine("emp1 == emp3 is {0}", (emp1 == emp3));

	array<Object^>^ list = gcnew array<Object^>(2);
	list[0] = emp1;
	list[1] = list[0];
/*2d*/	Console::WriteLine("list[0] == list[1] is {0}", (list[0] == list[1]));
/*2e*/	Console::WriteLine("list[0] == emp1 is {0}", (list[0] == emp1));
/*2f*/	Console::WriteLine("list[1] == emp1 is {0}", (list[1] == emp1));

	// Serialize data to a file.

	BinaryFormatter^ formatter = gcnew BinaryFormatter;
	Stream^ file = File::Open("Sr03.ser", FileMode::Create);

/*3a*/	formatter->Serialize(file, emp1);
/*3b*/	formatter->Serialize(file, emp2);
/*3c*/	formatter->Serialize(file, emp3);
/*3d*/	formatter->Serialize(file, list);

	file->Close();

	// Deserialize data from a file.

	file = File::Open("Sr03.ser", FileMode::Open);

/*4a*/	emp1 = static_cast<Employee^>(formatter->Deserialize(file));
/*4b*/	emp2 = static_cast<Employee^>(formatter->Deserialize(file));
/*4c*/	emp3 = static_cast<Employee^>(formatter->Deserialize(file));
/*4d*/	list = static_cast<array<Object^>^>(formatter->Deserialize(file));

	file->Close();

/*5a*/	Console::WriteLine("emp1 == emp2 is {0}", (emp1 == emp2));
/*5b*/	Console::WriteLine("emp2 == emp3 is {0}", (emp2 == emp3));
/*5c*/	Console::WriteLine("emp1 == emp3 is {0}", (emp1 == emp3));
/*5d*/	Console::WriteLine("list[0] == list[1] is {0}", (list[0] == list[1]));
/*5e*/	Console::WriteLine("list[0] == emp1 is {0}", (list[0] == emp1));
/*5f*/	Console::WriteLine("list[1] == emp1 is {0}", (list[1] == emp1));
}