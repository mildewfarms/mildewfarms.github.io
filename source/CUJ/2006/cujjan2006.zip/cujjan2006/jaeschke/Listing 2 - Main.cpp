/*------------------------------------------------------------------------

Copyright (C) 1998, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;
using namespace System::IO;
using namespace System::Collections;
using namespace System::Runtime::Serialization::Formatters::Binary;

int main()
{
/*1*/	Hashtable^ dictionary = gcnew Hashtable(21000);

	StreamReader^ inStream = File::OpenText("dictionary.txt");
	String^ str;

	while ((str = inStream->ReadLine()) != nullptr)
	{
/*2*/		dictionary->Add(str, nullptr);
	}

	inStream->Close();
/*3*/	Console::WriteLine("Dictionary contains {0} entries", dictionary->Count);

	BinaryFormatter^ formatter = gcnew BinaryFormatter();
	Stream^ file = File::Open("dictionary.ser", FileMode::Create);
/*4*/	formatter->Serialize(file, dictionary);
	file->Close();
}