/*------------------------------------------------------------------------

Copyright (C) 1998, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;
using namespace System::IO;
using namespace System::Collections;
using namespace System::Runtime::Serialization::Formatters::Binary;

int main()
{
	BinaryFormatter^ formatter = gcnew BinaryFormatter;

	Stream^ file = File::Open("dictionary.ser", FileMode::Open);
/*1*/	Hashtable^ dictionary = static_cast<Hashtable^>(formatter->Deserialize(file));
	file->Close();

/*2*/	Console::WriteLine("Dictionary contains {0} entries", dictionary->Count);

	String^ word;
	while (true)
	{
		Console::Write("Enter a word: ");
		word = Console::ReadLine();
		if (word == nullptr)
		{
			break;
		} 
/*3*/		Console::WriteLine("{0}{1} found", word, 
			(dictionary->Contains(word) ? "" : " not"));
	}
}