/*------------------------------------------------------------------------

Copyright (C) 2000, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;

/*1*/ [Serializable]
public ref class Pair
{
	int count;				// serialized
	String^ description;			// serialized

/*2*/	[NonSerialized] int temp1;		// not serialized
/*3*/	[NonSerialized] String^ temp2;		// not serialized

public:
	Pair(int cnt, String^ desc)
	{
		count = cnt;
		description = desc;
/*3*/		temp1 = -100;
/*4*/		temp2 = "XXX";
	}

	virtual String^ ToString() override
	{
		return "Pair -- count: " + count 
			+ ", description: " + description 
			+ ", temp1: " + temp1
			+ ", temp2: >" + (temp2 == nullptr ? "NULL" : temp2) + "<";
	}
};