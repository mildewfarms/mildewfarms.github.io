/*------------------------------------------------------------------------

Copyright (C) 1998, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;
using namespace System::IO;
using namespace System::Runtime::Serialization::Formatters::Binary;

int main() 
{
	Console::WriteLine("PointCount: {0}", Point::PointCount);
	Point^ p1 = gcnew Point(15, 10);
	Point^ p2 = gcnew Point(-2, 12);
	array<Point^>^ p3 = {gcnew Point(18, -5), gcnew Point(25, 19)};
	Console::WriteLine("PointCount: {0}", Point::PointCount);

	BinaryFormatter^ formatter = gcnew BinaryFormatter;
	Stream^ file = File::Open("Point.ser", FileMode::Create);

	formatter->Serialize(file, p1);
	formatter->Serialize(file, p2);
	formatter->Serialize(file, p3);

	file->Close();
	
	file = File::Open("Point.ser", FileMode::Open);

	Point^ p4 = static_cast<Point^>(formatter->Deserialize(file));
	Console::WriteLine("PointCount: {0}", Point::PointCount);
	Point^ p5 = static_cast<Point^>(formatter->Deserialize(file));
	Console::WriteLine("PointCount: {0}", Point::PointCount);
	array<Point^>^ p6 = static_cast<array<Point^>^>(formatter->Deserialize(file));
	Console::WriteLine("PointCount: {0}", Point::PointCount);

	file->Close();
    
	Console::WriteLine("p1: {0}, p4: {1}", p1, p4);
	Console::WriteLine("p2: {0}, p5: {1}", p2, p5);
	Console::WriteLine("p3[0]: {0}, p6[0]: {1}", p3[0], p6[0]);
	Console::WriteLine("p3[1]: {0}, p6[1]: {1}", p3[1], p6[1]);
}