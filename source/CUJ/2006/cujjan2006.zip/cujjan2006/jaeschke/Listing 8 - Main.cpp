/*------------------------------------------------------------------------

Copyright (C) 1998, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;
using namespace System::IO;
using namespace System::Runtime::Serialization::Formatters::Binary;

int main() 
{
	Pair^ p1 = gcnew Pair(10, "ball");
	BinaryFormatter^ formatter = gcnew BinaryFormatter;

	// Serialize data to a file.

	Stream^ file = File::Open("Sr05.ser", FileMode::Create);
	formatter->Serialize(file, p1);
	file->Close();

	// Deserialize data from a file.

	file = File::Open("Sr05.ser", FileMode::Open);
	Pair^ p2 = static_cast<Pair^>(formatter->Deserialize(file));
	file->Close();

	Console::WriteLine("p1 = {0}", p1);
	Console::WriteLine("p2 = {0}", p2);
}