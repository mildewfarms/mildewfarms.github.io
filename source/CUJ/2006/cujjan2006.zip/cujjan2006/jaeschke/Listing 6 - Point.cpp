/*------------------------------------------------------------------------

Copyright (C) 1998, 2001, 2005 Rex Jaeschke. All rights reserved.

Rex Jaeschke
2051 Swans Neck Way
Reston, VA 20191-4023
+1 703 860-0091
+1 703 860-3008 (fax)
rex@RexJaeschke.com

------------------------------------------------------------------------*/

using namespace System;
using namespace System::IO;
using namespace System::Runtime::Serialization;

[Serializable]
/*1*/ public ref class Point : ISerializable
{
	int xor;
	int yor;
/*2*/	static int pointCount = 0;

public:
	property int X {
		int get() { return xor; }
		void set(int value) { xor = value; }
	}
	property int Y {
		int get() { return yor; }
		void set(int value) { yor = value; }
	}
	static property int PointCount {
		int get() { return pointCount; }
		void set(int value) { pointCount = value; }
	}

	Point()
	{
		X = 0;
		Y = 0;
/*3*/		++PointCount;
	}

	Point(int x, int y)
	{
		X = x;
		Y = y;
		++PointCount;
	}

	virtual String^ ToString() override
	{
		return "(" + X + "," + Y + ")";
	}

/*4*/	virtual void GetObjectData(SerializationInfo^ si, StreamingContext context) 
	{
	// Indicate which values are to be serialized

/*5*/		si->AddValue("x-coordinate", X);
/*6*/		si->AddValue("y-coordinate", Y);
	}

private:
/*7*/	Point(SerializationInfo^ si, StreamingContext^ context) 
	{
	// Restore the x- and y-coordinate values by name using approach 1

/*8a*/		X = si->GetInt32("x-coordinate");
/*8b*/		Y = si->GetInt32("y-coordinate");

	// or restore them by name using approach 2

/*9a*/		Y = static_cast<int>(si->GetValue("y-coordinate", Y.GetType()));
/*9b*/		X = static_cast<int>(si->GetValue("x-coordinate", X.GetType()));

/*10*/		++PointCount;
	}
};