//  Waiter.m

#import "Waiter.h"
#import <stdlib.h>

@implementation Waiter

- (id) init {
  [super init];
  numberOfDinersServed = 0;
  return self;
}

// Here is the implementation of the "ServesTables" protocol:

- (NSArray *) takeOrdersFromDiners:(NSArray *)diners {
  
  // create somewhere to take orders
  NSMutableArray *orders = [[NSMutableArray alloc] init];
  
  int i;
  for (i=0; i < [diners count]; i++) {
    NSString *order = [[diners objectAtIndex:i] foodPreference];
    [orders addObject:order];
    numberOfDinersServed++;
  }
  return orders;
}

- (BOOL) doesNotLikeDiner: (Diner *)diner withOrder: (NSString *)order {
  if ([diner isRude] && [order isEqualTo:@"Fish"]) {
    return YES;
  }
  return NO;
}

- (void) spillDrinkOnDiner:(Diner *) diner {
  NSLog(@"%@ just spilled a drink on %@!", self, diner);
  [diner setIsRude:YES];
}

- (double) bringCheckOfAmount:(double)amount toDiner:(Diner *)diner {
  if ([diner isRude]) {
    return (amount + 20.0);
  }
  return amount;
}

- (BOOL) seemsStressed {
  return (numberOfDinersServed > 2);
}

- (void) takeSmokeBreakOf:(int)minutes {
  NSLog(@"%@ is on a smoke break of %d minutes", self, minutes);
}

@end
