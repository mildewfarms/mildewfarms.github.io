//  Diner.h

#import <Cocoa/Cocoa.h>
#import "Person.h"

@interface Diner : Person 
{
@private
	BOOL     isRude;
}

- (BOOL) isRude;
- (void) setIsRude:(BOOL)value;
- foodPreference;

@end
