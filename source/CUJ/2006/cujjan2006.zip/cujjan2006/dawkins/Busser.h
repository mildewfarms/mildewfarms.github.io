//  Busser.h

#import <Cocoa/Cocoa.h>
#import "Person.h"
#import "ServesTables.h"

@interface Busser : Person <ServesTables>
{
@private
	int numberOfDinersServed;
}
@end