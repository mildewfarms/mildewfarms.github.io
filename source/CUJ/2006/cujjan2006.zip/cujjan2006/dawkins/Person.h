//  Person.h

#import <Cocoa/Cocoa.h>

@interface Person : NSObject 
{
	id description;
}

- (NSString *) description;
- (void)       setDescription:(NSString *)value;

@end