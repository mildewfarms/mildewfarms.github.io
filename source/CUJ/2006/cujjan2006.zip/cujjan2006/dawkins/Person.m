//  Person.m

#import "Person.h"

@implementation Person

- (NSString *) description {
	return description;
}

- (void) setDescription:(NSString *)value {
	[description release];
	description = [value retain];
}

- (void) dealloc {
	NSLog(@"Releasing person %@", description);
	[description release];
	[super dealloc];
}

@end
