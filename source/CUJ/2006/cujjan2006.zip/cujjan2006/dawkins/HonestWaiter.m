//  HonestWaiter.m

#import "HonestWaiter.h"

@implementation HonestWaiter

- (double) bringCheckOfAmount:(double)amount toDiner:(Diner *)diner {
	NSLog(@"Waiter %@ is an honest waiter", description);
	return amount;
}

@end
