//  Waiter.h

#import <Cocoa/Cocoa.h>
#import "ServesTables.h"
#import "Person.h"

@interface Waiter : Person <ServesTables>
{
@private
	int numberOfDinersServed;
}

@end
