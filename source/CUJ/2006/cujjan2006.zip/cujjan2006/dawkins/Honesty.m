//  Honesty.m

#import "Honesty.h"

@implementation Waiter (Honesty)

- (double) bringCheckOfAmount:(double)amount toDiner:(Diner *)diner {
	NSLog(@"Waiter %@ has decided to be honest and not inflate the check", description);
	return amount;
}

@end
