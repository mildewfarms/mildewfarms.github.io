//  Restaurant.h

#import <Cocoa/Cocoa.h>
#import "Waiter.h"
#import "Diner.h"
#import "Busser.h"

@interface Restaurant : NSObject 
{
	Waiter  *waiter;
	Busser  *busser;
}

- (void) openDoorsToDiners:(NSArray *)diners;
@end
