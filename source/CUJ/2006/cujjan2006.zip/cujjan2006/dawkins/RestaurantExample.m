#import <Foundation/Foundation.h>
#import "Restaurant.h"
#import "HonestWaiter.h"

int main (int argc, const char * argv[]) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	[HonestWaiter poseAsClass:[Waiter class]];

    NSLog(@"Opening the restaurant!");
	
	id restaurant = [Restaurant new];
	
	// ignore argument checking here...
	int numberOfDiners = atoi(argv[1]);
	NSLog(@"Setting up the restaurant with %d diners", numberOfDiners);
	
	// create some diners
	NSMutableArray *diners = [NSMutableArray new];
	Diner *diner;
	int i;
	for (i=0; i < numberOfDiners; i++) {
		diner = [Diner new];
		[diner setIsRude: (i%2 ? YES : NO)];
		[diner setDescription:[NSString stringWithFormat:@"Diner number %d", i+1]];
		[diners addObject:diner];
	}
	
	// open the restaurant for business
	[restaurant openDoorsToDiners:diners];
	
	// clean up
	[restaurant release];
	[diners release];
	[pool release];
    return 0;
}
