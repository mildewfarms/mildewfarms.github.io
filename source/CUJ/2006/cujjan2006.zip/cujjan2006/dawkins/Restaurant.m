//  Restaurant.m

#import "Restaurant.h"

@implementation Restaurant

- (id) init {
	[super init];
	
	// create a waiter
	waiter = [Waiter new];
	[waiter setDescription:@"Walter"];
	
	// create a busser
	busser = [Busser new];
	[busser setDescription:@"Little Jonny"];
	
	return self;
}

// start running the restaurant
- (void) openDoorsToDiners:(NSArray *)diners {

	NSLog(@"Open!");
	int i;
	id <ServesTables> currentServer;
	
	// create a list of who can serve tables tonight:
	NSMutableArray *availableServers = [NSMutableArray new];
	[availableServers addObject:waiter];
	[availableServers addObject:busser];
	
	// pick the first from the list and shift them down
	currentServer = [availableServers objectAtIndex:0];
	[availableServers removeObjectAtIndex:0];
	
	while (currentServer && [currentServer conformsToProtocol:@protocol(ServesTables)]) {
		
		NSArray *orders = [currentServer takeOrdersFromDiners:diners];
		
		// who's having what?
		for (i=0; i < [orders count]; i++) {
			Diner    *diner = [diners objectAtIndex:i];
			NSString *order = [orders objectAtIndex:i];
			
			NSLog(@"%@ is having the %@", [diner description], order);
			
			if ([currentServer doesNotLikeDiner:diner withOrder:order]) {
				[currentServer spillDrinkOnDiner:diner];
			}
		}
		
		// now give them the check
		for (i=0; i < [diners count]; i++) {
			Diner    *diner = [diners objectAtIndex:i];
			double amountShownToDiner = [currentServer bringCheckOfAmount: (double)30.0 
																  toDiner: (Diner *)diner];
			
			NSLog(@"%@ gave the check to %@ asking for %2.2f dollars", currentServer, diner, amountShownToDiner);
		}
		
		if ([currentServer seemsStressed]) {
			[currentServer takeSmokeBreakOf:5];
			
			// if there are any other servers, grab one
			if ([availableServers count]) {
				currentServer = [availableServers objectAtIndex:0];
				[availableServers removeObjectAtIndex:0];
			} else {
				currentServer = nil;
			}
		}
	}
}

// clean up when the restaurant closes its doors
- (void) dealloc {
	NSLog(@"Closing down!");
	[waiter release];
	[busser release];
	[super dealloc];
}

@end
