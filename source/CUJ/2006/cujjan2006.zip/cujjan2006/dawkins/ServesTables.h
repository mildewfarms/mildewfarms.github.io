#import <Cocoa/Cocoa.h>
#import "Diner.h"

@protocol ServesTables
- (NSArray *) takeOrdersFromDiners:(NSArray *) diners;
- (BOOL)      doesNotLikeDiner:(Diner *) diner withOrder:(NSString *)order;
- (void)      spillDrinkOnDiner:(Diner *) diner;
- (double)    bringCheckOfAmount:(double) amount toDiner:(Diner *) diner;
- (BOOL)      seemsStressed;
- (void)      takeSmokeBreakOf:(int) minutes;
@end