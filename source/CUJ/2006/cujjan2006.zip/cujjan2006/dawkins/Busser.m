//  Busser.m

#import "Busser.h"

@implementation Busser

// Here is the implementation of the "ServesTables" protocol:

- (NSArray *) takeOrdersFromDiners:(NSArray *)diners {
  
  // create somewhere to take orders
  NSMutableArray *orders = [[NSMutableArray alloc] init];
  
  int i;
  for (i=0; i < [diners count]; i++) {
    NSString *order = [[diners objectAtIndex:i] foodPreference];
    [orders addObject:order];
    numberOfDinersServed++;
  }
  return orders;
}

- (BOOL) doesNotLikeDiner: (Diner *)diner withOrder: (NSString *)order {
  if ([diner isRude]) {
    return YES;
  }
  return NO;
}

- (void) spillDrinkOnDiner:(Diner *)diner {
  NSLog(@"%@ just spilled a drink on %@!", self, diner);
  [diner setIsRude:YES];
}

- (double) bringCheckOfAmount:(double)amount toDiner:(Diner *)diner {
  return amount;
}

- (BOOL) seemsStressed {
  return (numberOfDinersServed > 3);
}

- (void) takeSmokeBreakOf:(int)minutes {
  NSLog(@"%@ is on a smoke break of %d minutes", self, minutes);
}

@end
