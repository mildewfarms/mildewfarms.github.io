//  Honesty.h

#import <Cocoa/Cocoa.h>
#import "Waiter.h"

@interface Waiter (Honesty) 

- (double) bringCheckOfAmount:(double)amount toDiner:(Diner *)diner;

@end
