//  Diner.m

#import "Diner.h"

@implementation Diner

- (id) foodPreference {
	if (rand() > (RAND_MAX / 2)) {
		return [NSString stringWithCString:"Chicken"];
	}
	return [NSString stringWithCString:"Fish"];
}

- (BOOL) isRude {
	return isRude;
}

- (void) setIsRude:(BOOL)value {
	isRude = value;
}

@end
