//  HonestWaiter.h

#import <Cocoa/Cocoa.h>
#import "Waiter.h"

@interface HonestWaiter : Waiter 
- (double) bringCheckOfAmount:(double)amount toDiner:(Diner *)diner;
@end
