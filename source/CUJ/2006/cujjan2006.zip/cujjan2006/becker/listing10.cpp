#include <array>
#include <tuple>
#include <iostream>
#include <typeinfo>
using std::tr1::array;
using std::tr1::tuple; using std::tr1::get;
using std::tr1::tuple_size; using std::tr1::tuple_element;
using std::cout;

template <class Tuple>
void show_properties(Tuple tpl)
  { // show properties of argument
  cout << "Argument has "
    << tuple_size<Tuple>::value << " elements.\n";
  cout << "First element has type "
    << typeid(tuple_element<0, Tuple>::type).name() << '\n';
  cout << "First element has value "
    << get<0>(tpl) << '\n';
  }

int main()
  { // show tuple-like interface to array
  tuple<int, int, int> tpl;
  array<int, 3> arr = {};
  show_properties(tpl);
  cout << '\n';
  show_properties(arr);
  return 0;
  }