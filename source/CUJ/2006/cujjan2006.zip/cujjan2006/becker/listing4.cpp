#include <array>
#include <ostream>
#include <iostream>
using std::tr1::array;
using std::cout; using std::basic_ostream;

struct S
  {
  S() : val(-1) {}
  S(int i) : val(i + 1) {}
  int val;
  };

template <class Elem, class Traits>
basic_ostream<Elem, Traits>& operator<<(
  basic_ostream<Elem, Traits>& os, S s)
  {
  return os << s.val;
  }

int main()
  { // demonstrate array initialization
  const int size = 7;
  S carray[size] = { 1, 1, 2, 3, 5 };
  array<S, size> arr = { 1, 1, 2, 3, 5 };
  for (int i = 0; i < size; ++i)
    cout << carray[i] << ' ';
  cout << '\n';
  for (int i = 0; i < size; ++i)
    cout << arr[i] << ' ';
  cout << '\n';
  return 0;
  }