// the TR1 header <array>

namespace std {     // C++ Standard Library
 namespace tr1 {    // TR1 additions
template<class Ty, std::size_t N>
    class array;
        // TEMPLATE FUNCTIONS
template<class Ty, std::size_t N>
    bool operator==(const array<Ty, N>& left,
        const array<Ty, N>& right);
template<class Ty, std::size_t N>
    bool operator!=(const array<Ty, N>& left,
        const array<Ty, N>& right);
template<class Ty, std::size_t N>
    bool operator<(const array<Ty, N>& left,
        const array<Ty, N>& right);
template<class Ty, std::size_t N>
    bool operator<=(const array<Ty, N>& left,
        const array<Ty, N>& right);
template<class Ty, std::size_t N>
    bool operator>(const array<Ty, N>& left,
        const array<Ty, N>& right);
template<class Ty, std::size_t N>
    bool operator>=(const array<Ty, N>& left,
        const array<Ty, N>& right);
template<class Ty, std::size_t N>
    void swap(array<Ty, N>& left, array<Ty, N>& right);
        // tuple-LIKE INTERFACE
template<int Idx, class T, std::size_t N>
     RI get(array<T, N>&);
template<int Idx, class T, std::size_t N>
     const RI get(const array<T, N>&);
template<class T, std::size_t N>
    class tuple_element<array<T, N> >;
template<class T, std::size_t N>
    class tuple_size<array<T, N> >;
} };
