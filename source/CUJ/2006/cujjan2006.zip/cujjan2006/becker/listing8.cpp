#include <array>
#include <iostream>
using std::tr1::array;
using std::cout;

const int size = 7;

struct S
  { // struct that wraps C-style array
  int data[size];
  };

void show_elements(int *arr, int count)
  { // show array elements
  for (int i = 0; i < count; ++i)
    cout << arr[i] << ' ';
  cout << '\n';
  }

int main()
  { // demonstrate assignment
  S carray = { 1, 1, 2, 3, 5 };
  array<int, size> arr = { 1, 1, 2, 3, 5 };
  show_elements(carray.data, size);
  show_elements(arr.data(), size);
  cout << '\n';
  S carray1 = {};
  array<int, size> arr1 = {};
  carray = carray1;
  arr = arr1;
  show_elements(carray.data, size);
  show_elements(arr.data(), size);
  cout << '\n';
  return 0;
  }