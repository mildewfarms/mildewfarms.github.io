#include <array>
#include <iostream>
using std::tr1::array;
using std::cout;

template <class Iter>
void show_elements(Iter first, Iter last)
  { // show elements of a sequence
  cout << "[ ";
  while (first != last)
    cout << *first++ << ' ';
  cout << "]\n";
  }

void show_elements(const int *data, int count)
  { // show elements of an array
  cout << "[ ";
  while (count-- != 0)
    cout << *data++ << ' ';
  cout << "]\n";
  }

int main()
  { // demonstrate zero-sized array objects
  const int size = 5;
  array<int, size> arr = { 1, 1, 2, 3, 5 };
  show_elements(arr.begin(), arr.end());
  show_elements(arr.data(), arr.size());
  cout << '\n';

  array<int, 0> arr0;
  show_elements(arr0.begin(), arr0.end());
  show_elements(arr0.data(), arr0.size());
  return 0;
  }