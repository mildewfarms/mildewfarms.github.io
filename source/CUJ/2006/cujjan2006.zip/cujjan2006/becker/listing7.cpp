#include <array>
#include <iostream>
using std::tr1::array;
using std::cout;

void show_elements(int *arr, int count)
  { // show array elements
  for (int i = 0; i < count; ++i)
    cout << arr[i] << ' ';
  cout << '\n';
  }

int main()
  { // demonstrate use of data member function
  const int size = 7;
  int carray[size] = { 1, 1, 2, 3, 5 };
  array<int, size> arr = { 1, 1, 2, 3, 5 };
  show_elements(carray, sizeof(carray) / sizeof(carray[0]));
  show_elements(arr.data(), arr.size());
  return 0;
  }