// synopsis of template class array

template<class Ty, std::size_t N>
    class array {   // fixed size array of values
public:
    // NESTED TYPES
    typedef std::size_t size_type;
    typedef std::ptrdiff_t difference_type;
    typedef Ty& reference;
    typedef const Ty& const_reference;
    typedef Ty *pointer;
    typedef const Ty *const_pointer;
    typedef T0 iterator;
    typedef T1 const_iterator;
    typedef Ty value_type;
    typedef std::reverse_iterator<iterator> reverse_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

    // CONSTRUCTORS (exposition only)
    array();
    array(const array& right);

    // MODIFICATION
    void assign(const Ty& val);
    array& operator=(const array& right);    // exposition only
    void swap(array& right);

    // ITERATORS
    iterator begin();
    const_iterator begin() const;
    iterator end();
    const_iterator end() const;
    reverse_iterator rbegin();
    const_reverse_iterator rbegin() const;
    reverse_iterator rend();
    const_reverse_iterator rend() const;

    // SIZE QUERIES
    size_type size() const;
    size_type max_size() const;
    bool empty() const;

    // ELEMENT ACCESS
    reference at(size_type off);
    const_reference at(size_type off) const;
    reference operator[](size_type off);
    const_reference operator[](size_type off) const;

    reference front();
    const_reference front() const;
    reference back();
    const_reference back() const;

    Ty *data();
    const Ty *data() const;
    };
