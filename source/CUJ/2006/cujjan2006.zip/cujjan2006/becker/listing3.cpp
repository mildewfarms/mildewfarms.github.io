#include <array>
#include <iostream>
using std::tr1::array;
using std::cout;

int main()
  { // demonstrate array initialization
  const int size = 7;
  int carray[size] = { 1, 1, 2, 3, 5 };
  array<int, size> arr = { 1, 1, 2, 3, 5 };
  for (int i = 0; i < size; ++i)
    cout << carray[i] << ' ';
  cout << '\n';
  for (int i = 0; i < size; ++i)
    cout << arr[i] << ' ';
  cout << '\n';
  return 0;
  }