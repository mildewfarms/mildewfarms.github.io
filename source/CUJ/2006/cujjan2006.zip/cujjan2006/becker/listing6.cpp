#include <array>
#include <iostream>
#include <algorithm>
#include <iterator>
using std::tr1::array;
using std::cout; using std::copy;
using std::ostream_iterator;

int main()
  { // demonstrate assign and swap
  const int size = 7;
  int carray[size];
  array<int, size> arr;
  for (int i = 0; i < size; ++i)
    carray[i] = 3;
  arr.assign(3);
  copy(carray, carray + size, ostream_iterator<int>(cout, " "));
  cout << '\n';
  copy(arr.begin(), arr.end(), ostream_iterator<int>(cout, " "));
  cout << "\n\n";
  array<int, size> arr1 = { 1, 1, 2, 3, 5 };
  copy(arr1.rbegin(), arr1.rend(), ostream_iterator<int>(cout, " "));
  cout << '\n';
  arr.swap(arr1);
  copy(arr1.begin(), arr1.end(), ostream_iterator<int>(cout, " "));
  cout << '\n';
  return 0;
  }