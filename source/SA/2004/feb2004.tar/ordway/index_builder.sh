#!/usr/local/bin/bash
##############################################################################
#
# $Id: index_builder.sh,v 1.2 2003/05/29 19:10:28 root Exp $
#
##############################################################################
#
# Script: index_builder.sh
# Author: Ryan Ordway <rordway@once.com>
# Date: Thu May 29 11:34:42 PDT 2003
# Description:
#
#    This script is a part of the system inventory suite. This script is
#    called by the master script to run on each host to generate a short
#    description of the system to be added into the main HTML index page.
#
##############################################################################

PATH=/sbin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/ucb:/export/admin/bin
export PATH

DOMAINNAME="/usr/bin/domainname"
PSRINFO="/usr/sbin/psrinfo"
SHOWREV="/usr/bin/showrev"
PRTCONF="/usr/sbin/prtconf"
UNAME="/sbin/uname"
IFCONFIG="/sbin/ifconfig"
NETSTAT="/usr/bin/netstat"
SWAP="/usr/sbin/swap"
PKGINFO="/usr/bin/pkginfo"
AWK="/usr/bin/awk"
GREP="/usr/bin/grep"
ECHO="/usr/bin/echo"
UCBECHO="/usr/ucb/echo"
XARGS="/usr/bin/xargs"
SORT="/usr/bin/sort"
CUT="/usr/bin/cut"
HOSTNAME="/usr/bin/hostname"
UNIQ="/usr/bin/uniq"
DF="/usr/bin/df"
CAT="/usr/bin/cat"

# Base for our URLs. Change this if the html directory
# is not linked to $DocumentRoot/inventory
URL_BASE="/inventory"

# Do we also show the kernel patch version
DO_KERNEL="NO"


# Return the hostname of this system
get_hostname()
{
   hostname="`$HOSTNAME`"
   $UCBECHO -n "$hostname"
}

get_purpose()
{
   if [ -s /var/sadm/system/admin/PURPOSE ]; then
      purpose="`$CAT /var/sadm/system/admin/PURPOSE`"
   else
      purpose="Unknown"
   fi
   $UCBECHO -n "$purpose"
}

# Return a list of non-loopback IP addresses bound to the system
get_ip_info()
{
   if [ -f /etc/hostname.hme0 ]; then
      interface=hme0
   elif [ -f /etc/hostname.hme1 ]; then
      interface=hme1
   elif [ -f /etc/hostname.eri0 ]; then
      interface=eri0
   elif [ -f /etc/hostname.eri1 ]; then
      interface=eri1
   elif [ -f /etc/hostname.ge0 ]; then
      interface=ge0
   elif [ -f /etc/hostname.ge1 ]; then
      interface=ge1
   elif [ -f /etc/hostname.dmfe0 ]; then
      interface=dmfe0
   elif [ -f /etc/hostname.dmfe1 ]; then
      interface=dmfe1
   elif [ -f /etc/hostname.le0 ]; then
      interface=le0
   elif [ -f /etc/hostname.le1 ]; then
      interface=le1
   else
      interface=hme0 
   fi

   ip_addresses="`$IFCONFIG $interface | $GREP inet | $GREP -v "127.0.0.1" | $AWK '{print $2}'`"
   for addr in $ip_addresses; do
      if [ "$addr" != "" ]; then 
         $UCBECHO -n "$addr "
      else
         $UCBECHO -n "Unknown "
      fi
   done
}

# Return the type of system this is
get_hw_info()
{
   hw_type="`$UNAME -i`"

   # This isn't entirely accurate, but works for @Once
   case "$hw_type" in
      SUNW,UltraSPARC-IIi-cEngine*)
         $UCBECHO -n "Netra t1"
         ;;
      SUNW,Ultra-80*)
         $UCBECHO -n "E420R/Ultra80"
         ;;
      SUNW,Ultra-60*)
         $UCBECHO -n "E220R/Ultra60"
         ;;
      SUNW,Ultra-4*)
         $UCBECHO -n "E450"
         ;;
      SUNW,Ultra-250*)
         $UCBECHO -n "E250"
         ;;
      SUNW,Ultra-5_10*)
         $UCBECHO -n "Ultra 5/10"
         ;;
      SUNW,Ultra-30*)
         $UCBECHO -n "Ultra 30"
         ;;
      SUNW,Ultra-2*)
         $UCBECHO -n "Ultra 2"
         ;;
      SUNW,Ultra-Enterprise*)
         $UCBECHO -n "Ultra Enterprise"
         ;;
      SUNW,Sun-Blade-100*)
         $UCBECHO -n "SunBlade 100"
         ;;
      SUNW,Sun-Fire-880*)
         $UCBECHO -n "SunFire V880"
         ;;
      SUNW,UltraAX-i2*)
         $UCBECHO -n "SunFire V100"
         ;;
      *)
         $UCBECHO -n "UNKNOWN"
         ;;
   esac
}

# Return the OS version and kernel patch level
get_os_version()
{
   $UCBECHO -n "Solaris "

   version="`$UNAME -r`"
   case "$version" in
      5.6*)
         $UCBECHO -n "2.6"
         ;;
      5.7*)
         $UCBECHO -n "7"
         ;;
      5.8*)
         $UCBECHO -n "8"
         ;;
      5.9*)
         $UCBECHO -n "9"
         ;;
      *)
         $UCBECHO -n "UNKNOWN "
   esac

   if [ "$DO_KERNEL" = "YES" ]; then
      $UCBECHO -n " `$UNAME -v`"
   fi
}

# Return the amount of physical RAM
get_ram_info()
{
   memory="`$PRTCONF | $GREP 'Memory' | $AWK '{print $3}'`" 
   $UCBECHO -n "$memory"
   $UCBECHO -n "MB"
}

# Return the number and speed of the CPU(s)
get_cpu_info()
{
   num_cpus="`$UNAME -X | $GREP NumCPU | $AWK '{print $3}'`"
   $UCBECHO -n "$num_cpus" 
   $UCBECHO -n "x"
   cpu_speed="`$PSRINFO -v | $GREP MHz | $AWK '{print $6}' | $UNIQ`"
   $UCBECHO -n "$cpu_speed MHz"
}

# Return the amount of swap available on this system
get_swap_info()
{
   swap_info="`$DF -k | $GREP 'swap' | $AWK '{print $2}'`"
   $UCBECHO -n "$swap_info k"
}


get_nis_info()
{
   if [ -f /etc/defaultdomain ]; then
      domain="`$DOMAINNAME`"
   else
      domain="none"
   fi 
   $UCBECHO -n "$domain"
}

get_serial_number()
{
   if [ -f /var/sadm/system/admin/SERIALNUMBER ]; then
      serial_number="`$CAT /var/sadm/system/admin/SERIALNUMBER`"
   else
      serial_number="no file"
   fi
   $UCBECHO -n "$serial_number"
}

# Format of inventory:
#
# Hostname,IP Address,,,HW,OS,CPU,RAM,Swap,Disks,NIS domain

# kind of a kludge, but it gets the link to work correctly
$ECHO "  <tr>"
$UCBECHO -n "    <td valign=top><a href=$URL_BASE/"
get_hostname
$UCBECHO -n ".html>"
get_hostname
$UCBECHO -n "</a>"
$ECHO
$UCBECHO -n "    <td valign=top>"
get_purpose
$ECHO
$UCBECHO -n "    <td valign=top>"
get_ip_info
$ECHO
$UCBECHO -n "    <td valign=top>"
get_hw_info
$ECHO
$UCBECHO -n "    <td valign=top>"
get_os_version
$ECHO
$UCBECHO -n "    <td valign=top>"
get_cpu_info
$ECHO
$UCBECHO -n "    <td valign=top>"
get_ram_info
$ECHO
$UCBECHO -n "    <td valign=top>"
get_nis_info
$ECHO
$UCBECHO -n "    <td valign=top>"
get_serial_number
$ECHO
$ECHO "  </tr>"
