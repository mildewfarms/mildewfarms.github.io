#!/usr/local/bin/bash
##############################################################################
#
# $Id: client_info.sh,v 1.1 2003/05/29 18:40:04 root Exp $
#
##############################################################################
#
# Script: client_info.sh
# Author: Ryan Ordway <rordway@once.com>
# Date: Thu May 29 11:34:42 PDT 2003
# Description:
# 
#    This script is a part of the system inventory package. This script
#    generates inventory information about the system it is run on and
#    outputs HTML to stdout. This script is invoked by the master script
#    and the data captured to individual HTML data files.
#
##############################################################################

PATH=/sbin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/ucb:/export/admin/bin
export PATH

DOMAINNAME="/usr/bin/domainname"
HOSTNAME="/usr/bin/hostname"
EEPROM="/usr/sbin/eeprom"
PSRINFO="/usr/sbin/psrinfo"
SHOWREV="/usr/bin/showrev"
PRTCONF="/usr/sbin/prtconf"
UNAME="/sbin/uname"
IFCONFIG="/sbin/ifconfig"
NETSTAT="/usr/bin/netstat"
SWAP="/usr/sbin/swap"
PKGINFO="/usr/bin/pkginfo"
AWK="/usr/bin/awk"
GREP="/usr/bin/grep"
ECHO="/usr/bin/echo"
DATE="/usr/bin/date"
UCBECHO="/usr/ucb/echo"
PS="/usr/bin/ps"
XARGS="/usr/bin/xargs"
SORT="/usr/bin/sort"
CUT="/usr/bin/cut"
DF="/usr/sbin/df"
NDD="/usr/sbin/ndd"
CAT="/usr/bin/cat"
PRTDIAG="/usr/platform/`uname -m`/sbin/prtdiag"

FULL_PATCH=yes

TIME_STRING="`$DATE`"
IFCONFIG_INFO="`$IFCONFIG -a`"
IP_ADDRESSES="`$IFCONFIG -a | $GREP inet | $AWK '{print $2}'`"
MEMORY="`$PRTCONF | $GREP 'Memory'`" 
NUM_CPUS="`$UNAME -X | $GREP NumCPU | $AWK '{print $3}'`"
SWAP_INFO="`$SWAP -l | $GREP -v swapfile | $AWK '{print $4}'`"
OPEN_PORTS="`$NETSTAT -an | $GREP LISTEN | $AWK '{ print $1 }' | $AWK -F. '{ print $2}'`"
if [ "$FULL_PATCH" == "yes" ]; then
   PATCH_INFO="`$SHOWREV -p | $SORT`"
else
   PATCH_INFO="`$SHOWREV -p | $SORT | $CUT -f2 -d' '`"
fi
PACKAGE_INFO="`$PKGINFO | $GREP -v SUNW | $GREP -v SMEvpl`"
PACKAGE_INFO_NONPKG="`$CAT /var/sadm/softinfo/PACKAGES`"
DEFAULTROUTE="`$CAT /etc/defaultrouter`"


$ECHO "<html>
<head>
<title>Systems Inventory for `$HOSTNAME`</title>
</head>
<body bgcolor=ffffff text=000000>"


#########################################################################
# Lookup some system information
#########################################################################

$ECHO "<center><h2><u>Systems Inventory for `$HOSTNAME`</u></h2></center><p>"

$ECHO "<center><font size=-1><i>Last updated: $TIME_STRING</i></font></center><p>"

$ECHO "<p><hr><p>"

$ECHO '<a name="#sysinfo"><h3>System info:</h3></a><p>'

$ECHO "<blockquote>"

   $ECHO "<pre>"
   $SHOWREV
   $ECHO "Machine type: `$UNAME -i`"
   $ECHO "$MEMORY"
   $ECHO "Swap (blocks): $SWAP_INFO"
   $ECHO "Number of CPUs: $NUM_CPUS"
   $ECHO "</pre>"

$ECHO "</blockquote>"

$ECHO "<p><hr><p>"
$ECHO "<a name=#psrinfo><h3>Processor information:</h3></a><p>"

$ECHO "<blockquote>"

   $ECHO "<pre>"
   $PSRINFO -v
   $ECHO "</pre>"

$ECHO "</blockquote>"

$ECHO "<p>"

$ECHO "<p><hr><p>"

$ECHO "<a name=#diskinfo><h3>Disk information:</h3></a><p>"

   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $DF -k
   $ECHO "</blockquote>"
   $ECHO "</pre>"

$ECHO "<p><hr><p>"

$ECHO "<a name=#network><h3>Networking information:</h3></a><p>"

   $ECHO "<b>Network interfaces information:</b><p>"
   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $ECHO "$IFCONFIG_INFO <p>"
   $ECHO "</pre>"
   $ECHO "</blockquote>"

   for ip in $IP_ADDRESSES; do
      $GREP $ip /etc/hosts >> /dev/null
      if [ "$?" != "0" ]; then
         $ECHO "*** My IP Address ($ip) not listed in /etc/hosts! ***"
      fi
   done

   $ECHO "<p>"
   $ECHO "<b>Default router:</b><p>"

   $ECHO "<blockquote>"
      $ECHO "$DEFAULTROUTE <p>"
   $ECHO "</blockquote>"

   $GREP $DEFAULTROUTE /etc/hosts >> /dev/null

   if [ "$?" != "0" ]; then
      $ECHO "*** Default route not listed in /etc/hosts!! *** <p>"
   fi

   $ECHO "<b>Routing table:</b><p>"
   
   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $NETSTAT -rn | $GREP -v "Routing Table"
   $ECHO "</pre>"
   $ECHO "</blockquote>"

   $ECHO "<p>"
   $ECHO "<b>DNS Information:</b><p>"
   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $CAT /etc/resolv.conf
   $ECHO "</pre>"
   $ECHO "</blockquote>"

   $PS -ef | $GREP -v grep | $GREP 'named' >> /dev/null
   if [ "$?" = "0" ]; then
      $ECHO "<p>"
      $ECHO "*** This system is running a DNS daemon!! ***"
   fi   

$ECHO "<p>"
$ECHO "<b>Name Service Switch for host resolution:</b><p>"

   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $GREP hosts /etc/nsswitch.conf
   $ECHO "</blockquote>"
   $ECHO "</pre>"

$ECHO "<p>"
$ECHO "<b>NIS information:</b><p>"

   $ECHO "<blockquote>"
   $ECHO "<pre>"
   if [ -f /etc/defaultdomain ]; then
      nis_domain="`$CAT /etc/defaultdomain`"
      node_name="`$CAT /etc/nodename`"
      $ECHO "NIS nodename: $node_name"
      $ECHO "NIS domain: $nis_domain"
      $ECHO "NIS servers: `$CAT /var/yp/binding/$nis_domain/ypservers | $XARGS`"
      $PS -ef | $GREP -v grep | $GREP 'ypbind' >> /dev/null
      if [ "$?" != "0" ]; then
         $ECHO "*** WARNING: ypbind is not running! ***"
      fi
      
   else
      $ECHO "*** WARNING: no /etc/defaultdomain file! ***"
      $ECHO "NIS domain: `$DOMAINNAME`"
   fi

   $ECHO "</blockquote>"
   $ECHO "</pre>"

$ECHO "<p>"
$ECHO "<b>TCP/IP stack performance settings:</b><p>"

$ECHO "<ul>"
if [ "`uname -r`" = "5.7" ]; then
   $ECHO "<li>tcp_time_wait_interval: `$NDD -get /dev/tcp tcp_time_wait_interval`"
fi

if [ "`uname -r`" != "5.7" ]; then
   $ECHO "<li>tcp_close_wait_interval: `$NDD -get /dev/tcp tcp_close_wait_interval`"
fi

   $ECHO "<li>tcp_conn_req_max_q: `$NDD -get /dev/tcp tcp_conn_req_max_q`"
   $ECHO "<li>tcp_conn_req_max_q0: `$NDD -get /dev/tcp tcp_conn_req_max_q0`"
   $ECHO "<li>tcp_slow_start_initial: `$NDD -get /dev/tcp tcp_slow_start_initial`"
if [ "`uname -r`" != "5.7" ]; then
   $ECHO "<li>tcp_conn_hash_size:  `$NDD -get /dev/tcp tcp_conn_hash_size`"
fi
   $ECHO "<li>tcp_rexmit_interval_initial: `$NDD -get /dev/tcp tcp_rexmit_interval_initial`"
   $ECHO "<li>tcp_rexmit_interval_min: `$NDD -get /dev/tcp tcp_rexmit_interval_min`"
   $ECHO "<li>tcp_ip_abort_interval: `$NDD -get /dev/tcp tcp_ip_abort_interval`"
   $ECHO "<li>tcp_ip_abort_cinterval: `$NDD -get /dev/tcp tcp_ip_abort_cinterval`"
   $ECHO "<li>tcp_rexmit_interval_max: `$NDD -get /dev/tcp tcp_rexmit_interval_max`"
   $ECHO "<li>tcp_keepalive_interval: `$NDD -get /dev/tcp tcp_keepalive_interval`"
   $ECHO "<li>tcp_fin_wait_2_flush_interval: `$NDD -get /dev/tcp tcp_fin_wait_2_flush_interval`"
   $ECHO "<li>tcp_xmit_hiwat: `$NDD -get /dev/tcp tcp_xmit_hiwat`"
   $ECHO "<li>tcp_recv_hiwat: `$NDD -get /dev/tcp tcp_recv_hiwat`"
   $ECHO "<li>udp_xmit_hiwat: `$NDD -get /dev/udp udp_xmit_hiwat`"
   $ECHO "<li>udp_recv_hiwat: `$NDD -get /dev/udp udp_recv_hiwat`"
   $ECHO "</ul><p>"


$ECHO "<p>"
$ECHO "<b>Open TCP ports:</b><p>"

   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $ECHO "$OPEN_PORTS"
   $ECHO "</blockquote>"
   $ECHO "</pre>"

$ECHO "<p><hr><p>"
$ECHO "<a name=#pkginfo><h3>Third Party Packages:</h3></a><p>"

   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $ECHO "$PACKAGE_INFO"
   $ECHO "</blockquote>"
   $ECHO "</pre>"

$ECHO "<p><hr><p>"
$ECHO "<a name=#pkginfononpkg><h3>Third Party Packages: (non-pkg)</h3></a><p>"

   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $ECHO "$PACKAGE_INFO_NONPKG"
   $ECHO "</blockquote>"
   $ECHO "</pre>"

$ECHO "<p><hr><p>"
$ECHO "<a name=#patchinfo><h3>Patch information:</h3></a><p>"

   $ECHO "<blockquote>"
   $ECHO "<pre>"
      $ECHO "$PATCH_INFO"
   $ECHO "</blockquote>"
   $ECHO "</pre>"

$ECHO "<p><hr><p>"

$ECHO "<a name=#eeprom><h3>OpenBoot PROM information:</h3></a><p>"

$ECHO "<blockquote>"

   $ECHO "<pre>"
   $EEPROM
   $ECHO "</pre>"

$ECHO "</blockquote>"

$ECHO "<p><hr><p>"
$ECHO "<a name=#prtdiag><h3>Hardware Diagnostics:</h3></a><p>"

$ECHO "<blockquote>"

   $ECHO "<pre>"
   $PRTDIAG -v
   $ECHO "</pre>"

$ECHO "</blockquote>"

$ECHO "<p><hr><p>"
$ECHO "<center><font size=-1><i>Last updated: $TIME_STRING</i></font></center><p>"

$ECHO "</body></html>"
