#!/bin/bash
##############################################################################
#
# $Id: do_inventory.sh,v 1.1 2003/09/12 21:44:01 root Exp root $
#
##############################################################################
#
# Script: do-system-info-html.sh
# Author: Ryan Ordway <rordway@once.com>
# Date: Thu May 29 12:33:28 PDT 2003
# Description:
#
#    This is the master script for the systems inventory suite. This
#    script cycles through a list of systems and executes 2 different
#    scripts on each host via SSH. The first script generates a 
#    system-specific HTML file with inventory data about that particular
#    host. The second system generates information that this script
#    uses to build an HTML index file containing a summary of information
#    about each host in the list.
#
#    Additionally, once the index page and corresponding system-specific
#    HTML pages have been generated, the index page is embedded into a
#    MIME e-mail message and delivered to all addresses in the MAIL_RCPT
#    variable listed below.
#
##############################################################################

PATH=/sbin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/ucb:/export/admin/bin
export PATH

# Some macros
HOSTNAME="/usr/bin/hostname"
ECHO="/usr/bin/echo"
SSH="/usr/local/bin/ssh"
GREP="/usr/bin/grep"
AWK="/usr/bin/awk"
MKDIR="/usr/bin/mkdir"
DATE="/usr/bin/date"
MV="/usr/bin/mv"
CP="/usr/bin/cp"
RM="/usr/bin/rm"
WC="/usr/bin/wc"
CAT="/usr/bin/cat"
AWK="/usr/bin/awk"
SENDMAIL="/usr/local/sbin/sendmail"

##############################################################################
#
# Configuration section - this section contains various variables that
#    are somewhat tunable. If you know what you are doing then these
#    variables may be changed to suit your environment.
#
##############################################################################

# The string that we will attach to our backup HTML documents
DATE_STRING="`$DATE +%Y%m%d`"
UPDATE_STRING="`$DATE`"

# Location of the script that will generate the inventory. 
# This must be the same on each of the remote hosts, as well
# as on our master host, or at least symlinked to this location.
CLIENT_SCRIPT="client_info.sh"
INDEX_SCRIPT="index_builder.sh"
SCRIPTDIR="/usr/local/inventory/bin"

# Base directory for our inventory data, no trailing /
INVENTORY_BASE="/usr/local/inventory/html"

# Location of the inventory index page
INDEX="$INVENTORY_BASE/index.html"

# A temporary index that our inventory will be written to. Rather
# than have the index be "down" for as long as it takes to do the
# inventory, we can just copy it after we are done.
TMP_INDEX="$INVENTORY_BASE/tmpindex.html"

# Location of the list of hosts to inventory. This should be in
# the same format as /etc/hosts, with the IP address and hostname
# seperated by some form of whitespace (tab(s) or space(s)). Each
# system will need to have ssh installed obviously.
HOSTS="/usr/local/inventory/etc/hosts"

# The command we use to get the list of hosts to cycle through
NODES="`$GREP -v '^#' $HOSTS | $GREP -v '^ ' | $AWK '{ print $2 }'`"

# This is the user that will be calling the system-inventory.sh
# script on each system. I've not tested this with a non-root
# user, so YMMV. 
REMOTE_USER="inv"

# This information is used for sending the index page as a multi-part
# MIME message to whomever is listed in the MAIL_RCPT variable.
#
# If DO_MAIL is equal to 1, then the message will be generated and
# sent, otherwise it will not.
DO_MAIL=1
MAIL_RCPT="sysadmin@once.com"
MAIL_FROM="Systems Inventory <root@admin1.at-once.com>"
MAIL_SUBJECT="Systems Inventory: $UPDATE_STRING"


##############################################################################
#
# End of Configuration Section
#
##############################################################################

##############################################################################
#
# Backup the old index file, then generate the main portion of the index
# the clients will be creating their own entries in the inventory table,
# and we will insert the footer towards the end.
#
##############################################################################

if [ ! -d $INVENTORY_BASE/oldindex ]; then
   $MKDIR $INVENTORY_BASE/oldindex
fi
if [ -f $INDEX ]; then
   $CP $INDEX $INVENTORY_BASE/oldindex/index-$DATE_STRING.html
fi

$ECHO "Creating temporary HTML index page...\c"
$ECHO "<html><head><title>$TITLE</title></head><body bgcolor=ffffff text=000000>" > $TMP_INDEX
$ECHO "<center><h2><u>@Once Systems Inventory</u></h2><p></center>" >> $TMP_INDEX
$ECHO "<center><font size=-1><i>Last updated: $UPDATE_STRING</i></font><p></center>" >> $TMP_INDEX

$ECHO "<p><h3><b><u>System List</u></b></h3>" >> $TMP_INDEX
$ECHO "<table border=1 width=100%>" >> $TMP_INDEX
$ECHO "  <tr>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>Hostname</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>Purpose</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>IP Address</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>HW Platform</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>OS Version</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>CPU Info</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>RAM Info</b>" >> $TMP_INDEX
# No swap information for now
#$ECHO "    <td valign=top><b>Swap Info</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>NIS Domain</b>" >> $TMP_INDEX
$ECHO "    <td valign=top><b>Serial Number</b>" >> $TMP_INDEX
$ECHO "  </tr>" >> $TMP_INDEX

$ECHO " done."

##############################################################################
#
# Now cycle through the list of hosts, backup the old inventory data
# and execute the $CLIENT_SCRIPT file to generate a new inventory document
#
##############################################################################

$ECHO "Processing systems and generating inventory:"
$ECHO ""

for host in $NODES; do

  $ECHO "   $host...\c"

  $ECHO " webdir...\c"
  if [ ! -d $INVENTORY_BASE/$host ]; then
    $MKDIR $INVENTORY_BASE/$host
  fi
  if [ -f $INVENTORY_BASE/$host.html ]; then
    $MV $INVENTORY_BASE/$host.html $INVENTORY_BASE/$host/$host-$DATE_STRING.html
  fi

  $ECHO " client...\c"
  $SSH -l $REMOTE_USER $host "$SCRIPTDIR/$CLIENT_SCRIPT" > $INVENTORY_BASE/$host.html

  $ECHO " index...\c"
  $SSH -l $REMOTE_USER $host "$SCRIPTDIR/$INDEX_SCRIPT" >> $TMP_INDEX
  $ECHO " done."

done

##############################################################################
#
# And now we finish the table, add an additional footer and exit
#
##############################################################################



$ECHO "Creating HTML footer... \c"
$ECHO "</table></center><p><hr><p>" >> $TMP_INDEX
$ECHO "<center><font size=-1><i>Last updated: $UPDATE_STRING</i></font></center><p>" >> $TMP_INDEX
$ECHO "</body></html>" >> $TMP_INDEX
$ECHO " done."

$ECHO "Installing new HTML index... \c"
$MV $TMP_INDEX $INDEX
$ECHO " done."

$RM -rf $tmpdir

##############################################################################
#
# If $DO_MAIL is equal to 1, we will generate a MIME message and
# embed the index page into it to send to addresses in the MAIL_RCPT
# variable
#
##############################################################################

if [ "$DO_MAIL" -eq 1 ]; then

   mail_file=/tmp/system-inventory-email.$$.txt

   $ECHO "Generating multi-part email message...\c"

   $ECHO "To: $MAIL_RCPT" > $mail_file
   $ECHO "From: $MAIL_FROM" >> $mail_file
   $ECHO "Subject: $MAIL_SUBJECT" >> $mail_file
   $ECHO "X-Priority: 1" >> $mail_file
   $ECHO "Importance: high" >> $mail_file
   $ECHO "MIME-Version: 1.0" >> $mail_file
   $ECHO 'Content-Type: multipart/mixed; boundary="__endmime"' >> $mail_file

   $ECHO "" >> $mail_file
   $ECHO "This is a multi-part message in MIME format." >> $mail_file
   $ECHO "" >> $mail_file

   $ECHO "--__endmime" >> $mail_file
   $ECHO "Content-Type: text/html" >> $mail_file
   $ECHO "Content-Transfer-Encoding: 7bit" >> $mail_file
   $ECHO "Content-Disposition: inline" >> $mail_file
   $ECHO "" >> $mail_file

   $CAT $INDEX >> $mail_file

   $ECHO "" >> $mail_file

   #
   # Uncomment this if you want a plain-text version as well
   #
   #$ECHO "--__endmime" >> $mail_file
   #$ECHO "Content-Type: text/plain" >> $mail_file
   #$ECHO "Content-Disposition: inline" >> $mail_file
   #$ECHO "Content-Transfer-Encoding: 8bit" >> $mail_file
   #$ECHO "" >> $mail_file
   #$ECHO "Your mailer does not support HTML, darn you!" >> $mail_file
   #$ECHO "" >> $mail_file

   $ECHO " done."

   $ECHO "Sending message...\c"
   $CAT $mail_file | $SENDMAIL -t
   $ECHO " done."
   $RM -f $mail_file

fi

$ECHO "Systems inventory update completed, have a nice day."


##############################################################################
#
# $Log: do_inventory.sh,v $
# Revision 1.1  2003/09/12 21:44:01  root
# Initial revision
#
#
##############################################################################
