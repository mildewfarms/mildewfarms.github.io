# Accept an .nsr file as argv[1], and print an HTML cross-reference table to STDOUT.
#   The target IP addresses are across the top, and the found vulnerabilities are
#   down the left side.  
#
# 11 Mar. 2002 - Initial implementation - works as advertised.
#
# 12 Mar. 2002 - Cleaned up the comments.
#              - Removed the ---- in the clear cells - now they're just lime green.
#              - Added code to display multiple tables of 5 ip addresses each.  This
#                  makes the output much more readable on smaller screens at lower
#                  resolution.
#
# 13 Mar. 2002 - Cleaned up the commenting for the multiple tables part.
#              - Got rid of the temporary variable x that had been used as part of
#                  calculating the number of tables in the output.
#              - Right justified the numbers in the Summary table.
#
# 19 Mar. 2002 - Added a function, sortip, to sort IP addresses in the correct order.
#                  It accepts a list as an argument, and returns a list, sorted
#                  by address, not lexically.  This function assumes the addresses
#                  are unique, and that each entry in the list is an IP address with
#                  four octets.
#              - Removed the custom replace code based on vulnerability ID, and
#                  replaced it with a standard replacing of semi-colons (what Nessus
#                  uses to represent linebreaks in the vulnerability description)
#                  with spaces.
#              - In an effort to pull realistic, short descriptions from the Nessus
#                  vulnerabilities, I added code to look for a ;; from the right, and
#                  a : from the left.  Whichever is closest to the left of the string
#                  is used as the right hand side of the displayed description.
#
# NOTE 00: The NSR file is pipe delimited, and each line has either 2 or 5 columns
#          Column 1 - Subscript 0 - IP Address of the scanned host
#          Column 2 - Subscript 1 - Service Name - Port - Protocol
#          Column 3 - Subscript 2 - Nessus Plugin ID #
#          Column 4 - Subscript 3 - INFO, NOTE, or REPORT - Reports=holes, Infos=warnings
#          Column 5 - Subscript 4 - Description - semi-colons indicate EOL in display
#
import sys                                                           # Command line argument processing
import string                                                        # Split, strip, etc.

def usage():                                                         # Display usage information
  print 'USAGE: nsrxref.py NSRFILE'
  print '  NSRFILE is the fully qualified filename of a NESSUS report'
  print '  By: Paul Trout - V0.3A - 19 Mar. 2002'
  sys.exit()

def sortip(srclist):                                                 # Takes a list of IP addresses as an argument
  ipdict={}                                                          # Dictionary used for temporary workplace
  for ip in srclist:                                                 # Loop through all the addresses
    srcoctets=string.split(ip,'.')                                   # Split the address into separate octets
    paddedip=''                                                      # Padded IP starts as a blank string
    for octet in srcoctets:                                          # For each octet
      paddedip=paddedip+str(string.zfill(octet,3))+'.'               # The extra trailing . won't hurt
    ipdict[paddedip]=ip                                              # Make a dictionary entry keyed by the padded ip address
  keylist=ipdict.keys()                                              # Extract the padded ip address keys
  keylist.sort()                                                     # Which will now sort properly with a lexical sort
  retlist=[]                                                         # List of sorted ip addresses in non-paddded form
  for ip in keylist:                                                 # Step through the padded keys
    retlist.append(ipdict[ip])                                       # And append the next IP address to the end of the list
  return retlist                                                     # Return the sorted list of IP addresses

try:                                                                 # Trap errors accessing argv[1]
  nsrfile=open(sys.argv[1],'r')                                      # Open the file for read
except IndexError:                                                   # If no argv[1] was passed
  usage()                                                            # Display usage and exit
except IOError:                                                      # If error opening argv[1]
  print 'Error opening', sys.argv[1], 'for reading'                  # Display error message
  print 'Terminating'
  sys.exit()                                                         # And Exit

vulninfo={}                                                          # Dictionary of vulnerabilities - indexed by ID#
host_addr={}                                                         # Dictionary of host addresses
vulnbyhost={}                                                        # Dictionary of host/vulnerability combinations

linecounter=0                                                        # Idiot check
twoflds=0                                                            # Lines that don't have anything to process
notecounter=0                                                        # Note lines
warncounter=0                                                        # Warning lines
holecounter=0                                                        # Hole lines
currentline=nsrfile.readline()                                       # Read the first line
while len(currentline)>0:                                            # As long as there is data to process
  fields=string.split(currentline,'|')                               # The file is pipe delimited
  if len(fields)==3:                                                 # If there were only two fields
    twoflds=twoflds+1                                                # Increment the twoflds counter
  else:                                                              # Otherwise there were five flds
    if fields[3]=='NOTE':                                            # We just count notes
      notecounter=notecounter+1
    else:                                                            # Warnings and Holes we process
      eovuln0=string.rfind(fields[4],';;')                           # Find the last double ; in the description
      eovuln1=string.find(fields[4],':')                             # Find the first colon in the description
      if eovuln1<eovuln0:                                            # We want the shortest, most complete
        eovuln=eovuln1                                               # Description we can find - so depending on which
      else:                                                          # Is first, a colon or a double semi-colon, we'll
        eovuln=eovuln0                                               # Take the one closest to the beginning of the string.
      descstring=fields[4][:eovuln]                                  # Extract the first part of the description
      if len(descstring)==0:
        descstring=fields[4]
      descstring=string.replace(descstring,';',' ')                  # Replace semi-colons with spaces for better table format
      if vulninfo.has_key(fields[2])==0:                             # If the vulnerability is not already in the dictionary
        vulninfo[fields[2]]=descstring;                              # Then add it
      if host_addr.has_key(fields[0])==0:                            # If this host has not been added to the dictionary
        host_addr[fields[0]]=1                                       # Then add it
      if vulnbyhost.has_key(fields[0]+fields[2])==0:                 # If this host/vuln combination is not in the dictionary
        vulnbyhost[fields[0]+fields[2]]=1                            # Then add it
      if fields[3]=='INFO':                                          # Count the warnings
        warncounter=warncounter+1
      elif fields[3]=='REPORT':                                      # Count the holes
        holecounter=holecounter+1
  linecounter=linecounter+1                                          # Increment linecounter
  currentline=nsrfile.readline()                                     # Read the next line
nsrfile.close()                                                      # Close the NSR file

hostip=sortip(host_addr.keys())                                      # Get a properly sorted list of the host IP addresses
vulnid=vulninfo.keys()                                               # Get a list of the vulnerability IDs
vulnid.sort()                                                        # Sort it

# Emit the HTML output in a vertical series of tables - 5 hosts per table
print '<HTML>'                                                       # Very simple HTML output
print '  <HEAD>'                                                     # The header has only a title
print '    <TITLE>', sys.argv[1], 'XREF</TITLE>'                     # And that has the name of the original NSR file
print '  </HEAD>'
print '  <BODY>'                                                     # The body is multiple tables - the xref(s) and the summary
y=int(len(hostip)/5)                                                 # Calc number of tables by dividing number of hosts by 5
if (len(hostip)%5)>0:                                                # Adding 1 to that if there was any remainder
  y=int(y+1)
for counter in range(y):                                             # We're going to have y number of output tables
  tableip=hostip[counter*5:(counter*5)+5]                            # Slice off the next five each time
  print '    <TABLE BORDER=1>'                                       # Emit the table code
  print '      <TR>'                                                 
  print '        <TD></TD>'                                          # The cell over the vulenrabilities is blank
  for ipaddr in tableip:                                             # Populate the first row of the table with the IP Addresses
    print '        <TD>',ipaddr,'</TD>'
  print '      </TR>'
  for vuln in vulnid:
    print '      <TR>'
    print '        <TD><TEXT>',vuln,':',vulninfo[vuln],'</TEXT></TD>'# The leftmost column of the table is the vulnerability info
    for ipaddr in tableip:                                           # Then loop through the host IP addresses
      if vulnbyhost.has_key(ipaddr+vuln)==1:                         # Checking to see if that host has that vulnerability
        print '        <TD BGCOLOR="#FF0000">  FOUND  </TD>'         # If it does, print FOUND in the cell and make the BGCOLOR red
      else:                                                          # Otherwise
        print '        <TD BGCOLOR="#00FF00"></TD>'                  # It's an empty cell with the BGCOLOR lime green
    print '      </TR>'
  print '    </TABLE>'                                               # Close the current host table
  print '    &nbsp;'                                                 # Space each table vertically - 1 empty line apart
print '    <TABLE BORDER=1>'                                         # The summary table is really for
print '      <TR>'                                                   # Idiot checking purposes.
print '        <TD COLSPAN=2><CENTER>SUMMARY</CENTER</TD>'           # Ignored+NOTES+HOLES+WARNINGS should
print '      </TR>'                                                  # Equal the total.  If they don't, there
print '      <TR>'                                                   # Is a bug, somewhere in the code
print '        <TD ALIGN=RIGHT>',twoflds,'</TD>'
print '        <TD>  Lines were ignored </TD>'
print '      </TR>'
print '      <TR>'
print '        <TD ALIGN=RIGHT>',notecounter,'</TD>'
print '        <TD>  Lines were NOTES </TD>'
print '      </TR>'
print '      <TR>'
print '        <TD ALIGN=RIGHT>',warncounter,'</TD>'
print '        <TD>  Lines were WARNINGS </TD>'
print '      </TR>'
print '      <TR>'
print '        <TD ALIGN=RIGHT>',holecounter,'</TD>'
print '        <TD>  Lines were HOLES </TD>'
print '      </TR>'
print '      <TR>'
print '        <TD ALIGN=RIGHT>',linecounter,'</TD>'
print '        <TD>  Lines Total </TD>'
print '      </TR>'
print '    </TABLE>'                                                 # Close the summary table
print '  </BODY>'                                                    # Close the body
print '</HTML>'                                                      # Close the HTML document

