#!/usr/local/bin/perl
#mm_sar_q.pl
# run a sar -q on the machine

if ($#ARGV == -1)
{
        print "USAGE: $0 <machine name> <sar option>\n";
        exit();
}
else
{
        $mach = $ARGV[0];
	$option = $ARGV[1];
	if ($option eq "")
        {
            $option = "-u";
        }
}

$lc = 0;
$rval = 0;

$cmd = "/usr/sbin/sar ".$option." 5";
$test = "sar".$option;
open(SAR,"$cmd |");
while ($line=<SAR>)
{
  chomp($line);
  $lc++;
  if ($lc == 4)
  {
    @headers = split(/[\s]+/,$line);
  }
  elsif ($lc == 5)
  {
      @values = split(/[\s]+/,$line);
#      print "[$line]\n";
      $ans = sprintf "%s %s %d",$mach,$test,$rval;
      for ($i = 1; $i <= $#values; $i++)
      {
          $ans = sprintf "%s %s %s",$ans,$headers[$i],$values[$i];
      }
      print "$ans\n";
  }
}
close SAR;
if ($lc < 5)
{
    $rval = -1;
    print "$mach $test $rval\n";
}
