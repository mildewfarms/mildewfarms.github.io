#!/usr/bin/perl
#mm_admin_details.pl
# return details about an administrator 

@parts=split(/\\\?/,$ARGV[0]);
$admin = $parts[0];

$file = "admin_list.txt";

print "Content-type: text/html\n";

print "\n";

print "<!CGI script output:>\n";

print "<HTML>\n";
print "<HEAD> <TITLE> Administrators - details </TITLE>\n";
print "Details for $admin: $tag </HEAD> <BR>\n";
print "<BODY BGCOLOR=#FFFFFF> \n";
#print "$admin $part $file\n";
print "<P>";
open(IN,$file);
while ($line = <IN>)
{
	chop($line);
	($name,$longname,$phone,$email)=split(/\t/,$line);
	if ($name eq $admin)
	{
	    print "<TABLE>\n";
	    print "<TR><TD>Name:</TD><TD>$longname</TD></TR>\n";
	    print "<TR><TD>Phone:</TD><TD>$phone</TD></TR>\n";
	    print "</TABLE>\n";
	    print "<TR><TD>e-mail:</TD></TR><TR><TD>$email</TD></TR>\n";
	}
}
close (IN);

print "\n";
print "</BODY>\n";
print "</HTML>\n";

