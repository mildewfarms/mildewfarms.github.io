#!/usr/bin/perl
#test-cgi4.pl
# testing splitting up of input
# inputs can be on the command line, separated by "?"
#  OR
# in an environment variable QUERY_STRING

#
##
#
print_header();

#
## are there any command-line arguments?
#
if ($#ARGV != -1)
{
	print "Command-Line Arguments\n";
	@res = grep(/\?/,$ARGV[0]);
	if ($#res != -1)
	{
		print "CGI stye input\n";
#
# is "arg?arg2+part2" valid input?
# --> part2 ends up as ARGV[1]
#
		@parts = split(/[\\\?]+/,$ARGV[0]);
		foreach $arg (@parts)
		{
			$inputs{$arg} = $arg;
			printf ".....Arg number %d => %s\n",$ac++,$inputs{$arg};
		}
	}
	else
	{
		print "script style arguments\n";
		foreach $item (@ARGV)
		{
			$inputs{$item} = $item;
			printf ".....Arg number %d => %s\n",$ac++,$inputs{$item};
		}
	}
}
else
{
    print "\n";
    
    print "NO Command line Args\n";
    
    #determine the request method, make sure the data is defined in ARGV
    # and determine of the query string is defined page 28
    if ($ENV{REQUEST_METHOD} eq 'GET' && $ENV{QUERY_STRING} ne '')
    {
        # split the query into keywords
        foreach $input (split("&",$ENV{QUERY_STRING}))
        {
            if ($input =~ /(.*)=(.*)/)
            {
                ($key,$value) = ($1, $2);
                $value =~ s/\+/ /g ; # replace "+" with " "
                # convert hex characters
                $value =~ s/%(..)/pack('c',hex($1))/eg;
                $inputs{$key} = $value; # add keyword/value pair to a list
            }
        }
      
        foreach $item (keys %inputs)
        {
	    printf ".....Arg number %d => key = %s\n",$ac,$item;
	    printf ".....Arg number %d => val = %s\n",$ac,$inputs{$item};
            print "[$item] [$inputs{$item}]\n";
	    $ac++;
        }
    }
    else
    {
	print "$ENV{REQUEST_METHOD} $ENV{CONTENT_LENGTH}\n";
	if ($ENV{REQUEST_METHOD} eq "POST")
	{
    	    print "Checking STDIN\n";
            @data = <STDIN>;
	    foreach $line (@data)
            {
		chomp($line);
                print "STDIN: -->[$line]<---\n";
                foreach $input (split("&",$line))
                {
                    if ($input =~ /(.*)=(.*)/)
                    {
                        ($key,$value) = ($1, $2);
                        $value =~ s/\+/ /g ; # replace "+" with " "
                        # convert hex characters
                        $value =~ s/%(..)/pack('c',hex($1))/eg;
                        $inputs{$key} = $value; # add keyword/value pair to a list
                    }
                }
	    }
              
            foreach $item (keys %inputs)
            {
       	        printf ".....Arg number %d => key = %s\n",$ac,$item;
       	        printf ".....Arg number %d => val = %s\n",$ac,$inputs{$item};
                print "[$item] [$inputs{$item}]\n";
    	        $ac++;
            }
        }
        else
        {
            print "No inputs\n";
        }
    }
}

sub print_header
{
    if ($ENV{REQUEST_METHOD} eq "POST")
    {
        print "Content-type: text/html\n";
        print "\n";
        <PRE>
    }
    else
    {
        print "Content-type: text/plain\n";
        print "\n";
    }

print "CGI test script report:\n";
print "\n";

print "argc is ",$#ARGV,"\n";
if ($#ARGV != -1)
{
	$ac = 0;
	foreach $item (@ARGV)
	{
		printf ".....Arg number %d => %s\n",$ac++,$item;
	}
}
print "\n";

print "SERVER_SOFTWARE = ",$ENV{SERVER_SOFTWARE},"\n";
print "SERVER_NAME = ",$ENV{SERVER_NAME},"\n";
print "GATEWAY_INTERFACE = ",$ENV{GATEWAY_INTERFACE},"\n";
print "SERVER_PROTOCOL = ",$ENV{SERVER_PROTOCOL},"\n";
print "SERVER_PORT = ",$ENV{SERVER_PORT},"\n";
print "REQUEST_METHOD = ",$ENV{REQUEST_METHOD},"\n";
print "HTTP_ACCEPT = ",$ENV{HTTP_ACCEPT},"\n";
print "PATH_INFO = ",$ENV{PATH_INFO},"\n";
print "PATH_TRANSLATED = ",$ENV{PATH_TRANSLATED},"\n";
print "SCRIPT_NAME = ",$ENV{SCRIPT_NAME},"\n";
print "QUERY_STRING = ",$ENV{QUERY_STRING},"\n";
print "REMOTE_HOST = ",$ENV{REMOTE_HOST},"\n";
print "REMOTE_ADDR = ",$ENV{REMOTE_ADDR},"\n";
print "REMOTE_USER = ",$ENV{REMOTE_USER},"\n";
print "AUTH_TYPE = ",$ENV{AUTH_TYPE},"\n";
print "CONTENT_TYPE = ",$ENV{CONTENT_TYPE},"\n";
print "CONTENT_LENGTH = ",$ENV{CONTENT_LENGTH},"\n";

print "\n";
}
