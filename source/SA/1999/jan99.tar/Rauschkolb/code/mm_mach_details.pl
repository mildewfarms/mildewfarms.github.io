#!/usr/bin/perl
#mm_mach_details.pl
# return details about a machine

@parts=split(/\\\?/,$ARGV[0]);
$mach = $parts[0];
$mach =~ tr/A-Z/a-z/;

$file = "machine_list.txt";

print "Content-type: text/html\n";

print "\n";

print "<!CGI script output:>\n";

print "<HTML>\n";
print "<HEAD> <TITLE> Machines - status details </TITLE>\n";
printf "%s\n", 'Details for <A HREF='.'"'.'mm_more_mach_details.pl?'.$mach.'"'.' TARGET="right">'.$mach.'</A>: '.$tag.' </HEAD> <BR>';
#printf "%s\n","<TR><TD><A HREF=".'"'.'mm_more_mach_details.pl?'.$name.'"i'.' TARGET="right">'.$name.'</A></TD>';

print "<BODY BGCOLOR=#FFFFFF> \n";
print "<P>";
open(IN,$file);
while ($line = <IN>)
{
	chop($line);
	($name,$admin,$dba,$apps,$other)=split(/\t/,$line);
	$name =~ tr/A-Z/a-z/;
	if ($name eq $mach)
	{
	    print "<TABLE>\n";
        printf "%s\n","<TR><TD>Administrator:</TD><TD><A HREF=".'"'.'mm_admin_details.pl?'.$admin.'"'.' TARGET="right">'.$admin.'</A></TD></TR>';


	    if (($dba ne "") && ($dba ne " "))
	    {
	        print "<TR><TD>DBA:</TD><TD>$dba</TD></TR>\n";
	    }
	    @parts = split(/ /,$apps);
	    $lcount = 0;
	    foreach $part (@parts)
	    {
		if ($lcount == 0)
		{
		    print "<TR><TD>Applications:</TD><TD>$part</TD></TR>\n";
		    $lcount++;
		}
		else
		{
		    print "<TR><TD></TD><TD>$part</TD></TR>\n";
		}
	    }
	    @parts = split(/ /,$other);
	    $lcount = 0;
	    foreach $part (@parts)
	    {
		if ($lcount == 0)
		{
		    print "<TR><TD>Other:</TD><TD>$part</TD></TR>\n";
		    $lcount++;
		}
		else
		{
		    print "<TR><TD></TD><TD>$part</TD></TR>\n";
		}
	    }
	    print "</TABLE>\n";
	}
}
close (IN);

print "\n";
print "</BODY>\n";
print "</HTML>\n";

