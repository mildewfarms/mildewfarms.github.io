#!/usr/bin/perl
#test-cgi2.pl
# testin splitting up of input

print "Content-type: text/plain\n";
print "\n";

print "CGI/1.0 test script report:\n";
print "\n";

print "argc is ",$#ARGV,". argv is ",$ARGV[0],".\n";
print "\n";
if ($#ARGV != -1)
{
	@parts = split(/[\\,\?]+/,$ARGV[0]);
	foreach $arg (@parts)
	{
		print "argument = $arg\n";
	}
}
print "\n";

print "SERVER_SOFTWARE = ",$ENV{SERVER_SOFTWARE},"\n";
print "SERVER_NAME = ",$ENV{SERVER_NAME},"\n";
print "GATEWAY_INTERFACE = ",$ENV{GATEWAY_INTERFACE},"\n";
print "SERVER_PROTOCOL = ",$ENV{SERVER_PROTOCOL},"\n";
print "SERVER_PORT = ",$ENV{SERVER_PORT},"\n";
print "REQUEST_METHOD = ",$ENV{REQUEST_METHOD},"\n";
print "HTTP_ACCEPT = ",$ENV{HTTP_ACCEPT},"\n";
print "PATH_INFO = ",$ENV{PATH_INFO},"\n";
print "PATH_TRANSLATED = ",$ENV{PATH_TRANSLATED},"\n";
print "SCRIPT_NAME = ",$ENV{SCRIPT_NAME},"\n";
print "QUERY_STRING = ",$ENV{QUERY_STRING},"\n";
print "REMOTE_HOST = ",$ENV{REMOTE_HOST},"\n";
print "REMOTE_ADDR = ",$ENV{REMOTE_ADDR},"\n";
print "REMOTE_USER = ",$ENV{REMOTE_USER},"\n";
print "AUTH_TYPE = ",$ENV{AUTH_TYPE},"\n";
print "CONTENT_TYPE = ",$ENV{CONTENT_TYPE},"\n";
print "CONTENT_LENGTH = ",$ENV{CONTENT_LENGTH},"\n";

print "\n";

#determine the request method, make sure the data is defined in ARGV
# and determine of the query string is defined page 28
if ($#ARGV != 1 && $ENV{REQUEST_METHOD} eq 'GET' && $ENV{QUERY_STRING} ne '')
{
  # split the query into keywords
  foreach $input (split("&",$ENV{QUERY_STRING}))
  {
    if ($input =~ /(.*)=(.*)/)
    {
      ($key,$value) = ($1, $2);
      $value =~ s/\+/ /g ; # replace "+" with " "
      # convert hex characters
      $value =~ s/%(..)/pack('c',hex($1))/eg;
      $inputs{$key} = $value; # add keyword/value pair to a list
    }
  }

  print "$#inputs\n";
  
  foreach $item (keys %inputs)
  {
    print "[$item] [$inputs{$item}]\n";
  }
}
else
{
  print "No inputs\n";
}
