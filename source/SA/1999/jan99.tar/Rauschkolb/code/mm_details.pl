#!/usr/bin/perl
#mm_details.pl
# display details -- the results of a test

$DATADIR="/tmp/mmdata/";

@parts=split(/\\\?/,$ARGV[0]);
$mach = $parts[0];
$tag = $parts[1];

$file = $DATADIR.$mach.".mon";

print "Content-type: text/html\n";

print "\n";

print "<!CGI script output:>\n";

print "<HTML>\n";
print "<HEAD> <TITLE> Machines - status details </TITLE>\n";
print "Details for $mach: $tag </HEAD> <BR>\n";
print "<BODY BGCOLOR=#FFFFFF> \n";
print "<P>";
open (IN,$file);
while ($line=<IN>)
{
    chop($line);
    @parts = split(/ /,$line);
    if ($parts[1] eq $tag)
    {
	print "<TABLE>\n";
        for ($i = 2; $i <= $#parts; $i = $i + 2)
        {
            print "<TR><TD>$parts[$i]</TD><TD>$parts[$i+1]</TD></TR>\n";
	}
	print "</TABLE>\n";
    }
}
close IN;
print "\n";
print "</BODY>\n";
print "</HTML>\n";

