#!/usr/local/bin/perl
#mm_recv.pl.5
# version 3
#       does no logging
# version 4
#       was not capable of handling multiple connections
#       added forking  
# version 5
#	put things in /tmp/pm_mon
#

require 5.002;
#use strict;
BEGIN { $ENV{PATH} = '/usr/ucb:/bin' }
use Socket;
use Carp;
#open (LOG,">>/tmp/logmsg.txt");
open (LOG,">/tmp/logmsg.txt");
sub logmsg { print LOG "$0 $$: @_ at ", scalar localtime, "\n" }

logmsg "$#ARGV";

my ($linein, $count, $tag, $DIR, $file);
$DIR="/tmp/mm/";
if ( ! -d $DIR)
{
	umask(000);
	mkdir($DIR,0775);
}

######################
#BEGIN network "magic"

my $port = shift || 2345;
my $proto = getprotobyname('tcp');
socket(Server, PF_INET, SOCK_STREAM, $proto)	or die "socket: $!";
#setsockopt(Server, SOL_SOCKET, SO_REUSEADDR, pack("l",1))
#			 			or die "setsockopt: $!";
setsockopt(Server, SOL_SOCKET, SO_REUSEADDR, 1) or die "setsockopt: $!";
bind(Server, sockaddr_in($port, INADDR_ANY)) 	or die "bind: $!";
listen(Server, SOMAXCONN)			or die "listen: $!";

logmsg "server started on port $port";

my $paddr;
my $waitedpid = 0;

sub REAPER
{
        $SIG{CHLD} = \&REAPER;
        $waitedpid = wait;
}

$SIG{CHLD} = \&REAPER;

for ( ; $paddr = accept(Client,Server); close Client)
{
  my($port,$iaddr) = sockaddr_in($paddr);
  my $name = gethostbyaddr($iaddr,AF_INET);

  logmsg "connection from $name [", inet_ntoa($iaddr), "] at port $port";

#END network "magic"
######################

  my $pid;
  if (!defined($pid = fork))
  {
          next;
  }
  elsif ($pid)
  {
          next;
  }

  umask(022);
  $count = 0;
  while($linein=<Client>)
  {
        chomp($linein);
	if ($count == 0)
        {
          $linein =~ s/^  *//;
          ($file)=split(/[: ]+/,$linein);
	  $count = 1;
#print "$file \n";
	  if ($file eq "")
	  {
	    print "No file specified - using default data\n";
	    $file = "data";
	  }

            $file = $DIR.$file.".mon";
	    open(OUT,">$file");
            print OUT "$linein\n";

        }
	else
	{
#          print "-> $linein\n";
          print OUT "$linein\n";
	}
  }
  close OUT;
  exit;
}
