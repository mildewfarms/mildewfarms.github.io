#!/usr/bin/perl
#mm_more_mach_details.pl
# return more details about a machine

@parts=split(/\\\?/,$ARGV[0]);
$mach = $parts[0];
$mach =~ tr/A-Z/a-z/;

$file = "more_machine_details.txt";

print "Content-type: text/html\n";

print "\n";

print "<!CGI script output:>\n";

print "<HTML>\n";
print "<HEAD> <TITLE> Machines - status details </TITLE>\n";
print "Details for $mach: $tag </HEAD> <BR>\n";
print "<BODY BGCOLOR=#FFFFFF> \n";
#print "$mach $part $file\n";
print "<P>";
open(IN,$file);
while ($line = <IN>)
{
	chop($line);
	($name,$location,$model,$serial,$os,$osver)=split(/\t/,$line);
	$name =~ tr/A-Z/a-z/;
	if ($name eq $mach)
	{
	    print "<TABLE>\n";
	    print "<TR><TD>Location:</TD><TD>$location</TD></TR>\n";
	    print "<TR><TD>Model:</TD><TD>$model</TD></TR>\n";
	    print "<TR><TD>Serial #:</TD><TD>$serial</TD></TR>\n";
	    print "<TR><TD>OS:</TD><TD>$os</TD></TR>\n";
	    print "<TR><TD>OS Ver:</TD><TD>$osver</TD></TR>\n";
	    print "</TABLE>\n";
	}
}
close (IN);

print "\n";
print "</BODY>\n";
print "</HTML>\n";

