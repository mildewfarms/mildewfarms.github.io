#!/usr/local/bin/perl

# Check arguments
if ( $#ARGV != 2 ) {
	printf "Wrong # args.\n";
    exit;
}

# Set network number and name of pipe special file
$quad1 = $ARGV[0];
$quad2 = $ARGV[1];
$quad3 = $ARGV[2];

$win = ${quad1}."-".${quad2}."-".${quad3};

$pipename = "/sysadmin/PING.".${win};

# Create named pipe if it doesn't exist.
unless (-p $pipename) {
	unlink $pipename;
	system ('/etc/mknod', $pipename, 'p') || die "Can't mknod $pipename: $!";
}

# Open the pipe for writing, set to nonblocking I/O
open ( FIFOPIPE, "> ".$pipename );
select((select(FIFOPIPE), $| = 1)[0]);

# Loop through the subnet in 16 groups of 16 hosts, querying each machine.
# Send the last quad of the IP address and a '1' through the pipe if the host responded,
# last quad and a '0' if it did not.
for ( $mask = 0; $mask < 16; $mask += 1 ) {
    if ($pid = fork) {
    } elsif (defined $pid) {
	for ( $hostid = 0; $hostid < 16; $hostid += 1 ) {
	    $quad4 = $mask * 16 + $hostid;
	    $ipaddr = join '.', $quad1, $quad2, $quad3, $quad4;
	    $result = `/usr/sbin/ping $ipaddr 1`;
	    if ( $result =~ /alive/ ) {
                printf FIFOPIPE "$quad4 1\n";
            } else {
		printf FIFOPIPE "$quad4 0\n";
            }
        }
        exit;
    }
}
