#!/usr/local/bin/perl

# Read in the IP address as the command line argument.
$ipaddr = $ARGV[0];

# Test for correct number of arguments
if ( $ipaddr eq "" ) {
    printf "Wrong # args.\n";
    exit;
}

# PErform the lookup query
$nameline = `nslookup $ipaddr 2>/dev/null | grep Name:`;
chop $nameline;

# Parse the query output and retrieve only the hostname.  If the hostname
# doesn't exist, set the hostname string to "NOHOST"
if ( $nameline =~ /Name:\s*(.*)$/ ) {
    $mach_name = $1;
} else {
    $mach_name = "NOHOST";
}

# Print the hostname as retrieved, or "NOHOST" if the query was invalid.
printf "${mach_name}\n";
