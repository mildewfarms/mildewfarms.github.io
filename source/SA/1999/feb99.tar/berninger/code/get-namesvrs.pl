#!/usr/local/bin/perl

# Open the input stream from a system call
open ( SERVERS, "cat /etc/resolv.conf | grep nameserver | cut -f 2 -d ' ' |");

# For each nameserver line found in the resolv.conf file, put the name of the
# machine onto the stack.
while ( $line = <SERVERS> ) {
    chop $line;
    push @serverlist, $line;
}

# Print out a space-delimited list of the nameserver names.
foreach $name (@serverlist) {
    printf "%s ", $name;
}

# End the printout with a hard return (newline) to close list
printf "\n";
