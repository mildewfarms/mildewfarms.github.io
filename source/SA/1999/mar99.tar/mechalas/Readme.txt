
The archive contains the following files:

   * license.txt

	The license agreement for masshosts and its supporting software.

   * masshosts.txt 

	The text of the manuscript.  Lines in ALL CAPS and underlined with
	equal signs "====" are main headings.  Lines underlined with dashes
	"----" are sub-headings.

   * masshosts.html

	HTML formatted version of the manuscript.

   * Listing1.1
   * Listing1.2
   * Listing2.1
   * Listing2.2
   * Figure1.1
   * Figure1.2

	See "titles"

   * README.1ST

	This file.

   * titles

	Gives suggested titles for the Listings and Figures.

