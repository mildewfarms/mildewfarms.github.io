#
# ociwrap.pl -- oci function wrappers
#
# Copyright (c) 1996 danny lawrence

package Oci;

#-----------------------------------------------------------
# bomb -- print error message and die
#
# usage:
#    bomb($msg);

sub bomb {
     printf(STDERR "%s\n", $_[0]) if $_[0];
     printf(STDERR "oerr=%s\n", $oerr);
     printf(STDERR "oermsg=%s\n", chomp $oermsg);
     die;
}

#-----------------------------------------------------------
# ckconnect -- connect or die
#
# usage:
#    ckconnect($userid);

sub ckconnect {
     oraconnect($_[0]) || bomb("ckconnect");
}

#-----------------------------------------------------------
# ckdisconnect -- disconnect or die
#
# usage:
#    ckdisconnect();

sub ckdisconnect {
     oradisconnect() || bomb("oradisconnect");
}

#-----------------------------------------------------------
# ckcursor -- create cursor or die
#
# usage:
#    $curvar = ckcursor($stmt);

sub ckcursor {
     my $retval;
     my $cur;

     ($retval, $cur) = oracursor($_[0]);
     bomb("ckcursor: \n$_[0]\n") if $retval != $OK;
     return $cur;
}

#-----------------------------------------------------------
# ckbind -- bind value or die
#
# usage:
#    ckbind($cur, $sqlvar, $val, $len);

sub ckbind {
     my $len;

     if ($_[3]) {
          $len = $_[3];
     } else {
          $len = 0;
     }
     orabind($_[0], $_[1], $_[2], $len) || bomb("orabind $_[1]");
}

#-----------------------------------------------------------
# ckopen -- open cursor or die
#
# usage:
#    ckopen($cur);

sub ckopen {
     oraopen($_[0]) || bomb("oraopen");
}

#-----------------------------------------------------------
# ckclose -- close cursor or die
#
# usage:
#    ckclose($cur);

sub ckclose {
     oraclose($_[0]) || bomb("oraclose");
}

#------------------------------------------------------------
# ckcommit -- commit or die
#
# usage:
#    &ckcommit;

sub ckcommit {
     &oracommit || bomb("oracommit");
}

#-----------------------------------------------------------
# ckrollback -- rollback or die
#
# usage:
#    &ckrollback;

sub ckrollback {
     &orarollback || bomb("orarollback");
}

1;
