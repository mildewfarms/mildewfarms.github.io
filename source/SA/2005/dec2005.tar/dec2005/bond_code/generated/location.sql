USE workorder;
CREATE TABLE location (
id int(11) primary key auto_increment,
name varchar(255)
);