USE workorder;
CREATE TABLE tech (
id int(11) primary key auto_increment,
name varchar(255)
);