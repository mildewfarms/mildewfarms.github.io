USE workorder;
CREATE TABLE request (
id int(11) primary key auto_increment,
name varchar(255),
phone varchar(255),
email varchar(255),
location int,
category varchar(255),
priority varchar(255),
problem mediumtext,
tech int,
resolution mediumtext,
changed datetime
);