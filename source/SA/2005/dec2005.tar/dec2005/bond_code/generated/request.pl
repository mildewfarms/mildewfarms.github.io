#!/usr/bin/perl -w

use CGI;
use CGI::Carp('fatalsToBrowser');
use DBI;
use strict;
#require "workorder_common.pl";

my $ip = $ENV{'REMOTE_ADDR'};

my $dbh    = "";
my $q      = CGI->new();
my $id     = $q->param('id');
my $action = $q->param('action');
my $skip   = $q->param('skip');
my $sort   = $q->param('sort');
   $sort   = "" unless $sort;
my $sort2;

# Sanitize input
$id   =~ s/[^0-9]//g;  # nix anything not a number
$skip =~ s/[^0-9]//g;  # nix anything not a number
$skip = 0 unless $skip;

db_connect();

if($action eq "edit"){
	header();
	edit_item($id);
	footer();

}elsif($action eq "commit"){
	commit_item();

}elsif($action eq "delete"){
	delete_item($id);

}else{
	$action = "list";
	header();
	list_items();
	footer();
}



#----------------------------------------------------------------------------------
sub list_items {

  my ($id, $name, $phone, $email, $location, $category, $priority, $problem, $tech, $resolution, $changed) = "";
  my $statement = "SELECT id, name, phone, email, location, category, priority, problem, tech, resolution, changed FROM request";

  # sort clause
  if($sort){ 
	if($sort =~ /_desc$/){
		$sort2 = $sort;
		$sort2 =~ s/_desc$//;
		$statement .= " ORDER BY $sort2 DESC"; 
	}else{
		$statement .= " ORDER BY $sort"; 
	}
  }

  #------------------------------------------------
  # Paging through rows
  #------------------------------------------------
  # Get a count of the total records, for paging links
  my ($counter) = $dbh->selectrow_array("SELECT count(*) FROM request");

  my $rows_per_page = 20;
  my $skip_next     = $skip + $rows_per_page;
  my $skip_prev     = 0;
  if($skip > $rows_per_page){ $skip_prev = $skip - $rows_per_page; }

  my $url_next = "";
  my $url_prev = "";

  # Skip records - don't skip more than what exists, right?
  if($rows_per_page >= $counter){
	# We reached the end already
	$url_next   = "";
	$url_prev   = "";

  }elsif($skip==0){

	$url_prev   = "";  # no previous recs exist becuz we're at the beginning
	$url_next   = "<a href='request.pl?action=list&sort=$sort&skip=$skip_next'> More >> </a>";

  }elsif($skip + $rows_per_page >= $counter){
	# We reached the end already
	$url_next   = "";
	$url_prev   = "<a href='request.pl?action=list&sort=$sort&skip=$skip_prev'> << More</a>";

  }elsif($skip < $counter){
	# Everything's beautiful, baby -- the world is orderly
	$url_next   = "<a href='request.pl?action=list&sort=$sort&skip=$skip_next'> More >> </a>";
	$url_prev   = "<a href='request.pl?action=list&sort=$sort&skip=$skip_prev'> << More</a>";
  }
  $statement .= " LIMIT $skip,$rows_per_page";

  #die $statement;
  my $sth = $dbh->prepare($statement);
  $sth->execute;

  my $td_class = "tablerow1";
  my $tableheader = <<TABLEHEADER;
<table CELLSPACING=1 CELLPADDING=5 BORDER=0>

<tr>
	<td class=tableheader><a href='request.pl?action=list&sort=id'>id</a></td>
	<td class=tableheader><a href='request.pl?action=list&sort=name'>Name</a></td>
	<td class=tableheader><a href='request.pl?action=list&sort=phone'>Phone</a></td>
	<td class=tableheader><a href='request.pl?action=list&sort=email'>Email</a></td>
	<td class=tableheader><a href='request.pl?action=list&sort=category'>Category</a></td>
	<td class=tableheader><a href='request.pl?action=list&sort=priority'>Priority</a></td>
	<td class=tableheader><a href='request.pl?action=list&sort=tech'>Tech</a></td>
	<td class=tableheader><a href='request.pl?action=list&sort=changed'>Modified</a></td>
</tr>

TABLEHEADER
  if($sort) { $tableheader =~ s/(sort=$sort)/$1_desc/; }
  print $tableheader;

  while ( ($id, $name, $phone, $email, $location, $category, $priority, $problem, $tech, $resolution, $changed) = $sth->fetchrow_array){
	print <<DONE;

		
<tr>
	<td nowrap class=$td_class><a href='request.pl?action=edit&id=$id'>$id</a></td>
	<td nowrap class=$td_class>$name</td>
	<td nowrap class=$td_class>$phone</td>
	<td nowrap class=$td_class>$email</td>
	<td nowrap class=$td_class>$category</td>
	<td nowrap class=$td_class>$priority</td>
	<td nowrap class=$td_class>$tech</td>
	<td nowrap class=$td_class>$changed</td>
</tr>

DONE

	  if($td_class eq "tablerow1"){ $td_class = "tablerow2"; }else { $td_class = "tablerow1"; }

  }
  print "</table>\n";
  print <<SKIP;
<table width=100%>
<tr>
  <td>$url_prev</td>
  <td align=right>$url_next</td>
</tr>
</table>
SKIP


}
#----------------------------------------------------------------------------------
sub edit_item {

  my $this_id = shift;
  my $statement = "SELECT id, name, phone, email, location, category, priority, problem, tech, resolution, changed FROM request WHERE id=$this_id";

  my ($id, $name, $phone, $email, $location, $category, $priority, $problem, $tech, $resolution, $changed);

  if($this_id > 0){

	  ($id, $name, $phone, $email, $location, $category, $priority, $problem, $tech, $resolution, $changed) = $dbh->selectrow_array($statement);
  }

	
	my $select_priority = select_priority($priority);
	my $select_category = select_category($category);
	
	my $lookup_tech = lookup_tech($tech);
	my $lookup_location = lookup_location($location);
	my $edit_form = <<DONE;
	
<form name="editform" action="request.pl" method="post" onSubmit="return checkData()">
<input type="hidden" name="action" value="commit">
<table cellspacing="1" cellpadding="5" border="0"><tr>
	<td align="right" class="tablerow1"><b>id</b></td>
	<td valign="top" class="tablerow1"><input type="hidden" name="id" value="$id">$id</td>
</tr>
<tr>
	<td align="right" class="tablerow2"><b>Name</b></td>
	<td valign="top" class="tablerow2"><input type="text" name="name" size="30" value="$name"></td>
</tr>
<tr>
	<td align="right" class="tablerow1"><b>Phone</b></td>
	<td valign="top" class="tablerow1"><input type="text" name="phone" size="30" value="$phone"></td>
</tr>
<tr>
	<td align="right" class="tablerow2"><b>Email</b></td>
	<td valign="top" class="tablerow2"><input type="text" name="email" size="30" value="$email"></td>
</tr>
<tr>
	<td align="right" class="tablerow1"><b>Location</b></td>
	<td valign="top" class="tablerow1">$lookup_location</td>
</tr>
<tr>
	<td align="right" class="tablerow2"><b>Category</b></td>
	<td valign="top" class="tablerow2">$select_category</td>
</tr>
<tr>
	<td align="right" class="tablerow1"><b>Priority</b></td>
	<td valign="top" class="tablerow1">$select_priority</td>
</tr>
<tr>
	<td align="right" class="tablerow2"><b>Problem</b></td>
	<td valign="top" class="tablerow2"><textarea name="problem" rows="2" cols="80">$problem</textarea></td>
</tr>
<tr>
	<td align="right" class="tablerow1"><b>Tech</b></td>
	<td valign="top" class="tablerow1">$lookup_tech</td>
</tr>
<tr>
	<td align="right" class="tablerow2"><b>Resolution</b></td>
	<td valign="top" class="tablerow2"><textarea name="resolution" rows="2" cols="80">$resolution</textarea></td>
</tr>
<tr>
	<td align="right" class="tablerow1"><b>Modified</b></td>
	<td valign="top" class="tablerow1"></td>
</tr>
<tr><td></td><td><input type="submit" name="Submit"></td></tr>
</table>
</form>
	
DONE
print $edit_form;
print qq[<p><a href="request.pl?action=delete&id=$this_id">Delete</a></p>\n] if $this_id > 0;  

}
#----------------------------------------------------------------------------------
sub commit_item {

my $name                  = $q->param('name'); $name = $dbh->quote($name);
my $phone                 = $q->param('phone'); $phone = $dbh->quote($phone);
my $email                 = $q->param('email'); $email = $dbh->quote($email);
my $location              = $q->param('location'); $location = $dbh->quote($location);
my $category              = $q->param('category'); $category = $dbh->quote($category);
my $priority              = $q->param('priority'); $priority = $dbh->quote($priority);
my $problem               = $q->param('problem'); $problem = $dbh->quote($problem);
my $tech                  = $q->param('tech'); $tech = $dbh->quote($tech);
my $resolution            = $q->param('resolution'); $resolution = $dbh->quote($resolution);
my $changed               = $q->param('changed'); $changed = $dbh->quote($changed);


  my $statement;
  if($id > 0){
	$statement = "UPDATE request SET 
name                  = $name,
phone                 = $phone,
email                 = $email,
location              = $location,
category              = $category,
priority              = $priority,
problem               = $problem,
tech                  = $tech,
resolution            = $resolution,
changed               = $changed
 WHERE id=$id";
  }else{
	$statement = "INSERT INTO request (name, phone, email, location, category, priority, problem, tech, resolution, changed) VALUES ($name, $phone, $email, $location, $category, $priority, $problem, $tech, $resolution, $changed)";
  }

  #die $statement;
  $dbh->do($statement);
  print $q->redirect("request.pl?action=list");


}
#----------------------------------------------------------------------------------
sub delete_item {

  my $id = shift;
  $dbh->do("DELETE FROM request WHERE id=$id");
  print $q->redirect("request.pl?action=list");

}

#SELECT_SUBS#
#----------------------------------------------------------------------------------
sub select_priority {

	# This subroutine is for a simple lookup (no other tables involved)
	# May need hand-tweaking depending on whether you want 
	# null's or blanks to be valid choices, or if you want a default choice

	# One argument = the value to highlight in the dropdown
	my $selected = shift;

	my $dropdown = qq[<select name="priority" size="1"><option value=""></option><option value="Low">Low</option><option value="Medium">Medium</option><option value="High">High</option><option value="Emergency">Emergency</option></select>];

	if($selected){
		$dropdown  =~ s/(value="$selected")/$1 selected/;
	}
	return $dropdown;
}

#----------------------------------------------------------------------------------
sub select_category {

	# This subroutine is for a simple lookup (no other tables involved)
	# May need hand-tweaking depending on whether you want 
	# null's or blanks to be valid choices, or if you want a default choice

	# One argument = the value to highlight in the dropdown
	my $selected = shift;

	my $dropdown = qq[<select name="category" size="1"><option value=""></option><option value="Hardware">Hardware</option><option value="Software">Software</option><option value="Network">Network</option><option value="Telephone">Telephone</option><option value="Web">Web</option><option value="Other">Other</option></select>];

	if($selected){
		$dropdown  =~ s/(value="$selected")/$1 selected/;
	}
	return $dropdown;
}

#LOOKUP_SUBS#
#----------------------------------------------------------------------------------
sub lookup_tech {

	# Note: we assume the lookup table has a column called id
	# This subroutine may need manual tweaking

	# Argument = the value to highlight in the dropdown
	my $selected = shift;

	my $dropdown = qq[<select name="tech" size="1">\n<option value="0"></option>\n];

	my $stmt    = "SELECT id, name FROM tech ";
	my $sth     = $dbh->prepare($stmt);
	$sth->execute();

	while ( my ($id,$value) = $sth->fetchrow_array){
		$dropdown .= qq[<option value="$id">$value</option>\n];
	}
	$sth->finish;
	$dropdown .= "</select>\n";
	if($selected){
		$dropdown  =~ s/(value="$selected")/$1 selected/;
	}
	return $dropdown;
}

#----------------------------------------------------------------------------------
sub lookup_location {

	# Note: we assume the lookup table has a column called id
	# This subroutine may need manual tweaking

	# Argument = the value to highlight in the dropdown
	my $selected = shift;

	my $dropdown = qq[<select name="location" size="1">\n<option value="0"></option>\n];

	my $stmt    = "SELECT id, name FROM location ";
	my $sth     = $dbh->prepare($stmt);
	$sth->execute();

	while ( my ($id,$value) = $sth->fetchrow_array){
		$dropdown .= qq[<option value="$id">$value</option>\n];
	}
	$sth->finish;
	$dropdown .= "</select>\n";
	if($selected){
		$dropdown  =~ s/(value="$selected")/$1 selected/;
	}
	return $dropdown;
}



#--------------------------------------------------------------------------------
sub header {

  print <<DONE;
Content-type: text/html

<html><head>
<style type="text/css">

body {background-color : #ffffff; font-family: helvetica, arial,sans-serif; }
p    { font-size: 12px; }
h1   { color:#999999; font-size: 18px;}
h2   { color:#777777; font-size: 16px;}
h3   { color:#000000; font-size: 12px;}

a         {  }
a:link    { color: #000099; text-decoration:none;}
a:visited { color: #000099; }
a:hover   { color: #0000FF; text-decoration:underline;}
a:active  { color: #0000FF; }

td { font-size: 12px; }

.tableheader   { background-color: #dddddd; vertical-align: top;  font-weight: bold; white-space: nowrap; }
.tableheader a { color: #000000; text-decoration:none; }
.tableheader a:hover { text-decoration:underline; }
.tablerow1     { background-color: #e0e0e0; vertical-align: top; }
.tablerow2     { background-color: #eeeeee; vertical-align: top; }

</style>

<script language="JavaScript">
<!--

function checkData (){
	// Put any client-side validation routines in here
	//if(document.addform.name.value.length==0){
	//	alert("You must enter a name.");
	//	return false;
	//}
}
//-->
</script>

<title>workorder - request</title>

</head>

<body>
<h1>workorder - request</h1>

<p>
<a href="../">Home</a> |
<a href="request.pl?action=list">List All Requests</a> |
<a href="request.pl?action=edit">Add New Request</a>
<a href="tech.pl?action=list">Techs</a> |
<a href="location.pl?action=list">Locations</a> |
</p>
DONE
}



#----------------------------------------------------------------------------------
sub footer {
  print "</body></html>";

}
#----------------------------------------------------------------------------------
sub db_connect {
  $dbh = DBI->connect('DBI:mysql:workorder', 'workorder', 'workorder', {PrintError => 0,RaiseError => 1});

}

