// $Id: DHCPFingerprintLoader.java,v 1.8 2004/11/03 16:17:05 dphull Exp $ 

import java.io.*;
import java.util.*;

public class DHCPFingerprintLoader 
{
  
  public static DHCPFingerprint load(String fingerprintsFile) 
  {

		DHCPFingerprint fingerprints = new DHCPFingerprint();

	  try 
	  {
			File FingerprintFile = new File(fingerprintsFile);
			FileReader fileReader = new FileReader(FingerprintFile);
		  
		  BufferedReader reader = new BufferedReader(fileReader);
		  
		  String line = null;
		  
		  while ((line = reader.readLine()) != null) 
		  {
				StringBuffer dhcpOptions = new StringBuffer();
				String OS = null;
				String[] dhcpOptionsOS;
				dhcpOptionsOS = line.split(",");
				int i;
						
				for (i = 0; i < dhcpOptionsOS.length - 2; i++) 
				{
					dhcpOptionsOS[i] = String.valueOf((byte) Integer.parseInt(dhcpOptionsOS[i]));
					dhcpOptions.append(dhcpOptionsOS[i]);
					dhcpOptions.append(",");					
				}
				dhcpOptionsOS[i] = String.valueOf((byte) Integer.parseInt(dhcpOptionsOS[i]));
				dhcpOptions.append(dhcpOptionsOS[i]);				
				
				OS = dhcpOptionsOS[++i];
				
				fingerprints.put(dhcpOptions.toString(), OS);
			} 
		  reader.close();
		  
	  } catch(Exception ex) 
	  {
		  ex.printStackTrace();
	  }
	  
		return fingerprints;	  
  } 
}