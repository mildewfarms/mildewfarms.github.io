// $Id: DHCPFingerprint.java,v 1.11 2004/10/06 15:49:02 dphull Exp $

import java.util.*;

public class DHCPFingerprint 
{
	private HashMap optionsOSMap;
  		
	private static String toString(byte[] dhcpRequestedOptions) 
	{
    if(dhcpRequestedOptions == null)
    {
			return null;
		}
    
		StringBuffer options = new StringBuffer();
    
		int i;
    for (i = 0; i < dhcpRequestedOptions.length - 1; i++) 
		{
			options.append(dhcpRequestedOptions[i]);
			options.append(",");
		}
		options.append(dhcpRequestedOptions[i++]);
    
		return options.toString();
	}
		
	public DHCPFingerprint() 
	{
		optionsOSMap = new HashMap();
	}
	
	public void clear() 
	{
		optionsOSMap.clear();    
	}
  
	public String get(byte[] incomingOptionsRequested) 
	{
		return (String) optionsOSMap.get(toString(incomingOptionsRequested));
	}

	public boolean isEmpty() 
	{
		return optionsOSMap.isEmpty();    
	}
  
	public void put(byte[] dhcpRequestedOptions, String description) 
	{
		optionsOSMap.put(toString(dhcpRequestedOptions), description);    
	}
	
	public void put(String dhcpRequestedOptions, String description) 
	{
		optionsOSMap.put(dhcpRequestedOptions, description);
	}
  
	public String remove(byte[] removeOptions) 
	{
		return (String) optionsOSMap.remove(toString(removeOptions));
	}
	
	public int size()
	{
		return optionsOSMap.size();    
	}
}