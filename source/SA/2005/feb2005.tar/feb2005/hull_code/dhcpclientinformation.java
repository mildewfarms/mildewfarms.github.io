// $Id: DHCPClientInformation.java,v 1.7 2004/11/03 16:17:05 dphull Exp $

import java.util.Date;

public class DHCPClientInformation
{
    private String requestedIP;
    private String vendorClassID;
    private String systemName;
    private String messageType;
    private String ipAddress;
    private String macAddress;
    private String operatingSystem;

    public void setIpAddress(String ipAddress)
    {
        this.ipAddress = ipAddress;
    }

    public String getIpAddress()
    {
        return ipAddress;
    }

    public void setMacAddress(String macAddress)
    {
        this.macAddress = macAddress;
    }

    public String getMacAddress()
    {
        return macAddress;
    }
		
		public String toString() 
		{
			StringBuffer sb = new StringBuffer();
			sb.append("\t<dhcpMessage>\n");
			sb.append("\t\t<messageType>\n\t\t\t");
			sb.append(messageType);
			sb.append("\n\t\t</messageType>\n");
			sb.append("\t\t<macAddress>\n\t\t\t");
			sb.append(macAddress);
			sb.append("\n\t\t</macAddress>\n");
			sb.append("\t\t<requestedIP>\n\t\t\t");
			sb.append(requestedIP);
			sb.append("\n\t\t</requestedIP>\n");
			sb.append("\t\t<systemName>\n\t\t\t");
			sb.append(systemName);
			sb.append("\n\t\t</systemName>\n");
			sb.append("\t\t<operatingSystem>\n\t\t\t");
			sb.append(operatingSystem);
			sb.append("\n\t\t</operatingSystem>\n");			
			sb.append("\t\t<vendorClassID>\n\t\t\t");
			sb.append(vendorClassID);
			sb.append("\n\t\t</vendorClassID>\n");
			sb.append("\t\t<date>\n\t\t\t");
			sb.append(new Date().toString());
			sb.append("\n\t\t</date>\n");
			sb.append("\t</dhcpMessage>\n");
			return sb.toString();
		}
  
    public static String getHeader()
    {
      StringBuffer header = new StringBuffer();
      header.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
      header.append("<!DOCTYPE dhcpMessageList SYSTEM \"dhcpMessageList.dtd\" >\n");
			header.append("<dhcpMessageList>\n");
      return header.toString();
    }

    public static String getFooter()
    {
      StringBuffer footer = new StringBuffer();
      footer.append("</dhcpMessageList>");
      return footer.toString();
    }

  public String getOperatingSystem()
  {
    return operatingSystem;
  }

  public void setOperatingSystem(String operatingSystem)
  {
    this.operatingSystem = operatingSystem;
  }

  public String getMessageType()
  {
    return messageType;
  }

  public void setMessageType(String messageType)
  {
    this.messageType = messageType;
  }

  public String getSystemName()
  {
    return systemName;
  }

  public void setSystemName(String systemName)
  {
    this.systemName = systemName;
  }

  public String getVendorClassID()
  {
    return vendorClassID;
  }

  public void setVendorClassID(String vendorClassID)
  {
    this.vendorClassID = vendorClassID;
  }

  public String getRequestedIP()
  {
    return requestedIP;
  }

  public void setRequestedIP(String requestedIP)
  {
    this.requestedIP = requestedIP;
  }
}
