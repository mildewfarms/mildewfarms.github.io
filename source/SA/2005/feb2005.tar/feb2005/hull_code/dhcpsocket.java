// $Id: DHCPSocket.java,v 1.5 2004/09/13 20:47:17 gfwillar Exp $

/**
 * 
 */

import java.io.IOException;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;


public final class DHCPSocket
{
    private static final int DHCP_SERVER_PORT = 67;
    private DatagramSocket socket;

    public DHCPSocket() throws SocketException
    {
        socket = new DatagramSocket(DHCP_SERVER_PORT);
    }

    public byte[] getNextPacket() throws IOException
    {
        byte[] buffer = new byte[1500];
        DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length);

        socket.receive(datagramPacket);

        return datagramPacket.getData();
    }
}
