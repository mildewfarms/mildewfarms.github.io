package MyConfig::CDBI;
use base 'Class::DBI';
use Class::DBI::AbstractSearch;

package MyConfig::CDBI::Interface;
use base 'MyConfig::CDBI';
__PACKAGE__->columns(Primary => qw/interface device/);
__PACKAGE__->columns(Others => qw/description/);
__PACKAGE__->has_a(device => 'MyConfig::CDBI::Device');

package MyConfig::CDBI::Device;
use base 'MyConfig::CDBI';
__PACKAGE__->columns(Primary => qw/device/);
__PACKAGE__->columns
    (Others => qw/location contact serial hardware software class/);
__PACKAGE__->has_many(interfaces => 'MyConfig::CDBI::Interface' );

package MyConfig::CDBI::Address;
use base 'MyConfig::CDBI';
__PACKAGE__->columns(Primary => qw/ip interface device/);
__PACKAGE__->columns(Others => qw/cidr type/);
__PACKAGE__->has_a(device => 'MyConfig::CDBI::Device');
__PACKAGE__->has_a(cidr => 'MyConfig::CDBI::Subnet');

package MyConfig::CDBI::Subnet;
use base 'MyConfig::CDBI';
__PACKAGE__->columns(All => qw/cidr first last/);
__PACKAGE__->has_many(addresses => 'MyConfig::CDBI::Address');

package MyConfig::CDBI::Sighting;
use base 'MyConfig::CDBI';
__PACKAGE__->columns(Primary => qw/endpoint time device interface/);
__PACKAGE__->has_a(endpoint => 'MyConfig::CDBI::Endpoint');
__PACKAGE__->has_a(device => 'MyConfig::CDBI::Device');

package MyConfig::CDBI::Assignment;
use base 'MyConfig::CDBI';
__PACKAGE__->columns(Primary => qw/ip time/);
__PACKAGE__->columns(Other => qw/endpoint cidr/);
__PACKAGE__->has_a(endpoint => 'MyConfig::CDBI::Endpoint');
__PACKAGE__->has_a(cidr => 'MyConfig::CDBI::Subnet');

package MyConfig::CDBI::Endpoint;
use base 'MyConfig::CDBI';
__PACKAGE__->columns(Primary => qw/endpoint/);
__PACKAGE__->columns(Other => qw/os vendor time/);
__PACKAGE__->has_many(all_assignments => 'MyConfig::CDBI::Assignment');
__PACKAGE__->has_many(all_sightings => 'MyConfig::CDBI::Sighting');

42;
