#!/bin/bash
#
# Cellmate.sh
#
# Submit as  
# * * * * * /home/user/celllmate.sh
# in cron to check every minute.
#

./fetch_yahoo.sh 
./mail_from_yahoo.sh 
./queue.sh
./send_pass.sh
./process_queue.sh 