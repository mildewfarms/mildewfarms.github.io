#! /usr/bin/perl

sub dev_image ($) { return shapefile => './images/' 
			. ($_[0] || 'router') . '.gif'; }

our %device_node = (
    rank => 'device',
    fontname => 'Helvetica',
    peripheries => 0,
    cluster => {
	fontname => 'Helvetica',
	name => 'Devices',
	style => 'dashed',
    }
);

our %interface_node = (
    fillcolor => 'purple',
    color => 'blue',
    fontname => 'Helvetica',
    fontcolor => 'cyan',
    style => 'filled',
    shape => 'ellipse',
    rank => 'interface',
    cluster => {
	fontname => 'Helvetica',
	name => 'Interfaces',
	style => 'dashed',
    },
);

our %subnet_node = (
    shapefile => './images/subnet.gif',
    fontname => 'Helvetica',
    peripheries => 0,
    rank => 'subnet',
    cluster => {
	fontname => 'Helvetica',
	name => 'Networks',
	style => 'dashed',
    },
);

our %endpoint_node = (
    shapefile => './images/endpoint.gif',
    fixedsize => 1,
    fontname => 'Helvetica',
    rank => 'endpoint',
    peripheries => 0,
    cluster => {
	fontname => 'Helvetica',
	name => 'Endpoints',
	style => 'dashed',
    },
);

our %if_edge = (
    style => 'bold',
    color => 'blue',
    fontname => 'Helvetica',
    fontsize => 8,
);

our %addr_edge = (
    style => 'bold',
    color => 'orange',
    fontname => 'Helvetica',
    fontsize => 8,
);

our %assignment_edge = (
    style => 'dashed',
    color => 'orange',
    fontname => 'Helvetica',
    fontsize => 8,
);

our %sighting_edge = (
    style => 'dashed',
    color => 'purple',
    fontname => 'Helvetica',
    fontsize => 8,
);

our %graph_options = (
    layout => 'twopi', 
    fontname => 'Helvetica',
    directed => 0,
#    center => 1,
    height => 11,
    width => 8,
    pageheight => 11,
    pagewidth => 8,
    ratio => 'compress',
);

1;


