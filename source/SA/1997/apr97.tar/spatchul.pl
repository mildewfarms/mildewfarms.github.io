Author:  choba@sturgeon.ucsf.EDU (Wayne Wonchoba) at Internet
Date:    12/17/96  12:53 PM
Priority: Normal
TO: Amber Ankerholz at MFI-Lawrence
CC: choba@sturgeon.ucsf.EDU at Internet
Subject: Re: Sys Admin article
------------------------------- Message Contents -------------------------------

Here is the source

#!/usr/local/bin/perl  -T
# The script passes -w too, but (on my system) one of the perl libraries 
# didn't 
#
# $Id: Spatchula,v 1.4 1996/12/17 20:39:51 choba Exp choba $ 
#
# (C) Copyright 1996,  The Regents of the University of California, 
# San Francisco, California.  All rights reserved.
# 
# NEITHER THE UNIVERSITY OF CALIFORNIA, SAN FRANCISCO, NOR ANY OF
# THEIR EMPLOYEES, MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES 
# ANY LEGAL LIABILITY OR RESPONSIBILITY FOR THE ACCURACY, COMPLETENESS 
# OR USEFULNESS OF ANY INFORMATION, APPARATUS, PRODUCT, OR PROCESS
# DISCLOSED.
#
# Documentation is at the end via perl pod 
#
# To get an unformatted manpage try something like 
#
#    pod2man Spatchula >> ./man1/Spatchula.1 
#
# from your a manpage directory.  pod2man should have come with with your 
# perl5 distribution.  
#
     
my @patch_parameters = ( ['ALL_HOSTS',   '      : : '], 
                         ['snapper',     '2.5.1 : : '],
                         ['trout',       '2.5.1 : : '],
                         ['sturgeon',    '2.5   : : '],
                       );
     
# THINGS BELOW HERE NEED TO BE CHANGED AT INSTALLATION
     
my $PATCH_LOG = "/spare/patches/scripts/patch_log"; 
my $PATCH_DIR = "/spare/patches";
my $SUNSOLVE_LOGIN = '';  # supply your own Sunsolve login 
my $SUNSOLVE_PASSWD = ''; # supply your own Sunsolve password 
     
# NOTHING BELOW HERE NEEDS TO BE CHANGED
     
     
#basic security stuff
$ENV{'PATH'} = '/bin:/usr/bin';    
$ENV{'SHELL'} = '/bin/sh' if defined $ENV{'SHELL'}; 
$ENV{'IFS'} = ''          if defined $ENV{'IFS'};
     
use strict;
use LWP::UserAgent;
     
MAIN: {
     
    log_it (">>Beginning $0 on ".(localtime) .  
           "; directory is $PATCH_DIR\n"  );
     
    # initialize the "patch dictionary"
    my $patch_dict = &initialize;
     
    # now get the most recent recommended patch list from SunSolve 
    # foreach OS you have
    foreach  ( keys %{$patch_dict->{REC}} ) {
        & get_rec_patches ($patch_dict, $_); 
    }
     
    # first downloaded any needed patches over the net;  then install them 
    & download_patches ($patch_dict);
    & install_patches ($patch_dict);
     
    # clean up the patch directory $PATCH_DIR 
    & clean_up ($patch_dict);
     
    log_it (">>Finished $0 on ".(localtime) .  "\n\n"  );
}
     
sub install_patches ($) {
    my $patch_dict = shift; 
     
    my @patchlist = sort (keys %{$patch_dict->{LOCAL_PATCHES}}); 
    my ($h, $os, $patch);
     
    foreach (@patch_parameters) {
        next if ($_->[0] eq 'ALL_HOSTS');
     
        $h = $_->[0];
        $os = $patch_dict->{HOST}->{$h}->{OS}; 
     
        $patch_dict->{PATCH_FREE_HOSTS}->{$h} =1;
     
        foreach $patch (@patchlist) {
            # wrong os version
            next unless (exists $patch_dict->{REC}->{$os}->{$patch});
     
            unless (exists $patch_dict->{HOST}->{$h}->{HAS}->{$patch} ||
                    exists $patch_dict->{HOST}->{$h}->{OMITS}->{$patch} )  {
                  $patch_dict->{INSTALLED_PATCHES}->{$patch} =1 
                      if (& installpatch ($patch_dict, $h, $patch));
                  $patch_dict->{PATCH_FREE_HOSTS}->{$h} = 0;
            }
        } 
    }
    # add the SPECIAL INSTRUCTIONS for each patch successfully installed 
    foreach ( keys %{$patch_dict->{INSTALLED_PATCHES}} ) {
        &log_instructions ($_); 
    }
     
    # summarize what else happened (in the log file) 
    & summarize ($patch_dict);
}
     
sub initialize  {
     
     
    # initialize a patch dictionary and return it.
    my $dict = {ALL_HOSTS          =>       { OMITS => {},
                                              ARGS => '',
                                            },
                      HOST               => {},   # host info  
     
                      REC                => {},   # recommended patches 
                      DOWNLOAD_PATCHES   => {},   # patches you had to download 
                      LOCAL_PATCHES      => {},    
                      USED_PATCHES       => {},    
                      INSTALLED_PATCHES  => {},
                     };
     
    my ($h, $os, $args, $omit);
    foreach  (@patch_parameters) {
     
        $h = $_->[0];
        next if ($h =~ /ALL_HOSTS/);
     
        ($os, $args, $omit ) = split (/\s*:\s*/,$_->[1]);
     
        # get rid of commas in $omit
        $omit =~ tr/,//d;
     
        # define the os
        $dict->{REC}->{$os} = {};
     
        $dict->{HOST}->{$h} = {
                                      OMITS  => {}, # figure these out below 
                                      HAS    => {}, #   
                                      ARGS   => $args,
                                      OS     => $os,
                                      PATCH_OK   => {}, 
                                      PATCH_FAIL => {}, 
                                    };
        # find out which patches this host has
        foreach ( `/usr/ucb/rsh $h /bin/showrev -p 2>&1`  ) {
             $dict->{HOST}-> {$h}-> {HAS} -> {(split (/\s+/, $_))[1]} = 1;
        }
        # find out which patches this host omits 
        foreach (split (/\s+/, $omit)) {
             $dict->{HOST}->{$h}-> {OMITS}->{$_} = 1; 
        }
     
    }
    return $dict;
};
     
     
sub installpatch ($$$) {
     
    my ($dict, $host, $patch) = @_;
     
    my $d = "$PATCH_DIR/$patch";
    my $args = $dict->{HOST}->{$host}->{ARGS};
    $a = `rsh $host $d/installpatch $args $d 2>&1`;
     
    $dict->{USED_PATCHES}->{$patch} =1;
     
    # now check the result
    if ($a =~ /$patch has been (successfully )?installed\./) {
         log_it("> ".(localtime).  ": installed $patch on $host\n"); 
         $dict->{HOST}->{$host}->{PATCH_OK}->{$patch} =1;
         return 1;
    } else {
         # make the output indented in the log file for added readability 
         chop ($a); $a =~ s/\n/\n /g; 
     
         log_it("! ".(localtime).  
              ": installing patch $patch FAILED on $host:\n $a\n");
         $dict->{HOST}->{$host}->{PATCH_FAIL}->{$patch} =1; 
         return 0;
    }
}
     
sub download_patches ($) {
     
    my $dict = shift; 
     
    my ($line, $h, $os);
    foreach $line (@patch_parameters) {
        $h = $line->[0]; 
        next if ($h eq 'ALL_HOSTS'); 
     
        $os = $dict->{HOST}->{$h}->{OS};
     
        # now, we download each patch in the recommended patch 
        # list only if four things are true
        #     1) it isn't already installed on the host 
        #     2) it isn't in the hosts OMITS list 
        #     3) it isn't in the ALL_HOST OMITS list
        #     4) it isn't already in the $PATCH_DIR directory 
        foreach ( keys %{$dict->{REC}->{$os} }) {
     
            next if (exists $dict->{HOST}->{$h}->{HAS}->{$_} ); 
            next if (exists $dict->{HOST}->{$h}->{OMITS}->{$_}); 
            next if (exists $dict->{ALL_HOSTS}->{OMITS}->{$_}); 
            next if (-e "$PATCH_DIR/$_");
     
            & download_a_patch($h, $_);
            $dict->{DOWNLOAD_PATCHES}->{$_} = 1;
     
        }
    }
    # Finally, get all the patches that now exist in $PATCH_DIR 
    unless (opendir (PD, "$PATCH_DIR") )  {
        log_it("! ".(localtime).": Couldn't open $PATCH_DIR\n"); 
        return undef;
    }
     
    while ($_ = readdir (PD)) {
        next if ($_ !~ /\d{6}-\d{2}/);
        $dict->{LOCAL_PATCHES}->{$_} =1;
    }
    close (PD); 
     
    my @dp =keys %{$dict->{DOWNLOAD_PATCHES}}; 
    if (defined (@dp)) {
         my $dp = join (" ", sort (@dp));
         log_it("> ".(localtime)." Downloaded patches $dp\n");
    } else { 
         log_it("> ".(localtime)." No patches needed from the net\n");
    }
     
}
     
     
     
     
sub get_rec_patches ($$) {
# This creates a hash with the current recommended patches from Sunsolve 
     
    my $dict  = shift;
    my $os  = shift;
     
    my $ua = new LWP::UserAgent;
     
    # This is the basic sunsolve ftp site 
    my $req = new HTTP::Request 'GET',
"ftp://sunsolve.Sun.COM/pub/patches/${os}_Recommended.README";
     
    #get the page...
    my $res = $ua->request($req);
     
    # ...and strip out the patch information 
    foreach ( split (/\n/, $res->content )) {
         $dict->{REC}->{$os}->{$1} = $_  if (/^(\d{6}-\d{2})/); 
    }
     
    log_it ("> ".(localtime)." Recommended patches for Solaris $os are ". 
         join (" ", sort (keys(%{   $dict->{REC}->{$os}  }))) . "\n");
}
     
     
     
sub log_it {
     
    open (LOG, ">>$PATCH_LOG");
       print LOG shift;
    close LOG;
}
     
     
     
sub download_a_patch ($$) {
     
    my ($host, $patch) = @_;
     
    my $req = new HTTP::Request 'GET', 
         "http://sunsolve.Sun.COM:80/private-cgi/senddoc?/${patch}.tar.Z";
     
    $req->authorization_basic( "$SUNSOLVE_LOGIN","$SUNSOLVE_PASSWD");
     
    my $ua = new LWP::UserAgent;
     
    my $res = $ua->request ($req, "$PATCH_DIR/${patch}.tar.Z");
     
    if ($res->is_success) {
        # now  uncompress and untar this patch
        `/bin/uncompress -c $PATCH_DIR/${patch}.tar.Z | (cd $PATCH_DIR;
/usr/local/gnu/bin/tar xf -)`;
        # now remove the patch tar file
        unlink "$PATCH_DIR/${patch}.tar.Z";
    } else {
        log_it("! ".(localtime).": download of $patch into $PATCH_DIR
FAILED\n");
    }
     
}
     
sub log_instructions ($) {
     
    my $patch = shift;
     
    chdir "$PATCH_DIR/$patch";
     
    if ( open (RM, "$PATCH_DIR/$patch/README.$patch") )  {
        undef $/;
          my $inst = (split (/\nSpecial\s+Install\s+Instructions:\s*-*/io, <RM>,
2))[1];
        $/ = "\n";
        chop ($inst);
        # indent it a bit, for clarity
        $inst =~ s/\n/\n /g;
        log_it("Instructions for $patch:$inst\n");
     
    } else {
        log_it("! ERROR couldn't open  $PATCH_DIR/$patch/README.$patch to get
instructions\n");
    }
     
}
     
sub summarize ($) {
     
    my $dict = shift;
    my $pfh =  $dict->{PATCH_FREE_HOSTS};
     
    foreach (keys %{$pfh}) {
        delete ($pfh ->{$_}) if ($pfh->{$_} == 0);
    }
     
    my @npf = sort (keys %{$pfh});
     
    if (defined @npf) {
        log_it ("> ".(localtime).": No patches needed for ". 
              join (" ", @npf) . "\n");
    }
}
     
sub clean_up ($) {
    my  $dict = shift;
     
    foreach (keys %{$dict->{LOCAL_PATCHES}}) {
       next if (exists $dict ->{USED_PATCHES} ->{$_});
     
       `/bin/rm -rf $PATCH_DIR/$_ 2>&1`;
       log_it ("> ".(localtime).
           ": Removed patch directory $PATCH_DIR/$_\n");
    }
     
     
}
     
     
     
=head1 NAME
     
Spatchula - Patch a Solaris LAN via a perl script 
     
=head1 SYNOPSIS
     
Spatchula
     
=head1 DESCRIPTION
     
This script transparently patches a Solaris 2.x LAN, which is described in 
a simple data structure at the beginning of the script.  It compares
the recommended patches obtained from the SunSolve site 
http://Sunsolve.sun.com to patches on each LAN host, and downloads/installs 
any patches which aren't there.
     
The script logs useful information (patches it has to download, and 
so on).
     
=head1 SETUP/INSTALLATION
     
We assume you have a working perl 5 (at least patch level 2) on your system. 
Use 'perl C<-v>' to check your version.  Some sites call perl 5 'perl5'.
You will, of course, have to change the first line of the script 
to the location of your version of perl 5.
     
This script also uses the excellent and freely-available LWP extension for 
http and ftp negotiation.  To see if you have installed it, try (among other 
things)
     
 'echo use LWP | perl '
     
If there's an error, you need to install the LWP module.   Get it from 
your nearest CPAN site; if you don't know what a CPAN site is, see
the perl homepage http://perl.com/, or more specifically, 
http://perl.com/perl/info/cool_modules.html/
     
     
To use Spatchula, you need to first define  the hosts you wish to patch. 
We define  this information in a data structure at the beginning, via
     
 my @patch_parameters = ( ['ALL_HOSTS', ': : '       ],
                          ['snapper',   '2.5.1 : C<-d>:'],
                          ['trout',     '2.5.1 :    :'],
                          ['sturgeon',  '2.5   :    :'],
                        );
     
(an array of array references, for those who know perl).
This defines a patch suite for three hosts: snapper, trout and sturgeon, 
Associated with each host is an action string
     
  'osC<-v>ersion : arguments_to_installpatch : patches_to_skip'
     
The osC<-v>ersion is the version this host is running; we could 
get this information from uname, but since it is fairly static, we 
require it explicitly.
     
Arguments_to_installpatch list arguments, if any, to be passed to 
./installpatch  for the indicated host.   Above we have passed 
the "C<-d>" switch  to snapper, which prevents installpatch from 
saving old versions of patched files. This prevents the "backing
out" of patches so installed.  One might do this if one was running 
out of local disk space in /var (which is where patch data is stored, 
by default).
     
Finally, patches_to_skip lists patches to be omitted from installation, even 
if they are recommended.   One might need this if the patch patches a 
nonexistent package on your system.
     
ALL_HOSTS  applies to every host.  To skip patch 103683-01 on each host 
(for example), you could add this patch id to ALL_HOSTs id string.
     
We will see examples of these various options in the Examples below.
     
Next, we define the location of our NFS-mounted patch directory, our 
log file, and our Sunsolve login and password (in plaintext)
     
    my $PATCH_LOG = "/spare/patches/scripts/patch_log"; 
    my $PATCH_DIR = "/spare/patches";
    my $SUNSOLVE_LOGIN =  '';  # supply your own 
                               # Sunsolve login
    my $SUNSOLVE_PASSWD = ''; # supply your own 
                              # SunSolve passwd
     
Finally, be sure the "serving" host (the host you are running the 
script from) appears in each "client" hosts's /.rhost; more generally,
be sure the "serving" host appears in each "client" host's /etc/hosts.equiv. 
This is so Spatchula can rsh to each host to execute installpatch.
     
=head1 BUGS
     
This script does not currently handle patch clusters or negotiate through 
firewalls.  It would be very easy to incorporate these changes however; 
if there is any interest out there I'd be happy to do it...
     
=head1 SEE ALSO
     
A Sys Admin article in March or April 1997
     
=head1 AUTHOR
     
 Wayne Wonchoba
 choba@mudpuppie.com
 http://www.mudpuppie.com
     
=cut
     
