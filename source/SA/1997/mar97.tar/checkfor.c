/****************************************************************/
/*	checkfor.c						*/
/*	written by B. Schaffer					*/
/****************************************************************/
/*	A utility to trace out email forwarding.		*/
/*	There is no warranty, expressed or implied.		*/
/*	Use at your own risk.					*/
/****************************************************************/

/****************************************************************/
/* Defines the maximum size of the buffers.			*/
/****************************************************************/
#define OURHOSTNAME	"machine"	/* Need to specify what machine you are */
#define	MAXBUF		1024		/* Input buffer */
#define MAXHIST		50		/* History buffer */

/****************************************************************/
/* Get the header files that we need.				*/ 
/****************************************************************/
#include <sys/socket.h>	
#include <netdb.h>
#include <netinet/in.h>
#include <signal.h>
#include <setjmp.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/****************************************************************/
/* Our function prototypes.					*/
/****************************************************************/
int	open_sock	(char *,char *);
int	responses	(int, char *);
void	alarmclk	(void);
int	mysizeof	(char *);
void	parse_names	(char *, char *, char *);
void	check		(char *, char *);
int	dup		(char *, char *);
void	add		(char *, char *);
void	flush_hist	(void);

/****************************************************************/
/* Our global variable definitions.				*/
/****************************************************************/
jmp_buf	sjbuf;			/* Return from event location */
int	sk;
int	results;		/* Gets the result of an SMTP command */
char	buf[50];		/* Scratch buffer space for messages */
char	c,cn;
int	logging;
char	dest[50],username[20];
int	ok;
char	parsem;
int	depth;
char	dupptr;
char	ulist[MAXHIST][20];
char	hlist[MAXHIST][50];
int 	np;

/****************************************************************/
/* The main procedure.  Gets things rolling.			*/
/****************************************************************/
main(int argc, char *argv[]) {
   char *uptr,*hptr,ch;
   char udat[20],hdat[50];
   if (argc<=1) {				/* Don't know what they want */
      printf("\ncheckfor - trace email forwarding\n");
      printf("\t-h\tdisplays this help message.\n");
      printf("\t-s\tread from standard input.\n");
      printf("\t-f\tparse a data file.\n");
      printf("otherwise:\n\tcheckfor username@hostname\n");
      }
   else if (strncmp(argv[1],"-h",2)==0) {	/* A plea for help */
      printf("\ncheckfor - trace email forwarding\n");
      printf("\t-h\tdisplays this help message.\n");
      printf("\t-s\tread from standard input.\n");
      printf("\t-f\tparse a data file.\n");
      printf("otherwise:\n\tcheckfor username@hostname\n");
      }
   else if (strncmp(argv[1],"-s",2)==0) {	/* Standard input stream */
      while ((ch=getchar())!=EOF) {		/* Read until close of standard input */
         uptr=udat;				/* Init username field */
         hptr=hdat;				/* Init hostname field */
         while (((ch==' ')||(ch==13)||(ch==10))&&(ch!=EOF)) {
            ch=getchar();			/* Skip any leading whitespace */
            }
         while ((ch!=' ')&&(ch!=13)&&(ch!=10)&&(ch!=EOF)) {
            *uptr++=ch;				/* Get the username */
            ch=getchar();
            }
         *uptr++=0;
         while (((ch==' ')||(ch==13)||(ch==10))&&(ch!=EOF)) {
            ch=getchar();			/* Skip any middle whitespace */
            }
         while ((ch!=' ')&&(ch!=13)&&(ch!=10)&&(ch!=EOF)) {
            *hptr++=ch;				/* Get the hostname */
            ch=getchar();
            }
         *hptr++=0;
         if (hdat[0]==0) {			/* If no hostname */
            strcpy(hdat,"localhost");		/* User localhost */
            }
         depth=0;				/* Init tree depth counter */
         dupptr=0;
         flush_hist();				/* Flush the history log for new user */
         if (udat[0]!=0) {			/* If we actually have a username */
            printf("\n\n%s@%s   ",udat,hdat);
            check(hdat,udat);			/* Check it */
            }
         }
      }
   else {					/* User and host on command line */
      depth=0;
      dupptr=0;
      uptr=argv[1];				/* Point to username on command line */
      hptr=argv[2];				/* Point to hostname on command line */
      printf("\n%s@%s   ",uptr,hptr);
      if (hptr!=NULL) {				/* If a hostname was specified */
         check(hptr,uptr);			/* Check them */
         }
      else {					/* No hostname specified */
         check("localhost",uptr);		/* Check them on localhost */
         }
      }
   printf("\n\nFinished.\n");
   }

/****************************************************************/
/* Checks to see if username/hostname pair is already in log.	*/
/****************************************************************/
int dup (char *hostname, char *username) {
   char ptr;
   for (ptr=0;ptr<dupptr;ptr++) {
      if ((strcmp(ulist[ptr],username)==0)&&(strcmp(hlist[ptr],hostname)==0)) {
         return(0);
         }
      }
   return(1);
   }

/****************************************************************/
/* Adds a new username/hostname pair to the history log.	*/
/****************************************************************/
void add (char *hostname, char *username) {
   strcpy(ulist[dupptr],username);		/* Put username in */
   strcpy(hlist[dupptr],hostname);		/* Put hostname in */
   dupptr++;					/* Increment pointer */
   }

/****************************************************************/
/* Talks to remote machine and finds out SMTP info.		*/
/****************************************************************/
void check(char *dest, char *username) {
   char	inpbuf[MAXBUF];
   if (strlen(dest)!=0) {			/* Make sure a destination was specified */
      cn=0;					
      depth++;					/* Increment our tree depth */
      parsem=0;
      ok=0;
      sk=open_sock(dest,"25");			/* Open socket to remote machine */
      if (sk!=0) {				/* If successful */
         results=responses(30,inpbuf);		/* Wait for SMTP to identify itself */
         if (results==220) {			/* If ok */
            sprintf(buf,"HELO %s\n",OURHOSTNAME);
            write(sk,buf,mysizeof(buf));	/* Identify ourselves to remote machine */
            results=responses(5,inpbuf);	/* Wait for response */
            if (results==250) {			/* If ok */
               sprintf(buf,"EXPN %s\n",username);
               write(sk,buf,mysizeof(buf));	/* Ask about user */
               results=responses(5,inpbuf);
               if (results==250) {		/* If we got an answer */
                  parsem=1;			/* Set flag to parse response */
                  }
               else if (results==252) {		/* Got an Ultrix machine */
                  sprintf(buf,"VRFY %s\n",username);
                  write(sk,buf,mysizeof(buf));	/* Ask about user */
                  results=responses(5,inpbuf);
                  if (results==250) {		/* If we got an answer */
                     parsem=1;			/* Set flag to parse response */
                     }
                  else if (results==550) {	/* Nobody here by that name */
                     printf("Username unknown.",username,dest);
                     }
                  }
               else if (results==550) {		/* Nobody here by that name */
                  printf("Username unknown.",username,dest);
                  }
               }
            }
         write(sk,"QUIT\n",5);			/* Disconnect politely */
         results=responses(5,buf);
         close(sk);				/* Close the socket */
         }
      }
   if (parsem!=0) {				/* Parsing flag is set */
      parse_names(dest,username,inpbuf);	/* Look at spooled data for user info */
      }
   depth--;					/* Decrement tree depth by one */
   }

/****************************************************************/
/* Pulls usernames out of the returned data.			*/
/****************************************************************/
void parse_names(char *dest, char *username, char *inpbuf) {
   char *pt;
   char usernew[20],hostnew[50];
   pt=inpbuf;					/* Point to input buffer */
   while (*pt!=0) {				/* Scan till end of buffer */
      if (*pt=='<') {				/* Start of user's mail address */
         pt++;
         np=0;
         while ((*pt!='@')&&(*pt!='>')) {
            usernew[np++]=*pt++;		/* This is the new username */
            }
         usernew[np++]=0;			/* Terminate the username */
         if (*pt=='@') {			/* Is a hostname following? */
            pt++;				/* Yup, get it */
            np=0;
            while (*pt!='>') {
               hostnew[np++]=*pt++;		/* This is the new hostname */
               }
            hostnew[np++]=0;			/* Terminate the hostname */
            }
         else {					/* No hostname followed username */
            strcpy(hostnew,dest);		/* Assume it is same as machine we're talking to */
            }
         if ((strcmp(dest,hostnew)==0)&&(strcmp(username,usernew)==0)) {
            if (depth==1) {			/* Same as user and machine we're talking to */
               printf("  No forwarding.");	/* But is first machine we asked */
               }
            else {				/* Not first machine we asked */
               printf("End of forwarding chain.");	/* Host returned its own name */
               }
            }
         else if (dup(hostnew,usernew)==0) {	/* Is name/host pair a duplicate */
            printf("\n");			/* Yup */
            for (np=0;np<(depth-1);np++) {	/* Tab over */
               printf("    ");
               }
            printf("    %s@%s  Duplicate user/hostname combination!",usernew,hostnew);
            }
         else {					/* New user and hostname */
            add(hostnew,usernew);		/* Add user and host to history buffer */
            printf("\n");
            for (np=0;np<(depth-1);np++) {	/* Tab over */
               printf("    ");
               }
            printf("    %s@%s  ",usernew,hostnew); 	/* Tell em about it */
            check(hostnew,usernew);		/* New user/host, check them */
            }
         }
      pt++;					/* Check for more */
      }
   }

/****************************************************************/
/* Handles the locating of a remote host and opens a socket	*/
/****************************************************************/
int open_sock(char *brgv,char *brgw) {
   int s;
   struct	sockaddr_in	sock;
   struct	hostent		*hp;

   if ((s=socket(AF_INET,SOCK_STREAM,0))<0) {		/* Grab a socket */
      printf("Couldn't get a socket.");			/* Oops, didn't work */
      return(0);
      }
   sock.sin_family=AF_INET;				/* Set to Internet format */
   hp=gethostbyname(brgv);				/* Get the IP address of host */
   if (hp==0) {						/* Oops, couldn't find it */
      printf("Couldn't get host by name.");
      return(0);
      }
   memcpy((char *)&sock.sin_addr, (char*)hp->h_addr,hp->h_length);
   sock.sin_port=htons(atoi(brgw));			/* Convert it */
   if (connect(s,(struct sockaddr *)&sock,sizeof(sock))<0) {	/* Connect sockets */
      printf("Couldn't connect socket to port.");	/* Oops, didn't work */
      return(0);
      }
   return(s);						/* Return socket pointer */
   }

/****************************************************************/
/* Spools data returning from a command.			*/
/****************************************************************/
int responses(int timeout, char *inpbuf) {
   char *state;
   char *pt;
   char cx1;
   int	rc;

   if (setjmp(sjbuf)!=0) {			/* Timeout returns to here */
      signal(SIGALRM,SIG_DFL);			/* Reset the alarm signal */
      alarm(0);					/* Clear the alarm timer */
      return(0);				/* Return a dud code */
      }
   signal(SIGALRM,(__sighandler_t)alarmclk);	/* Setup alarm signal to our handler */
   alarm(timeout);				/* Setup alarm timeout */
   state=inpbuf;				/* Init the loop flag */
   pt=inpbuf;					/* Point to the input buffer */
   *pt++=0x0a;					/* Prime it with a line feed */
   while (state==inpbuf) {
      if (read(sk,&cx1,1)>0) {			/* Get a character from the socket */
         *pt=cx1;				/* Store the character in input buffer */
         if ((*pt==' ')&&(*(pt-4)==0x0a)) {	/* Last line begins with <LF>nnn<SP> */
            state=pt;				/* Save our place for finding the return code */
            }
         alarm(timeout);			/* Reset the character timeout */
         pt++;					/* Increment the input buffer pointer */
         }
      }
   while (cx1!=13) {
      read(sk,&cx1,1);				/* Flush until CRLF */
      *pt=cx1;					/* Store the character in the input buffer */
      pt++;					/* Increment the input buffer pointer */
      }
   *pt=0;					/* Mark end of buffer */
   alarm(0);					/* Clear the alarm timer */
   signal(SIGALRM,SIG_DFL);			/* Reset the alarm hander to it's default */
						/* Compute the result code */
   rc=((*(state-3)-0x30)*100)+((*(state-2)-0x30)*10)+(*(state-1)-0x30);
   return(rc);
   }

/****************************************************************/
/* This is called when we have an inactivity timeout.		*/
/****************************************************************/
void alarmclk() {
   longjmp(sjbuf,1);				/* Jump back to top of responses() */
   }

/****************************************************************/
/* A quick routine to determine the length of a string.		*/
/****************************************************************/
int mysizeof(char *p) {
   int q;
   q=0;
   while (*p!=0) {				/* While char not null */
      p++;					/* Increment pointer */
      q++;					/* Increment counter */
      }
   return(q);					/* Return counter */
   }

/****************************************************************/
/* Flushes out the history log for a new user hostname pair.	*/
/****************************************************************/
void flush_hist() {
   char ptr;
   for (ptr=0;ptr<MAXHIST;ptr++) {
      ulist[ptr][0]=0;
      hlist[ptr][0]=0;
      }
   }


