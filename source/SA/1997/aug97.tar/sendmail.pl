#!/usr/bin/perl
#
# sendmailto.pl - A nice WWW front-end for off-line messaging on
# wwwgnats.pl - a WWW interface to the GNATS bug tracking system
# Thanks to Larry Wall, CERN, and NCSA for Perl, WWW, and Mosaic!
#
### Modification log:
# 2/1/95  Dan Kegel        - Split off from wwwgnats.pl
# 3/1/95  Dan Kegel        - Added pr_addr function
# 12/3/97 Luca Salvadori   - Added parametrization for system executables
#                          - Polished html code
#                          - Ported whole stuff to work with NCSA httpd
#                          - Changed domainization from "-domain" to ".domain"
#                            (no reason: just liked it more)
#                          - Only PRs relevant to selected domain are now manage
#                            PRs assigned to other domains' responsibles were
#                            displayed as well: this caused confusion. "Pending"
#                            PRs are displayed in all domains: it's correct,
#                            since no responsible has been defined yet.
#                          - Lists are more readable (titles in bold)
#                          - ">Unformatted:" field now managed
#                          - Old values of textarea fields now displayed and 
#                            editable
#
# Luca Salvadori - LABEN S.p.A. <lsalvadori@batman.laben.it>
#
### End Modification log
#
#
$pathinfo = $ENV{"PATH_INFO"};
@pathlist = split(/\//, $pathinfo);
$prog = shift(@pathlist);
$username = shift(@pathlist);
$eladdress = shift(@pathlist);
 if ($username eq "1") {
	$username = ""
	}
if ($eladdress eq "1") {
	$eladdress = ""
	}
$tomail = shift(@pathlist);
$subject =join("/",@pathlist);
# Unescape blanks in $subject
$subject =~ s/\+/ /g;
$path = join("/", @pathlist);
$nameemail = join("/","",$username,$eladdress);
 
if ($path eq "") {
    $path = "";
} else {
    $path = ("/".$path);
}

require "cgi-lib.pl";
 
&ReadParse;

print "<HTML>\n";
print "<HEAD>\n";
print &PrintHeader;

# Print the document
print <<"EOM";

<TITLE>Mail from the GNATS Problem Report Service</TITLE>
<!-- Changed by: Susana Fernandez, 31-Mar-1995 -->
<!-- Changed by: Maria Paz Alvarez, 7-Aug-1995 -->
<!-- Changed by: Luca Salvadori, 13-Mar-1997 -->

</HEAD>
<BODY>
<H2>Mail from <A HREF="http://consult.cern.ch/writeups/gnats/gnats.html">GNATS</A> Problem Report Service for <A HREF="http://www.laben.it">LABEN S.p.A.</A></H2>
<HR>
<FORM METHOD="POST" ACTION="http://caf70.laben.it/cgi-bin/gnats/mailto.sh">
<INPUT TYPE="text" NAME="from_name" SIZE=25 VALUE=\"$username\" >Your name<BR>
<INPUT TYPE="text" NAME="division" VALUE="LABEN" SIZE=25>Your Division/Group<BR>
<INPUT TYPE="text" NAME="from_mail" SIZE=25 VALUE=\"$eladdress\" >Your e-mail address <BR>
<INPUT TYPE="text" NAME="to_mail" VALUE=\"$tomail\" SIZE=25>To e-mail address <BR>
<INPUT TYPE="text" NAME="subject" VALUE=\"$subject\" SIZE=50>Subject of your mail<BR>
Write your message here: <TEXTAREA NAME="text" ROWS=10 COLS=80></TEXTAREA>
<P>
<INPUT TYPE="submit" VALUE="Send"> <INPUT TYPE="reset" VALUE="Clear">
<HR>
</FORM>
</BODY>

</HTML>


EOM

1;
