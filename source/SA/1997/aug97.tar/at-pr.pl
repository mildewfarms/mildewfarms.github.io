#! /usr/bin/perl
# FILENAME: at-pr.pl
# DESCRIPTION: Perl front-end to standard gnats utilities to remind
#              responsibles of open PRs. Intended to be run by GNATS
#              crontab entry.
#
# USAGE: at-pr.pl
#
# LABEN S.p.A. - 18-mar-1997
#
# HISTORY:
# V1.0 Luca Salvadori 18-mar-1997
# 	- Basic functions and behaviour
#       - Loops over all stored PRs, regardless of domain
#       - Acts on "open", "assigned", "feedback", "suspended" status
#         with relevant timeouts
#
#
########### S U B R O U T I N E S ###########

# Initialization
# Define gnats variables and files. Most are also defined in libgnats.pl,
# but a "require" statement would need some strange setup to avoid silly
# complaints about uninitialized vars, etc.
$GNATS_ROOT = "/usr/local/share/gnats/gnats-db" ;
$GNATS_ADM = "$GNATS_ROOT/gnats-adm" ;
$GNATS_LIB = "/usr/local/lib/gnats" ;
# Index file: most PRs info is stored there
$INDEX = "$GNATS_ADM/index" ;
# GNATS Administrator: he's reminded as well as PRs responsibles
$gnats_admin = "gnats-admin" ;
# Define timeouts for relevant status (in days)
$OPEN_TIMEOUT = 0.5 ;
$ASSIGNED_TIMEOUT = 1 ;
$SUSPENDED_TIMEOUT = 5 ;
$FEEDBACK_TIMEOUT = 0.5 ;
# Define system executables path, just in case
$MAILER = "/usr/sbin/sendmail -oi -t";

####### E N D  O F  S U B R O U T I N E S ######


########### M A I N  P R O G R A M ###########

# Read PRs data from index file
if(!open(INDEX, "$INDEX")) {
	print "Error - Cannot open index file $INDEX.\n";
	die;
}
while(<INDEX>) {
	# Get arguments from each entry
	chop($_);
	($file,$submitter,$responsible,$status,$impact,$priority) = split(/:/,$_);
	($cat,$pr) = split(/\//,$file);
	# Now get fields from PR file
	#
	# Get PR's submitter
	chop($originator = `grep \"^\>Originator:\" $GNATS_ROOT/$file`);
	$originator =~ s/>Originator\:\s*//;
	# Get submitter's e-mail address
	chop($email = `grep \"^Reply-To:\s*\" $GNATS_ROOT/$file`);
	$email =~ s/Reply-To:\s*//;
	# Get PR's status
	chop($state = `grep \">State:\" $GNATS_ROOT/$file`);
	$state =~ s/>State:\s*//;
	# Get PR's title
	chop($synopsis = `grep \">Synopsis:\" $GNATS_ROOT/$file`);
	$synopsis =~ s/>Synopsis:\s*//;
	# Get PR's assigned responsible
	chop($responsible = `grep \">Responsible:\" $GNATS_ROOT/$file`);
	$responsible =~ s/>Responsible:\s*//;
	# Now, act upon PR's status
	# Initialize a flag to send reminder message or not (default no)
	$send_message = 0 ;
	if ($state eq "open") {
	# Check time since PR has been submitted, cut to first decimal
	$age = -M "$GNATS_ROOT/$file" ;
	$age =~ s/\.(\d)\d*$/\.$1/ ;
	# If timeout is over, set variables and flag
	if ($age >= $OPEN_TIMEOUT) {
		$TIMEOUT = $OPEN_TIMEOUT ;
		$send_message = 1 ;
		}
	}

	if ($state eq "assigned") {
	# Check time since last access, cut to first decimal
	$age = -M "$GNATS_ROOT/$file" ;
	$age =~ s/\.(\d)\d*$/\.$1/ ;
	# If timeout is over, set variables and flag
	if ($age >= $ASSIGNED_TIMEOUT) {
		$TIMEOUT = $ASSIGNED_TIMEOUT ;
		$send_message = 1 ;
		}
	}

	if ($state eq "suspended") {
	# Check time since last access, cut to first decimal
	$age = -M "$GNATS_ROOT/$file" ;
	$age =~ s/\.(\d)\d*$/\.$1/ ;
	# If timeout is over, set variables and flag
	if ($age >= $SUSPENDED_TIMEOUT) {
		$TIMEOUT = $SUSPENDED_TIMEOUT ;
		$send_message = 1 ;
		}
	}

	if ($state eq "feedback") {
	# Check time since last access, cut to first decimal
	$age = -M "$GNATS_ROOT/$file" ;
	$age =~ s/\.(\d)\d*$/\.$1/ ;
	# If timeout is over, set variables and flag
	if ($age >= $FEEDBACK_TIMEOUT) {
		$TIMEOUT = $FEEDBACK_TIMEOUT ;
		$send_message = 1 ;
		}
	}
	# If flag is set, send reminder by mail
	if ($send_message) {
		open(MAIL, "|$MAILER") ;
		print MAIL
"To: $gnats_admin,$responsible
Subject: PR# $pr - Still in \"$state\" status
From: at-pr (GNATS Automatic Reminder System)

This is an automated message produced by GNATS System. Don't reply.

WARNING! PR# $pr is still in \"$state\" status after $age days.
Timeout for this status is $TIMEOUT day(s).
Please act to solve the problem.

PR# $pr data follow:
---------------------
Originator:     $originator
E-Mail Address: $email
Synopsis:       $synopsis
Responsible:    $responsible
---------------------
End of data

             GNATS Automatic Reminder System

";
		close(MAIL) ;
	}
}
close(INDEX);
# Happily exit
exit(0);

####### E N D  O F  M A I N  P R O G R A M ######
