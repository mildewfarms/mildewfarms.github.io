#! /bin/bash -
# FILENAME: queue-pr.sh
# DESCRIPTION: Runs queue-pr (standard gnats queue manager) over domainized
#              sites managed by CERN version of wwwgnats. Intended to be
#              run by default gnats user's crontab.
#
# USAGE: queue-pr.sh
#
# LABEN S.p.A. - 14-mar-1997
#
# HISTORY:
# V1.0 Luca Salvadori 14-mar-1997
# 	- Basic functions
#       - Searches for domains defined in default gnats administration dir
#	- Checks for domain locks before firing up
#
# Luca Salvadori - LABEN S.p.A. <lsalvadori@batman.laben.it>
#
########### S U B R O U T I N E S ###########

# Initialization of local variables and other stuff
# Also defined in libgnats.pl
GNATS_ROOT=~gnats
GNATS_ADM=$GNATS_ROOT/gnats-adm
GNATS_QUEUE=$GNATS_ROOT/gnats-queue
QUEUE_PR="/usr/local/lib/gnats/queue-pr --run"
LOCKFILE=$GNATS_ADM/lock.domain
DOMAINS=$GNATS_ADM/domains
CATEGORIES=$GNATS_ADM/categories
EDITORS=$GNATS_ADM/editors
RESPONSIBLE=$GNATS_ADM/responsible
SUBMITTERS=$GNATS_ADM/submitters
TEMP=$GNATS_ROOT/tmp
# End initialization

uncomment ()
{
# Takes out comments from a file. Comments are preceded by "#".
cat $1 | \
sed "s/#.*//" | \
sed "/^$/d"
}

####### E N D  O F  S U B R O U T I N E S ######


########### M A I N  P R O G R A M ###########

# First, move all pending PRs in temporary directory
for file in $GNATS_QUEUE/gnats*
do
	[ -f $file ] && mv $file $TEMP
done

# Loop over defined domains and execute queue-pr after proper environment
# setting, then cleanup and exit.

for domain in `uncomment $DOMAINS`
do
	# Setting up relevant environment by copying domainized files over
	# generic version
	# First, check for domainized files. If something is missing, take
	# another domain.
	if [ -f $CATEGORIES.$domain -a -f $EDITORS.$domain -a -f $RESPONSIBLE.$domain -a -f $SUBMITTERS.$domain ]
	then
		while [ -f $LOCKFILE ]
		do
			sleep 5
		done
		touch $LOCKFILE
		cp $CATEGORIES.$domain $CATEGORIES
		cp $EDITORS.$domain $EDITORS
		cp $RESPONSIBLE.$domain $RESPONSIBLE
		cp $SUBMITTERS.$domain $SUBMITTERS
		# Domain is got from "X-gnats-domain:" field in file header.
		STRING="X-gnats-domain: $domain"
		# If domain is OK, move files back in queue
		for file in $TEMP/gnats*
		do
			if [ `grep -c "$STRING" $file` = "1" ]
			then
				mv $file $GNATS_QUEUE
			fi
		done
		# Now, run GNATS-standard queue-pr on all files in queue.
		$QUEUE_PR
		# Clean up environment
		[ -f $LOCKFILE ] && rm $LOCKFILE
		[ -f $CATEGORIES ] && rm $CATEGORIES
		[ -f $EDITORS ] && rm $EDITORS
		[ -f $RESPONSIBLE ] && rm $RESPONSIBLE
		[ -f $SUBMITTERS ] && rm $SUBMITTERS
	fi
done

# Exit
exit 0
####### E N D  O F  M A I N  P R O G R A M ######
