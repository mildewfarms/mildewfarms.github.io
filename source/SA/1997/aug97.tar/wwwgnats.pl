#!/usr/bin/perl
#
$| = 1;
#
# wwwgnats.pl - a WWW interface to the GNATS bug tracking system
# Thanks to Larry Wall, CERN, and NCSA for Perl, WWW, and Mosaic!
#
### Modification log:
# 2/1/95  Dan Kegel        - Split off from wwwgnats.pl
# 3/1/95  Dan Kegel        - Added pr_addr function
# 12/3/97 Luca Salvadori   - Added parametrization for system executables
#                          - Polished html code
#                          - Ported whole stuff to work with NCSA httpd
#                          - Changed domainization from "-domain" to ".domain"
#                            (no reason: just liked it more)
#                          - Only PRs relevant to selected domain are now managed:
#                            PRs assigned to other domains' responsibles were
#                            displayed as well: this caused confusion. "Pending"
#                            PRs are displayed in all domains: it's correct,
#                            since no responsible has been defined yet.
#                          - Lists are more readable (titles in bold)
#                          - ">Unformatted:" field now managed
#                          - Old values of textarea fields now displayed and 
#                            editable
#
# Luca Salvadori - LABEN S.p.A. <lsalvadori@batman.laben.it>
#
### End Modification log

$pathinfo = $ENV{"PATH_INFO"};
@pathlist = split(/\//, $pathinfo);
$prog = shift(@pathlist);
$domain = shift(@pathlist);
$username = shift(@pathlist);
if ($username eq "") {
    $username = "1";
}
$eladdress = shift(@pathlist);
if ($eladdress eq "") {
    $eladdress = "1";
}
$path = join("/", @pathlist);
$path2 = join("/","",$username,$eladdress);
 
if ($path eq "") {
    $path = "";
} else {

    $path = ("/".$path);
}

$PATH_INFO = $path;

$SCRIPT_NAME = ($ENV{"SCRIPT_NAME"}."/".$domain.$path2);

require "/usr/local/etc/httpd/cgi-bin/gnats/libgnats.pl";
require "cgi-lib.pl";

#### Configuration begins here

# Miscellanous data
$EDITOR_FILE = "$GNATS_ADM/editors.$domain";
$ORIGIN_FILE = $EDITOR_FILE;
$HELP_FILE   = "http://www.laben.it/utilities/help/gnats-help.html";
# Outside commands
$MAILER      = "/usr/lib/sendmail -oi -t";
$DATEPROG    = "/bin/date";
$LSPROG      = "/bin/ls";
$EDIT_PR     = "/cgi-bin/gnats/edit_pr.pl";
### Configuration ends here

### Environment variables
$QUERY_STRING = $ENV{"QUERY_STRING"};
$CONTENT_LENGTH = $ENV{"CONTENT_LENGTH"};
$HTTP_AGENT = $ENV{"HTTP_USER_AGENT"};
$SERVER_NAME = $ENV{"SERVER_NAME"};
$REMOTE_HOST = $ENV{"REMOTE_HOST"};
$REMOTE_IDENT = $ENV{"REMOTE_IDENT"};
$REMOTE_ADDR = $ENV{"REMOTE_ADDR"};
#################### Array definitions
# Query-pr's -i option outputs the following fields numerically.
# Define arrays to map numbers to name.
$validcateg = join("|", @nCategory);
### Arrays for quick output display with restricted output fields
@quickSeverity = ("", "critical", "serious", "noncri");
@quickPriority = ("", "High", "Medium", "Low");
@quickfmt    = ("brief","regular","verbose");
   # The first field is the quickfmt, the second is the field width
%field      = (
		"CATEGORY",     "0:10",
		"RELEASE",      "2:10", # Not displayed
		"SEVERITY",     "4:8",  # Not displayed
		"PRIORITY",     "1:8", 
		"RESPONSIBLE",  "1:8",
		"STATE",        "0:8",
		"CLASS",        "2:8",
		"SUBMITTER",    "2:7", # Not displayed
	        "START_DATE",   "1:15",
		"END_DATE",     "2:15",
		"ARRIVAL_DATE", "1:14",
		"ORIGINATOR",   "1:9",
		"SYNOPSIS",     "0:0",
	     );
   # Defines order of field display in quick output
@field      = (
		"CATEGORY",
		"RELEASE",
		"SEVERITY",
		"PRIORITY",
		"RESPONSIBLE",
		"STATE",
		"CLASS",
	        "START_DATE",
                "END_DATE",
		"SUBMITTER",
		"ARRIVAL_DATE",
		"ORIGINATOR",
		"SYNOPSIS",
	     );

# Arrays for quick output of PR's with restricted characteristics
# The first field is the restriction, the second field is the default option
%quickrestr = (
                "Category",    "any",
		"State",       "any",
		"Responsible", "any",
		"Originator",  "any",
	    );
# Defines order of quick output restrictions, originally was also 
# the Originator field
@quickrestr = (
                "Category",
		"State",
		"Responsible",
	    );

# month array for change_date procedure
%montharray = (
	       "Jan", 1,
	       "Feb", 2,
	       "Mar", 3,
	       "Apr", 4,
	       "May", 5,
	       "Jun", 6,
	       "Jul", 7,
	       "Aug", 8,
	       "Sep", 9,
	       "Oct", 10,
	       "Nov", 11,
	       "Dec", 12,
	        1, "Jan",
	        2, "Feb",
	        3, "Mar", 
	        4, "Apr",
	        5, "May",
	        6, "Jun",
	        7, "Jul",
	        8, "Aug",
	        9, "Sep",
	        10, "Oct",
	        11, "Nov",
	        12, "Dec",
	       );


#################### Main routine
# Main Program
# Initialization
print "Content-type: text/html\n\n";
print "<HTML>\n";

&read_originator;
&read_editor;

### Submit a new PR
if ($PATH_INFO =~ m,^/send_pr,) {
    &send_pr();
} elsif ($PATH_INFO =~ m,^/handle_send_pr,) {
    &handle_send_pr();

### Edit an existing PR

} elsif ($PATH_INFO =~ m,^/handle_edit_pr/,) {
    if ($PATH_INFO =~ m,^/handle_edit_pr/(\d+)&([^&]+)&([^&]+)$,) {
	&handle_edit_pr($1, $2, $3);
    } else {
	print "Bad args for handle_edit_pr!\n";
	print "Args are $PATH_INFO.\n";
	if ($PATH_INFO =~ m,^/handle_edit_pr/(\d+)&,) {
	    print "Doesn't have digits&\n";
	}
	if ($PATH_INFO =~ m,^/handle_edit_pr/(\d+)&([^&]+)&,) {
	    print "Doesn't have digits&stuff\n";
	}
    }

### Display the entire PR
} elsif ($PATH_INFO =~ m,^/full,) {
    local($subdir);
    $subdir = $PATH_INFO;
    if ($subdir =~ m,^/full/(\d+),) {  # Called from quick query
        &query_full($1);
    } else {
	$QUERY_STRING =~ m,^pr=(\w+)$,;
	&query_full($1);
    }

### Query a number of PR's and display in quick output form
} elsif ($PATH_INFO =~ m,^/quick,) {
    # Get arg of quickfmt=
    $QUERY_STRING =~ m,^quickfmt=(\w+)&.*&Date=([^&]*)&,;
    $QUICKFMT = $1;
    $DATEVALUE=$2;
    if ($DATEVALUE eq "last+week") {
        $do_listing=1;
    }    
    if ($QUERY_STRING =~ m,date_start=([^&]*)&date_end=(.*),) {
	$DATEVALUE="manual+input+done";
	$do_listing=1;
	$DATESTART=$1;
	$DATEEND=$2;
	$QUERY_STRING =~ s/date_start=([^&]*)&date_end=(.*)//;
    }
    &change_date;
    $QUERY_STRING =~ s/&Date=([^&]*)&/&Date=$DATEVALUE&/;
    # Get all restrictions.  First, strip off quickfmt prefix.
    ($RESTR = $QUERY_STRING) =~ s/^quickfmt=\w+&//;
    # Then, split into words.
    @RESTR=split(/&/,$RESTR);
    &query_quick($QUICKFMT,@RESTR);

### Get count of pending bugs by category
} elsif ($PATH_INFO =~ m,^/summary_cat,) {

    &query_summary_cat();

### Get count of pending bugs by person
} elsif ($PATH_INFO =~ m,^/summary,) {

    &query_summary();
### Get custom summary
} elsif ($PATH_INFO =~ m,^/custom_sum,) {

    &custom_sum();

### Report generation
} elsif ($PATH_INFO =~ m,^/report,) {

    &report();

### Main menu
} elsif ($PATH_INFO eq "") {
    &main_menu();
    print"<HR>\n";
    print"Original Version: 15 Mar 95<BR>Authors: <A HREF=\"http://alumni.caltech.edu/~dank\">Dan Kegel</A> (dank\@alumni.caltech.edu) & Huy Le (huyle\@alumni.caltech.edu)<BR>\n";
    print"Production Version: 20 Mar 97<BR>Author: <A HREF=\"mailto:lsalvadori\@batman.laben.it\">Luca Salvadori</A> - <A HREF=\"http://www.laben.it/\">LABEN S.p.A.</A><HR>\n";
  
} else {
    print "<HEAD><TITLE>LABEN S.p.A. Help Desk</TITLE></HEAD>
<H1>LABEN S.p.A. Help Desk</H1>
<BODY>
";
   print "Bad subdirectory/parameters specified in URL.\n";
}


print "\n</BODY>\n";
print "</HTML>\n";
exit(0);

#################### Main routine - END

#################### PR submission

# Sends the new PR
sub handle_send_pr {   
    # Display title
#    print &PrintHeader();
    print "<HEAD><TITLE>New Problem Report Submission</TITLE></HEAD>
<BODY>
";
   
# Get arguments
    local($_)=scalar($ENV{"QUERY_STRING"});
    chop; s/\r$//;
    local($i,%input);
    undef(%fieldvalues);	# Global!
    foreach (split(/&/)) {
        ++$i;
        local($key,$value)=split(/=/);
	$value = &cgi_trans($value);
	# By convention, multi-line fields have newlines at end of
	# each line.  I think some browsers forget the last newline?
	if ($fieldnames_multi{$key} > 0 && $value !~ /\n$/) {
	    $value .= "\n"; 
	    
	}
       
       # $fieldvalues{$key}=$value;
	# Begin parsing
	if ($fieldnames_multi{$key} > 0) {
	    &format_sixty($value);
	}
	# End parsing
	$fieldvalues{$key}=$value;
    }

    # Verify arguments
    local($field);
    foreach $field ("Originator", "Category", "Release", "Synopsis", "Environment", "Description" ) {
	if ($fieldvalues{$field} eq "") {
	    print "<H3>Your problem report has not been sent.</H3>\n";
	    print "You must select/fill  $field.\n";
	    return;
	}
       
    }

    # kludge
    $fieldvalues{"Confidential"} = "no";
    # megakludge.
    $fieldvalues{"Submitter-Id"} = $fieldvalues{"Organization"};
    if ($fieldvalues{"Organization"} eq "LABEN") {
	$fieldvalues{"Submitter-Id"} = "laben.it";
	 }
    # Send the PR
    $prtext = &unparse_pr("send");
   
    open(MAIL, "|$MAILER") || die "Error while invoking sendmail";
    print MAIL
"To: $GNATS_ADDR
Subject: $fieldvalues{\"Synopsis\"}
From: $fieldvalues{\"Email\"} ($fieldvalues{\"Originator\"})
Reply-To: $fieldvalues{\"Email\"}
X-send-pr-version: $GNATS_VER
X-gnats-domain: $domain

$prtext";
    close(MAIL);
    print "<H3>Your problem report has been queued.</H3> It will take about 10 minutes to show up in the system.
You will be notified by e-mail as soon as PR is assigned to the relevant people
and anytime any progress towards resolution occurs.<BR>Thanks for your cooperation.\n";
    
}
1;



####################################
# Sends the PR changes
sub handle_edit_pr  {
# Display title
    print "<HEAD><TITLE>Problem Report Editing</TITLE></HEAD>
<BODY>
";
    # Initialization
    # Set environment for pr_edit, since it won't be joked by domainized files
    &set_gnats_env($domain) ;
    $errmsg="<H3>Your problem report changes have not been sent.</H3>\n";

    # Get the PR, editor, old state, and timestamp
    local($pr, $oldstate, $timestamp) = @_;

    # Get arguments
    local($_)=scalar(<STDIN>);
   
  
    chop; s/\r$//;
    local($i,%input);
    foreach (split(/&/)) {
        ++$i;
        local($key,$value)=split(/=/);
        $input{$key}=&cgi_trans($value);
       
    
    #in multiline fields get append newline at the end, for response and how-to-repeat
    # By convention, multi-line fields have newlines at end of
	# each line.  I think some browsers forget the last newline?
	if ($fieldnames_multi{$key} > 0 && $value !~ /\n$/) {
	    $input{$key} .= "\n";
	}

# Begin parsing
	if ($fieldnames_multi{$key}>0) {
	    &format_sixty($input{$key});
	}
# End parsing

    # end of newline append
   } 
    # Verify arguments
    if (!$input{"Editor"}) {
       print $errmsg, "You must register your name in \"Editor:\" field.\n";
       # Reset to standard, domainized environment
       &unset_gnats_env;
       die;
    }
     
    if (!$nEditor{$input{'Editor'}}) {
    print "<HEAD><TITLE>Problem Report Editing</TITLE></HEAD>
<BODY>
";
      
	print $errmsg, "Sorry, <B><I>$input{'Editor'}</I></B>. You're not registered as PR editor.\n";
	# Reset to standard, domainized environment
  	&unset_gnats_env;
	die;
    }
    # Lock and read the PR into @oldpr and %fieldvalues\"submit\"
    # Also sets $semipr and $fullpr
    $err = &read_pr($pr, $input{"Editor"});
    if ($err ne "") {
	print $errmsg, $err;
 	# Reset to standard, domainized environment
  	&unset_gnats_env;
	die;
    }
    local($oldsyn) = $fieldvalues{"Synopsis"};
    local($oldresp) = $fieldvalues{"Responsible"};
    local($startdate) = $fieldvalues{"Start-Date"};
    local($enddate) = $fieldvalues{"End-Date"};
    # Kludge to allow editing of Response and How-To-Repeat fields
    local($oldfix) =  $fieldvalues{"Response"};
    local($oldhowtorepeat) = $fieldvalues{"How-To-Repeat"};
    # Get old ">Unformatted:" field. L.Salv. 20-mar-1997
    local($oldunformatted) = $fieldvalues{"Unformatted"};
    # end of kludge
    #
    $oldresp =~ s/\s*\(.*$//; # Get rid of comment in responsible party name
    local($reply_to) = $fieldvalues{"Reply-To"};
    if ($reply_to eq "") {
	# "Reply-To:" takes precedence over "From:".
	$reply_to = $fieldvalues{"From"};
    }

    local($ed_err);
    local(%mail_to);
    local($change_msg) = "***********************************************\n";
    LOCKED: {
	# Now that pr has been locked, if any errors are encountered,
	# set $ed_err to the reason and jump to UNLOCK.

	# Check that the timestamp hasn't changed since the form was generated
	if ($timestamp ne &timestamp($fullpr)) {
	    $ed_err = "$errmsg\nThis PR has been modified since you started editing it.\n";
	    last LOCKED;
	}

	# Another sanity check
	if ($reply_to eq "" || $oldresp eq "") {
	    $ed_err = "$errmsg\nHey!  Old responsible is '$oldresp', reply address on pr is '$reply_to'!\n";
	    last LOCKED;
	}

	# Get the date
	local($date);
	if (!open(DATE, "$DATEPROG|")) {
	    $ed_err = "$errmsg\nError: can't run $DATEPROG";
	    last LOCKED;
	}
	chop($date=<DATE>);
	close(DATE);

	$mail_to{&tolower($nEditor{$input{'Editor'}})} = 1;
	local($to_subm, $to_old, $to_new);
	$responsible = $input{'Responsible'};
		$resp_fullname = &read_resp_fullname($responsible);

	# Update the audit trail
	if ($input{"State"} ne $fieldvalues{'State'}) {
	   
# if status changes from open to assigned but the resp is the same 
# notify it to the user
	    if ($input{'State'} eq "assigned" && $fieldvalues{'State'} eq "open") {
       	if ($input{'StateReason'} eq "") {
		$input{'StateReason'} .= "The responsible assigned  is  $resp_fullname";
	    }
    }
# end of test    

	    $change_msg .= "State-Changed-From-To: $fieldvalues{'State'}-$input{'State'}
State-Changed-By: $input{'Editor'}
State-Changed-When: $date
State-Changed-Why: $input{'StateReason'}    
";
	    $to_subm = 1;
	    $fieldvalues{'State'} = $input{'State'};
	}

	if ($input{'Responsible'} ne $oldresp) {
	    if ($input{'ResponsibleReason'} eq "") {
		$ed_err = "$errmsg\nYou must tell why the Responsible person changed.\n";
		last LOCKED;
	    }
# Kludge if status changed from open to assigned & resp is assigned then notify
	    if ($input{'State'} eq "assigned" && $oldstate eq "open") {
		$change_msg .= "Responsible-Assigned: $resp_fullname\n";
	    }
	    else {
		$change_msg .= "Responsible-Changed-From-To: $fieldvalues{'Responsible'}-$input{'Responsible'} ($resp_fullname)\n";
	    }
	    
$change_msg .= "Responsible-Changed-By: $input{'Editor'}
Responsible-Changed-When: $date
";
# end of kludge
	   $to_subm = $to_old = $to_new = 1;
	    $fieldvalues{'Responsible'} = $input{'Responsible'}." (".$resp_fullname.")";
	}


#my little kludge: first I check if a category from other domain has been
#chosen
     if (!open(DOMAIN, "$GNATS_ADM/domains")) {
		print "Couln't get domains file $GNATS_ADM/domains\n";
		# Reset to standard, domainized environment
		&unset_gnats_env ;
		die;
	};
    while (<DOMAIN>) {
       if (!/^\s*#|^\s*\n$|^#.$/) {
            $_ =~ s/^/-/;
            $_ =~ s/#.*$//;
	    push(@nDomain, $_);
	}
    }
    close(DOMAIN);
    @nDomain = sort(@nDomain);
	$modified=0;
	$i=1;
	$chdomain=0;
	foreach $domi (@nDomain) {
	    if ($i>0) { chop ($domi);}
	    $i++;
	$estrin="Category".$domi;
	    if ($input{$estrin}) {
		$modified++;
		$newdomain=$domi;
		#in newdomain I keep the new domain of the pr, it will only
		#be valuable if only 1 domain has been chosen (error otherwise)
	    }
	}
	if ($modified>1) {
	    print "<H1>Error! You've moved the PR to more than 1 domain!</H1>";
	    system("$PR_EDIT --unlock $semipr");
	    print "</HTML>";
	    # Reset to standard, domainized environment
	    &unset_gnats_env;
	    exit(0);
	}
	if ($modified>0) {
	    $oldomain=$domain;    # We keep the old domain 
	    $oldomain=~ s/^-//;   # Remove the dash
	    $newdomain =~ s/^-//; # Remove the dash . Jesus 6/12/96.
	    $domain = $newdomain; # Replace domain with the new value
	    print "<H1>You've moved PR to domain: $newdomain.</H1>";
	    $estrin="Category".$domain;
	    # Add dash back. Not so elegant...
	    $estrin=~ s/^Category/Category-/;
	    # Change of domain
	    $input{"Category"}=$input{$estrin};
	    print "<h2>New category: $input{$estrin}</h2>";
	    # The problem is not marked as moved, we just change the category.
	    # Jesus 6/12/96.
	    print "<P>This problem report has be marked as <EM>moved</EM> and submitted to the new responsibles.<P>";

	    $change_msg.="Domain changed from: $oldomain to: $newdomain\n";

	}
#

#end of my little kludge, but in fact this if which comes next should be 
#executed only if there hasn't been a change of domain.


	if ($input{"Category"} ne $fieldvalues{"Category"}) {
	    # Gnats' original edit-pr command didn't generate an audit
	    # trail for this change
	    # Note: category names might have dashes in them, making
	    # the following line hard to parse!

# if the category is changed then the responsible should be reassigned

if(!open(CATEG, "$GNATS_ADM/categories.$domain")) {
	# Reset to standard, domainized environment
	&unset_gnats_env;
	print "Couln't get categories file $GNATS_ADM/categories.$domain\n";
	die;
	}
    while (<CATEG>) {
	if (!/^\s*#|^\s*\n$/) {
	    chop;	
    @nResp = split(/:/, $_);
	    $cat=shift(@nResp);
	    $descr=shift(@nResp);
	    $a=@nResp;
	    if ($cat eq $input{'Category'} ) {
		$fieldvalues{'Responsible'} = shift(@nResp);
		$nresponsible = $fieldvalues{'Responsible'};
		$nresp_fullname = &read_resp_fullname($nresponsible);
				
	    }
	
	}

    }




	    $change_msg .= 
"Category-Changed-From: $fieldvalues{'Category'} To: $input{'Category'}
Category-Changed-By: $input{'Editor'}
Category-Changed-When: $date
\n";

$change_msg .= "Responsible-Changed-From-To: $input{'Responsible'} ($resp_fullname) - $fieldvalues{'Responsible'} ($nresp_fullname)\n";    
$change_msg .= "Responsible-Changed-By: $input{'Editor'}
Responsible-Changed-When: $date
";
if ($modified>0) {  # The reason of the Responsible change could be due to a
		    # change in the domain... Jesus 6/12/96.
$change_msg .= "Responsible-Changed-Why: Due to change in domain from $oldomain to $newdomain
";}
else {		    # ... or a change in the category. Jesus 6/12/96.
$change_msg .= "Responsible-Changed-Why: Due to change in category from $fieldvalues{'Category'} to $input{'Category'}
";}

	    $fieldvalues{'Category'} = $input{'Category'};
            $input{'Responsible'} = $fieldvalues{'Responsible'};
	     $fieldvalues{'Responsible'} .= " (".$nresp_fullname.")";
		$to_subm = $to_old = $to_new = 1;
}


#### Update the start-date and end-date fields if they have changed

if ($input{"Start-Date"} ne $fieldvalues{'Start-Date'}) {
	       
	    $change_msg .= "Start-Date-Changed-From-To: $fieldvalues{'Start-Date'}-$input{'Start-Date'}
State-Changed-By: $input{'Editor'}
State-Changed-When: $date
";
	    #$to_subm = 1;
	    $fieldvalues{'Start-Date'} = $input{'Start-Date'};
	}



if ($input{"End-Date"} ne $fieldvalues{'End-Date'}) {
	       
	    $change_msg .= "End-Date-Changed-From-To: $fieldvalues{'End-Date'}-$input{'End-Date'}
State-Changed-By: $input{'Editor'}
State-Changed-When: $date
";
	    #$to_subm = 1;
	    $fieldvalues{'End-Date'} = $input{'End-Date'};
	}


      # Update the audit trail if Response and How-To-Repeat fields have changed

	while (($input{"Response"}=~/\n$/) || ($input{"Response"}=~/\r$/)){
	    chop($input{"Response"});
	     }

	while (($oldfix=~/\n$/) || ($oldfix=~/\r$/)){
	    chop($oldfix);
	     }
	  
	# To avoid the modification of the Response field if it's empty
	# in the form submitted. Jesus 14/11/96.

	if (($input{"Response"} ne "")&&($input{"Response"} ne $oldfix)) {
	    # Gnats' original edit-pr command didn't generate an audit
	    # trail for this change
	    
	if ($oldfix ne "") { # if the Response field had a value,
$change_msg .=               # the old value and the new one will be 
		             # reflected in the audit-trail. Jesus 4/12/96.
"Response-Changed-From:
 $fieldvalues{\"Response\"}
To:
 $input{\"Response\"}
";}
	else {		     # if the Response field was empty
$change_msg .=               # we only reflect the new value in 
			     # the audit-trail. Jesus 4/12/96.
"Response-Changed-To:
 $input{\"Response\"}
";}

$change_msg .=
"Response-Changed-By: $input{'Editor'}
Response-Changed-When: $date
\n";	    
        $input{"Response"} .= "\n";
	$fieldvalues{'Response'} = $input{'Response'};
	$to_subm = 1; # to inform the submitter when the
		      # Response field is changed but there is
		      # no state change. Jesus 14/11/96.
	}

	$input{"Response"} .= "\n";
	$oldfix .= "\n";

      #  same for the How-To-Repeat field

	# same as for Response

	while (($input{"How-To-Repeat"}=~/\n$/) || ($input{"How-To-Repeat"}=~/\r$/)){
	    chop($input{"How-To-Repeat"});
	     }

	while (($oldhowtorepeat=~/\n$/) || ($oldhowtorepeat=~/\r$/)){
	    chop($oldhowtorepeat);
	     }
	  
	# To avoid the modification of the How-To-Repeat field if it's empty
	# in the form submitted. Jesus 4/12/96.
	if (($input{"How-To-Repeat"} ne "")&&($input{"How-To-Repeat"} ne $oldhowtorepeat)) {
	    # Gnats' original edit-pr command didn't generate an audit
	    # trail for this change
	if ($oldhowtorepeat ne "") { # if the How-To-Repeat field had a value,
	    $change_msg .=           # the old value and the new one will be 
			             # reflected in the audit-trail. Jesus 4/12/96.
	    "How-To-Repeat-Changed-From: 
 $fieldvalues{\"How-To-Repeat\"}
To:
 $input{'How-To-Repeat'}
";}
	else {		               # if the How-To-Repeat field was empty
	  $change_msg .=               # we only reflect the new value in 
			               # the audit-trail. Jesus 4/12/96.
	  "How-To-Repeat-Changed-To:
 $input{\"How-To-Repeat\"}
";}
	  $change_msg .=
"How-To-Repeat-Changed-By: $input{'Editor'}
How-To-Repeat-Changed-When: $date
\n";    

	    $input{"How-To-Repeat"}.="\n";
	    $fieldvalues{'How-To-Repeat'} = $input{'How-To-Repeat'};
	 }
	$input{"How-To-Repeat"}.="\n";
	# end of change

	# Check that changes were actually made
	if ($change_msg eq "") {
	    $ed_err = "$errmsg\nNothing was changed.\n";
	    last LOCKED;
	}
	# Add the change log to the PR
	$fieldvalues{'Audit-Trail'} .= $change_msg;

	# My kludge. Now ">Unformatted:" field is managed as well.
	# Same as for Response. L.Salv. 20-mar-1997

	while (($input{"Unformatted"}=~/\n$/) || ($input{"Unformatted"}=~/\r$/)){
	    chop($input{"Unformatted"});
	     }

	while (($oldunformatted=~/\n$/) || ($oldunformatted=~/\r$/)){
	    chop($oldunformatted);
	     }
	# Since unformatted field is not traced in audit trail, just check
	# if it changed and write it back, appending to previous text.
	if (($input{"Unformatted"} ne "")&&($input{"Unformatted"} ne $oldunformatted)) {
		$input{"Unformatted"}.="\n";
		$input{"Unformatted"} =~ s/^$oldunformatted\n+//;
		$fieldvalues{'Unformatted'} .= $input{'Unformatted'};
	}
	# End of kludge. L.Salv. 20-mar-1997

	# Generate the mailing list
	if ($to_subm) {
	    $mail_to{&tolower($reply_to)} = 1;
	}
	if ($to_old) {
	    ($adr, $err) = &pr_addr($oldresp);
	    if ($err ne "") {
		$ed_err = "$errmsg\n$err";
		last LOCKED;
	    }
	    $mail_to{&tolower($adr)} = 1;
	}
	if ($to_new) {
	    ($adr, $err) = &pr_addr($input{'Responsible'});
	    if ($err ne "") {
		$ed_err = "$errmsg\n$err";
		last LOCKED;
	    }
	    $mail_to{&tolower($adr)} = 1;
	}

	# Apply the changes and send the new PR
	$newpr = &unparse_pr("");
	unlink("/tmp/wwwgnats.$$");
	if (!open(PREDIT, "|$PR_EDIT > /tmp/wwwgnats.$$ 2>&1")) {
	    $ed_err = "$errmsg\nError: can't invoke pr-edit\n";
	    last LOCKED;
	}
	print PREDIT $newpr;
	close(PREDIT);
	if ($?) {
	    $ed_err = "$errmsg\nError: pr-edit returns status $?, and reports:\n";
	    if (!open(PREDIT, "/tmp/wwwgnats.$$")) {
		$ed_err .= "(whoops, no output from pr-edit found; couldn't open /tmp/wwwgnats.$$)\n";
	    } else {
		$ed_err .= join("\n",<PREDIT>);
		close(PREDIT);
	    }
	    unlink("/tmp/wwwgnats.$$");
	    last LOCKED;
	}
	unlink("/tmp/wwwgnats.$$");
    }

    # UNLOCK - Unlock the PR
    system("$PR_EDIT --unlock $semipr");
    # if we got here via a last, report the error and quit
    if ($ed_err ne "") {
	print "<PRE>";
	print $ed_err;
	print "</PRE>";
	# Reset to standard, domainized environment
	&unset_gnats_env;
	return;
    }

    # Email-notify all concerned parties
    
    local($mail_to);
    $mail_to = join(", ", sort(keys(%mail_to)));

    if ($mail_to ne "") {
	if (open(MAILER, "|$MAILER")) {
	    $msg = 
"To: $mail_to
From: $GNATS_ADDR, $nEditor{$input{'Editor'}}
Subject: $semipr Change Information

Synopsis: $oldsyn

$change_msg
";
	    print MAILER $msg;
	    print MAILER "$mail_to\n";
            sleep 3;
	    close(MAILER);
	    sleep 3;
	    # Display message
	   
  # Display title
    print "<HEAD><TITLE>Problem Report Editing</TITLE></HEAD>
<BODY>
";
print 
"<H3>Your changes to PR $pr were filed to the database.</H3>
The parties concerned were notified via e-mail as follows:
<BR><PRE>$msg</PRE>
";
	} else {
	    print "Error: can't run $MAILER\n";
	}
    }
 

    if ($chdomain>0) {  # We no longer need it, we do not re-submit the problem
			# report. Jesus 6/12/96.

#

	$fieldvalues{'State'}="Open";
	$fieldvalues{'Category'}=$input{$estrin};
	$prtext = &unparse_pr("send");


	@lins=split(/Number:/,$prtext);
	$i=0;
	$prtext="Number:";

	foreach $li (@lins) {
	    if ($i>0) {
		$prtext.=$li;
	    }
	    $i++;
	}


 open(MAIL, "|$MAILER") || die "Error while invoking sendmail";
 print MAIL
"To: $GNATS_ADDR
Subject: $fieldvalues{\"Synopsis\"}
From: $fieldvalues{\"Reply-To\"} ($fieldvalues{\"Originator\"})
Reply-To: $fieldvalues{\"Reply-To\"}
X-send-pr-version: $GNATS_VER

$prtext";
    close(MAIL);


    }
# Reset to standard, domainized environment
&unset_gnats_env;
}

#################### Quick query

sub query_quick {
    # Print title
    print "<HEAD><TITLE>Quick Summary of Problem Reports</TITLE></HEAD>
<H2>Quick Summary of Problem Reports:</H2>
<BODY>
";
    local($quickfmt,@restrict)=@_;

    # Convert $quickfmt to index into @quickfmt
    LOOP: for ($i=0; $i<@quickfmt; $i++) {
	if ($quickfmt eq $quickfmt[$i]) {
	    $quickfmt=$i;
	    last LOOP;
	}
    }
    # Split restrictions into key,value pairs
    # Collapse multiple selections with same key
    # Store collapsed restrictions in %restrict
    local($oldkey, $oldval);
    local(%restrict);
    foreach (@restrict) {
	$_ = &tolower($_);
	$_ = &cgi_trans($_);
	local($key,$val) = split(/=/);
	if ($key ne $oldkey) {
	    if ($oldval ne "") {
		$restrict{$oldkey} = $oldval;
	    }
	    $oldkey = $key;
	    $oldval = "";
	    $oldval = $val if ($val ne "");
	} else {
	    # just continue adding to old restriction
	    $oldval .= "|" if ($oldval ne "");
	    $oldval .= "$val" if ($val ne "");
	}
    }
    # Could have put a sentinel on the end of @restrict, but let's duplicate
    # code instead.
    if ($oldval ne "") {
	$restrict{$oldkey} = $oldval;
    }
   
     if ($DATEVALUE eq "manual+input") {
	print "<BR><FORM ACTION=\"http:$SCRIPT_NAME/quick\" METHOD=\"GET\">\n";
	print "<INPUT NAME=\"quickfmt\" TYPE=\"hidden\" VALUE=$_[0]>";
	
        foreach (keys(%restrict)) {
	    print "<INPUT NAME=\"$_\" TYPE=\"hidden\" VALUE=\"$restrict{$_}\">" if ($restrict{$_} ne "" && $_ ne "date");
	}
	print "<INPUT NAME=\"Date\" TYPE=\"hidden\" VALUE=\"manual input\">\n";
	&dates_manual_input;
	print "<BR>Enter start date (7 days ago by default): <INPUT NAME=\"date_start\" VALUE=\"$seven_days_ago\">\n";
	print "<BR>Enter end date (today by default): <INPUT NAME=\"date_end\" VALUE=\"$date_of_today\">\n";
	print "<BR><BR><INPUT TYPE=\"submit\" VALUE=\"Click here\" >      <INPUT TYPE=\"reset\" VALUE=\"Default\">\n";
	print "<BR></FORM>\n";
	print "</BODY></HTML>\n";
    }
    else {

    local($opts);
    local(@prs);
    # Read in quick format list of pr's matching query
    # If querying by person, then do two queries: originator and responsible
    if ($restrict{"person"} ne "") {
	$fullname = $restrict{"person"};
	# Look up bugs for which this person is the originator.
	if ($fullname eq "any") {
	    $opts = "--state=\"open|assigned|feedback\"";
	} else {
	    $oldval = $fullname;
	    # Turn underscores and spaces into regular expression
	    # that match either underscores or spaces
	    # (Our database sometimes puts underscores instead of spaces).
	    $oldval =~ s/[\s_]/[ _]/g;
	    $oldval =~ s/\[ _\]([1-9])\|/[ _][ _]$1\|/g;
            $oldval =~ s/\[ _\]([1-9])$/[ _][ _]$1/;
	    # Handle bugs with no known originator
	    if ($oldval eq "nobody") {
		$oldval = "nobody|^\$";
	    }
	    # Convert this key into a query-pr option
	    $opts = " --originator=\"$oldval\"";
	    # The originator cares about bugs which are in feedback state.
	    $opts .= " --state=\"feedback\"";
	}

	# Look up bugs for which this person is the responsible party.
	# Convert person's name into nickname
	$nickname = $fullname2nametag{$fullname};
	# Golly, maybe the spaces have been replaced with underscores.
	if ($nickname eq "") {
	    $fullname =~ s/_/\040/g;
	    $nickname = $fullname2nametag{$fullname};
	}
	if ($nickname ne "") {
	    # Convert this key into a query-pr option
	    $opts = " --responsible=\"$nickname\"";
	    $dom=$domain;
	    $dom =~ s/^-//;
	     print "<PRE> <STRONG>In domain $dom:</STRONG> </PRE>\n";
	    # Responsible person cares about bugs which are open or assigned.
	     foreach $option (@nCategory) {
		if ($option ne "") { 
	    $opts .= " --state=\"open|assigned|feedback\" --category=$option";
	    open(PIPE,"$GNATS_BIN/query-pr -i $opts 2>/dev/null |") || die "Can't open";
	     $opts = " --responsible=\"$nickname\"";
	    @prs = (@prs,<PIPE>);
	    close(PIPE);
	}
	    }
	}
		else {
	    print "Warning: $fullname has no nickname.\n";
	    ;
	}
    } else {
	# Output restrictions as query-pr options
	foreach (keys(%restrict)) {
	    $oldkey = $_;
	    $oldval = $restrict{$oldkey};
	    # If "any" was given, don't bother using this key
	    if ($oldval !~ /\bany\b/) {
		# Turn underscores and spaces into regular expression
		# that match either underscores or spaces
		# (Our database sometimes puts underscores instead of spaces).
		$oldval =~ s/[\s_]/[ _]/g;
   		$oldval =~ s/\[ _\]([1-9])\|/[ _][ _]$1\|/g;
                $oldval =~ s/\[ _\]([1-9])$/[ _][ _]$1/;
		# Convert this key into a query-pr option
		$opts .= " --$oldkey=\"$oldval\"";
	   #However if "any" was chosen for the category then we still
	   #want to restrict the listing to the problem reports for
	   #the current domain
	    } elsif ($oldkey =~ /\bcategory\b/) {
                if ($oldval =~ /\bany\b/) {
                $anyopts = join("|",@nCategory);
                $anyopts =~ s/^\|//;
		$opts .= " --category=\"$anyopts\""; 
	    }
	    }
	}
	# Kludge for selecting only PRs relevant to actual domain by selecting
	# domain's responsibles. Also gnats-admin is selected, since it is part
	# of all domains. L.Salv. 14-mar-1997
	$opts .= " --responsible=\"";
	foreach $option1(@nResponsible) {
	if ($option1 ne "") {
		$opts .= "$option1\|";
		}
	}
	$opts .= "\"";
	$opts =~ s/\|\"$/\"/;
	# End of kludge
	open(PIPE,"$GNATS_BIN/query-pr -i $opts 2>/dev/null |") || die "Can't open";
	@prs = <PIPE>;
	close(PIPE);
    }
    
    if (@prs == 0) {
	print "<H3>No problem reports match your query.</H3>\n";
	return;
    }
    print "<PRE>\n";
    # Print field headers.
    local($QUICKFMT, $WIDTH, $fstring, $str);
    $fstring = "";
    foreach (@field) {
	($QUICKFMT, $WIDTH)=split(/:/,$field{$_});
	if ($QUICKFMT <= $quickfmt) {
	    $fstring .= &truncstr($_, $WIDTH) . " ";
	}
    }
    print "<B>PR#  $fstring</B>\n"; 

    opendir(MYDIR,"$GNATS_ROOT") || die "Can't open listing";
    local(@filelist)=readdir MYDIR;
    local($filename);
    foreach $filename(@filelist) {
      if ($filename =~ m,^listing\d+,) {
	unlink("$GNATS_TEMP/$filename");
      }
    }
    closedir(MYDIR);    
	    
     # Print each PR in result as link to full text 
     foreach (@prs) {
	s/\s*\|\s*/|/go;
        ($PRIORITY,
        $NUMBER, 
	$CATEGORY,
	$SYNOPSIS,
	$CONFIDENTIAL,
	$SEVERITY,
	$RESPONSIBLE,
	$STATE,
	$CLASS,
	$SUBMITTER,
	$ARRIVAL_DATE,
	$ORIGINATOR,
        $START_DATE,
        $END_DATE,
	$RELEASE ) = split(/\|/, $_);
	$SEVERITY = $quickSeverity[$SEVERITY];
	$PRIORITY = $quickPriority[$PRIORITY];
	$STATE = $nState[$STATE];
	$CLASS = $nClass[$CLASS];

	$fstring = sprintf("%s", substr("    ", 0, (length($NUMBER)<5)?4-length("$NUMBER"):1));
	# @field is an array of the variable names $NUMBER, etc., in presentation order.
	# %field tells which quickfmt level and ?below? to print this variable
	#       in, and how wide to print it.
	foreach (@field) {
	    ($QUICKFMT, $WIDTH)=split(/:/,$field{$_});
	    if ($QUICKFMT <= $quickfmt) {
		$str = eval "\$$_";
		$fstring .= &truncstr($str, $WIDTH) . " ";
	    }
	}
	&listing($NUMBER) if ($do_listing == 1);
	print "<A HREF=http:$SCRIPT_NAME/full/$NUMBER>$NUMBER</A> ",&html_escape($fstring),"\n"; 
    }
	    print "</PRE>\n";
	    print "<HR>";
	    print  "<H4>You may also see a <A HREF=http:$HTTP_TEMP/$GNATS_LISTING$$.html>Full-Text Listing</A> of the matching Problems Reports.</H4>\n" if ($do_listing == 1);
	    $do_listing=0;
	    }
}


###########################
sub query_summary {
    # Print title
    print "<HEAD><TITLE>Summary of Active Problem Reports by Person and Status</TITLE></HEAD>
<H2>Summary of active Problem Reports by person and status:</H2>
<BODY>
";
    @prs == 0;
	# Kludge for selecting only PRs relevant to actual domain by selecting
	# domain's responsibles. Also gnats-admin is selected, since it is part
	# of all domains. L.Salv. 14-mar-1997
        $opts .= " --responsible=\"";
        foreach $option1(@nResponsible) {
        if ($option1 ne "") {
                $opts .= "$option1\|";
                }
        }
        $opts .= "\"";
        $opts =~ s/\|\"$/\"/;
	# End of kludge

    foreach $option(@nCategory){
	
	if ($option ne  "") {
      	open(PIPE,"$GNATS_BIN/query-pr -i --state=\"open|assigned|feedback\" --category=$option $opts 2>/dev/null |") || die "Can't open";
      	@prss = <PIPE>;
      	close(PIPE);
      	push(@prs,@prss);
	}
    }
   
    if (@prs == 0) {
	print "<H3>No problem reports match your query.</H3>\n";
	return;
    }
    # Count bugs by person.
    # Print each PR in result as link to full text 
    local(%counts,%names);
    foreach (@prs) {
	s/\s*\|\s*/|/go;
	($PRIORITY, 
	 $NUMBER,
	$CATEGORY,
	$SYNOPSIS,
	$CONFIDENTIAL,
	$SEVERITY,
	$RESPONSIBLE,
	$STATE,
	$CLASS,
	$SUBMITTER,
	$ARRIVAL_DATE,
	$ORIGINATOR,
        $START_DATE,
	$END_DATE,
	$RELEASE ) = split(/\|/, $_);
	$STATE = $nState[$STATE];
	# Figure out which person this bug is waiting on, if any
	if ($STATE eq "open" || $STATE eq "assigned" || $STATE eq "feedback") {
	    # Waiting on responsible person
	    # Convert nickname to fullname
	    $nickname = $RESPONSIBLE;
	    $nickname = &tolower($nickname);
	    $fullname = $nametag2fullname{$nickname};
	    if ($fullname eq "") {
		$fullname = $nickname;
		
	    }

	} 
	if ($fullname eq "") {
	    $fullname = "nobody";

	}

	if ($STATE eq "open" || $STATE eq "assigned" || $STATE eq "feedback") {
	    $counts{$fullname."_".$STATE}++;
	    $names{$fullname}++;
	}
    } 

    # Print field headers.
    print "<PRE>\n";
    local(@states) = ("open", "assigned", "feedback");
    local($fstring, $str);
    $fstring = &truncstr("responsible", 20)."   ";
    foreach (@states) {
	$fstring .= &truncstr($_, 10) . " ";
    }
    $fstring =~ tr/[a-z]/[A-Z]/;
    print "<B>$fstring</B>\n"; 
    # Print counts per person.
    foreach $fullname (sort(keys(%names))) {
	$fstring = &truncstr($fullname, 20)."   ";
	local($_fullname) = $fullname;
	$_fullname =~ tr/ /_/;
	$fstring =~ s/(\s*)$//;
	print "<A HREF=http:$SCRIPT_NAME/quick?quickfmt=regular&Person=$_fullname&Date=&Multitext=>$fstring</A>$1"; 
	$fstring = "";
	foreach (@states) {
	    $str = $counts{$fullname."_".$_}+0;
	    $fstring .= &truncstr($str, 10) . " ";
	}
	print "$fstring\n";
    }
    print "</PRE>\n";
    print "<HR>";

}



##############################    
sub query_summary_cat {
    # Print title
    print "<HEAD><TITLE>Summary of Problem Reports by Category and Status</TITLE></HEAD>
<H2>Summary of Problem Reports by Category and Status:</H2>
<BODY>
";
    
	# Kludge for selecting only PRs relevant to actual domain by selecting
	# domain's responsibles. Also gnats-admin is selected, since it is part
	# of all domains. L.Salv. 14-mar-1997
        $opts .= " --responsible=\"";
        foreach $option1(@nResponsible) {
        if ($option1 ne "") {
                $opts .= "$option1\|";
                }
        }
        $opts .= "\"";
        $opts =~ s/\|\"$/\"/;
	# End of kludge

    foreach $option (@nCategory) {
	if ($option ne "") {
	    open(PIPE,"$GNATS_BIN/query-pr -i --category=$option $opts 2>/dev/null |") || die "Can't open";
	    @prss = <PIPE>;
	    push(@prs,@prss);
	    close(PIPE);
	}
    }
	if (@prs == 0) {
	    print "<H3>No problem reports match your query.</H3>\n";
	    return;
    }
    # Count bugs by category.
    # Print each PR in result as link to full text 
    local(%counts,%names,%states);
 
    foreach (@prs) {
	s/\s*\|\s*/|/go;
	( $PRIORITY,
	 $NUMBER,
	 $CATEGORY,
	$SYNOPSIS,
	$CONFIDENTIAL,
	$SEVERITY,
	$RESPONSIBLE,
	$STATE,
	$CLASS,
	$SUBMITTER,
	$ARRIVAL_DATE,
	$ORIGINATOR,
        $START_DATE,
        $END_DATE,
	$RELEASE ) = split(/\|/, $_);
	$STATE = $nState[$STATE];

	$counts{$CATEGORY."_".$STATE}++;
	$names{$CATEGORY}++;
	$states{$STATE}++;
    } 

    # Print field headers.
    print "<PRE>\n";
    local(@states) = ("open", "assigned", "feedback", "closed", "suspended");
    local($fstring, $str);
    $fstring = &truncstr("category", 20)."   ";
    foreach (@states) {
	$fstring .= &truncstr($_, 10) . " ";
    }
    $fstring =~ tr/[a-z]/[A-Z]/;
    print "<B>$fstring</B>\n"; 
    # Print counts per person.
    foreach $CATEGORY (sort(keys(%names))) {
	$fstring = &truncstr($CATEGORY, 20)."   ";
	$fstring =~ s/(\s*)$//;
	print "<A HREF=http:$SCRIPT_NAME/quick?quickfmt=regular&Category=$CATEGORY&Date=&Text=>$fstring</A>$1"; 
	$fstring = "";
	foreach (@states) {
	    next if ($_ eq "");
	    $str = $counts{$CATEGORY."_".$_}+0;
	    if ($str > 0) {
		# Who's gonna answer the following query?
		$fstring .= "<A HREF=http:$SCRIPT_NAME/quick?quickfmt=regular&Category=$CATEGORY&Date=&State=$_>$str</A>"; 
		$fstring .= " " x (11-length($str));
	    } else {
		$fstring .= &truncstr($str, 10) . " ";
	    }
	}
	print "$fstring\n";
    }
    print "</PRE>\n";
    print "<HR>";

}
    
######################## Full query
sub query_full
{
    local($pr) = $_[0];
    print "<HEAD><TITLE>Full Problem Report Text</TITLE></HEAD>
<BODY>
";
    if ($pr eq "") {
	print "<H3>Sorry</H3>\n";
	print "You must specify the number of the problem report to view.\n";
	return;
    }
    $err = &read_pr($pr, "");
    if ($err ne "") {
	print "$err\n";
    } else {
	print "
<FORM ACTION=\"http:$EDIT_PR/$domain$path2\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Click here to edit\">
<INPUT NAME=\"pr\" TYPE=\"hidden\" VALUE=\"$pr\">
</FORM>
<FORM ACTION=\"$HELP_FILE\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Click here for help\" >
</FORM>
<H2>Full text of Problem Report number $pr :</H2>
";
	print "<PRE>\n";
	$subject=$fieldvalues{"Synopsis"};
	# Escape blank spaces in string to avoid truncation
	$subject=~ s/ /+/g;
	$prtext = &html_escape(join("",@oldpr));
	$prtext =~ s/&gt;([\w-]*):/<STRONG>$1<\/STRONG>:/g;
	$prtext =~ s/Reply-To: ([\w-@\.]*)\n/ $subject;

	    if ($1 eq "")
	    { join('', $1); }
	else
	{ join('', 'Reply-To: <A HREF="\/cgi-bin\/gnats\/sendmailto.pl\/',$username,'\/', $eladdress,'\/', $1,'\/', $subject, '">', $1, "<\/a>\n"); }/e;

	# patch to allow reply to bugs, so user can append info to Pr, also
	# the subject field of the message should be changed so bugs understands it
	$subject=join("/",$fieldvalues{"Category"},$pr);
	# Escape blank spaces in string to avoid truncation
	$subject1=$subject;
	$subject1=~ s/ /+/g;
	$prtext =~ s/To: ([\w-@\.]*)\n/
	    $subject=$fieldvalues{"Synopsis"};

	    if ($1 eq "")
	    { join('', $1); }
	else
	{ join('', 'To: <A HREF="\/cgi-bin\/gnats\/sendmailto.pl\/',$username,'\/', $eladdress,'\/', $1,'\/', $subject1, '">', $1, "<\/a>\n"); }/e;
	# end of patch................................
	print $prtext;
	print "</PRE>\n";
	print "<HR>";

    }
}

############################# Main Menu
#
# Very first page of front end
#
sub main_menu {
    # Display title
    print "<HEAD><TITLE>LABEN S.p.A. Help Desk</TITLE></HEAD>
<H2><A HREF=\"http://www.laben.it/\">LABEN S.p.A.</A>
 Problem Reporting System</H2>
<BODY>
<STRONG>
";

print "
Click <A HREF=\"$GNATS_DOC\"> here </A>
for an introduction to the GNATS Problem Reporting System
or choose one of the following commands:
<OL>
<LI><FORM ACTION=\"http:$SCRIPT_NAME/send_pr\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Submit a New Problem Report\">
</FORM>
<LI><FORM ACTION=\"http:$SCRIPT_NAME/full\" METHOD=\"GET\">
Enter Problem Report number <INPUT NAME=\"pr\" SIZE=6>
and click <INPUT TYPE=\"submit\" VALUE=\"HERE\"> to view/edit an existing report
</FORM>
<LI><FORM ACTION=\"http:$SCRIPT_NAME/summary\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Summary of Active Problems by Status and Person\">.
</FORM>
<LI><FORM ACTION=\"http:$SCRIPT_NAME/summary_cat\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Summary of All Problems by Status and Category\">.
</FORM>
<LI><FORM ACTION=\"http:$SCRIPT_NAME/custom_sum\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Keyword Search Utility\">.
</FORM>
<LI><FORM ACTION=\"http:$SCRIPT_NAME/report\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Report Generation\">.
</FORM>
<LI><FORM ACTION=\"$HELP_FILE\" METHOD=\"GET\">
<INPUT TYPE=\"submit\" VALUE=\"Help on GNATS Problem Reports Fields\">.
</FORM>
</OL>
</STRONG>
";
}

######################## Quick query
sub custom_sum 
{
# Display title
   
print "<HTML>\n";

print "<HEAD><TITLE>Keyword Search</TITLE></HEAD>
<H1>Keyword Search</H1>";
print "<HR>\n";
print "<LI><STRONG>Use the following form for a keyword search of the database:</STRONG>";
print "</HEAD>";
print "<BODY>";
    print "<BR><FORM ACTION=\"http:$SCRIPT_NAME/quick\">\n";

    # Choose quick output format.
    print "Select \n";
    print "<SELECT NAME=\"quickfmt\">\n";
    foreach (@quickfmt) {
	print "<OPTION", ($_ eq "regular") ? " SELECTED" : "", "> $_\n";
    }
    print "</SELECT> output format. <BR>\n";

    local($mode);

    print "<BR>Restrict the output by specifying a value for one or more <A HREF=\"http://consult.cern.ch/writeup/gnats/gnats_1.html#SEC6\">problem report fields</A>:\n";

  print "
  <PRE>
<A HREF=\"$HELP_FILE#severity\">Severity</A>  :<INPUT TYPE=\"checkbox\" NAME=\"Severity\" VALUE=\"any\" checked> any  <INPUT TYPE=\"checkbox\" NAME=\"Severity\" VALUE=\"non-critical\"> non-critical  <INPUT TYPE=\"checkbox\" NAME=\"Severity\" VALUE=\"serious\"> serious       <INPUT TYPE=\"checkbox\" NAME=\"Severity\" VALUE=\"critical\"> critical

<A HREF=\"$HELP_FILE#priority\">Priority</A>  :<input NAME=\"Priority\" type=\"checkbox\" VALUE=\"any\" checked> any  <input NAME=\"Priority\" type=\"checkbox\" VALUE=\"low\" > low           <input NAME=\"Priority\" type=\"checkbox\" VALUE=\"medium\"> medium        <input NAME=\"Priority\" type=\"checkbox\" VALUE=\"high\"> high

<A HREF=\"$HELP_FILE#class\">Class</A>     :<input NAME=\"Class\" type=\"checkbox\" VALUE=\"any\" checked> any  <input NAME=\"Class\" type=\"checkbox\" VALUE=\"support\" > support       <input NAME=\"Class\" type=\"checkbox\" VALUE=\"scheduled\"> scheduled     <input NAME=\"Class\" type=\"checkbox\" VALUE=\"duplicate\"> duplicate
                   <input NAME=\"Class\" type=\"checkbox\" VALUE=\"sw-bug\"> Software      <input NAME=\"Class\" type=\"checkbox\" VALUE=\"doc-bug\"> Documentation <input NAME=\"Class\" type=\"checkbox\" VALUE=\"change-request\"> Change Request 

</PRE>\n";
        

    # Loop over output restrictions (Category, State, Responsible).
    foreach (@quickrestr) {
	# Make sure choices fit within window
	$mode = eval"\@n$_">30 ? "SIZE=2" : "";
	# Let user select more than one choice for "State".
	if ($_ eq "State") {
 	    $mode = "SIZE=". eval"\@n$_";
	    $mode .= " MULTIPLE";
	}
        $helpfile = $_;
        $helpfile =~ tr/A-Z/a-z/;
	print "<DT> <A HREF=\"$HELP_FILE#$helpfile\">$_</A>\n";
        print "<DD>";
        print "<SELECT $mode NAME=\"$_\">\n";
	# Refer to arrays @nCategory, @nState, @nResponsible as appropriate.
	# Note use of eval.
        foreach $option (eval "\@n$_") {
	    $option= "any" if (!$option);
	    print "<OPTION", ($option eq $quickrestr{$_}) ? " SELECTED" : "", "> $option\n"; 
	}
        print "</SELECT>";
    }

    # Loop over freeform search restrictions (Text, Multitext).
    print "</DL>\n";
    print "and/or specifying a 
<A HREF=\"http://consult.cern.ch/writeup/gnats/gnats_6.html\">freeform text search</A>
on
<A HREF=\"http://consult.cern.ch/writeup/gnats/gnats_1.html#SEC6\">any GNATS field</A>.\n";
    print "<DL>\n";
    foreach ("Arrival-Date, Date of last modification") {
	print "<DT><A HREF=\"$HELP_FILE#date\"> $_</A>\n";
        print "<DD>\n";
      	print "<SELECT NAME=\"Date\">\n";
	print "<OPTION SELECTED> any\n";
	print "<OPTION> manual input\n";
	print "<OPTION> today\n";
	print "<OPTION> yesterday\n";
	print "<OPTION VALUE=\"last week\"> last 7 days\n";
	print "<OPTION VALUE=\"last two weeks\"> last 14 days\n";
	print "<OPTION VALUE=\"last month\"> last 30 days\n";
	print "</SELECT>\n";
    }

    print "<BR><BR>\n<DT><A HREF=\"$HELP_FILE#occurencetime\"> Date and Time of occurence</A>\n";
    print "<DD>\n";
    print "<INPUT NAME=\"StartDate\" SIZE=\"16\">\n";

    print "<BR><BR>\n<DT><A HREF=\"$HELP_FILE#occurencetime\"> Date and Time of end</A>\n";
    print "<DD>\n";
    print "<INPUT NAME=\"EndDate\" SIZE=\"16\">\n";

    print "<DT><A HREF=\"$HELP_FILE#synopsis\"> Synopsis</A>\n";
    print "<DD>\n";
    print "<INPUT NAME=\"Text\" SIZE=\"16\">\n";

    print "<DT><A HREF=\"$HELP_FILE#description\"> Description</A>\n";
    print "<DD>\n";
    print "<INPUT NAME=\"Multitext\" SIZE=\"32\">\n";

print "</DL>
<BR><INPUT TYPE=\"submit\" VALUE=\"Click Here to Search\">. <BR>
</FORM>
<HR>
</BODY>
</HTML>
";

}


######################### send-pr
sub send_pr 
{
    if ($username eq "1") {
	$username = ""
	}
if ($eladdress eq "1") {
	$eladdress = ""
	}
print "<HTML>\n";
print "<HEAD>\n";

# The domain of the problem report is put in the request field
# example: http://your_server.your_domain/htbin/send_gnats/UWC/ -> -UWC

# default for start-date field
&dates_manual_input;

# Print the document
print <<"EOM";

<TITLE>Submit a New Problem Report</TITLE>
</HEAD>

<BODY>
<H1>Submit a New Problem Report</H1>
<HR>

Please fill out the following form to describe the problem that you wish to 
report. Help can be obtained on any of the fields by clicking on the 
highlighted keywords

<HR>
<FORM METHOD=\"GET\" ACTION=\"http:$SCRIPT_NAME/handle_send_pr\">

<PRE>
<A HREF=\"$HELP_FILE#severity\">Severity</A>     :<input NAME=\"Severity\" type=\"radio\" VALUE=\"non-critical\" checked>non-critical  <input NAME=\"Severity\" type=\"radio\" VALUE=\"serious\">serious       <input NAME=\"Severity\" type=\"radio\" VALUE=\"critical\">critical
<A HREF=\"$HELP_FILE#priority\">Priority</A>     :<input NAME=\"Priority\" type=\"radio\" VALUE=\"low\" checked>low           <input NAME=\"Priority\" type=\"radio\" VALUE=\"medium\">medium        <input NAME=\"Priority\" type=\"radio\" VALUE=\"high\">high
<A HREF=\"$HELP_FILE#class\">Class</A>        :<input NAME=\"Class\" type=\"radio\" VALUE=\"support\" checked>support       <input NAME=\"Class\" type=\"radio\" VALUE=\"scheduled\">scheduled     <input NAME=\"Class\" type=\"radio\" VALUE=\"duplicate\">duplicate<BR>              <input NAME=\"Class\" type=\"radio\" VALUE=\"sw-bug\">software-bug  <input NAME=\"Class\" type=\"radio\" VALUE=\"doc-bug\">documentation <input NAME=\"Class\" type=\"radio\" VALUE=\"change-request\">change-request
 
<A HREF=\"$HELP_FILE#originator\">Originator</A>   :<input NAME=\"Originator\" VALUE=\"$username\">

<A HREF=\"$HELP_FILE#email\">Email address</A>:<input NAME=\"Email\" VALUE=\"$eladdress\" size=24><INPUT TYPE="hidden" NAME=\"Organization\" VALUE=\"LABEN\">

<A HREF=\"$HELP_FILE#occtime\">Date and Time</A>:<input NAME=\"Start-Date\" VALUE=\"$default_for_start_date\"> when the problem occured

<A HREF=\"$HELP_FILE#endtime\">Date and Time</A>:<input NAME=\"End-Date\" VALUE=\"\"> when the problem ended<INPUT TYPE="hidden" NAME=\"Release\" VALUE=\"unknown\">

EOM

print "<A HREF=\"$HELP_FILE#synopsis\">Synopsis</A>      :"; 

$result=&read_subject;

    if ($result==1) {
	print "<SELECT NAME=\"Synopsis\">\n";
	
        # open the domain specific subject file and dump the contents
	# here as options

	foreach $option (@nSubject) {
	    print "<OPTION>$option\n" if ($option);
	}
	print "</SELECT>\n";
    }
    else 
    {
	print "<input NAME=\"Synopsis\">\n";
    }


print <<"EOM";

<A HREF=\"$HELP_FILE#category\">Category</A>     :<SELECT NAME=\"Category\">


EOM

# open the domain specific problem category file and dump the contents
# here as options

foreach $option (@nCategory) {
    print "<OPTION>$option\n" if ($option);
}


print <<"EOM";
</SELECT>

<A HREF=\"$HELP_FILE#environment\">Environment</A>: (Copy the result of 'uname -a' command here)
<TEXTAREA NAME=\"Environment\" ROWS=2 COLS=80>
unknown
</TEXTAREA>

<A HREF=\"$HELP_FILE#description\">Description</A>:
<TEXTAREA NAME=\"Description\" ROWS=10 COLS=80>
</TEXTAREA>

<A HREF=\"$HELP_FILE#repeat\">How to repeat</A>:
<TEXTAREA NAME=\"How-To-Repeat\" ROWS=5 COLS=80>
</TEXTAREA>

<INPUT TYPE=\"submit\" NAME=\"submit\" VALUE=\"Send the report\">    <INPUT TYPE=\"reset\" VALUE="clear">
</PRE>
</FORM>

<HR>
</BODY>
</HTML>
EOM
;
}


######################## Report generation
sub report 
{
 # Display title
   
print "<HTML>\n";

print "<HEAD><TITLE>Report Generation</TITLE></HEAD>
<H1>Report Generation</H1>";
   
print "<BODY>
<HR>
<H3>Please select one of the following templates:</H3>
<H4>
<OL>
<LI><A HREF=\"http:$SCRIPT_NAME/custom_sum\">Keyword search</A>
<LI><A HREF=\"http:$SCRIPT_NAME/quick?quickfmt=regular&Severity=serious&Severity=critical&Priority=high&Category=any&State=any&Responsible=any&Date=last+week&Multitext=\">Tough Stuff</A>
<LI><A HREF=\"http:$SCRIPT_NAME/quick?quickfmt=regular&Severity=any&Priority=any&Category=any&State=any&Responsible=any&Date=last+week&Multitext=\">Full Weekly Report</A>
<LI><A HREF=\"http:$SCRIPT_NAME/quick?quickfmt=regular&Severity=any&Priority=any&Category=any&State=any&Responsible=any&Date=manual+input&Multitext=\">Select by Date</A>
</OL>
</H4>
<HR>
</BODY>
</HTML>
";

}
