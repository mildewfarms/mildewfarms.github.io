#!/usr/bin/perl
#
#
# This is the Gnats home page. Part of
# wwwgnats.pl - a WWW interface to the GNATS bug tracking system
# Thanks to Larry Wall, CERN, and NCSA for Perl, WWW, and Mosaic!
#
### Modification log:
# 2/1/95  Dan Kegel        - Split off from wwwgnats.pl
# 3/1/95  Dan Kegel        - Added pr_addr function
# 12/3/97 Luca Salvadori   - Added parametrization for system executables
#                          - Polished html code
#                          - Ported whole stuff to work with NCSA httpd
#                          - Changed domainization from "-domain" to ".domain"
#                            (no reason: just liked it more)
#                          - Only PRs relevant to selected domain are now manage
#                            PRs assigned to other domains' responsibles were
#                            displayed as well: this caused confusion. "Pending"
#                            PRs are displayed in all domains: it's correct,
#                            since no responsible has been defined yet.
#                          - Lists are more readable (titles in bold)
#                          - ">Unformatted:" field now managed
#                          - Old values of textarea fields now displayed and 
#                            editable
#
# Luca Salvadori - LABEN S.p.A. <lsalvadori@batman.laben.it>
#
### End Modification log
#
$pathinfo = $ENV{"PATH_INFO"};
@pathlist = split(/\//, $pathinfo);
$prog = shift(@pathlist);
$username = shift(@pathlist);
$eladdress = shift(@pathlist);
if ($username eq "") {
    $username = "1";
}

if ($eladdress eq "") {
    $eladdress = "1";
}

require "cgi-lib.pl";
 
print &PrintHeader;

# Print the document
print <<"EOM";

<HTML>
<HEAD><TITLE>LABEN S.p.A. - Help Desk Home Page</TITLE>
<!-- Changed by: Alan John Lovell, 21-Apr-1995 -->
<!-- Changed by: system PRIVILEGED account, 16-Jun-1995 -->
<!-- Tided up by: Jesus Sanchez, 23-Oct-1996 -->
<!-- Taken to production status: Luca Salvadori, 13-Mar-1997 -->
</HEAD>

<H1><a href="http://www.laben.it">LABEN S.p.A.</a></H1>
<H2>A New Help Desk System Home Page</H2>

<FONT SIZE=+1>
This is home page for <a href="http://www.laben.it">LABEN S.p.A.</a> Help Desk System. This system is based on 
<A HREF="http://consult.cern.ch/writeups/gnats/gnats.html">  Gnats </A>
Problem Report Management System and its useful WWW extensions.
<P>In order to improve clarity several different reporting "Domains" have been
created. These domains are listed below. You may access the domain of your
choice by clicking on the relevant domain title.
</FONT>
<BR>
<HR>
<STRONG>
<OL>
<LI><A HREF="http://caf70.laben.it/cgi-bin/gnats/wwwgnats.pl/laben/$username/$eladdress/" >
LABEN</A> - Support Services for <A HREF="http://www.laben.it/">LABEN S.p.A.</A>, Milan Plant
<LI><A HREF="http://caf70.laben.it/cgi-bin/gnats/wwwgnats.pl/proel/$username/$eladdress/" >
PROEL</A> - Support Services for <A HREF="http://www.laben.it/proel">PROEL Tecnologie Division</A>, Florence Plant
</OL>
<HR>
</STRONG>
</BODY>
</HTML>

EOM

1;
