#!/bin/sh  
#
# NAME
#	CGI/1.0 script for collecting customer information
#
# ALGORITHM
#		Calls cgi_parse to get the form information
#		Check if all we need is filled out:
#			if not, then:
#			Returns a warning web page to the user
#			Send a mail correctly formatted to recipient 
#			Return a confirmation web page to user
#
#
# CONDITIONS
#	Script is invoked as form with METHOD=POST.
#	QUERY_STRING environment variable must have the form:
#		name=name&email=email&body=body  ...
#
# WRITTEN
#     Susana Fernandez Jan 1995 - susana@www.cern.ch 
#
# CHANGES
#     Luca Salvadori Mar 1997 - lsalvadori@batman.laben.it
#                - HTML Code polished
#                - Mail message reformatted to allow better reading
#                - Sendmail invoked with -f option, so actual sender
#                  is reported to recipient instead of <httpd>
#
# Luca Salvadori - LABEN S.p.A. <lsalvadori@batman.laben.it>
#
#
##################################################################
Variables to set up depending on the machine:

CGIPARSE=/usr/local/bin/cgiparse
SIGN="<a href="mailto:lsalvadori@batman.laben.it">Luca Salvadori</a> - Information Systems, LABEN S.p.A. - Milan, Italy"
SENDMAIL=/usr/sbin/sendmail
##################################################################

#	Write header and title
echo "Content-Type: text/html"
echo
echo "<HEAD><TITLE>Mail to WWW Support Service at LABEN S.p.A.</TITLE></HEAD><BODY>"

#
#       Set the QUERY_STRING variable
#
 
eval `$CGIPARSE -init -quiet`
#
#       Parse QUERY_STRING
#
PARSED=`$CGIPARSE -form -quiet`
if [ $? -ne 0 ]
then
        echo "<H1>Internal Error Parsing QUERY_STRING</H1>"
        echo "<CODE>cgiparse</CODE> complains: <PRE>"
        echo "    $PARSED"
        echo "</PRE></BODY>"
        exit 0
fi
eval $PARSED
 
#
#       Check if all the necessary info is entered
# 	if not exit and do mail error info
#
if [ $FORM_subject = "form" ]
then
FORM_text="."
fi

if [ \( -z "$FORM_from_mail" \)   -o \( -z "$FORM_division" \) -o \( -z "$FORM_subject" \) -o \( -z "$FORM_to_mail" \) -o  \( -z "$FORM_text" \)  ]
then
cat <<until_1 

	<H1>Sorry</H1>
	<P>
	Your message was not processed because some information was
	missing in the filled out form.
	<P>
	Please go back, complete the form and resubmit your request.
	
	<P>
	<HR>
	<ADDRESS> $SIGN </ADDRESS>
	</BODY>
until_1

exit
fi

#
#	Create temp file to send by mail
#
echo "From: $FORM_from_mail" > /tmp/send-mail$$ 
echo "Subject: $FORM_subject" >> /tmp/send-mail$$ 
echo "" >> /tmp/send-mail$$
echo "SUBJECT=$FORM_subject" >> /tmp/send-mail$$
echo "NAME = $FORM_from_name" >> /tmp/send-mail$$
echo "DIVISION/GROUP= $FORM_division" >> /tmp/send-mail$$
echo "EMAIL = $FORM_from_mail" >> /tmp/send-mail$$
echo "" >> /tmp/send-mail$$
echo "CONTENT= " >> /tmp/send-mail$$
#	How can I keep the newlines sending the mail?
#	$CGIPARSE -value "text"
$CGIPARSE -value "text" >> /tmp/send-mail$$
echo "+++ END OF MESSAGE +++" >> /tmp/send-mail$$

#
#	Send the mail to $FORM_to_mail and clean up temp file
#
cat /tmp/send-mail$$ | $SENDMAIL -f$FORM_from_mail $FORM_to_mail > /dev/null 2>&1
rm /tmp/send-mail$$

#
#	Echo success message to browser
#

cat <<until_2
<H2>MAIL SENT!</H2>
Your message has been sent to <STRONG>$FORM_to_mail</STRONG> with 
the following information:
<P>
<HR>

<PRE>
<B>Name: </B>$FORM_from_name
<B>Division/Group</B> = $FORM_division
<B>E-mail: </B>$FORM_from_mail
<B>Subject: </B>$FORM_subject<HR>
<B>Content: </B>$fill_form

until_2

$CGIPARSE -value "text"

cat <<until_3
</PRE>

<HR>
<ADDRESS> $SIGN </ADDRESS>
</BODY>

until_3
