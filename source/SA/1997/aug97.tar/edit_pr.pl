#!/usr/bin/perl
$| = 1;
# edit_pr.pl - Problem Report editor for 
# wwwgnats.pl - a WWW interface to the GNATS bug tracking system
# Thanks to Larry Wall, CERN, and NCSA for Perl, WWW, and Mosaic!
#
### Modification log:
# 2/1/95  Dan Kegel        - Split off from wwwgnats.pl
# 3/1/95  Dan Kegel        - Added pr_addr function
# 12/3/97 Luca Salvadori   - Added parametrization for system executables
#                          - Polished html code
#                          - Ported whole stuff to work with NCSA httpd
#                          - Changed domainization from "-domain" to ".domain"
#                            (no reason: just liked it more)
# 15/3/97 Luca Salvadori   - Only PRs relevant to selected domain are now manage
#                            PRs assigned to other domains' responsibles were
#                            displayed as well: this caused confusion. "Pending"
#                            PRs are displayed in all domains: it's correct,
#                            since no responsible has been defined yet.
#                          - Lists are more readable (titles in bold)
#                          - ">Unformatted:" field now managed
#                          - Old values of textarea fields now displayed and 
#                            editable
#
# Luca Salvadori - LABEN S.p.A. <lsalvadori@batman.laben.it>
#
### End Modification log
# 
$pathinfo = $ENV{"PATH_INFO"};
@pathlist = split(/\//, $pathinfo);
$prog = shift(@pathlist);
$domain = shift(@pathlist);
$username = shift(@pathlist);
$eladdress = shift(@pathlist);
$domain =~ s/^//;
$path = join("/", @pathlist);
$path2 = join("/","",$username,$eladdress);
 
if ($path eq "") {
    $path = "";
} else {
    $path = ("/".$path);
}

require "/usr/local/etc/httpd/cgi-bin/gnats/libgnats.pl";
require "cgi-lib.pl";

$SCRIPT_NAME = "/cgi-bin/gnats/wwwgnats.pl/".$domain.$path2;
$EDITOR_FILE = "$GNATS_ADM/editors.".$domain;
$ORIGIN_FILE = $EDITOR_FILE;
$LSPROG      = "/bin/ls";
$HELP_FILE   = "http://www.laben.it/utilities/help/gnats-help.html";

print "Content-type: text/html\n\n";
print "<HTML>\n";
&read_originator;
&read_editor;
&ReadParse(*in);

# Gives the interface to change the PR

    # Display title
    print "<HEAD><TITLE>Problem Report Editing</TITLE></HEAD><BODY>\n";
    $pr = $in{'pr'};
    if ($pr eq "") {
	print "<H3>Sorry</H3>\n";
	print "You must specify the number of the problem report to edit.\n";
	return;
    }
    $err = &read_pr($pr, "");
    if ($err ne "") {
	print "$err\n";
	return;
    }
    local($oldsyn) = $fieldvalues{"Synopsis"};
    local($oldstate) = $fieldvalues{"State"};
    local($oldresp) = $fieldvalues{"Responsible"};
    local($oldcategory) = $fieldvalues{"Category"};
    local($oldstartdate) = $fieldvalues{"Start-Date"};
    local($oldenddate) = $fieldvalues{"End-Date"};
    local($oldfix);
    ($oldfix = $fieldvalues{"Response"}) =~ s/"/'/g;
    # Get also ">Unformatted:" field. L.Salv. 20-mar-1997
    local($oldunformatted);
    ($oldunformatted = $fieldvalues{"Unformatted"}) =~ s/"/'/g;

    # Kludge to allow editing of Response and How-To-Repeat fields
    local($oldhowtorepeat) = $fieldvalues{"How-To-Repeat"};
    # end of kludge
    $oldresp =~ s/\s*\(.*$//; # Get rid of comment in responsible party name

    local($timestamp)=&timestamp($fullpr);


$catindom=0; # category in domain?
foreach $categ (@nCategory) {
    if ($categ eq $oldcategory) {
	$catindom=1;
    }
}
if ($catindom==0) {
    print "<P>The problem report doesn't belong to the domain $domain. You cannot modify it.<P>";
    print "\n</BODY></HTML>";
    exit(0);
}


    # The modification form
    print "
<H2>Modification Form for Problem Report nr. $pr</H2>
<B>Description: </B>" . &html_escape($oldsyn) . " <BR>

<BR>
Click <A HREF=\"$SCRIPT_NAME/full/$pr\"> here </A>
to view the full text of Problem Report number $pr
<P>
<FORM METHOD=\"POST\" ACTION=\"$SCRIPT_NAME/handle_edit_pr/$pr&$oldstate&$timestamp\">
";

    # Maximize box dimensions
    local($width)= 80;
    local($height)= 4;

 if ($username eq "1") {
	$username = ""
	}
if ($eladdress eq "1") {
	$eladdress = ""
	}

 print "<DL>
<DT><H3>Editor (you):  $username</H3>
<INPUT NAME=\"Editor\" VALUE=$username >\n
<P>
<HR>
";


    print "<DT>Normally the problem report will change 
    <A HREF=\"$HELP_FILE#state\">state</A> each time it is modified. 
    Please select a new <A HREF=\"$HELP_FILE#state\">state</A> from 
    the following list:\n";
    print "<DD>";
    print "<SELECT NAME=\"State\">\n";
    foreach $option (@nState) {
	next if (!$option);
	print "<OPTION";
	if ($option eq $oldstate) { print " SELECTED"; }
	print "> $option\n";
    }
    print 
    "</SELECT><BR>
<DT>Please give the reason for the state change here:<DD><TEXTAREA NAME=\"StateReason\" COLS=$width ROWS=2></TEXTAREA>
<BR>
";

   

    print "<DT>If the problem report has been re-assigned you will need to
    select the new responsible person from the following list:\n";
    print "<DD>";
    print "<SELECT NAME=\"Responsible\">\n";
    local($somebody_resp);

# Kludge to list only responsibles for that category

open(CATEG, "$GNATS_ADM/categories.".$domain) ||
	die "Couldn't get categories file\n";
    while (<CATEG>) {
	if (!/^\s*#|^\s*\n$/) {
	    chop;
	    @nResp = split(/:/, $_);
	    $cat=shift(@nResp);
	    $descr=shift(@nResp);
	    $a=@nResp;
	    if ($cat eq $fieldvalues{"Category"} ) {
       		$save = shift(@nResp);
		@nResp = split(/,/, $nResp[0]);
		unshift(@nResp,$save);
		foreach $option (@nResp) {
		    next if (!$option);
		   
	print "<OPTION";
		   
	if ($option eq $oldresp) { print " SELECTED"; $somebody_resp = 1; }
	print "> $option\n";
		}
    print "</SELECT><BR>\n";
		print "<DT><HR>";
	    }
	}
    }
          if (! $somebody_resp) {
	print "<B>Error! No known person responsible for this PR!</B> (PR# $pr belonging to another domain?)<HR>\n";
    }
    close(CATEG);
# end Kludge

print "<DT><A HREF=\"$HELP_FILE#occtime\">Date and time of occurrence</A>:";
print "<DD><INPUT NAME=\"Start-Date\" VALUE=\"$oldstartdate\"><BR><BR>\n";

print "<DT><A HREF=\"$HELP_FILE#endtime\">Date and time of end</A>:";
print "<DD><INPUT NAME=\"End-Date\" VALUE=\"$oldenddate\"><BR><BR>\n";

print "<DT><A HREF=\"$HELP_FILE#response\">Response</A>:";
print "<DD><TEXTAREA NAME=\"Response\" VALUE=\"$oldfix\" ROWS=15 COLS=$width>$oldfix</TEXTAREA><BR>\n";

print "<DT><A HREF=\"$HELP_FILE#repeat\">How to repeat</A>:";
print "<DD><TEXTAREA NAME=\"How-To-Repeat\" VALUE=\"$oldhowtorepeat\" ROWS=$height COLS=$width>$oldhowtorepeat</TEXTAREA>\n";

#ZZ
print "<DT><A HREF=\"$HELP_FILE#unformatted\">Unformatted</A>:";
print "<DD><TEXTAREA NAME=\"Unformatted\" VALUE=\"$oldunformatted\" ROWS=$height COLS=$width>$oldunformatted</TEXTAREA>\n";
#ZZ

print "<DT><HR>";

            $dom=$domain;
	    $dom =~ s/^-//;
#make sure that the list of categories will fit on the screen
 $mode = eval "\@nCategory" >30 ? "SIZE=5" : "";

print "<H3> Domain/Category Selection </H3>";

 print "<DT>If the problem report has been moved within the <B>$dom</B> domain
- please select the new category below:\n";
    print "<DD>";
    print "<SELECT $mode NAME=\"Category\">\n";
    foreach $option (@nCategory) {
	next if (!$option);
	print "<OPTION";
	if ($option eq $fieldvalues{"Category"}) { print " SELECTED"; }
	print "> $option\n";
    }
    print "</SELECT><BR>\n";

print "<DT><HR>";

print " If the problem report has been incorrectly filed to the <B>$dom</B> 
domain - please select the correct domain and category from the selection boxes below.<BR>";

print "<BR>";

#adding new buttons for different domains and its categories

open(DOMAIN, "$GNATS_ADM/domains") ||
	die "Couln't get domains file\n";
    while (<DOMAIN>) {
	# Test below changed to allow "# comments" in domains file
	if (!/^\s*#|^\s*\n$|^#.\n$/) {
	    $_ =~ s/^//;
	    $_ =~ s/\s.*#.*$//;
	    push(@nDomain, $_);
	}
    }
    close(DOMAIN);
    @nDomain = sort(@nDomain);
    
$i=1;


foreach $dom (@nDomain) {
 
    #Make sure that the list of categories for each domain will fit on the screen
    @nCat=&read_domain($dom);
    $mode = eval "\@nCat">10 ? "SIZE=5" : "";
    next if (!$dom);

# it seems that it appends a blank space at the end of the domain if it is not
# the first domain from the file. 
    if ($i>0) {chop($dom);}
    $i++;
 
    if ($dom ne $domain) {
    $dom =~ s/^-//;
    print "<DT>New category in <B>$dom</B> domain:";
    $dom =~ s/^/-/;
    print "<DD>";
    print "<SELECT $mode NAME=\"Category$dom\">\n";

    foreach $option (@nCat) {       
        next if (!option);
	print "<option> $option\n";
    }   
    print "</SELECT><BR>\n";

}
}
    

#end adding new buttons
   


print "</DL>\n";
print "<INPUT TYPE=\"submit\" VALUE=\"Click here to submit the changes.\">\n";
print "<INPUT TYPE=\"reset\" VALUE=\"Clear\">\n";
print "</FORM>\n";
print "\n</BODY>\n";
print "</HTML>\n";
exit(0);
