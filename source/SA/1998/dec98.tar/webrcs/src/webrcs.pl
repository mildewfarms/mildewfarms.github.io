#!/bin/perl -T
# webrcs.pl (12/30/97 rss)

require 5.004;

use strict;
use English;

#
# Global variables.
#

my ($RCSROOT, $MIN_UID, $ADMIN_EMAIL, $LOGFILE, $RCS_USER_ID, $RCS_GROUP_ID,
    $RCS_USER_DIR, $DOMAIN, $IP_DOMAIN);
my ($pathinfo, $scriptname, $content_type, $stuff, $post_stuff, $front_stuff,
    $back_stuff, $action, $revision, $boundary);
my ($remote_addr, $remote_host, $remote_browser);
my ($user, $userid, $rcsuid, $gname, $gpw, $rcsgid, $gmembers);
my ($path, $real_path, $rcs_flag, $rc);
my (@files, $next, $next_anchor, $file, $real_file, $i);
my ($rcs_status);
my ($logdir);

my $rcs_description;
my $rev_count;

my @rev = ();
my @co = ();
my @desc = ();

my ($name,$passwd,$userid,$gid,$quota,$comment,$gcos,$home_dir,$shell);

my ($rcs_dir, $rcs_file);

my $form_description;

#
# Critical variables and constants.
#

# RCSROOT must point to the top of the RCS source tree.

if ($ENV{'HTTP_HOST'} =~ /pluto/) {
  $RCSROOT = '/home/httpd/rcs';
} else {
  $RCSROOT = '/u/.rcs';
}

# $RCS_USER_ID and $RCS_GROUP_ID are the user and group ID's that "own"
# RCS files on your system.

$RCS_USER_ID = 'rcs';
$RCS_GROUP_ID = 'rcs';

# $MIN_UID is the lowest UID that could belong to a valid user on your system.

$MIN_UID = 500;

# $ADMIN_EMAIL is the email address of whoever administrates your RCS tree.

$ADMIN_EMAIL = 'webrcs@provista.com';

# $LOGFILE is used for debugging purposes.  If left blank then logging is
# turned off.

$LOGFILE = '/home/httpd/webrcs/logs/webrcs.log';

# $DOMAIN is a list of valid DNS domains for client validation (in Perl RE format).
# $ID_DOMAIN is a list of valid IP domains for client validation (in Perl RE format).
#
# Web/RCS will allow a client if it matches either DNS or IP (or both).

$DOMAIN = 'provista.com';
$IP_DOMAIN = '205.179.95';

#
# $RCS_USER_DIR is the name of user directory that holds checked out files.
# Don't use 'RCS' (upper-case) because it causes checkin problems.
#

$RCS_USER_DIR = 'rcs';

#
# Miscellaneous trivial and housekeeping subs.
#

sub Get_Date {
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)
    = localtime(time);
  return sprintf("%02d/%02d/%02d %02d:%02d:%02d",
		 ++$mon, $mday, $year, $hour, $min, $sec);
}

sub Logger {
  my $msg = shift;
  if ($LOGFILE) {
    open LOGFILE, ">>$LOGFILE";
    print LOGFILE Get_Date(), " ", $$, " ", $msg, "\n";
    close LOGFILE;
  }
}

sub fix_file_rcs($) {
  my $file = shift;
  my $cnt = chown($rcsuid, $rcsgid, $file);
  if ($cnt != 1) {
    Logger("ERROR: fix_file: $cnt");
  }
}

sub fix_file_user($) {
  my $file = shift;
  my $cnt = chown($userid, $rcsgid, $file);
  if ($cnt != 1) {
    Logger("ERROR: fix_file: $cnt");
  }
}

sub Fix_action($) {
  $_ = shift;
  s/\+//g;
  s/%(..)//g;
  return $_;
}

sub Cleanup($) {
  $_ = $_[0];
  s/\+/ /g;
  s/%(..)/sprintf("%c", hex($1))/ge;
  s/\r//g;
  $_[0] = $_;
}

sub Untaint_user($) {
  $_ = $_[0];
  /^(\w*)$/;
  $_[0] = $1;
}

sub Untaint_path($) {
  $_ = $_[0];
# /^([\w\/\.-]*)/;
  /^(.*)$/;
  $_[0] = $1;
}

sub Basename($) {
  $_ = shift;
  /.*[\/\\](.*)/;
  return $1;
}

sub Dirname($) {
  $_ = shift;
  /(.*)[\/\\]/;
  return $1;
}

#
# Subs dealing with HTML.
#

sub Html_head {
  my $title = shift || "TITLE";
  print "Content-type: text/html\n\n";
  print "<HTML>\n";
  print "<HEAD>\n";
  print "<TITLE>Web/RCS: $title</TITLE>\n";
  print "</HEAD>\n";
  print "<BODY BGCOLOR=\"#EEE9E9\" TEXT=\"#191970\">\n";
  print "<TT>\n";
  print "<B>Web/RCS: $title</B>\n";
  print "<HR NOSHADE>\n";
}

sub Html_tail {
  print "<HR NOSHADE>\n";
  print "<ADDRESS>\n";
  print "<A HREF=mailto:$ADMIN_EMAIL>$ADMIN_EMAIL</A>\n";
  print "</ADDRESS>\n";
  print "</TT>\n";
  print "</BODY>\n";
  print "</HTML>\n";
}

sub Form_Head {
  print "<FORM METHOD=POST>\n";
}

sub Form_Head_Upload {
  print "<FORM METHOD=POST ENCTYPE=\"multipart/form-data\">\n";
}

sub Form_Button ($) {
  my $value = shift;
  print "<INPUT TYPE=Submit NAME=Action VALUE=\" $value \">\n"
}

sub Form_Hide ($) {
  my $value = shift;
  print "<INPUT TYPE=Hidden NAME=Rev VALUE=$value>\n"
}

sub Form_Text_Field ($) {
  my $value = shift;
  my $text_str = Get_Date() . " $user\n";
  print "<TEXTAREA NAME=$value COLS=70 ROWS=4 WRAP>$text_str</TEXTAREA>\n";
  print "<BR>\n";
}

sub Form_File_Field ($) {
  my $value = shift;
  print "<INPUT TYPE=File NAME=$value SIZE=60 MAXLENGTH=80>\n";
}

sub Form_Tail {
  print "</FORM>\n";
}

sub Anchor {
  my ($href, $ref, $icon) = @_;
  $href =~ s/ /%20/g;
  "<NOBR><A HREF=\"$href\"><IMG BORDER=0 SRC=\"$icon\"></A>"
    .  " "
    .  "<A HREF=\"$href\">$ref</A></NOBR>\n";
}

sub Back_dir_anchor() {
  my $new_path = Dirname($path) || '/';
  my $new_anchor = $scriptname . $new_path;
  print Anchor($new_anchor, $new_path, "/webrcs_icons/left_sm.gif");
}

sub Back_file_anchor() {
  my $new_anchor = $scriptname . $path;
  print Anchor($new_anchor, $path, "/webrcs_icons/left_sm.gif");
}

sub Error {
  my $msg = shift;
  Html_head("Error");
  print $msg, "\n";
  Html_tail();
  Logger("ERROR: $msg");
  Logger("END");
  exit;
}

#
# Safe_qx is "safer" than normal backticks because it doesn't use a shell.
# However it also defeats Perl's usual taint checks, so be careful.
#

sub Safe_qx {
  my $lines;
  if (open(CHILD, "-|")) {
    $lines = <CHILD>;
    close(CHILD);
    $rc = $? >> 8;
  } else {
    open(STDERR, ">&STDOUT");
    exec @_;
  }
  return $lines;
}

#
# Get_Rlog_Info performs the important task of determing if a file is
# checked out, by whom, how may revisions are there, etc.
#

sub Get_Rlog_Info ($) {
  my $rlogfile = shift;
  $rcs_status = 'ci';
  my $i = 0;
  my $rlog_out = Safe_qx('rlog', $rlogfile);

  if ($rlog_out =~ /description:(.*?)----------------------------/s) {
    $rcs_description = $1;
  }
  my @rlog_array = split(/-{2,}\n/, $rlog_out);
  shift @rlog_array;
  foreach (@rlog_array) {
    if (/revision ([\d\.]+)/s) {
      $rev[$i] = $1;
    }
    if (/locked by: (\w+)/s) {
      $rcs_status = "co";
      $co[$i] = $1;
    }
    if (/(?:.+?\n){2}(.+?)$/s) {
      $desc[$i] = $1;
      $desc[$i] =~ s/\n={2,}//;
    }
    $i++;
  }
  $rev_count = $i;
}

sub Verify_RCS_Dir() {
  if ($RCS_USER_DIR eq '') {
    Error("\$RCS_USER_DIR is not defined");
  }
  if ($home_dir eq '') {
    Error("No home directory defined for user $user");
  }
  if (! -e $home_dir) {
    Error("Unable to read home directory \"$home_dir\" for user $user");
  }
  $rcs_dir = $home_dir . '/' . $RCS_USER_DIR . '/';
  if (! -e $rcs_dir) {
    Error("Unable to read directory \"$rcs_dir\"");
  }
  $rcs_file = $rcs_dir . Basename($path);
}

#
# The rest of these subs implement the various "Actions" that are passed
# in the POST data.
#

sub Show_File() {
  my $real_filename = Basename($path);
  print "Content-Disposition: filename=\"$real_filename\"\n";
  print "Content-type: text/plain\n\n";
  if ($rcs_flag) {
    my $stuff = Safe_qx('co', "-r$revision", '-p', $real_path);
    ($stuff) = $stuff =~ /^(?:.+?\n){2}(.*)/s;
    print $stuff;
  } else {
    open SOURCE, $real_path;
    print <SOURCE>;
    close SOURCE;
  }
}

sub Copy_File() {
  Verify_RCS_Dir();
  if (-e $rcs_file) {
    Error("File \"$rcs_file\" already exists (please delete or rename)");
  }

  Html_head("Action = Copy; Path = $path");
  print "<P>Copying from $path to $rcs_file\n";

  if ($rcs_flag) {
    $stuff = Safe_qx('co', "-r$revision", '-p', $real_path);
    ($front_stuff, $back_stuff) = ($stuff =~ /^((?:.+?\n){2})(.*)/s);

    open COPYFILE, ">$rcs_file";
    print COPYFILE $back_stuff;
    close COPYFILE;

    print "<XMP>\n";
    print "=" x 77, "\n";
    print $front_stuff;
    print "=" x 77, "\n";
    print "</XMP>\n";
  } else {
    $stuff = Safe_qx('cp', $real_path, $rcs_file);
  }
  fix_file_user($rcs_file);

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Download_File() {
  if ($rcs_flag) {
    $_ = Safe_qx('co', '-p', $real_path);
    s/^(?:.+?\n){2}//;
  } else {
    open SOURCE, $real_path;
    $_ = <SOURCE>;
    close SOURCE;
  }

# my $real_filename = Basename($path);
# print "Content-Disposition: filename=\"$real_filename\"\n";
  print "Content-Length: ", length, "\n";
  print "Content-Type: application/octet-stream\n\n";
  print;
}

sub Show_Diffs() {
  my ($i, $prior_rev, $diffs);

  Html_head("Action = Diffs; Path = $path; Revision = $revision");
  Get_Rlog_Info($real_path);

  for ($i = 0; $i < $rev_count; $i++) {
    last if $rev[$i] eq $revision;
  }
  $prior_rev = $rev[++$i];

# print "<BR>Diffs between revsion <B>$revision</B> and <B>$prior_rev</B>\n";

  $diffs = Safe_qx('rcsdiff', "-r$prior_rev", "-r$revision", $real_path);

  print "<XMP>\n";
  print $diffs;
  print "=" x 67, "\n";
  print "</XMP>\n";

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Show_Rlog_Info() {
  Html_head("Action = Rlog; Path = $path");

  print "<XMP>\n";
  print "=" x 77;
  print Safe_qx('rlog', $real_path);
  print "</XMP>\n";

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();

  Html_tail();
}

sub Lock_File() {
# my $dir = Dirname($real_path);
# chmod 0770, $dir;

  my $stuff = Safe_qx('rcs', '-l', $real_path);
  fix_file_rcs($real_path);

# chmod 0550, $dir;

  Html_head("Action = Lock; Path = $path");
  if ($rc == 0) {
    print "Lock of $path by $user was successful";
  } else {
    print "Lock of $path by $user was not successful ($rc)";
  }

  print "<XMP>\n";
  print "=" x 77, "\n";
  print $stuff;
  print "=" x 77, "\n";
  print "</XMP>\n";

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Unlock_File() {
  my $stuff = Safe_qx('rcs', '-u', $real_path);
  fix_file_rcs($real_path);

  Html_head("Action = Unlock; Path = $path");
  if ($rc == 0) {
    print "Unlock of $path by $user was successful";
  } else {
    print "Unlock of $path by $user was not successful ($rc)";
  }

  print "<XMP>\n";
  print "=" x 77, "\n";
  print $stuff;
  print "=" x 77, "\n";
  print "</XMP>\n";

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Initial_Checkin_File() {
  Html_head("Action = CheckIn; Path = $path");
  Form_Head();
  print "Enter description of $path for RCS header:<BR>\n";
  Form_Text_Field("Desc");
  Form_Button("Confirm");
  Form_Tail();

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Confirm_Initial_Checkin() {
#  my $comment = '';
#  if ($post_stuff =~ /^Desc=(.*?)&Action=\+Confirm\+/) {
#    $comment = $1;
#    Cleanup($comment);
#  }

  my $stuff1 = Safe_qx('rcs', '-i', "-t-$form_description", $real_path);
  my $rc1 = $rc;

  my $dir = Dirname($real_path);
# chmod 0770, $dir;

  my $stuff2 = Safe_qx('ci', $real_path);
  my $rc2 = $rc;

# chmod 0550, $dir;

  $real_path .= ',v';
  fix_file_rcs($real_path);

  Html_head("Action = Confirm; Path = $path");

  if (($rc1 == 0) && ($rc2 == 0)) {
    print "Check in of $path was successful\n";
  } else {
    print "Check in of $path was unsuccessful ($rc1, $rc2)\n";
  }

  print "<XMP>\n";
  print "=" x 77, "\n";
  print $stuff1;
  print "=" x 77, "\n";
  print $stuff2;
  print "=" x 77, "\n";
  print "</XMP>\n";

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();

  Html_tail();
}

sub Checkin_File_Direct() {
  Verify_RCS_Dir();
  if (! -r $rcs_file) {
    Error("Unable to read file \"$rcs_file\"");
  }

  Html_head("Action = Check In (File); Path = $path");

  Form_Head();
  print "Found file $rcs_file\n";

  my $true_name = Basename($path);
  print "<P>Enter description of this revision of $true_name for RCS header:<BR>\n";
  Form_Text_Field("Desc");

  print "<P>Hit <B>Check In</B> to check this file in against $path<BR>\n";
  Form_Button("Check In");
  Form_Tail();

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Confirm_File_Checkin() {
  Verify_RCS_Dir();
  if (! -r $rcs_file) {
    Error("Unable to read file \"$rcs_file\"");
  }

  my $tmp_rcs_file = '/tmp/' . Basename($path);

#  Logger("RCS> $real_path");
#  Logger("RCS> $rcs_file");
#  Logger("RCS> $tmp_rcs_file");

  $stuff = Safe_qx('cp', $rcs_file, $tmp_rcs_file);
  my $cnt = chown($userid, $rcsgid, $tmp_rcs_file);

  $stuff = Safe_qx('ci', "-m$form_description", $real_path, $tmp_rcs_file);

  Html_head("Action = Check In (File); Path = $path");

  if ($rc == 0) {
    print "<P>Check in of $path was successful\n";
  } else {
    print "<P>Check in of $path was unsuccessful ($rc)\n";
  }

  print "<XMP>\n";
  print "=" x 77, "\n";
  print $stuff;
  print "=" x 77, "\n";
  print "</XMP>\n";

  fix_file_rcs($real_path);

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Checkin_File_Upload() {
  Html_head("Action = Check In (Upload); Path = $path");

  Form_Head_Upload();
  print "Enter file to upload:<BR>\n";
  Form_File_Field("Upload_file");

  my $true_name = Basename($path);
  print "<P>Enter description of this revision of $true_name for RCS header:<BR>\n";
  Form_Text_Field("Desc");

  print "<P>Hit <B>Upload</B> to send this file and check it in against $path<BR>\n";
  Form_Button("Upload");

  Form_Tail();

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();
  Html_tail();
}

sub Upload_File {
  my $slen = 0;
  my ($real_name, $stuff, $comment);
  if ($post_stuff =~ /$boundary.+?;\ filename="(.*?)".*?\r\n\r\n(.*?)\r\n
                    --$boundary.+?;\ name="Desc"\r\n\r\n(.*?)\r\n
                    --$boundary/sx) {
    $real_name = Basename($1);
    $stuff = $2;
    $slen = length($stuff);
    $comment = $3;
    Cleanup($comment);
  }

  Html_head("Action = Upload; Path = $path");
  if ($slen == 0) {
    print "<B>ERROR: Can't check in file (no data received)</B>";
  } elsif ($real_name eq '') {
    print "<B>ERROR: Can't check in file (invalid upload file name)</B>";
  } else {
    my $true_name = Basename($path);
    my $temp_path = "/tmp/$true_name";
    open TEMP, ">$temp_path";
    print TEMP $stuff;
    close TEMP;
    my $cnt = chown($userid, $rcsgid, $temp_path);
    my $temp_type = ((-T $temp_path) ? 'text' : 'binary');
    my $real_type = ((-T $real_path) ? 'text' : 'binary');

#   print "<P>Temp file name: $temp_path";
    print "Upload file name: $real_name";
    print "<P>Upload file size: $slen bytes ($temp_type)\n";

    Logger("R> $real_name");
    Logger("T> $true_name");

    if ($real_name ne $true_name) {
      print "<P><B>ERROR: Can't check in file (file name mismatch)</B>";
    } elsif ($real_type ne $temp_type) {
      print "<P><B>ERROR: Can't check in file (text/binary mismatch)</B>";
    } else {

      my $stuff = Safe_qx('ci', "-m$comment", $real_path, $temp_path);

      if ($rc == 0) {
	print "<P>Check in of $path was successful\n";
      } else {
	print "<P>Check in of $path was unsuccessful ($rc)\n";
      }
      print "<XMP>\n";
      print "=" x 77, "\n";
      print $stuff;
      print "=" x 77, "\n";
      print "</XMP>\n";

      fix_file_rcs($real_path);
    }
  }

  print "<P>\n";
  Back_file_anchor();
  Back_dir_anchor();

  Html_tail();
}

sub Show_File_Info {
  Html_head("Path = $path");
  if (-T $real_path) {
    print "Type: ASCII Text\n";
  } else {
    print "Type: Binary Data\n";
  }

  my $size = (-s $real_path);
  print "<P>Size: $size bytes\n";

  if ($rcs_flag) {
    Get_Rlog_Info($real_path);

    print "<XMP>\n";
    print "RCS Description:\n";
    print "-" x 75;
    print $rcs_description;
    print "-" x 75;
    print "</XMP>\n";

    my $i;
    for ($i = 0; $i < $rev_count; $i++) {
      print "<HR NOSHADE>\n";
      print "<B>Revision $rev[$i]</B>\n";
      print "<B>(Locked by $co[$i])</B>\n" if ($co[$i]);

      print "<XMP>\n";
      print "-" x 75, "\n";
      print @desc[$i], "\n";
      print "-" x 75, "\n";
      print "</XMP>\n";

      Form_Head();

      Form_Button("View") if (-T $real_path);
      Form_Button("Copy");
      Form_Button("Download");

      if (($i < ($rev_count - 1)) && (-T $real_path)) {
	Form_Button("Diffs");
      }
      Form_Hide($rev[$i]);
      Form_Tail();
    }
    print "<HR NOSHADE>\n";

  } else {
    print "<P>Status: No RCS Information\n";
  }

  Form_Head();
  if (! $rcs_flag) {
    Form_Button("View") if (-T $real_path);
    Form_Button("Copy");
    Form_Button("Download");
    Form_Button("Check In (Init)");
  }

  if ($rcs_status eq "ci") {
    Form_Button("Lock");
  }

  if (($rcs_status eq "co") && ($user eq $co[$0])) {
    Form_Button("Check In (File)");
    Form_Button("Check In (Upload)");
    Form_Button("Unlock");
  }

  if ($rcs_flag) {
    Form_Button("Rlog");
  }

  Form_Tail();
  Back_dir_anchor();
  Html_tail();
}

#
# End of subroutines.  Real program logic starts here.
#

Logger("START");

#
# I make a global assumption that all reads are done in one big slurp.
#

undef $RS;

#
# Set up for security.
#

$ENV{'PATH'} = '/bin:/usr/bin';
delete @ENV{'IFS', 'CDPATH', 'ENV', 'BASH_ENV'};

#
# Validate the environment.
#

if ($LOGFILE ne '') {
  $logdir = Dirname($LOGFILE);
  if (! -d $logdir) {
    Error("LOGFILE does not point to a valid directory ($logdir).");
  }
}

if (! -d $RCSROOT) {
  Error("RCSROOT does not point to a valid directory.");
}

($rcsuid = getpwnam($RCS_USER_ID))
  || Error("RCS_USER_ID does not contain a valid user id for this system.");

(($gname, $gpw, $rcsgid, $gmembers) = getgrnam($RCS_GROUP_ID))
  || Error("RCS_GROUP_ID does not contain a valid group id for this system.");

#
# Validate the remote host.
#

$remote_addr = $ENV{'REMOTE_ADDR'};
$remote_host = $ENV{'REMOTE_HOST'};
$remote_browser = $ENV{'HTTP_USER_AGENT'};

Logger("\$remote_addr = $remote_addr");
Logger("\$remote_host = $remote_host");
Logger("\$remote_browser = $remote_browser");

if (($remote_addr !~ $IP_DOMAIN) && ($remote_host !~ $DOMAIN)) {
  Error("Domain error.");
}

#
# Validate the user.
#

$user = $ENV{'REMOTE_USER'};
Untaint_user($user);
Logger("\$user = $user");

#$userid = getpwnam($user);
($name,$passwd,$userid,$gid,$quota,$comment,$gcos,$home_dir,$shell) = getpwnam($user);
Logger("DIR> $home_dir");

if ($userid eq '') {
  Error("Can't determine your User ID.");
}

if ($userid < $MIN_UID) {
  Error("System-level User ID's are not allowed to use this system.");
}

if ($gmembers !~ /\b$user\b/) {
  Error("System Error: User $user is not a member of Group $RCS_GROUP_ID (members = $gmembers)");
}

#
# Change the group ID.
#

$ERRNO = 0;
$GID = $EGID = $rcsgid;
if ($ERRNO != 0) {
  Error("System Error: Unable to set Group ID to $rcsgid ($ERRNO)");
}

Logger ("G=$GID E=$EGID");

#
# Change the user ID.
#

$ERRNO = 0;
$UID = $userid;
if ($ERRNO != 0) {
  Error("System Error: Unable to set User ID to $userid ($ERRNO)");
}

Logger ("U=$UID E=$EUID");

#
# Get the rest of the environment information and GET/POST data.
#

$pathinfo = $ENV{'PATH_INFO'};
Logger("\$pathinfo = $pathinfo");
Untaint_path($pathinfo);

$scriptname = $ENV{'SCRIPT_NAME'};
Untaint_path($scriptname);

$content_type = $ENV{'CONTENT_TYPE'};

$post_stuff = <STDIN>;

Logger($post_stuff);

if ($post_stuff ne '') {
  if ($content_type =~ /multipart\/form-data; boundary=(.*)/ ) {
    $action = "Upload";
    $boundary = $1;
  } elsif ($post_stuff =~ /^Desc=(.*?)&Action=(.+)/) {
    $form_description = $1;
    Cleanup($form_description);
    $action = Fix_action($2);
  } elsif ($post_stuff =~ /^Action=(.+?)&Rev=([\d\.]+)/) {
    $action = Fix_action($1);
    $revision = $2;
  } elsif ($post_stuff =~ /^Action=(.+)/) {
    $action = Fix_action($1);
  } else {
    Error("System Error: Unable to interpret POST data");
  }
}

Logger("\$action = $action");
Logger("\$revision = $revision");
Logger("\$form_description = $form_description");

if ($pathinfo) {
  $path = $pathinfo;
  $real_path = $RCSROOT . $path;
} else {
  $path = '/';
  $real_path = $RCSROOT;
}

# Logger("\$path = $path");
# Logger("\$real_path = $real_path");

#
# Validate the path that was passed.
#

if (! -e $real_path) {
  $real_path .= ',v';
  if (! -e $real_path) {
    Error("Unable to read path \"$path\"");
  }
  $rcs_flag = 1;
}

#
# Now process the path info.
#

if (-d $real_path) {
  opendir RCSDIR, $real_path;
  @files = readdir RCSDIR;
  closedir RCSDIR;

  shift @files;
  shift @files;

  Html_head("Path = $path");

  if ($path ne '/') {
    $next = Dirname($path) || '/';
    $next_anchor = $scriptname . $next;
    print Anchor($next_anchor, $next, "/webrcs_icons/left_lg.gif");
    print "<BR>";
  }

  foreach $file (sort @files) {
    if ($i) { print "<BR>" } else { $i = 1 }
    if ($path eq '/') {
      $next_anchor = "$scriptname/$file";
    } else {
      $next_anchor = "$scriptname$path/$file";
    }
    $real_file = "$real_path/$file";
    if (-d $real_file) {
      print Anchor($next_anchor, $file, "/webrcs_icons/rcs_fldr.gif");
    }
    elsif (-f $real_file) {
      if ($file =~ /,v$/) {
	$file =~ s/,v//;
	$next_anchor =~ s/,v//;
	Get_Rlog_Info($real_file);
	if ($rcs_status eq 'ci') {
	  print Anchor($next_anchor, $file, "/webrcs_icons/rcs_in.gif");
	} else {
	  print Anchor($next_anchor, $file, "/webrcs_icons/rcs_out.gif");
	}
      } else {
	print Anchor($next_anchor, $file, "/webrcs_icons/rcs_txt.gif");
      }
    }
  }
  Html_tail();
}
elsif (-f $real_path) {
  if ($action eq "View") {
    Show_File();

  } elsif ($action eq "Copy") {
    Copy_File();

  } elsif ($action eq "Download") {
    Download_File();

  } elsif ($action eq "Diffs") {
    Show_Diffs();

  } elsif ($action eq "Rlog") {
    Show_Rlog_Info();

  } elsif ($action eq "Lock") {
    Lock_File();

  } elsif ($action eq "Unlock") {
    Unlock_File();

  } elsif ($action eq "CheckInInit") {
    Initial_Checkin_File();

  } elsif ($action eq "Confirm") {
    Confirm_Initial_Checkin();

  } elsif ($action eq "CheckInFile") {
    Checkin_File_Direct();

  } elsif ($action eq "CheckIn") {
    Confirm_File_Checkin();

  } elsif ($action eq "CheckInUpload") {
    Checkin_File_Upload();

  } elsif ($action eq "Upload") {
    Upload_File();

  } else {
    Show_File_Info();
  }

} else {
  Error("Unable to read path \"$path\" (unexpected error)");
}

Logger("END");

#
# webrcs.pl ends here
