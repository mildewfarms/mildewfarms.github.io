#!/bin/perl
# ci.pl (01/26/98 rss)

use lib '/home/rss/webrcs';
require 'webrcs_lib.pl';

foreach $file (@ARGV) {

  $string = "My Initial Checkin";

  if ($file =~ /,v$/) {
    print "$file: already in\n";
  } else {
    @stuff = Safe_qx('ci', '-i', "-t-$string", $file);
    print "$file: \$rc = $rc\n";
  }
}

#
# ci.pl ends here
