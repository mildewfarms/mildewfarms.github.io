#define REAL_PATH "/home/httpd/webrcs/src/webrcs.pl"
main(ac, av)
  char **av;
{
  execv(REAL_PATH, av);
}
