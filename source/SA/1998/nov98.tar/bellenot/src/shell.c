#include <stdlib.h>
#include <unistd.h>

/* char* host = "DISPLAY=DISPLAY_HOST:0.0";*/
char* host = "DISPLAY=localhost:0.0";

int main( int argc, char ** argv ) {
    putenv ( host );
    putenv ( "SHELL=/bin/ksh" );
    chdir ( "CONFIG_TOP/src/" );
    return system ("./account.tcl");
}

