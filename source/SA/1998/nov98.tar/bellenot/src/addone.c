#include <stdlib.h>
#include <stdio.h>
#include <strings.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>

#define MAX_STUDENT 50
const int TRUE = 1;
const int FALSE = 0;

int gid = 506;
int uid_count;

typedef struct student
{
	char first[80];
	char last[80];
	int  new_account;
	char login[9];
	int uid;
	char passwd[20];
	char cpasswd[20];
} Student;

Student data[MAX_STUDENT];

void getpasswd( char passwd[] );
void pwcrypt( char src[], char dest[] );
int get_start_uid ( void );
int MergeNetgroups();
void AddItem ( char * name );
void fileunlock ();
int filelock ();
int cp (char * src, char * dst );
int shell ( char* arg1, char* arg2 );

/* calling sequence, First-Name Last-Name Encrypted-passwd */

int main ( int argc, char ** argv )
{
	int i, j, k;
	int NetFail;
	int olduid;
	FILE * fp, *outp, * pw, * net;
	char buf[100];
	char first[100];
	char last[100];
	char netbuff[20];

	if ( argc != 4 )
	{
		printf ("Usage: addone firstname lastname encyrptedpasswd\n");
		exit ( 1 );
	}
#if 0
	The chdir is done in accout.tcl
	if ( chdir ( "CONFIG_TOP/src" ) != 0 )
	{
		perror("chdir");
		printf ( "Can't cd to CONFIG_TOP/src\n" );
		exit ( 1 );
	}
#endif
#if 0
	The old system expect a file of student names
	if ( ! ( fp = fopen ( argv[1], "r" ) ) )
	{
		printf ( "Can't open %s\n", argv[1] );
		exit ( 1 );
	}
#endif
	sprintf ( buf, "addone.out" );
	if ( ! ( outp = fopen ( buf, "w" ) ) )
	{
		perror("addone.out");
		printf ( "Can't open %s\n", buf );
		exit ( 1 );
	}
	if ( ! ( pw = fopen ( "temp.pw", "w" ) ) )
	{
		perror("temp.pw");
		printf ( "Can't open temp.pw\n" );
		exit ( 1 );
	}
	if ( ! ( net = fopen ( "temp.net", "w" ) ) )
	{
		perror("temp.net");
		printf ( "Can't open temp.net\n" );
		exit ( 1 );
	}
	if ( (olduid = getuid()) < 0 )
	{
		perror("getuid");
		exit ( 1 );
	}
	if ( setuid(0) < 0 )
	{
		perror ( "setuid" );
		exit ( 1 );
	}
	/*system ( "/bin/cp /etc/nis.master/passwd /etc/ulab/passwd.bak" ); */
	cp ( "../nis/passwd", "../nis/passwd.bak" );

	i =  0;
	uid_count = get_start_uid();
	strncpy ( data[i].first, argv[1], 80 );
	data[i].first[0] = toupper ( data[i].first[0] );
	j = 1;
	while ( (j < 80) && data[i].first[j] )
	{
		data[i].first[j] = tolower ( data[i].first[j] );
		j++;
	}

	strncpy ( data[i].last, argv[2], 80 );
	data[i].last[0] = toupper ( data[i].last[0] );
	j = 1;
	while ( (j < 80) && data[i].last[j] )
	{
		data[i].last[j] = tolower ( data[i].last[j] );
		j++;
	}

	strncpy ( data[i].cpasswd, argv[3], 20 );
	strncpy ( data[i].passwd, argv[3], 20 );
	/* The old system handled a class at a time
	while ( ( i < MAX_STUDENT) &&
		( 2 == fscanf ( fp, "%s %s", data[i].first, data[i].last ) ) )
	*/
	{
		data[i].login[0] = (data[i].first[0]); /* first initial */
		j = 1; k = 0;
		while ( j < 8 )
		{
			if ( isalpha ( data[i].last[k] ) )
			{
				data[i].login[j] = data[i].last[k];
				j++;
			}
			else if ( ! data[i].last[k] )
			{
				data[i].login[j] = data[i].last[k];
				j++;
				break;
			}
			k++;
		}
		/*strncpy ( &data[i].login[1], data[i].last, 7 ); last name <=7 */
		data[i].login[8] = '\0';
		for ( j = 0; j < 8; j++ ) /* every thing in lower case. */
			data[i].login[j] = tolower(data[i].login[j]);

		/*sprintf ( buf, "grep '^%s:' /etc/nis.master/passwd > /dev/null", */
		sprintf ( buf, "grep '^%s:' ../nis/passwd.bak > /dev/null",
			data[i].login );

		data[i].new_account = TRUE;
		if ( ! system ( buf ) )
		{
			printf ( "%s: match found\n", data[i].login );
			data[i].new_account = FALSE;
			fprintf( outp, "%s %s Already has an account with login %s\n",
			data[i].first, data[i].last, data[i].login );
		
			goto outofhere;
		}

		data[i].uid = uid_count++;
		/* The old system randomly generated passwords and assigned them
		getpasswd ( data[i].passwd );
		pwcrypt ( data[i].passwd, data[i].cpasswd );

		fprintf ( outp, "%s %s has login %s and password %s\nemail address %s@math.fsu.edu\nThis account valid on taylor.math.fsu.edu\n\n\n\n",
		*/
		fprintf ( outp, "%s %s has login %s added by %s\n",
			data[i].first, data[i].last, data[i].login, "TO BE ADDED" );
			

		fprintf ( pw, "%s:%s:%d:%d:%s %s:/home/m0/%s:/bin/csh\n",
			data[i].login, data[i].cpasswd, data[i].uid,
			gid, data[i].first,
			data[i].last, data[i].login ); 

		fprintf ( net, " (,%s,)", data[i].login );
		sprintf ( netbuff, "(,%s,)", data[i].login );
		AddItem ( netbuff );
		
		i++;
	}

	/*system ( "cp ../nis/netgroup ." );*/
	cp ( "../nis/netgroup", "netgroup" );
	if ( NetFail = MergeNetgroups() )
		fprintf ( stderr, "MergeNetgroups failed\n" );
	else 
	{
		if ( filelock() < 0 )
		{
			NetFail = 1;
		}
		else
		{
			/*system ( "mv netout ../nis/netgroup" ); */
			cp ( "netout", "../nis/netgroup" );
			fileunlock();
		}
	}

	fprintf ( net, "\n" );
	fclose ( net );
	fclose ( pw );
	fclose ( outp );

	if ( filelock() < 0 )
	{
		fprintf ( stderr,  "Update passwd by hand\n"  );
	}
	else
	{
		/*system ( "./vipw.kludge" ); */
		shell ( "./vipw.kludge", NULL );
		fileunlock();
		/*system ( "ypmake" ); */
		shell ( "./ypmake", NULL );
	}


	for ( j = 0; j < i; j++ )
	{
		printf ( "<%s><%s>  <%s><%s> <%s>\n",
			data[j].first, data[j].last,
			data[j].login, data[j].passwd, data[j].cpasswd );
		/* shell ( "./copyfiles.sh", data[j].login ); */
		shell ( "./copyfiles.sh", data[j].login );
		system ( "/bin/mailx -s NewAccount  root < addone.out" );
	}

	if ( NetFail )
		printf ( "\n\n\nfix ../nis/netgroup\n" );

	return 0;

outofhere:
	fclose ( outp );
	system ( "/bin/mailx -s NewAccount  root < addone.out" );
}
