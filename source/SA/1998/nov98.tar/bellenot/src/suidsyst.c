#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>

int shell ( char* arg1, char* arg2 ) {
	pid_t pid, qid;
	char* childArgV[4];
	childArgV[0] = "/bin/sh";
	childArgV[1] = arg1;
	childArgV[2] = arg2;
	childArgV[3] = NULL;

	if ( (pid = fork()) == 0 ) { /* I am the child */
		execv("/bin/sh", childArgV);
		/* cannot get here */
	} else { /* I am the parent */
		int status;
		while ( qid = wait ( & status ) ) {
			if ( ( qid == -1 ) && (errno == ECHILD) ) {
				fprintf ( stderr, "Parent has no children" );
				return 1;
			}
			if ( qid == pid )
				break;
		}
		return (status & 0xff00)>>8;
	}
}

#if MAIN
main() {
	return shell ( "./echo", "hello world" );
}
#endif

