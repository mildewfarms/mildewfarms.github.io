#!/bin/sh
#
temp=`date '+%Y/%m/%d:%T'`
echo $temp $LOGNAME --\> $* >> ../var/account.log
