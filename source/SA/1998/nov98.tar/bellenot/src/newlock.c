#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

static char *fname = "../nis/.pwd.lock";
static int fd;

int filelock () {
	struct flock lock;
	fd = open ( fname, O_RDWR);

	if ( fd < 0 ) {
		fprintf ( stderr, "Can't open %s\n", fname );
		perror ( "open" );
		return (-1);
	}

	lock.l_type = F_WRLCK;
	lock.l_start = 0;
	lock.l_whence = SEEK_SET;
	lock.l_len = 0; /* whole file */

	if ( fcntl ( fd, F_SETLKW, &lock) < 0 ) {
		fprintf ( stderr, "Can't lock %s\n", fname );
		close ( fd );
		return (-1);
	} 
	return (0);
}

void fileunlock () {
	struct flock lock;
	lock.l_type = F_UNLCK;
	lock.l_start = 0;
	lock.l_whence = SEEK_SET;
	lock.l_len = 0; /* whole file */

	if ( fcntl ( fd, F_SETLK, &lock) < 0 ) {
		fprintf ( stderr, "Can't unlock %s\n", fname );
	} 
	close ( fd );
}
