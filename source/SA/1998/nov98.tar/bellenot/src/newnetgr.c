#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char InName[] = "netgroup";
char OutName[] = "netout";

FILE* InFile;
FILE* OutFile;

#define BUF_SIZE 8096
#define MAX_LEN 1010
char buf[BUF_SIZE];
int item_size;
int item_current;
char ** item;

void AddItem ( char * name ) {
	int i;
	char ** data;
	int new_size;

	if ( item_current == item_size ) {
		if ( item_size < 1024 )
			new_size = 1024;
		else
			new_size *= 2;

		data = malloc ( new_size * sizeof ( char*) );

		for ( i = 0; i < item_size; i++ )
			data[i] = item[i];

		free ( item );
		item = data;
		item_size = new_size;
	}

	item[item_current] = malloc ( strlen(name) + 1 );
	strcpy ( item[item_current], name );
	item_current++;
}

int compareItems ( const void * a, const void * b ) {
	char *s = *(char **) a;
	char *t = *(char **) b;
	return strcmp ( s, t );
}

void SortItems() {
	qsort ( (void *) item, item_current, sizeof(char *), compareItems );
}

void OutputUlabGroups() {
	int i, j = 0;
	int running_len;

	for ( i = 0; i < 128; i++ ) /* there is a limit to this */
	{
		fprintf ( OutFile, "ulab%d", i );

		running_len = 7; 

		while ( MAX_LEN > running_len + strlen(item[j]) + 1 ) {
			running_len += strlen(item[j]) + 1;
			fprintf ( OutFile, " %s", item[j] );
			j++;

			if ( j  >= item_current ) {
				fprintf ( OutFile, "\n" );
				goto done;
			}
		}
		fprintf ( OutFile, "\n" );
		if ( j  >= item_current ) {
			goto done;
		}
	}
	if ( j < item_current ) {
		fprintf ( stderr, "Too Many Students (More than 128 * 80 )\n" );
		fprintf ( stderr, "Truncating: " );
		for ( i = j; i < item_current; i++ )
			fprintf ( stderr, " %s", item[j] );
		fprintf ( stderr, "\n" );
	}
done:
	fprintf ( OutFile, "ulab" );
	for ( j = 0; j <= i; j++ )
		fprintf ( OutFile, " ulab%d", j );
	fprintf ( OutFile, "\n" );
}

void ProcessUlabLine ( char * buf ) {
	char * token;

	if ( strncmp ( buf, "ulab ", 5 ) == 0 )
		return;
	else {
		if ( (token = strtok ( buf, " " )) == NULL  ) {
			fprintf ( stderr, "Something is Wrong\n" );
		}
		while ( token = strtok ( NULL, " " ) ) {
			AddItem ( token );
		}
	}
}

int getline ( char* buf, int bufSize ) {
	int c;
	int i = 0;
	while ( ( c = getc ( InFile ) ) != EOF ) {
		if ( c == '\n' ) {
			buf[i] = '\0';
			return 1;
		}
		buf[i++] = c;
		if ( i >= bufSize ) {
			fprintf ( stderr, "Buffer over run\n" );
			buf[i-1] = '\0';
			return -1;
		}
	}
	return 0;
}

int MergeNetgroups() {
	InFile = fopen ( InName, "r" );
	if ( !InFile ) {
		fprintf ( stderr, "Could Not Open: %s\n", InName );
		return -1;
	}

	OutFile = fopen ( OutName, "w" );
	if ( !OutFile ) {
		fprintf ( stderr, "Could Not Open: %s For Writing\n",
			OutName );
		return -1;
	}

	for ( ;; ) {
		if ( ! getline( buf, BUF_SIZE ) )
			break;
		if ( strncmp ( buf, "ulab", 4  ) != 0 ) {
			fprintf ( OutFile, "%s\n", buf );
		} else {
			ProcessUlabLine ( buf );
		}
	}
	fclose ( InFile );
	SortItems();
	OutputUlabGroups ();
	fclose ( OutFile );
	return 0;
}
