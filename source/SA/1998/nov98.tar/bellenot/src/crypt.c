#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
char list[]= "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789./";
int num = sizeof(list)-1;

void seed () {
	unsigned long seed;
	struct timeval t;
	struct timezone tz;

	gettimeofday ( &t, &tz );
	seed = t.tv_usec + t.tv_sec;
	srand48 ( seed );
}

int rn ( int n ) {
	return (int) (drand48() * n);
}

main ( int argc, char ** argv ) {
	char salt[3];

	if ( argc != 2 ) {
		printf ( "*\n" ); /* No password */
	} else {
		seed();
		salt[0] = list[rn(num)];
		salt[1] = list[rn(num)];
		printf ( "%s\n", crypt( argv[1], salt ) ); /* encrypted passwd */
	}
	return 0;
}
