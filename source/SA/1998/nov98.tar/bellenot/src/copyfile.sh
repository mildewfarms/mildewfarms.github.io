#! /bin/sh -p
#
if [ $# != 1 ]; then
	echo Usage copyfiles.sh login-name
	exit 1;
fi
# exit early for testing
echo "copyfiles.sh $1 called but not done"
exit 0;
# The real stuff
login=$1
	echo "   ...creating home directory"
	mkdir /home/m0/$login
	mkdir /home/m0/$login/Mail
	chmod 700 /home/m0/$login/Mail
	echo "   ...copying dotted files"
	cp -r /home/m1/NEW/.[a-zA-Z]* /home/m0/$login
ex /home/m0/$login/.login << HERE
/setenv PRINTER lw/s/lw/ulab/
wq
HERE
	chown -R $login /home/m0/$login
	chgrp -R classf96 /home/m0/$login
	/usr/sbin/edquota -p ulabnew $login
	echo "   ...creating printer permissions"
	touch /home/m1/lp/users/$login
	echo "   ...setting quotas"
	rsh taylor /usr/sbin/edquota -p ulabnew $login
	#echo "   ...updating yellow pages"
	echo "   ...mailing welcome letter"
	mail $login < /etc/ulab/src/ulab.letter
	echo " "

