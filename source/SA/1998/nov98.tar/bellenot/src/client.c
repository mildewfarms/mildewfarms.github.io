#include <stdlib.h>

/* change NIS-master to your NIS-master */
char* login_cmd = "rlogin NIS-master";

/* I'm not sure why this is not a shell script. */
int main ( int argc, char ** argv )
{
    system ( login_cmd  );
}
