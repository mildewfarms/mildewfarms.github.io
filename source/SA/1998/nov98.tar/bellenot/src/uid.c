#include <stdio.h>

/* find the earliest unused uid above 20000. The 32767 kludge is for nobody. */
int get_start_uid ( void ) {
	FILE * pw;
	char buf[200];
	int j, temp, uid_temp = 20000;

	pw = fopen ( "../nis/passwd", "r" );

	while ( fgets( buf, 200, pw ) ) {
		j = 0;
		while ( buf[j++] != ':' ) /* skip user name */
			;
		while ( buf[j++] != ':' ) /* skip passwd */
			;

		sscanf ( &buf[j], "%d", &temp ); /* read uid */

		if ( temp < 32767 )
			uid_temp = ( temp > uid_temp )? temp: uid_temp;
	}

	fclose ( pw );
	return uid_temp + 1;
}
