#!/usr/bin/perl
eval 'exec /usr/opt/perl5/bin/perl -S $0 ${1+"$@"}'
    if $running_under_some_shell;
			# this emulates #! processing on NIH machines.
			# (remove #! line above if indigestible)

eval '$'.$1.'$2;' while $ARGV[0] =~ /^([A-Za-z_0-9]+=)(.*)/ && shift;
			# process any FOO=bar switches

$[ = 1;			# set array base to 1

$BEGINTOPRINT = 0;
$BEGINTOPRINT1 = 0;
$FNAME = ' ';
$DONEPRINTING1 = 0;
$DONEPRINTING = 0;

while (<>) {
    #chomp;	# strip record separator
    @Fld = split(' ', $_, 9999);

    if ($BEGINTOPRINT =~ /1/) {
	if ($Fld[1] =~ /end/) {
	    $BEGINTOPRINT = 0;
	    $BEGINTOPRINT1 = 0;
            $DONEPRINTING1 = 1;
            $FNAME=">/dev/null";
	}
        if ($DONEPRINTING1 =~ /0/) {
            $STUFFTOPRINT=$_;
        }
        else
        {
            $STUFFTOPRINT="";
        }
    }
    if ($BEGINTOPRINT1 =~ /1/) {
    }
    if ($BEGINTOPRINT1 =~ /1/) {
	if ($BEGINTOPRINT =~ /1/) {
            if ($DONEPRINTING1 =~/1/)
            {
                $DONEPRINTING=1;
            }
            else
            {
                if ($DONEPRINTING1 =~/0/)
                {
                    open (FNAME,">>tsm.$FNAME");
	            print FNAME $STUFFTOPRINT;
                    close (FNAME);
                    chmod 0755,"tsm.$FNAME";
                }
            }
	}
    }
    if ($BEGINTOPRINT1 =~ /1/) {
	$BEGINTOPRINT = 1;
    }
    if ($Fld[1] =~ /begin/) {
	$FNAME = $Fld[2];
	#print "FILENAME is " FNAME
	$BEGINTOPRINT1 = 1;
	$DONEPRINTING = 0;
	$DONEPRINTING1 = 0;
    }
}
