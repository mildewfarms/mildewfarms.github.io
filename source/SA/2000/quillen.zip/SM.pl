#################################################################
### 
###  Script Manager 1.0 by Edward Quillen (ed@quillen.net)
###
###  CopyRight 1999
###
###  Run this command with no options for get help
###
#################################################################

use Globals;
use Misc;
use Repos;
use Level;
use Script;
use MyUtil;

################################################################
##### HANDLE SIGNALS ###########################################
sub myexit {
  local($rcode)=@_;
  ( $rcode !~ /^\d/ ) and $rcode=99;  #caught a signal
  Repos::close_all;
  system("rm -f /tmp/sm.$$.* 2> /dev/null");
  exit $rcode; 
}
$SIG{INT}='myexit';
$SIG{QUIT}='myexit';
###############################################################

Misc::load_all_config_files;

&separate_args;

### process command line arguments ###############################
$command=shift @ARGV || "";
$command=MyUtil::trim($command);
( $command ne "init_repos" and $command ne "" ) and Repos::open($Globals::curr_repos);

if ( $command eq "run" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  run_script($scriptpath,@ARGV);
}elsif ( $command eq "info" ) {
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name and not a level. Aborting...\n";
    myexit 4;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:script [$scriptpath] does not exist. Aborting...\n";
    myexit 6;
  }
  Script::display_info($scriptpath);
}elsif ( $command eq "show_family" ) {
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name and not a level. Aborting...\n";
    myexit 4;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:script [$scriptpath] does not exist. Aborting...\n";
    myexit 6;
  }
  list_all_relatives($scriptpath);
}elsif ( $command eq "cat" ) {
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name and not a level. Aborting...\n";
    myexit 4;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:script [$scriptpath] does not exist. Aborting...\n";
    myexit 6;
  }
  Script::cat($scriptpath);
}elsif ( $command eq "pwd" or $command eq "cwd" ) {
  Level::cwd;
}elsif ( $command eq "cd" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  $scriptpath=MyUtil::trim($scriptpath);
  if ( $scriptpath eq "\.\." ) {
    Globals::get_level ne "/" and Globals::set_level(MyUtil::parent_dir(Globals::get_level));
  }else {   
    if ($scriptpath) {
      #must have forgot to add /
      ( $scriptpath =~ /\/$/ ) or $scriptpath .= "/";
    }
    ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
    if ( $scriptname ) {
      print "SM:ERROR:must specify a level name. HINT: append a /?. Aborting...\n";
      myexit 6;
    }
    if ( ! Repos::islevel($level) ) {
      print "SM:ERROR:level [$level] does not exist. Aborting...\n";
      myexit 5;
    }
    Globals::set_level($level);
  }
}elsif ( $command eq "doc" or $command eq "man" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name. Aborting...\n";
    myexit 6;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:$scriptpath does not exist. Aborting...\n";
    myexit 24;
  }
  Script::show_doc($scriptpath);
}elsif ( $command eq "replace" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name. Aborting...\n";
    myexit 6;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:$scriptpath does not exist. Aborting...\n";
    myexit 24;
  }
  $fpath=shift @ARGV || "";
  $fpath=MyUtil::trim($fpath);
  if ( ! $fpath ) {
    Misc::show_usage();
    myexit 20;
  }
  if ( ! -r $fpath ) {
    print "SM:ERROR:could not read input script file [$fpath]. Aborting...\n";
    myexit 25;
  }
  Script::replace($scriptpath,$fpath);
}elsif ( $command eq "submit_doc" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name. Aborting...\n";
    myexit 6;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:$scriptpath does not exist. Aborting...\n";
    myexit 24;
  }
  $fpath=shift @ARGV || "";
  $fpath=MyUtil::trim($fpath);
  if ( ! $fpath ) {
    Misc::show_usage();
    myexit 20;
  }
  if ( ! -r $fpath ) {
    print "SM:ERROR:could not read input doc file [$fpath]. Aborting...\n";
    myexit 25;
  }
  Script::submit_doc($scriptpath,$fpath);
}elsif ( $command eq "create" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name. Aborting...\n";
    myexit 6;
  }
  if ( Repos::exists($scriptpath) ) {
    print "SM:ERROR:$scriptpath alerady exists. Aborting...\n";
    myexit 19;
  }
  if ( ! Repos::islevel($level) ) {
    print "SM:ERROR:level [$level] does not exist. Aborting...\n";
    myexit 18;
  }
  $fpath=shift @ARGV || "";
  $fpath=MyUtil::trim($fpath);
  if ( ! $fpath ) {
    Misc::show_usage();
    myexit 20;
  }
  if ( ! -r $fpath ) {
    print "SM:ERROR:could not read input script file [$fpath]. Aborting...\n";
    myexit 21;
  }
  Script::create($scriptpath,$fpath);
}elsif ( $command eq "mkdir" or $command eq "create_level" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  $scriptpath=MyUtil::trim($scriptpath);
  if ( $scriptpath ) { ( $scriptpath =~ /\/$/ ) or $scriptpath .= "/"; }
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( $scriptname ) {
    print "SM:ERROR:must specify a level name. HINT: append a /. Aborting...\n";
    myexit 6;
  }
  if ( Repos::islevel($scriptpath) ) {
    print "SM:ERROR:level [$scriptpath] already exist. Aborting...\n";
    myexit 33;
  }
  if($level ne "/") {
    $pdir=MyUtil::parent_dir($level);
    if ( ! Repos::islevel($pdir) ) {
      print "SM:ERROR:parent level [$pdir] does not exist. Aborting...\n";
      myexit 8;
    }
  }else { $pdir="/"; }
  Level::create($scriptpath);
}elsif ( $command eq "list" or $command eq "ls" or $command eq "dir" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  $scriptpath=MyUtil::trim($scriptpath);
  if ( $scriptpath ) {
    ( $scriptpath =~ /\/$/ ) or $scriptpath .= "/";
    ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
    if ( $scriptname ) {
      print "SM:ERROR:must specify a level name. Aborting...\n";
      myexit 6;
    }
    if ( ! Repos::islevel($level) ) {
      print "SM:ERROR:level [$level] does not exist. Aborting...\n";
      myexit 5;
    }
  }else {
    $level=Globals::get_level;
  }
  Level::cwd;
  foreach $child (Level::list($level)) {
    if ( $child =~ /\/$/ ) {
      push @dlist, $child;
    }else {
      push @slist, $child;
    }
  }
  foreach $child (sort @dlist) {
    $desc=Script::getdesc("$level$child");
    print "$child - $desc\n";
  }
  foreach $child (sort @slist) {
    $desc=Script::getdesc("$level$child");
    if ( Script::hasdoc("$level$child") ) {
      print "$child* - $desc\n";
    }else {
      print "$child - $desc\n";
    }
  }
  print "\nNOTE: a * means that script has a doc (use: sm doc <script>)\n\n";
}elsif ( $command eq "apropos" ) {
  $word=shift @ARGV || "";
  if ( $word ) {
    Script::apropos($word);
  }else {
    Misc::show_usage;
    myexit 20
  }
}elsif ( $command eq "remove_doc" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name. Aborting...\n";
    myexit 6;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:$scriptpath does not exist. Aborting...\n";
    myexit 24;
  }
  Script::remove_doc($scriptpath);
}elsif ( $command eq "list_shells" ) {
  while ( ($key,$val) = each %Globals::shelldefs ) {
    print "\t$key => $val\n"
  }
}elsif ( $command eq "list_repos" ) {
  while ( ($key,$val) = each %Globals::reposdefs ) {
    print "\t$key => $val\n"
  }
}elsif ( $command eq "report" ) {
  $repname=shift || "";
  if ( ! $repname ) {
    Misc::show_usage;
    myexit 43;
  }
  $repname=MyUtil::trim($repname);
  if ( $repname eq "lastrun" ) {
    foreach $path (Level::recurse("/")) {
      ( $path =~ /\/$/ ) and next; #skip over levels
      $lastrun=Script::get_lastrun($path);
      if ( $lastrun ) {
        $atime=localtime($lastrun);
        print "$path - $lastrun - $atime\n";
      }else {
        print "$path - never - never\n";
      }
    }
  }else {
    Misc::show_usage;
    myexit 43;
  }
}elsif ( $command eq "recurse" ) {
  foreach $path (Level::recurse("/")) {
    print "$path\n";
  }
}elsif ( $command eq "delete" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! Repos::exists($scriptpath) ) {
    if ( $scriptpath =~ /\/$/ ) {
      #specified a level, nothing more to try
      print "SM:ERROR: path [$scriptpath] does not exist. Aborting...\n";
      myexit 13; 
    }else {
      #maybe the person was lazy and forgot the trailing /
      ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath . "/");
      if ( ! Repos::exists($scriptpath) ) {
        print "SM:ERROR: path [$scriptpath] does not exist. Aborting...\n";
        myexit 13; 
      }
      #ok...lets continue on
    }
  }
  if ( ! $scriptname ) {
    #is a level
    if ( Level::list($scriptpath) ) {
      #the level is not empty, no delete
      print "SM:ERROR: level [$scriptpath] is not empty. Aborting...\n";
      myexit 12;
    }
  }
  if ( continue_after_relative_check($scriptpath) ) {
    Repos::delete_entry($scriptpath);
  }
}elsif ( $command eq "move" ) {
  $srcpath=shift @ARGV || "";
  ($srcpath,$srclevel,$srcscriptname)=process_path_arg($srcpath);
  if ( ! Repos::exists($srcpath) ) {
    if ( $srcpath =~ /\/$/ ) {
      #specified a level, nothing more to try
      print "SM:ERROR: path [$srcpath] does not exist. Aborting...\n";
      myexit 13; 
    }else {
      #maybe the person was lazy and forgot the trailing /
      ($srcpath,$srclevel,$scriptname)=process_path_arg($srcpath . "/");
      if ( ! Repos::exists($srcpath) ) {
        print "SM:ERROR: path [$srcpath] does not exist. Aborting...\n";
        myexit 13; 
      }
      #ok...lets continue on
    }
  }
  if ( $srcpath eq "/" ) {
    print "SM:ERROR:moving / would not be a good idea. Aborting...\n";
    myexit 14;
  }
  $dstpath=shift @ARGV || "";
  $dstpath=MyUtil::trim($dstpath);
  if ( $dstpath ) { ( $dstpath =~ /\/$/ ) or $dstpath .= "/"; }
  ($dstpath,$dstlevel,$dstscriptname)=process_path_arg($dstpath);
  if ( ! Repos::exists($dstpath) ) {
    print "SM:ERROR: path [$dstpath] does not exist. Aborting...\n";
    myexit 13; 
  }
  if ( $dstscriptname ) {
    print "SM:ERROR:must specify a level as the destination. Aborting...\n";
    myexit 6;
  }
  ### now we have a valid path to move to a valid level ###
  $srcchildpath=MyUtil::child_path($srcpath);
  $newpath="$dstpath$srcchildpath";
  if ( Repos::exists($newpath) ) {
    print "SM:ERROR:cannot move $srcchildpath because it already exists in $dstpath. Aborting...\n";
    myexit 15;
  } 
  if ( continue_after_relative_check($srcpath) ) {
    Repos::move_entry($srcpath,$newpath); 
  }
}elsif ( $command eq "rename" ) {
  $srcpath=shift @ARGV || "";
  ($srcpath,$srclevel,$srcscriptname)=process_path_arg($srcpath);
  if ( ! Repos::exists($srcpath) ) {
    if ( $srcpath =~ /\/$/ ) {
      #specified a level, nothing more to try
      print "SM:ERROR: path [$srcpath] does not exist. Aborting...\n";
      myexit 13; 
    }else {
      #maybe the person was lazy and forgot the trailing /
      ($srcpath,$srclevel,$scriptname)=process_path_arg($srcpath . "/");
      if ( ! Repos::exists($srcpath) ) {
        print "SM:ERROR: path [$srcpath] does not exist. Aborting...\n";
        myexit 13; 
      }
      #ok...lets continue on
    }
  }
  if ( $srcpath eq "/" ) {
    print "SM:ERROR:renaming / would not be a good idea. Aborting...\n";
    myexit 14;
  }
  $dstpath=shift @ARGV || "";
  $dstpath=MyUtil::trim($dstpath);
  if ( $srcpath =~ /\/$/ and $dstpath !~ /\/$/ and $dstpath ) {
    #since the srcpath is a level (ends in /) then the dstpath must be one
    $dstpath .= "/";
  }
  ($dstpath,$dstlevel,$dstscriptname)=process_path_arg($dstpath);
  if ( Repos::exists($dstpath) ) {
    print "SM:ERROR:cannot rename $srcpath because $dstpath already exists. Aborting...\n";
    myexit 15;
  } 
  ### make sure this is a local rename (in the same level)
  if ( MyUtil::parent_dir($srcpath) ne MyUtil::parent_dir($dstpath) ) {
    print "SM:ERROR:cannot rename across levels. Use the move function. Aborting...\n";
    myexit 16;
  }
  ### now lets check that we are moving script to script or level to level
  ###    and not mixing
  if ( $srcpath =~ /\/$/ and $dstpath =~ /\/$/ ) {
    Repos::move_entry($srcpath,$dstpath); 
  }elsif ( $srcpath !~ /\/$/ and $dstpath !~ /\/$/ ) {
    if ( continue_after_relative_check($srcpath) ) {
      Repos::move_entry($srcpath,$dstpath); 
    }
  }else {
    print "SM:ERROR:cannot convert between a script and a level. Aborting...\n";
    myexit 17;
  } 
}elsif ( $command eq "init_repos" ) {
  print "\nWARNING:The directory associated with [$Globals::curr_repos] must already exist before we can initialize the repository. If you get an error after this message, that is probably the issue.\n\n";
  Repos::create($Globals::curr_repos);
}elsif ( $command eq "modify_script" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name and not a level.Aborting...\n";
    myexit 22;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:script [$scriptpath] does not exist. Aborting...\n";
    myexit 23;
  }
  Script::modify($scriptpath);
}elsif ( $command eq "modify_level" ) {
  #lets grab the scriptpath first
  $scriptpath=shift @ARGV || "";
  $scriptpath=MyUtil::trim($scriptpath);
  if ( $scriptpath ) { ( $scriptpath =~ /\/$/ ) or $scriptpath .= "/"; }
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( $scriptname ) {
    print "SM:ERROR:must specify a level name. Aborting...\n";
    myexit 6;
  }
  if ( ! Repos::islevel($level) ) {
    print "SM:ERROR:level [$level] does not exist. Aborting...\n";
    myexit 5;
  }
  Level::modify($scriptpath);
}elsif ( $command eq "modify_repos" ) {
  Repos::modify;
}else {
  if ( $command ) {
    run_script($command,@ARGV);
  }else {
    Misc::show_usage;
    myexit 2;
  }
}

myexit 0;

sub run_script {
  local($scriptpath,@ARGS)=@_;
  local($level,$scriptname);
  ($scriptpath,$level,$scriptname)=process_path_arg($scriptpath);
  if ( ! $scriptname ) {
    print "SM:ERROR:must specify a script name and not a level. Aborting...\n";
    myexit 4;
  }
  if ( ! Repos::isscript($scriptpath) ) {
    print "SM:ERROR:script [$scriptpath] does not exist. Aborting...\n";
    myexit 6;
  }
  Script::execute($scriptpath,@ARGS);
}

sub list_all_relatives {
  local($scriptpath)=@_;
  ($pstr,$cstr)=split('<o>',Script::list_relatives($scriptpath));
  $pstr=MyUtil::trim($pstr);
  $cstr=MyUtil::trim($cstr);
  if ( $pstr or $cstr ) {
    print "\n";
    if ( $pstr ) {
      print "PARENTS (# of accesses and when last registered):\n";
      %phash=split('\^',$pstr);
      foreach $key (keys %phash) {
        ($lasttime,$cnt)=split(/:/,$phash{$key});
        ($cnt) or $cnt=1;
        $lasttimestr=localtime($lasttime);
        print "\t$key - $cnt times - $lasttime - $lasttimestr\n";
      }
    }
    if ( $cstr ) {
      print "CHILDREN (# or accesses and when last registered):\n";
      %chash=split('\^',$cstr);
      foreach $key (keys %chash) {
        ($lasttime,$cnt)=split(/:/,$chash{$key});
        ($cnt) or $cnt=1;
        $lasttimestr=localtime($lasttime);
        print "\t$key - $cnt times - $lasttime - $lasttimestr\n";
      }
    }
    print "\n";
  }
  return 1;
}

sub continue_after_relative_check {
  local($scriptpath)=@_;
  ($pstr,$cstr)=split('<o>',Script::list_relatives($scriptpath));
  $pstr=MyUtil::trim($pstr);
  $cstr=MyUtil::trim($cstr);
  if ( $pstr or $cstr ) {
    print "SM:WARNING:The following parents/children are registered for this script:\n\n";
    if ( $pstr ) {
      print "PARENTS (# of accesses and when last registered):\n";
      %phash=split('\^',$pstr);
      foreach $key (keys %phash) {
        ($lasttime,$cnt)=split(/:/,$phash{$key});
        ($cnt) or $cnt=1;
        $thash{$key}=1;
        $lasttimestr=localtime($lasttime);
        print "\t$key - $cnt times - $lasttime - $lasttimestr\n";
      }
    }
    if ( $cstr ) {
      print "CHILDREN (# or accesses and when last registered):\n";
      %chash=split('\^',$cstr);
      foreach $key (keys %chash) {
        ($lasttime,$cnt)=split(/:/,$phash{$key});
        ($cnt) or $cnt=1;
        $thash{$key}=1;
        $lasttimestr=localtime($lasttime);
        print "\t$key - $cnt times - $lasttime - $lasttimestr\n";
      }
    }
    print "\nDo you still wish to perform this action even though there are registered\n";
    print "     parents and/or children? [n] ";
    $ans = <STDIN>;
    $ans = MyUtil::trim($ans);
    if ( $ans eq "y" ) {
      Script::disown_relatives($scriptpath,keys %thash);
      return 1;
    }
    print "\nNOT performing action. Quiting...\n";
    return 0;
  }
  return 1;
}


sub process_path_arg {
  local($scriptpath)=@_;

  if( ! $scriptpath ) {
    Misc::show_usage;
    myexit 3;
  }
  $scriptpath=MyUtil::trim($scriptpath); 

  ### now lets check out the scriptname given
  $scriptpath=Repos::fixpath($scriptpath);
  ($level,$scriptname)=MyUtil::parse_path($scriptpath);
 ($scriptpath,$level,$scriptname);
}
 
sub separate_args {
  #now lets separate the run args from the script args
  $scriptargs=0;
  while (@ARGV) {
    $arg=MyUtil::trim(shift @ARGV);
    if ( $arg =~ /^-sm{(.*?)}/ ) {
      $opt=MyUtil::trim($1);  
      if ($NOT_STANDALONE_OPTS{$opt}) {
        (@ARGV) and $OPTIONS{$opt}=MyUtil::trim(shift @ARGV);
      }else {
        $OPTIONS{$opt}="1";
      }
    }else {
      push @SMARGV,$arg;
    }
  }
  @ARGV=@SMARGV;
}
