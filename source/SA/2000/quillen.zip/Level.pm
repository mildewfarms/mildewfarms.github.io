package Level;

require 5.002;

use Globals;
use MyUtil;
use Repos;

sub cwd {
  print "\nRepository: " . Repos::get_name . "\n";
  print "Current Level: $Globals::curr_level\n\n";
}

sub create {
  local($scriptpath)=@_;
  local(%lhash);
  %lhash=prompt_for();
  ### lets set the dynamic info about this level ###
  $lhash{time_created}=time();
  $lhash{owner}=$Globals::curr_username;
  $lhash{owner_uid}=$<;
  ($lhash{owner_gid})=split(" ",$();
  Repos::create_entry($scriptpath,%lhash);
  1;
}

@RECURSE_WORK=();
$LEVEL=0;

sub recurse {
  local($level)=@_;
  local(@paths,$child);
  if ( $LEVEL == 0 ) {
    @RECURSE_WORK=();
  }
  $LEVEL++;  
  push @RECURSE_WORK,$level;
  for $child (list($level)) {
    if ( $child =~ /\/$/ ) {
      #subdir
      recurse("$level$child");
    }else {
      push @RECURSE_WORK,"$level$child";
    }
  }
  $LEVEL--;
  if ( $LEVEL ) {
    return ();
  }else {
    return @RECURSE_WORK;
  }
}

sub list {
  local($level)=@_;
  local(@paths,%children,$child);
  @paths=Repos::return_all_paths;
  foreach $path (@paths) {
    if ( $path =~ /^$level/ and $path ne $level ) {
      $path =~ s/^$level//;
      ($child) = split("/",$path);
      if ( $path =~ /^$child\// ) {
        #subdir
        $child .= "/";
      }
      $children{$child}=1;
    }
  } 
  @paths=();
  foreach $child (sort (keys %children)) {
    push @paths,"$child";  
  }
  @paths;
}

sub modify {
  local($path)=@_;
  local(%thash);
  %thash=Repos::read_entry_hash($path);
  %thash=prompt_for(%thash);
  Repos::write_entry_hash($path,%thash);
}

sub prompt_for {
  local(%lhash)=@_;
  print "-----------------------\n";
  print "LEVEL INFORMATION ENTRY\n";
  print "-----------------------\n";
  $lhash{sdesc}=MyUtil::prompt_for_value("Enter in a short description (< 60 chars):",$lhash{sdesc},0);
 # while(1) {
 # print "\nEnter in the colon delimated list of acl strings for this level\n";
 # print "and all its children:\n\n";
 # print "SYNTAX EXP: <all>,user1,%grp1,-user2,-grp2:priv1,priv2^user3:priv3\n";
 # print "PRIVLIST: read,exec,modify,delete,metaread,metamod,admin,\n";
 # print "          lvl_browse,lvl_create,lvl_delete,lvl_metamod\n\n";
 # $cval="";
 # $lhash{acls} and $cval=$lhash{acls};
 # print "CURRENT: [$cval]\n";
 # print "ENTER: ";
 # $acls=<STDIN>;
 # print "\n";
 # $lhash{acls}=MyUtil::trim($acls) and last;
 # }
  %lhash;
}

1;
