
package Misc;

require 5.002;

use Globals;
use MyUtil;

sub show_usage {
  print "ScriptManager $Globals::version by Edward Quillen (ed\@quillen.net)\n";
  print "                                          (http://quilen.net/tools)\n";
  print "USAGE: sm <command> [<args>]\n\n";
  print "  sm [run] <script> [-- script args] - run the script (NOTE the -- for args)\n";
  print "  sm create <script> <file>  -  create a new script\n";
  print "  sm list_shells  -  list all currently defined shells\n";
  print "  sm list_repos  -  list all currently defined repositories\n";
  print "  sm cat <script>  -  display the script\n";
  print "  sm info <script>  -  display info about the script object\n";
  print "  sm show_family <script>  -  show parents and children of script\n";
  print "  sm report lastrun  -  show last run time for all scripts\n";
  print "  sm replace <script> <file>  -  replace the script file with a new one\n";
  print "  sm init_repos  -  initialize a new repository\n";
  print "  sm list|ls|dir [level]  -  list entries in current or specified level\n" ;
  print "  sm recurse  -  list all objects in repository\n";
  print "  sm cwd|pwd  -  show current level\n";
  print "  sm cd ..|<level>  -  change to level\n";
  print "  sm submit_doc <script> <file>  -  submit doc for script\n";
  print "  sm remove_doc <script>  -  remove doc for script\n";
  print "  sm doc|man <script>  -  show doc for script\n";
  print "  sm apropos <word>  -  search all script descs for word\n";
  print "  sm mkdir|create_level <level>  -  create a new level\n";
  print "  sm modify_repos  -  modify the repository settings\n";
  print "  sm modify_level <level>  -  modify the level settings\n";
  print "  sm modify_script <script>  -  modify the script settings\n";
  print "  sm delete <script|level>  -  remove a script or level\n";
  print "  sm move <script|level> <level>  -  move a script or level\n";
  print "  sm rename <script|level> <script|level>  -  rename a script or level\n";
  print "NOTE: <script> and <level> can be relative\n\n";
  print "ENV VARIABLES - OPTIONAL:\n";
  print "\tSM_CONF_FILE  -  sm.conf file to use other than defaults\n";
  print "\tSM_REPOS  -  which defined repository to use (def: default)\n";
  print "\tSM_REPOS_DEF  -  undefined repository dir or ftp URL to use - overrides SM_REPOS\n";
  print "CONFIG FILES (processed in the following order):\n";
  print "\t/etc/sm.conf\n";
  print "\t/etc/sm.conf.<HOSTNAME>\n";
  print "\t~/.sm.conf\n";
  print "POSSIBLE CONFIG FILE ENTRIES:\n";
  print "\tshell shellname=shell def  (use sm list_shells to get examples)\n";
  print "\trepos reposname=directory  (where the repositories are)\n";
  print "\trepos reposname=ftp_url    (example: ftp://user:pass\@hostname/dirname)\n";
  print "\tdefault_repos=reposname    (def: default)\n";
  print "\tlog_file=filename or |command (script execution is logged here)\n";
  print "\t                              (def: /tmp/sm.log.<USERNAME>)\n";
  print "\tretain_env_var=VARNAME    (keep this env variable during run)\n";
  print "\tdont_wipe_env_vars_by_default=0|1 (def:0)\n";
  print "\tuse_runners_umask_by_default=0|1  (def:0)\n";
  print "\n";
  print "ScriptManager $Globals::version by Edward Quillen (ed\@quillen.net)\n";
  print "                                          (http://quilen.net/tools)\n";
}

sub check_shell_def {
  local($shelldef)=@_;
  if ( $shelldef =~ /\// and $shelldef =~ /{file}/ and $shelldef =~ /{args}/ ) {
    return 1;
  }else {
    print "SM:ERROR:shell definition is incorrect. You must have an absolute path to a shell and include the {file} and {args} macros in the string. Aborting...\n";
    main::myexit(30);
  }
}

sub load_config_file {
  local($fname)=@_;
  local($line);
  open(FIN,"$fname") || return;
  while(1) {
    $line = <FIN> || last;
    $line =~ /^#/ && next;  #comment line
    $line=MyUtil::trim($line);    
    if ($line =~ /^shell/) {
      ($before,@rest)=split(/=/,$line);
      $shelldef=join('=',@rest);
      ($junk,$shellname)=split(" ",$before);
      $shellname=MyUtil::trim($shellname);    
      $shelldef=MyUtil::trim($shelldef);    
      check_shell_def($shelldef);
      $Globals::shelldefs{$shellname}=$shelldef;
    }elsif ($line =~ /^retain_env_var/) {
      ($before,$envname)=split(/=/,$line);
      $envname=MyUtil::trim($envname);    
      $Globals::retained_envs{$envname}=1;
    }elsif ($line =~ /^repos/) {
      ($before,@rest)=split(/=/,$line);
      $reposdef=join('=',@rest);
      ($junk,$reposname)=split(" ",$before);
      $reposname=MyUtil::trim($reposname);    
      $reposdef=MyUtil::trim($reposdef);    
      $Globals::reposdefs{$reposname}=$reposdef;
    }elsif ($line =~ /^use_runners_umask_as_default/) {
      ($before,$flag)=split(/=/,$line);
      $flag=MyUtil::trim($flag);
      $Globals::use_runners_umask_as_default=$flag;
    }elsif ($line =~ /^dont_wipe_env_vars_by_default/) {
      ($before,$flag)=split(/=/,$line);
      $flag=MyUtil::trim($flag);
      $Globals::dont_wipe_env_vars_by_default=$flag;
    }elsif ($line =~ /^log_file/) {
      ($before,$lfile)=split(/=/,$line);
      $lfile=MyUtil::trim($lfile);
      $Globals::log_file=$lfile;
    }elsif ($line =~ /^default_repos/) {
      ($before,$reposname)=split(/=/,$line);
      $reposname=MyUtil::trim($reposname);
      $Globals::curr_repos=$reposname;
    }
  }
  close(FIN);
}

sub load_all_config_files {
  #load system wide file
  local($envval);
  $envval=$ENV{"SM_CONF_FILE"} || "";
  ( -r "$Globals::conf_file") && load_config_file($Globals::conf_file);
  ( -r "$Globals::conf_file_host") && load_config_file($Globals::conf_file_host);
  ( -r "$Globals::per_conf_file") && load_config_file($Globals::per_conf_file);
  ( -r "$Globals::per_conf_host_file") && load_config_file($Globals::per_conf_host_file);
  ( -r "$envval") && load_config_file($envval);
}

