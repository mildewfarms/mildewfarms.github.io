package Script;

require 5.002;

use Globals;
use MyUtil;
use Repos;
use Misc;
use Cwd;

sub replace {
  local($path,$fname)=@_;
  local(%thash,$flen,$rlen);
  %thash=Repos::read_entry_hash($path);
  $flen=(-s $fname);
  if ( ! open(SCIN,"$fname") or $flen == 0 ) {
    print "SM:ERROR:could not open script file for reading. Aborting...\n";
    main::myexit(17);
  }
  $rlen=read(SCIN,$thash{script},(-s $fname));
  close(SCIN);
  if ( $rlen != $flen ) {
    print "SM:ERROR:error reading in doc file. Aborting...\n";
    main::myexit(18);
  }
  $thash{time_modified}=time();
  Repos::write_entry_hash($path,%thash);
}

sub list_relatives {
  local($path)=@_;
  local(%thash,%chash,@plist,@clist,$key);
  %thash=Repos::read_entry_hash($path);
  %chash=split('\^',$thash{parents});
  foreach $key (keys %chash) {
    push @plist,"$key^$chash{$key}";
  }
  %chash=split('\^',$thash{children});
  foreach $key (keys %chash) {
    push @clist,"$key^$chash{$key}";
  }
  "$thash{parents}<o>$thash{children}";
}

sub disown_relatives {
  local($path,@relatives)=@_;
  local(%thash,%chash,%phash);

  #clean up relatives
  foreach $relativepath (@relatives) {
    ( $relativepath eq $path ) and next; #don't bother cleaning myself here
    %thash=Repos::read_entry_hash($relativepath);
    %chash=split('\^',$thash{children});
    delete $chash{$path};
    $thash{children}=join('^',%chash);
    %chash=split('\^',$thash{parents});
    delete $chash{$path};
    $thash{parents}=join('^',%chash);
    Repos::write_entry_hash($relativepath,%thash);
  }

  #clean up myself
  %thash=Repos::read_entry_hash($path);
  %chash=split('\^',$thash{children});
  %phash=split('\^',$thash{parents});
  foreach $relativepath (@relatives) {
    delete $chash{$relativepath};
    delete $phash{$relativepath};
  }
  $thash{children}=join('^',%chash);
  $thash{parents}=join('^',%phash);
  Repos::write_entry_hash($path,%thash);
  1; 
}

sub execute {
  local($path,@args)=@_;
  local(%thash,%tthash,$tmpfile,$oldtime,$oldcnt,$oldtime);
  %thash=Repos::read_entry_hash($path);
  $tmpfile="/tmp/sm-$$.tmp";
  open(SEOUT ,">$tmpfile");
  print SEOUT $thash{script};
  close(SEOUT);
  chmod 0700,$tmpfile;

  ### update the run count #############
  if ( $thash{numruns} ) {
    $thash{numruns}++;
  }else {
    $thash{numruns}=1;
  }

  ### check the username restriction ###
  if ( $thash{userlist} ) {
    $found=0;
    foreach $uname (split(" ",$thash{userlist})) {
      if ( $uname eq $Globals::curr_username ) {
        $found=1;
        last;
      }
    }
    if ( ! $found ) {
      print "SM:ERROR:you are not allowed to execute this script. Aborting...\n";
      main::myexit(37);
    }
  }
  ### check the hostname restriction ###
  if ( $thash{hostlist} ) {
    $found=0;
    foreach $hname (split(" ",$thash{hostlist})) {
      if ( $hname eq $Globals::hostname ) {
        $found=1;
        last;
      }
    }
    if ( ! $found ) {
      print "SM:ERROR:you are not allowed to execute this script on this host. Aborting...\n";
      main::myexit(38);
    }
  }
  ### now lets check if we are the child of another sm script #####
  if ( $ENV{SM_PARENT} ) {
    ## yup, we are
    # SM_PARENT is formatted like the following: repos:script_path
    ($repos,$parentpath)=split(/:/,$ENV{SM_PARENT});
    if ( $repos eq Repos::get_name ) {
      %tthash=Repos::read_entry_hash($parentpath);
      if ( %tthash ) {
        %chash=split('\^',$tthash{children});
        $newtime=time();
        if ( $chash{$path} ) {
          ($oldtime,$oldcnt)=split(/:/,$chash{$path});
          ( $oldcnt ) or $oldcnt=1;
          $oldcnt++;
          $chash{$path}="$newtime:$oldcnt";
        }else {
          $chash{$path}="$newtime:1";
        }
        $tthash{children}=join('^',%chash);
        Repos::write_entry_hash($parentpath,%tthash);
        %chash=split('\^',$thash{parents});
        if ( $chash{$path} ) {
          ($oldtime,$oldcnt)=split(/:/,$chash{$parentpath});
          ( $oldcnt ) or $oldcnt=1;
          $oldcnt++;
          $chash{$parentpath}="$newtime:$oldcnt";
        }else {
          $chash{$parentpath}="$newtime:1";
        }
        $thash{parents}=join('^',%chash);
      }
    }
  }
  ### now lets mark that we have been run ##################
  $thash{last_run}=time();

  ### now lets save our entry and close out the repository
  Repos::write_entry_hash($path,%thash);
  Repos::close;

  ### now lets alter the env accordingly ###################
  ## cwd ##
  if ( $thash{cwdval} =~ /^\// ) {
    if ( ! chdir $thash{cwdval} ) {
      print "SM:ERROR:could not cd to $thash{cwdval}. Aborting...\n";
      main::myexit(26); 
    }
  }
  ## umask ##
  #note: method 1 is use the runners so we do nothing
  if ( $thash{umaskmethod} == 0 ) {
    # use 077 method. I like this one.
    umask 077; 
  }elsif ( $thash{umaskmethod} == 2 ) {
    # use a custom umask 
    umask $thash{umaskval}; 
  }
  ## env ##
  #note: method 1 is don't wipe them so we do nothing ... yet
  if ( $thash{envmethod} == 0) {
    # wipe all env vars except those specified
    #  lets build our list of vars to keep by just adding ours to the main hash
    foreach $env (split " ",$thash{envs_retained}) {
      $env=MyUtil::trim($env);
      ( $env ) and $Globals::retained_envs{$env}=1;
    } 
    #now lets step through the env vars slashing as we go
    foreach $env (keys %ENV) {
      $Globals::retained_envs{$env} or delete $ENV{$env};
    } 
  }
  # now lets modify whats left of the env
  process_env_mods($thash{envmods});

  ### now lets build the command ###########################
  if ( $thash{shelltype} == 0 ) {
    #no shell - just run it
    $cmdstr=create_complete_cmd_string("{file} {args}",$tmpfile,@args);
  }elsif ( $thash{shelltype} == 1 ) {
    #defined shell 
    $shelldef=$Globals::shelldefs{$thash{shellname}};
    if ( ! $shelldef ) {
       print "SM:ERROR:defined shell [$thash{shellname}] does not exist. Add it to sm.conf files. Aborting...\n";
       main::myexit(29);
    }
    $cmdstr=create_complete_cmd_string($shelldef,$tmpfile,@args);
  }elsif ( $thash{shelltype} == 2 ) {
    #specd shell
    $cmdstr=create_complete_cmd_string($thash{shellspec},$tmpfile,@args);
  }else {
    print "SM:ERROR:script entry in repository is corrupted. Aborting...\n";
    main::myexit(28);
  }
  if( $Globals::log_file =~ /^\|/ ) {
    open(EFOUT,"$Globals::log_file");
  }else {
    open(EFOUT,">>$Globals::log_file");
  }
  $now=time();
  $um=sprintf "%lo", umask;
  $pwd=Cwd::cwd();
  print EFOUT "$now^starting^repos=$Globals::curr_repos^path=$path^umask=$um^cwd=$pwd^ppid=$$^cmd=$cmdstr^uid=$<^username=$Globals::curr_username^gid=$(\n";
  close EFOUT;

  ### now lets tell our child who its daddy is
  $ENV{SM_PARENT}="${Globals::curr_repos}:$path";

  $rcode = system($cmdstr);
  unlink($tmpfile);
  $rcode /= 256;
  if( $Globals::log_file =~ /^\|/ ) {
    open(EFOUT,"$Globals::log_file");
  }else {
    open(EFOUT,">>$Globals::log_file");
  }
  $now=time();
  print EFOUT "$now^ending^rcode=$rcode^repos=$Globals::curr_repos^path=$path^ppid=$$\n";
  close EFOUT;
  main::myexit($rcode);
}

sub create {
  local($scriptpath,$fname)=@_;
  local(%shash,$flen,$rlen);
  %shash=prompt_for();
  ### lets set the dynamic info about this level ###
  $shash{time_created}=time();
  $shash{time_modified}=$shash{time_created};
  $shash{last_run}=0;
  $shash{owner}=$Globals::curr_username;
  $shash{owner_uid}=$<;
  ($shash{owner_gid})=split(" ",$();
  $flen=(-s $fname);
  if ( ! open(SCIN,"$fname") or $flen == 0 ) {
    print "SM:ERROR:could not open script file for reading. Aborting...\n";
    main::myexit(17);
  }
  $rlen=read(SCIN,$shash{script},(-s $fname));
  close(SCIN);
  if ( $rlen != $flen ) {
    print "SM:ERROR:error reading in script. Aborting...\n";
    main::myexit(18);
  }
  Repos::create_entry($scriptpath,%shash);
  1;
}

sub modify {
  local($path)=@_;
  local(%thash);
  %thash=Repos::read_entry_hash($path);
  %thash=prompt_for(%thash);
  Repos::write_entry_hash($path,%thash);
}

sub display_info {
  local($path)=@_;
  local(%thash,%level,%temp,$key,$datestr);
  %level=( 0 => "low" , 1 => "medium" , 2 => "high" );
  %thash=Repos::read_entry_hash($path);
  print "\nDisplay for: $path\n\n";
  foreach $key ( sort (keys %thash) ) {
    ( $key eq "script" or $key eq "doc" ) and next; #don't display these
    if ( $key eq "auditlevel" or $key eq "importance" ) { 
      print "$key = $thash{$key} ($level{$thash{$key}})\n";
    }elsif ( $key eq "envmethod" ) {
      %temp=( 0 => "wipe out vars" , 1 => "retain vars" );
      print "$key = $thash{$key} ($temp{$thash{$key}})\n";
    }elsif ( $key eq "umaskmethod" ) {
      %temp=( 0 => "use 077" , 1 => "use the user's" , 2 => "use custom one defined with {umaskval}" );
      print "$key = $thash{$key} ($temp{$thash{$key}})\n";
    }elsif ( $key eq "shelltype" ) {
      %temp=( 0 => "no shell" , 1 => "defined shell" , 2 => "specified shell" );
      print "$key = $thash{$key} ($temp{$thash{$key}})\n";
    }elsif ( $key =~ "last_run|time_created|time_modified" ) {
      $datestr=localtime($thash{$key});
      print "$key = $thash{$key} ($datestr)\n";
    }elsif ( $key eq "type" ) {
      %temp=( 0 => "interactive" , 1 => "scheduled batch" , 2 => "adhoc batch" , 3 => "daemon" );
      print "$key = $thash{$key} ($temp{$thash{$key}})\n";
    }elsif ( $key eq "parents" or $key eq "children" ) {
      #skip showing
      next;
    }else {
      print "$key = $thash{$key}\n";
    }
  } 
  print "\n";
}

sub get_lastrun {
  local($path)=@_;
  local(%thash);
  %thash=Repos::read_entry_hash($path);
  $thash{last_run};
}

sub cat {
  local($path)=@_;
  local(%thash);
  %thash=Repos::read_entry_hash($path);
  print "$thash{script}";
}

sub apropos {
  local($word)=@_;
  local($found,$val,$desc,%thash);
  foreach $path (Level::recurse("/")) {
    ( $path =~ /\/$/ ) and next; #skip levels and just look at scripts
    $found=0;
    $desc=Repos::get_entry_desc($path);
    if ( $desc =~ /$word/i ) {
      $found=1;
    #}else {
    #  if ( Repos::entry_has_doc($path) ) {
    #    %thash=Repos::read_entry_hash($path);
    #    ( $thash{doc} =~ /$word/i ) and $found=1;
    #  }
    }
    ( $found ) and print "$path - $thash{sdesc}\n";
  }
  1;
}

sub getdesc {
  local($path)=@_;
  Repos::get_entry_desc($path);
}

sub hasdoc {
  local($path)=@_;
  Repos::entry_has_doc($path);
}

sub show_doc {
  local($path)=@_;
  local(%thash);
  if ( hasdoc($path) ) {
    %thash=Repos::read_entry_hash($path);
    ( $thash{doc} ) and print "$thash{doc}";
  }
  1;
}

sub remove_doc {
  local($path)=@_;
  local(%thash);
  %thash=Repos::read_entry_hash($path);
  delete $thash{doc};
  Repos::write_entry_hash($path,%thash);
  1;
}

sub submit_doc {
  local($path,$fname)=@_;
  local(%thash,$flen,$rlen);
  %thash=Repos::read_entry_hash($path);
  $flen=(-s $fname);
  if ( ! open(SCIN,"$fname") or $flen == 0 ) {
    print "SM:ERROR:could not open doc file for reading. Aborting...\n";
    main::myexit(17);
  }
  $rlen=read(SCIN,$thash{doc},(-s $fname));
  close(SCIN);
  if ( $rlen != $flen ) {
    print "SM:ERROR:error reading in doc file. Aborting...\n";
    main::myexit(18);
  }
  Repos::write_entry_hash($path,%thash);
  1;
}

sub prompt_for {
  local(%lhash)=@_;
  print "------------------------\n";
  print "SCRIPT INFORMATION ENTRY\n";
  print "------------------------\n";
  $lhash{sdesc}=MyUtil::prompt_for_value("Enter in a short description (< 60 chars):",$lhash{sdesc},0);
  ( ! $lhash{shelltype} ) and $lhash{shelltype}=1;
  $lhash{shelltype}=MyUtil::prompt_for_choices("Enter in the type of shell to use for this script:",$lhash{shelltype},("no shell - run the script directly","use a defined shell - RECOMMENDED","specify shell in detail"));
  if($lhash{shelltype} == 1) {
    #wants a defined shell, lets prompt for which one
    if ( %Globals::shelldefs ) { 
      $cval="";
      @options=();
      $num=0;
      foreach $sname (keys %Globals::shelldefs) {
        ( $sname eq $lhash{shellname} ) and $cval=$num;
        push @options,"$sname => $Globals::shelldefs{$sname}";
        $num++;
      }
      $cval=MyUtil::prompt_for_choices("Enter in which defined shell to use:",$cval,@options);
      ($lhash{shellname})=split(" ",$options[$cval]);
    }else {
      print "SM:ERROR:you do not have any shells defined. You must define some in the sm.conf files (/etc/sm.conf,/etc/sm.conf.HOSTNAME,~/.sm.conf,~/.sm.conf.HOSTNAME). Aborting...\n";
      main::myexit(25);
    }
  }elsif($lhash{shelltype} == 2) {
    #wants to specify shell in detail
    $lhash{shellspec}=MyUtil::prompt_for_value("Enter in the specification for the shell using a full path and specifying where the script file and script args should be placed using the macros {file} and {args} respectively.\nEXAMPLE: /bin/bash -norc - {file} {args}\n",$lhash{shellspec},0);
    Misc::check_shell_def($lhash{shellspec});
  }
  
  ############ now lets get the cwd to run at ####################
  ( $lhash{cwdval} ) or $lhash{cwdval}="/tmp";
  $lhash{cwdval}=MyUtil::prompt_for_value("Enter in the absolute directory to cd to before running this script (enter \"cwd\" to choose the runners cwd):",$lhash{cwdval},0);

  ############ now lets get the group name to run as ####################
  ###$lhash{groupname}=MyUtil::prompt_for_value("Enter in a group name to run the script as (def: the primary of the runner):",$lhash{groupname},1);

  ############ now lets get the umask to use ####################
  if ( $Globals::use_runners_umask_as_default ) {
    $defaultval=1;
  }else {
    $defaultval=0;
  }
  ( ! $lhash{umaskmethod} ) and $lhash{umaskmethod}=$defaultval;
  $lhash{umaskmethod}=MyUtil::prompt_for_choices("Pick which method you want to use to handle the umask of the script when it runs:",$lhash{umaskmethod},("use 077 - RECOMMENDED","use the runners umask - no guts","define a custom umask"));
  if ( $lhash{umaskmethod} == 2 ) {
    $cval="";
    ( $lhash{umaskval} ) and $cval=sprintf "%lo",$lhash{umaskval};
    $cval=MyUtil::prompt_for_value("Enter in the umask value to use while running this script (ex: 077):",$cval,1);
    ( $cval ne "" ) and $cval=oct($cval);
    $lhash{umaskval}=$cval;
  }

  ############ now lets get the env settings ####################
  if ( $Globals::dont_wipe_env_vars_by_default ) {
    $defaultval=1;
  }else {
    $defaultval=0;
  }
  ( $lhash{envmethod} eq "" ) and $lhash{envmethod}=$defaultval;
  $lhash{envmethod}=MyUtil::prompt_for_choices("Pick how to handle env variables before running the script (NOTE: the env variables can be manipulated either way based on a config option introduced later):",$lhash{envmethod},("wipe them all EXCEPT for a set to retain - RECOMMENDED","keep all the env variables - you wimp"));
  ### if were are wiping env vars - lets get a set of retained ones
  if ( $lhash{envmethod} == 0 ) {
    $lhash{envs_retained}=MyUtil::prompt_for_value("Enter in a space delimited list of env variable names that you wish to retain and not wipe away before running this script (NOTE: this is in addition to ones defined in the sm.conf files using retained_env_var= lines):",$lhash{envs_retained},1);
  }
  ### now lets get any env modifications for the script ###
  $lhash{envmods}=MyUtil::prompt_for_value("Enter in a carrot ^ delimited list of env mod commands of the form COMMAND:VARIABLENAME:VALUE which COMMAND can be DELETE, REPLACE, PREPEND, APPEND and VARIABLENAME can be <ALL> for the DELETE command.\nExample: DELETE:<ALL>^REPLACE:EDITOR:/bin/vi^APPEND:PATH:/bin",$lhash{envmods},1);

  ############ now get the host list #########################
  $lhash{hostlist}=MyUtil::prompt_for_value("Enter in a space delimited list of hostnames (without the attached domain name) on which this script should be allowed to run or leave it empty to allow all hosts:",$lhash{hostlist},1);

  ############ now get the user list #########################
  $lhash{userlist}=MyUtil::prompt_for_value("Enter in a space delimited list of usernames who should be allowed to run this script or leave it empty to allow all users:",$lhash{userlist},1);

  ############ now get the script type #########################
  ( ! $lhash{type} ) and $lhash{type}=0;
  $lhash{type}=MyUtil::prompt_for_choices("Enter in how this script is used:",$lhash{type},("interactive - mainly run from the prompt","scheduled batch - run regulary not attached to a login","adhoc batch - run sporadically not attached to a login","daemon - meant to run constantly in the backgroud"));

  ############ now get the script crit #########################
  ( ! $lhash{importance} ) and $lhash{importance}=1;
  $lhash{importance}=MyUtil::prompt_for_choices("Enter in the level of importance of this script:",$lhash{importance},("low - in fact it was a waste of time writing","medium - I guess it does something worthwhile","high - life as we know it would cease to exist without it"));

  ############ now get the audit level #########################
  ( ! $lhash{auditlevel} ) and $lhash{auditlevel}=1;
  $lhash{auditlevel}=MyUtil::prompt_for_choices("Enter in the level of auditing that should be used with this script:",$lhash{auditlevel},("low - not worth the disk space","medium - I'm sure its buggy enough to need some","high - its really buggy, so keep as much info about it as possible"));

  ############ lets get the author information ##################
  $lhash{author}=MyUtil::prompt_for_value("Enter in the name of the author so we know who to sue:",$lhash{author},1);
  $lhash{date_authored}=MyUtil::prompt_for_value("When was this script written (def:today):",$lhash{date_authored},1);
  ( ! $lhash{date_authored} ) and $lhash{date_authored}=localtime(time);

 # print "\nEnter in the colon delimated list of acl strings for this level\n";
 # print "and all its children:\n\n";
 # print "SYNTAX EXP: <all>,user1,%grp1,-user2,-grp2:priv1,priv2^user3:priv3\n";
 # print "PRIVLIST: read,exec,modify,delete,metaread,metamod,admin,\n";
 # print "          lvl_browse,lvl_create,lvl_delete,lvl_metamod\n\n";
 # $cval="";
 # $lhash{acls} and $cval=$lhash{acls};
 # print "CURRENT: [$cval]\n";
 # print "ENTER: ";
 # $acls=<STDIN>;
 # print "\n";
 # $lhash{acls}=MyUtil::trim($acls) and last;
 # }
  %lhash;
}

sub process_env_mods {
  local($modstrlist)=@_;
  local($modstr,$command,$varname,@rest,$value,$oldval,$key);
  foreach $modstr (split(/\^/,MyUtil::trim($modstrlist))) {
    ($command,$varname,@rest)=split(':',$modstr);
    $value=join(':',@rest); 
    $command=MyUtil::trim($command);
    $varname=MyUtil::trim($varname);
    $value=MyUtil::trim($value);
    if($command eq "DELETE") {
      if ( $varname eq "<ALL>" ) {
	foreach $key (keys %ENV) {
          delete $ENV{$key};
        }		
      }else {
        delete($ENV{$varname});
      }
    }elsif($command eq "REPLACE") {
      $ENV{$varname}=$value;
    }elsif($command eq "APPEND") {
      $oldval=MyUtil::trim($ENV{$varname});
      $ENV{$varname}=$oldval . $value;
    }elsif($command eq "PREPEND") {
      $oldval=MyUtil::trim($ENV{$varname});
      $ENV{$varname}=$value . $oldval;
    } 
  }
  return 1;
}

sub create_complete_cmd_string {
  local($spec,$filename,@args)=@_;
  local($argstr);
  $spec =~ s/{file}/$filename/g;
  if ( @args ) {
    $argstr='"' . join('" "',@args) . '"';
    $spec =~ s/{args}/$argstr/g;
  }else {
    $spec =~ s/{args}//g;
  }
  $spec;
}

1;
