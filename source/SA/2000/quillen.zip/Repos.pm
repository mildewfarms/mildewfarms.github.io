
package Repos;

require 5.002;

use MyUtil;
use Globals;
use MyDB;

###### used to store all open repositories ##############
%ALLREPS=();
$CURRENT=0; #used to point to the current one

sub set_current {
  local($repos)=@_;
  $CURRENT=$repos;
  $Globals::curr_repos=$repos->{name};
  Globals::get_stored_level;
  1;
}

sub get_name {
  $CURRENT->{name};
}

sub get_location {
  $CURRENT->{location};
}

sub open {
  local($name)=@_;
  local(%thash,%tthash,%ttthash,$href,$key,$warned);
  $href={};
  $href->{name}=$name;
  $href->{location}=name2location($name);
  $href->{db}=MyDB::open($href->{location});
  if ( ! MyDB::table_exists($href->{db},"meta") ) {
    print "SM:ERROR:the repository [$name] does not exist. You might want to use the [init_repos] function of sm. Aborting...\n";
    main::myexit(10);
  }
  %thash=MyDB::read_table($href->{db},"meta");
  $href->{meta}=\%thash;
  if ( MyDB::table_exists($href->{db},"index") ) {
    %tthash=MyDB::read_table($href->{db},"index");  
    $href->{index}=\%tthash;
    ### now for some backward compatibility, lets populate descriptions and 
    ###   hasdoc's in the index table if they don't exist
    $warned=0;
    foreach $key (keys %tthash) {
      ($id,$desc,$hasdoc)=split('\^',$tthash{$key});
      if ( ! $desc ) {
        #looks like an old style repos
        if ( ! $warned ) {
          $warned=1;
          print "SM:WARNING:it make take a few minutes to convert your repository to the new format. This should give you some speed gains. Please wait...\n";
          sleep 2;
        }
        print "Probing $key ... ";
        %ttthash=MyDB::read_table($href->{db},$id);  
        $hasdoc=0;
        ( $ttthash{doc} ) and $hasdoc=1;
        $tthash{$key}=join('^',($id,$ttthash{sdesc},$hasdoc));
        print "done!\n";
      }
    }
    if ( $warned ) { 
      MyDB::write_table($href->{db},"index",%tthash);
      print "DONE with conversion!\n";
    }
  }else { 
    $href->{index}={};
  }
  if ( ! %ALLREPS ) {
    #since this is the first repository, make it the current one
    set_current($href);
  }
  $ALLREPS{$href}=1;
  $href;
}

sub close {
  MyDB::close($CURRENT->{db});
  delete $ALLREPS{$CURRENT};
  1;
}

sub close_all {
  local($key);
  foreach $key (keys %ALLREPS) {
    set_current($key);
    Repos::close;
  }
  1; 
}

sub mark_repos_mod {
  local($href);
  $href=$CURRENT->{meta};
  $href->{last_modified}=time();
  $href->{last_modifier}=$Globals::curr_username;
  $href->{last_modifier_uid}=$<;
  ($href->{last_modifier_uid})=split(" ",$();
  MyDB::write_table($CURRENT->{db},"meta",%$href);
}

sub modify {
  &prompt_for;
  &mark_repos_mod;
}

sub exists {
  local($path)=@_;
  ${$CURRENT}{index}{$path} or return 0;
  1;
}

sub islevel {
  local($path)=@_;
  ( $path =~ /\/$/ ) or return 0;
  Repos::exists($path);
}

sub isscript {
  local($path)=@_;
  ( $path =~ /\/$/ ) and return 0;
  Repos::exists($path);
}

sub fixpath {
  local($path)=@_;
  $path=MyUtil::trim($path);
  if ( $path !~ /^\// ) {
    #relative path
    $path="$Globals::curr_level$path";
  }
  $path;
}

sub name2location {
  local($name)=@_;
  local($loc);
  $loc=$Globals::reposdefs{$name};
  if ( ! $loc ) {
    print "SM:ERROR:repository [$name] is not defined!\n\n";
    print "Current repositories defined:\n";
    while (($key,$value) = each %Globals::reposdefs) {
      print "$key => $value\n";
    }
    print "\nEither there is not a defined repository named 'default' or\n";
    print "  your env variable SM_REPOS is pointing to a non existent one.\n";
    print "NOTE: you can define repositories by adding lines like the\n";
    print "      following to the /etc/sm.conf or ~/.sm.conf files or \n";
    print "      setting the env var SM_REPOS_DEF to a directory name:\n";
    print "\nrepos reposname=directory\n\n";
    print "Aborting...\n\n";
    main::myexit(9);
  }
  $loc;
}

sub create {
  local($name)=@_;
  local($location,%lhash,$db,$repos,$href);
  $location=name2location($name);
  $db=MyDB::open($location);
  MyDB::write_table($db,"meta",());
  MyDB::close($db);
  $repos=Repos::open($name);
  set_current($repos);
  $href=$repos->{meta};
  &prompt_for;
  ### lets set some other info about the repos ###
  $href->{time_created}=time();
  $href->{owner}=$Globals::curr_username;
  $href->{owner_uid}=$<;
  ($href->{owner_gid})=split(" ",$();
  ### lets set the dynamic info about the root level ###
  $lhash{sdesc}="root level";
  $lhash{time_created}=time();
  $lhash{owner}=$Globals::curr_username;
  $lhash{owner_uid}=$<;
  ($lhash{owner_gid})=split(" ",$();
  create_entry("/",%lhash); ### a mark_repos_mod will happen in this sub 
  Repos::close;
}

sub prompt_for {
  local($metaref);

  $metaref=$CURRENT->{meta};

  print "----------------------------\n";
  print "REPOSITORY INFORMATION ENTRY\n";
  print "----------------------------\n";

  #### description
  $metaref->{sdesc}=MyUtil::prompt_for_value("Enter in a short description (< 60 chars):",$metaref->{sdesc},0);

#  #### chmod setting
#  #convert the current value into decimal text (from octal)
#  $cval="";
#  $metaref->{chmd} and $cval=$metaref->{chmd};
#  ( $cval ) and $cval=sprintf "%lo",$cval;
#  $cval=MyUtil::prompt_for_value("Enter in a chmod setting for repository files and dirs (ex: 770):",$cval,0);
#  $metaref->{chmd}=oct($cval);

#  #### gid setting
#  $metaref->{gowner}=MyUtil::prompt_for_value("Enter in a gid for repository files (def: your primary):",$metaref->{gowner},1);
#  ( $metaref->{gowner} eq "" ) and ($metaref->{gowner})=split(" ",$));  
}

sub entry_has_doc {
  local($path)=@_;
  local($id,$desc,$hasdoc);
  ${$CURRENT}{index}{$path} or return ();
  ($id,$desc,$hasdoc)=split('\^',${$CURRENT}{index}{$path});
  $hasdoc;
}

sub get_entry_desc {
  local($path)=@_;
  local($id,$desc);
  ${$CURRENT}{index}{$path} or return ();
  ($id,$desc)=split('\^',${$CURRENT}{index}{$path});
  $desc;
}

sub read_entry_hash {
  local($path)=@_;
  local($id);
  ${$CURRENT}{index}{$path} or return ();
  ($id)=split('\^',${$CURRENT}{index}{$path});
  MyDB::read_table($CURRENT->{db},$id);
}

sub write_entry_hash {
  local($path,%thash)=@_;
  local($id,$desc,$hasdoc,$update_index=0);
  ${$CURRENT}{index}{$path} or return ();
  ($id,$desc,$hasdoc)=split('\^',${$CURRENT}{index}{$path});
  ( $thash{sdesc} ne $desc ) and $update_index=1;
  ( $thash{doc} and ( ! $hasdoc ) ) and $update_index=1;
  ( ( ! $thash{doc} ) and $hasdoc ) and $update_index=1;
  if ( $update_index ) {
    #looks like they changed the description or done something diff with doc
    $hasdoc=0;
    ( $thash{doc} ) and $hasdoc=1;
    ${$CURRENT}{index}{$path}=join('^',($id,$thash{sdesc},$hasdoc));
    MyDB::write_table($CURRENT->{db},"index",%{$CURRENT->{index}});
  }
  &mark_repos_mod;
  MyDB::write_table($CURRENT->{db},$id,%thash);
}

sub create_entry {
  local($path,%data)=@_;
  local($id,$href);
  $href=$CURRENT->{index};
  $href->{$path} and return 0;
  $id=time();
  sleep(1); #to gaurantee unique ids
  $href->{$path}=join('^',($id,$data{sdesc},0));
  &mark_repos_mod;
  MyDB::write_table($CURRENT->{db},"index",%$href);
  MyDB::write_table($CURRENT->{db},$id,%data);
}

sub return_all_paths {
  keys %{$CURRENT->{index}};
}

sub delete_entry {
  local($path)=@_;
  local($id);
  ${$CURRENT}{index}{$path} or return 0;
  ($id)=split('\^',${$CURRENT}{index}{$path});
  MyDB::delete_table($CURRENT->{db},$id);
  delete ${$CURRENT}{index}{$path};
  &mark_repos_mod;
  MyDB::write_table($CURRENT->{db},"index",%{$CURRENT->{index}});
  1;
}

sub move_entry {
  local($srcpath,$dstpath)=@_;
  local($id,$desc,$hasdoc);
  ${$CURRENT}{index}{$srcpath} or return 0;
  ($id,$desc,$hasdoc)=split('\^',${$CURRENT}{index}{$srcpath});
  delete ${$CURRENT}{index}{$srcpath};
  ${$CURRENT}{index}{$dstpath}=join('^',($id,$desc,$hasdoc));
  &mark_repos_mod;
  MyDB::write_table($CURRENT->{db},"index",%{$CURRENT->{index}});
  1;
}

1;
