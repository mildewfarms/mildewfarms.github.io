
package MyDB;

require 5.002;

use MyFTP;

#########################################################3
### globals
%ALLDBS=(); ## stores current list of all open dbs
#########################################################3

#########################################################3
### close all open databases
#########################################################3
sub close_all {
  foreach $key ( keys %ALLDBS ) {
    close($key);
  }
  1;
}

#########################################################3
### open a database (either ftp or dir)
#########################################################3
sub open {
  local($location)=@_;
  local($href,$ftp);
  $href={};
  $href->{location}=$location;
  if ( $location =~ /ftp:/ ) {
    $ftp=MyFTP::open_ftp_connection($location); 
    $href->{type}="ftp";
    $href->{ftp}=$ftp;
  }else {
    if ( ! -d $location ) {
      print "SM:ERROR:could not open db directory $location. Aborting...\n";
      main::myexit(39);
    }
    $href->{type}="dir";
  }
  $ALLDBS{$href}=1;
  $href;
}

sub close {
  local($db)=@_;
  if ($db->{type} eq "ftp") { 
    MyFTP::close_ftp_connection($db->{ftp});
  }
  delete $ALLDBS{$db};
  1;
}

sub table_exists {
  local($db,$name)=@_;
  local($val);
  if ($db->{type} eq "ftp") { 
    $val = MyFTP::remote_file_exists($db->{ftp},$name);
  }else {
    $val = ( -r "$db->{location}/$name" );
  }
  $val;
}

sub delete_table {
  local($db,$name)=@_;
  if ($db->{type} eq "ftp") { 
    MyFTP::delete_remote_file($db->{ftp},$name);
  }else {
    unlink("$db->{location}/$name");
  }
  1;
}

sub unlock_table {
  local($db,$name)=@_;
  if ($db->{type} eq "ftp") { 
    MyFTP::delete_remote_file($db->{ftp},"$name.lock");
  }else {
    unlink("$db->{location}/$name.lock");
  }
  1;
}

sub lock_table {
  local($db,$name)=@_;
  local($cnt);
  #just wait around for 3 seconds before we just take over
  for($cnt=0;$cnt<3;$cnt++) {
    if ($db->{type} eq "ftp") {
      MyFTP::remote_file_exists($db->{ftp},"$name.lock") or last; 
    }else {
      ( -r "$db->{location}/$name.lock" ) or last;
    }
    sleep 1;
  }
  if ($db->{type} eq "ftp") { 
    MyFTP::put_remote_file($db->{ftp},"/bin/true","$name.lock");
  }else {
    open(LOCK,">$db->{location}/$name.lock");print LOCK "$$\n";close(LOCK);
  }
  1;
}

sub write_table {
  local($db,$name,%thash)=@_;
  local($tmpfile,$fname,$flen1,$flen2);
  lock_table($db,$name);
  if ( $db->{type} eq "ftp" ) {
    $fname="/tmp/sm.$$.db.tmp";
    $tmpfile="/tmp/sm.$$.db.2.tmp";
  }else {
    $fname="$db->{location}/$name"; 
  }
  if ( open(MYDBFOUT,">$fname") ) {
    print MYDBFOUT "SMDB1 " . list2str(%thash); # SMDB1 is just to mark this style of database incase a conversion is needed in the future
    close(MYDBFOUT);
  }else {
    print "SM:ERROR:could not write to table file $fname. Aborting...\n";
    main::myexit(40);
  }
  if ( $db->{type} eq "ftp" ) {
    MyFTP::put_remote_file($db->{ftp},$fname,"$name.$$");
    MyFTP::get_remote_file($db->{ftp},"$name.$$",$tmpfile);
    $flen1=(-s $fname);
    $flen2=(-s $tmpfile);
    unlink $fname;
    unlink $tmpfile;
    if ( $flen1 != $flen2 ) {
      print "SM:ERROR:file put via ftp does not match file sent. Aborting...\n";
      MyFTP::delete_remote_file($db->{ftp},"$name.$$");
    }
    MyFTP::rename_remote_file($db->{ftp},"$name.$$",$name);
  }
  unlock_table($db,$name);
  1;
}

sub read_table {
  local($db,$name)=@_;
  local($fname,$buffer="",$flen,%thash);
  if ( ! table_exists($db,$name) ) {
    print "SM:ERROR:table $name does not exist for read. Aborting...\n";
    main::myexit(42);
  }
  lock_table($db,$name);
  if ( $db->{type} eq "ftp" ) {
    $fname="/tmp/sm.$$.db.tmp";
    if ( MyFTP::remote_file_exists($db->{ftp},$name) ) {
      MyFTP::get_remote_file($db->{ftp},$name,$fname);
    }
  }else {
    $fname="$db->{location}/$name"; 
  }
  $flen=(-s $fname);
  $flen -= 6;
  if ( open(MYDBFIN,"$fname") ) {
    read(MYDBFIN,$buffer,6); #skip over db version field (6 bytes)
    if ( $flen != read(MYDBFIN,$buffer,$flen) ) {
      print "SM:ERROR:could not read in complete table - $name. Aborting...\n";
      unlock_table($db,$name);
      main::myexit(41);
    }
    close(MYDBFIN);
  }else {
    print "SM:ERROR:could not open table file - $fname. Aborting...\n";
    unlock_table($db,$name);
    main::myexit(42);
  }
  if ( $db->{type} eq "ftp" ) {
    unlink $fname;
  }
  unlock_table($db,$name);
  str2list($buffer);
}

#### convert a list to a string using an escaped delimeter of <xXx>
####   NOTE: the only reason for the ugly delimeter was it was not always
####         escaped so it needed to be uncommon
sub list2str {
  local($val,@nlist);
  foreach $val ( @_ ) {
    $val =~ s/<(\\*)xXx>/<\\$1xXx>/g;
    push @nlist,$val;
  }
  join('<xXx>',@nlist);
}

#### convert a string to a list using an escaped delimiter of <xXx>
####   NOTE: the only reason for the ugly delimeter was it was not always
####         escaped so it needed to be uncommon
sub str2list {
  local($nstr)=@_;
  local(@nlist,@olist,$str);
  @nlist=split(/<xXx>/,$nstr);
  foreach $str (@nlist) {
    $str =~ s/<\\(\\*)xXx>/<$1xXx>/g;
    push @olist,$str;
  }
  @olist;
}
1;
