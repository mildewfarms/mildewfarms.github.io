package MyFTP;

#### uses the libnet FTP module written by Graham Barr

require 5.002;

use MyUtil;
use Net::FTP;

#### used to store info about current ftp sessions
%ALLFTPS=();

sub close_all_ftps {
  local($key);
  foreach $key ( keys %ALLFTPS ) {
    close_ftp_connection($key); 
    delete $ALLFTPS{$key};
  }
  1;
}

sub dumb_crypt {
  local($str)=@_;
  local($newstr="",$ch,$val);
  for($a = 0;$a < length($str);$a++) {
    $ch=substr($str,$a,1);
    $val=ord($ch)+1;
    $newstr .= chr($val);
  } 
  $newstr;
}

sub dumb_uncrypt {
  local($str)=@_;
  local($newstr="",$ch,$val);
  for($a=0;$a<length($str);$a++) {
    $ch=substr($str,$a,1);
    $val=ord($ch)-1;
    $newstr .= chr($val);
  } 
  $newstr;
}

sub parse_ftp_url {
  local($location)=@_;
  local($userspec,$hostname,$dirname,$user,$pass,$junk);
  if ( $location =~ m^ftp://(.*?)\@(.*?)/(.*)^ ) {
    $userspec=$1;
    $hostname=$2;
    $dirname=$3;
    ($user,$pass)=split(/:/,$userspec);
    $dirname="/" . MyUtil::trim($dirname);
    $hostname=MyUtil::trim($hostname);
    $user=MyUtil::trim($user);
    $pass=MyUtil::trim($pass);
    if ( $pass =~ /enc=/ ) {
      ($junk,$pass)=split('=',$pass);
      $pass=dumb_uncrypt(MyUtil::trim($pass));
    }
  }else {
    print "SM:ERROR:could not parse ftp URL. Aborting...\n";
    main::myexit(35);
  }
  ($hostname,$user,$pass,$dirname);
}

sub show_ftp_error {
  local($ftp,$mesg)=@_;
  if ($ALLFTPS{$ftp}) {
    ($hostname,$uname,$dname)=split('\^',$ALLFTPS{$ftp});
    print "SM:ERROR:ftp error: $mesg : host=$hostname,user=$uname,dir=$dname. Aborting...\n";
  }else {
    print "SM:ERROR:ftp error: $mesg. Aborting...\n";
  }
  close_ftp_connection($ftp);
  main::myexit(36);
}

sub close_ftp_connection {
  local($ftp)=@_;
  delete $ALLFTPS{$ftp};
  $ftp->quit;
}

sub open_ftp_connection {
  local($location)=@_;
  ($hostname,$user,$pass,$dirname)=parse_ftp_url($location);
  $ftp = Net::FTP->new($hostname,Timeout => 10) or show_ftp_error("","Could not open connection to $hostname");
  $ALLFTPS{$ftp}="$hostname^$user^$dirname";
  $ftp->login($user,$pass) or show_ftp_error($ftp,"Could not login");
  $ftp->binary() or show_ftp_error($ftp,"Could not switch to binary");
  $ftp->cwd($dirname) or show_ftp_error($ftp,"Could not change dir");
  $ftp;
}

sub remote_file_exists {
  local($ftp,$name)=@_;
  local(@rfiles);
  @rfiles=$ftp->ls($name);
  ( $rfiles[0] eq $name ) or return 0;
  return 1;
}

sub get_remote_file {
  local($ftp,$name,$nameto)=@_;
  $ftp->get($name,$nameto) or show_ftp_error($ftp,"Getting file - $name => $nameto"); 
}

sub put_remote_file {
  local($ftp,$name,$nameto)=@_;
  $ftp->put($name,$nameto) or show_ftp_error($ftp,"Putting file - $name => $nameto"); 
}

sub delete_remote_file {
  local($ftp,$name)=@_;
  $ftp->delete($name) or show_ftp_error($ftp,"Deleting file $name");
}

sub rename_remote_file {
  local($ftp,$name,$nameto)=@_;
  $ftp->rename($name,$nameto) or show_ftp_error($ftp,"Renaming $name to $nameto");
}
1;
