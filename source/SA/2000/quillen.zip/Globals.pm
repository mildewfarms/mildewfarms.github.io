
package Globals;

require 5.002;

use MyUtil;
use Sys::Hostname;

#### global vars ##############################
$version="1.1";
# holds mappings between shelldefs and their names
%shelldefs=(
	sh => "/bin/sh {file} {args}",
	csh => "/bin/csh {file} {args}",
	ksh_debug => "/bin/ksh -x {file} {args}",
	bash => "/bin/bash {file} {args}",
	perl => "/usr/bin/perl {file} {args}",
	perl_strict => "/usr/bin/perl -w {file} {args}",
	ksh => "/bin/ksh {file} {args}",
);
%reposdefs=();  # holds mappings between reposdefs and their names
%retained_envs=(); # holds env vars that should be retained before run
($hostname)=split(/\./,Sys::Hostname::hostname());
$conf_file="/etc/sm.conf";
$conf_file_host="/etc/sm.conf.$hostname";
###get the users home dir#######
@userinfo=getpwuid($<);
$home_dir=MyUtil::trim($userinfo[7]);
$home_dir or $home_dir=$ENV{"HOME"};
( -d "$home_dir" ) or ($home_dir="/tmp");
##########################################
$curr_username=""; #current user name
$curr_username= (getpwuid($>))[0] || getlogin || "nobody";
$curr_rusername= (getpwuid($<))[0] || getlogin || "nobody";
$curr_sudo_username=$ENV{SUDO_USER};
if ( $curr_sudo_username ) {
  $log_file="/var/tmp/sm.log.$curr_sudo_username";
}else {
  $log_file="/var/tmp/sm.log.$curr_rusername";
}
$per_conf_file="$home_dir/.sm.conf";
$per_conf_host_file="$home_dir/.sm.conf.$hostname";
$curr_repos=$ENV{"SM_REPOS"} || "default"; # current repos name
if ( $ENV{"SM_REPOS_DEF"} ) {
  $curr_repos_def=$ENV{"SM_REPOS_DEF"};
  $curr_repos="ENV{SM_REPOS_DEF}";
}else {
  $curr_repos_def="";
}
$use_runners_umask_as_default=0; #by default use 077 
$dont_wipe_env_vars_by_default=0; #by default wipe them out except for the retained list

sub set_level {
  local($level)=@_;
  $curr_level=$level; # current level
  if ( $curr_sudo_username ) {
    $cwd_file="$home_dir/.sm.cwd.$curr_sudo_username.$curr_repos";
  }else {
    $cwd_file="$home_dir/.sm.cwd.$curr_rusername.$curr_repos";
  }
  if (open(CCOUT,">$cwd_file")) {
    print CCOUT "$level\n";
    close(CCOUT);
    return 1;
  }
  return 0;
}

sub get_level {
  $curr_level;
}

sub get_stored_level {
  $curr_level="/"; # current level
  if ( $curr_sudo_username ) {
    $cwd_file="$home_dir/.sm.cwd.$curr_sudo_username.$curr_repos";
  }else {
    $cwd_file="$home_dir/.sm.cwd.$curr_rusername.$curr_repos";
  }
  if ( -r "$cwd_file" ) { 
    if (open(CCIN,"$cwd_file")) {
      $curr_level=<CCIN>;
      $curr_level=MyUtil::trim($curr_level);
      ( $curr_level =~ /\/$/ ) or $curr_level="/";
      close(CCIN);
    }
  }
  $curr_level;
}
1;
