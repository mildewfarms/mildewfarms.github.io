#!/bin/sh

if [ ! -r SM.pl ]
then
  echo "Thats funny...I cant find the SM.pl file. You should run this from"
  echo "  the directory you unpack Script Manager in. Aborting..."
  exit 1
fi

echo ""
echo "This script will try to install Script Manager by simply"
echo "     doing the following:"
echo ""
echo "1 - determine where your perl binary is"
echo ""
echo "2 - determine a directory to store Script Manager libs and copy them over"
echo ""
echo "3 - Build an sm executable and optionally place it for you"
echo ""
echo "Now for 1..."
if which perl 2> /dev/null | grep "no perl" > /dev/null
then
  echo "I could not find perl. So where is it?"
  read PPATH
else
  PPATH=`which perl 2> /dev/null`
  echo "I found a perl binary at $PPATH. Is this correct? [y] "
  read ans
  if [ "$ans" = "n" ]
  then
    echo "So where is it then? "
    read PPATH
  fi
fi
echo ""
echo "I have a perl path of $PPATH. If this is not correct, dont worry. Im"
echo "  only going to jam it at the top of the sm executable for you. You"
echo "  can change it later."
echo ""
echo "Now for 2..."
echo ""
echo "Enter in a directory to install the Script Manager files or just"
echo "  hit Enter to use the current directory: [./] \c"
read SPATH
if [ "$SPATH" = "" ]
then
  SPATH=`/bin/pwd`
fi
if [ ! -d $SPATH ]
then
  echo "$SPATH does not exist. Do you want me to create it? [y] \c"
  read ans
  if [ "$ans" = "n" ]
  then
    echo "Im outta here..."
    exit 3
  fi
  if mkdir -p $SPATH
  then
    :
  else
    echo "Error creating $SPATH. Aborting..."
    exit 4
  fi
fi
CPATH=`/bin/pwd`
if [ "$CPATH" != "$SPATH" ]
then
  tar -cpf - . | ( cd $SPATH;tar -xpf -)
fi
echo ""
echo "Now for 3..."
echo ""
(echo "#!$PPATH";echo "use lib \"$SPATH\";";cat SM.pl) > /tmp/sm.$$
chmod 755 /tmp/sm.$$
echo ""
echo "OK, I built the sm executable and it is sitting at: /tmp/sm.$$"
echo ""
echo "If you want, enter in the directory to move this file to or Ctrl-C to quit:"
read NDIR
if [ ! -d $NDIR ]
then
  echo "$NDIR doesnt exist. Aborting. Remember the file is at /tmp/sm.$$."
  exit 2
fi
if cp /tmp/sm.$$ $NDIR/sm
then 
  rm -f /tmp/sm.$$
  echo "It has been moved!"
  echo ""
  ls -l $NDIR/sm
  echo ""
else
  echo ""
  echo "Got an error copying /tmp/sm.$$. Aborting..."
  echo ""
fi
exit 0
