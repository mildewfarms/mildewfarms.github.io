package MyUtil;

require 5.002;

sub display_time_diff {
  local($before,$after)=@_;
  local($diffsecs,$diffmins,$diffhours,$diffdays);
  $diffsecs=$after-$before;
  $diffdays=int($diffsecs/(3600*24));
  $diffsecs -= $diffdays*3600*24;
  $diffhours=int($diffsecs/3600);
  $diffsecs -= $diffhours*3600;
  $diffmins=int($diffsecs/60);
  $diffsecs -= $diffmins*60;
  ($diffdays) and return "${diffdays} days ${diffhours} hrs ${diffmins} mins ${diffsecs} secs";
  ($diffhours) and return "${diffhours} hrs ${diffmins} mins ${diffsecs} secs";
  ($diffmins) and return "${diffmins} mins ${diffsecs} secs";
  return "${diffsecs} secs";
}

sub prompt_for_choices {
  local($text,$cval,@options)=@_;
  local($sdesc,$num);
  while(1) {
    print "\n$text\n";
    print "CURRENT: [$cval]\n";
    $num=0;
    while( $num < @options ) {
      print "\t$num - $options[$num]\n";
      $num++;
    }
    print "ENTER: ";
    $sdesc=<STDIN>;
    $sdesc=trim($sdesc);
    ( $sdesc eq "" ) and $sdesc=$cval;
    ( $sdesc =~ /^\d+$/ ) or next;
    ( $options[$sdesc] ) and last;
  }
  $sdesc;
}

sub prompt_for_value {
  local($text,$cval,$empty_string_allowed)=@_;
  local($sdesc);
  while(1) {
    print "\n$text\n";
    print "CURRENT: [$cval]\n";
    print "ENTER: ";
    $sdesc=<STDIN>;
    $sdesc=trim($sdesc);
    ( $sdesc eq "" ) and $sdesc=$cval;
    ( $empty_string_allowed ) and last;
    ( $sdesc eq "" ) or last;
  }
  $sdesc;
}

#### ASSUMES all dir paths end in / ####
sub parse_path {
  local($path)=@_;
#print "p in $path xxx\n";
  $path=trim($path);
  #handle special case of root dir
  #( $path eq "/" ) and return ("/","");
  @plist=split(/\//,$path);
  @rplist=reverse @plist; 
  if ( $path =~ /\/$/ ) {
    $fname="";
    $dname=$path;
  }else {
    $fname=$rplist[0];
    pop @plist;
    $dname=join('/',@plist) . "/";
  }
#print "d: $dname f: $fname yyy\n";
  ($dname,$fname);
}

#### ASSUMES all dir paths end in / ####
sub parent_dir {
  local($path)=@_;
  $path=trim($path);
  #handle special case of root dir
  ( $path eq "/" ) and return "";
  @plist=split(/\//,$path);
  @rplist=reverse @plist; 
  pop @plist;
  $dname=join('/',@plist) . "/";
  $dname;
}

#### ASSUMES all dir paths end in / ####
sub child_path {
  local($path)=@_;
  local($pdir);
  $path=trim($path);
  $pdir=parent_dir($path);
  ( ! $pdir ) and return "";
  $path =~ s/^$pdir//;
  MyUtil::trim($path);
}

sub trim {
  local($str)=@_;
  $str =~ s/^\s*(.*?)\s*$/$1/; #get rid of pre/post whitspace
  $str;
}

sub readkey {
  local($val);
  system "stty -icanon min 1 time 0";
  $val=getc;
  system "stty icanon";
  $val;
}

