#!/bin/ksh

##############################################################################
# backup.sh - Written May 6, 1999 by Jeff Gilbertson (jgilber@yahoo.com)
##############################################################################

# Everything starts from the root directory
cd /

function Report_Status {
  echo "`date '+%d%b%Y %H:%M'` $STATUS" > $SLOG
  echo "`date '+%d%b%Y %H:%M'` $STATUS" >> $BLOG 
  echo "`date '+%d%b%Y %H:%M'` $STATUS" >> $TLOG
  if [ `echo '$STATUS' | egrep -c "failed|successful"` = 1 ]
  then
    echo "`date '+%d%b%Y %H:%M'` $STATUS" >> $VLOG
  fi
}

function Abort_Backup {
  mail -s "Backup problem on $HOST" $RECIPIENTS << EOF
  $STATUS
EOF
  Report_Status
  exit 1
}

# Set variables
  LOGBACK=/usr/spool/logs/backup
  LOGSYS=/usr/spool/logs/sysfiles
  BLOG=$LOGBACK/Backup.Log
  VLOG=$LOGBACK/Verify.Log
  LFILE=$LOGBACK/backup.`date +'%d'`
  LGB=$LOGBACK/LastGoodBackup
  SLOG=$LOGBACK/Backup.Status
  TLOG=/backup/TapeLog
  SNFILE=/backup/SerialNumber
  HOST=`hostname | cut -d "." -f1`
  ERRCK="^cpio"
  SKIP2="2001032"

  # Use alternate config file if specified on the command line
  if [ "$1" = "" ]
  then
    CFG=/backup/backup.cfg
  else
    CFG=$1
  fi

# Abort backup (with email notification) if config file is missing
  if [ ! -f $CFG ]
  then
    STATUS="Backup aborted on $HOST: Missing configuration file"
    Abort_Backup
  else
    # Read in values from configuration file
    . $CFG
  fi

# Abort backup (with email notification ) if $TAPE is not a valid device file
  if [ ! -c $TAPE ]
  then
    STATUS="Backup aborted on $HOST: Bad device file"
    Abort_Backup
  fi

# Copy system files
  # Create the directories if they don't exist
  for DIR in $LOGBACK $LOGSYS
  do
    if [ ! -d $DIR ]
    then
      mkdir -p $DIR && chmod 755 $DIR
    fi
  done

  # Make a backup copy of important system files
  for FILE in passwd shadow group inittab
  do
    if [ -f /etc/$FILE ]
    then
      cp /etc/$FILE $LOGSYS/$FILE.`date +'%d'`
      chmod 400 $LOGSYS/$FILE.`date +'%d'`
    fi
  done

# Determine if this will be a daily or weekly backup
  BTYPE="Daily"
  if [ "`date '+%w'`" = "0" ]
  then
    if [ "$WEEKLY" = "1" ]
    then
      BTYPE="Weekly"
    fi
  fi
  STATUS="Starting $BTYPE backup on $HOST"
  Report_Status

# Create the files that will be used for verification following the backup
  ps -ef > /backup/verify.data
  sum -r /backup/verify.data > /backup/verify.sum

# Manage Serial Number and Tape Log files
  # Remove existing files from server
  rm -f $SNFILE $TLOG

  # Rewind tape
  eval $REW_CMD >> /backup/errlog 2>&1

  # Advance to the first file on tape
  eval $GOTO_F1_CMD >> /backup/errlog 2>&1

  # Don't try to read the serial number off the tape unless it is
  # after XXXX XX, XXXX - this will cause one to be assigned.
  if [ `date +'%Y%j'` -gt "$SKIP2" ]
  then
    # Read serial number from tape
    eval $READ_F1_CMD >> /backup/errlog 2>&1
  fi

  # If the file wasn't restored, then it must be a tape that doesn't yet
  # have a serial number or log file associated with it, so create both.
  if [ ! -f $SNFILE ]
  then
    # Create a serial number for this tape.
    if [ `date +'%H'` -gt 5 ]
    then
      DY=`date +%d`
    else
      DY=`TZ=MST+24 date +%d`
    fi
    SN="$HOST-$DY"
    echo $SN > $SNFILE
    echo "`date '+%d%b%Y %H:%M'` Assigning serial number $SN to this tape" > $TLOG
  else
    # Since the Serial Number file was found, there must also be a Tape Log.
    # Advance to last file on tape
    eval $GOTO_F3_CMD >> /backup/errlog 2>&1

    # Restore log file
    eval $READ_F3_CMD >> /backup/errlog 2>&1

    # Set the SN variable to today's tape serial number
    SN=`cat $SNFILE`
    echo "`date '+%d%b%Y %H:%M'` Read serial number $SN from tape" >> $TLOG
  fi

  if [ ! -f $SNFILE ]
  then
    # Something is amiss. Abort backup (with email notification).
    STATUS="Backup aborted on $HOST: No serial number on tape."
    Abort_Backup
  fi

  if [ ! -f $TLOG ]
  then
    # Something is amiss. Abort backup (with email notification).
    STATUS="Backup aborted on $HOST: No log file on tape."
    Abort_Backup
  fi

# Make sure this is not the same tape that was used yesterday
  # Get filename of yesterday's backup
  YESTFN=`ls -ldtr $LOGBACK/backup.* 2>&1 | tail -1 | awk '{ print $9 }'`

  # Get tape serial number from the last line of yesterday's backup file
  if [ "$YESTFN" != ""  ]
  then
    YESTSN=`tail -1 $YESTFN | awk -F\- '{ print $NF }'`
  fi

  # Abort backup (with email notification) if they match
  if [ "`echo $SN | awk -F\- '{ print $NF }'`" = "$YESTSN" ]
  then
    STATUS="Backup aborted on $HOST: Tape not changed"
    Abort_Backup
  fi

# Begin process of creating today's backup tape

  # Rewind tape
  echo "`date '+%d%b%Y %H:%M'` Rewinding $TAPE" >> $TLOG
  eval $REW_CMD >> /backup/errlog 2>&1

  # Write Serial Number
  echo "`date '+%d%b%Y %H:%M'` Writing serial number $SN to $TAPE" >> $TLOG
  eval $WRITE_F1_CMD >> /backup/errlog 2>&1
  rm -f $SNFILE

# Start Backup
  if [ "$PRE" = "1" ]
  then
    STATUS="$BTYPE: Performing pre-backup commands on $HOST"
    Report_Status
    /backup/backup.pre
  fi

  if [ "$BTYPE" = "Weekly" ]
  then
    STATUS="$HOST: $BTYPE: $WEEKLY_BU_CMD"
    Report_Status
    eval $WEEKLY_BU_CMD > $LFILE 2>&1
  else
    STATUS="$HOST: $BTYPE: $DAILY_BU_CMD"
    Report_Status
    eval $DAILY_BU_CMD > $LFILE 2>&1
  fi

  # Add tape serial number information to the backup file
  echo "Tape number: $SN" >> $LFILE

  if [ "$POST" = "1" ]
  then
    STATUS="$BTYPE: Performing post-backup commands on $HOST"
    Report_Status
    /backup/backup.post
  fi

  STATUS="Completed $BTYPE backup on $HOST"
  Report_Status

# Check for backup errors
  if [ "`grep -c $ERRCK $LFILE`" -gt "0" ]
  then
    STATUS="`grep $ERRCK $LFILE`"
    Report_Status
  fi

# Verify Backup
  STATUS="$BTYPE backup verification in progress on $HOST"
  Report_Status

  # Rewind tape
  echo "`date '+%d%b%Y %H:%M'` Rewinding $TAPE" >> $TLOG
  eval $REW_CMD >> /backup/errlog 2>&1

  # Go to file two on tape
  echo "`date '+%d%b%Y %H:%M'` Positioning $TAPE at file two" >> $TLOG
  eval $GOTO_F2_CMD >> /backup/errlog 2>&1

  # Remove existing verification files
  rm -f /backup/verify.data /backup/verify.sum

  STATUS="$HOST: Restoring: $RESTORE_CMD"
  Report_Status
  eval $RESTORE_CMD >> /backup/errlog 2>&1

  sum -r /backup/verify.data > /backup/verify.test
  cmp -s /backup/verify.sum /backup/verify.test > /dev/null

  if [ "$?" -ne "0" ]
  then
    # Verification failed
    STATUS="** $BTYPE backup verification failed on $HOST. Tape number $SN."
    Report_Status
    for VFILE in /backup/verify.data /backup/verify.sum /backup/verify.test
    do
      if [ -f $VFILE ]
      then
        ls -l $VFILE >> $TLOG
        cp $VFILE $VFILE.diag
      else
        echo "$VFILE does not exist" >> $TLOG
      fi
    done
  else
    # Verification passed
    STATUS="$BTYPE backup verified successful on $HOST. Tape number $SN."
    Report_Status
    rm -f $LGB
    echo "`date '+%d%b%Y'` ($BTYPE)" > $LGB
  fi

# Remove verification files
  rm -f /backup/verify.data /backup/verify.sum /backup/verify.test

# Write Log File
  echo "`date '+%d%b%Y %H:%M'` Writing log file to $TAPE\\n" >> $TLOG
  eval $GOTO_F3_CMD >> /backup/errlog 2>&1
  eval $WRITE_F3_CMD >> /backup/errlog 2>&1

# Rewind tape so it is at the beginning the next time it is used
  eval $REW_CMD >> /backup/errlog 2>&1

# Start an at job to run at 2300.
at 2300 <<EOF> /dev/null
echo "Backup did not start on $HOST" > $SLOG
EOF

# Exit gracefully
exit 0
