to start.
0.  Preludes
	a.create ftp user balsa, password balsa (usually home dir /dev/null). 
	NOTE: insure you have perms to w/r to the applic dirs:
		such as:
			-local_temp
			-ftp_source_dir
			-master_cache
			-cfg and profiles dirs
	recc win32 ftpd systems (in no order of personal prefs):
		-warftpd
		-Hummingbird inted package
		-older windows IIS servers
        (NOTE: win32 defaults to ASCII , use bin(ary)!!!!) 
	b.install perl, libnet and tk perl (tk only for those needing gui)
	where can I find?
		Perl Unix
			*www.perl.com
		Perl Win32
			*www.activestate.com
	        (get libnet version 1.06 or later)	
		Libnet Unix
			*www.perl.com/CPAN 
		(read the README on ppm ppm.bat)
		Libnet  win32
			*www.activestate.com/packages/zips
		Perl/Tk Unix
			*www.perl.com/CPAN 
		(read the README on ppm ppm.bat)
		Perl/Tk  win32
			*www.activestate.com/packages/zips
	c. Set up a directory /tmp/spool/out or N:\tmp\spool\out.
	on the master email server (the one that will exec sendmail)
		this is for non-mailing clients to ftp to the mailsrv
		administrator.
				
make sure that these dirs exist (using winzip on win32 will often miss them):
	log
	db 
	spool
	spool/in
	spool/out
	tmp
before running step 1.

1. run perl install00.pl under the ../bin dir.
   
2. edit the mailsvr and mailpath in the ../cfg dir as desired.
Note that mailpath for windows often needs editing after install script.
 As do the setup.ini and CUSTOM_CFG entries (remove the win32 on these)
 Specifically, source_path needs to be of the form
    unix: /apps/balsa/log/gl_syslog
    win32: c!/apps/balsa/log/gl_syslog
    (yes, reverse slashes are okay on win32)
 and ftp_source_path is usually just like unix 
    /apps/balsa/log/gl_syslog
 for both win32 and unix

Also edit the vars 
	-aux_pgm
	-master_pgm
	-dbmaint_pgm 
	-local_temp
	-aux_kill_time
  	-use_aux_locl
	-master_cache
in setup.ini

3. Verify setup:
make sure the SUBSCRIBER_TABLE has entries of the form:
(win32) 24.4.109.210:C!/apps/devel/log/gl_syslog:2112:24.4.109.210
(unix)  24.4.109.210:/apps/devel/log/gl_syslog:2112:24.4.109.210

make sure that setup.ini has entries of the form (at the bottom):
  server=24.4.109.210
  source_dir=c!/apps/devel   (for win32)
  source_dir=/apps/devel     (for unix )
  ftp_source_dir=/apps/devel (for ftping over)

OPTIONAL ( a heck of a backup):
verify CUSTOM_CFG has entries of the form (at the bottom):
  server=24.4.109.210
  source_dir=C!/apps/devel   (for win32)
  source_dir=/apps/devel     (for unix )
	 
4. for each node in an instance,
edit the CUSTOM_CFG and setup.ini files to point at the server 
you wish your instance to be under, ie: change server=ip_addr 
and ftp_source_dir to that of the master. (source_dir is local)

5. edit the licensing stuff.
	  -get the license codes for your nodes by contacting Balsa support with
		the following info:  hostname (run balsa_hostname.pl) and
		your contract number that gives support and app