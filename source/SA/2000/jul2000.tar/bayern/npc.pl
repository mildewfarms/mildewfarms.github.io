#!/usr/bin/perl

# NP (Named Pipes) Complete 
# Version 1.0
#    For wish v1.0.
# By Shawn Bayern
#
# Allows (multiple) arbitrary processes to communicate with a single target
# process using named pipes.  Usage:
#
#     npc.pl process read-pipe write-pipe
#
# npc places itself in the backgroun
#
# If either pipe already exists, it will be overwritten.  Otherwise, it
# will be created automatically.  Either way, both pipes will be deleted
# when we are finished.
#
# Make sure that every I/O fragment that we write to our 'write pipe' 
# ends with a newline so that our clients can just read lines instead of
# having to parallel our own logic to implement turn-taking between our
# target applications' reads and writes.
#
###############################################################################

###
### Parameters
###

# How many seconds do we wait for a handle's I/O before we assume
# that it is done?
$patience = 0.5;

###############################################################################

# Get arguments
$process = shift;
$rp = shift;
$wp = shift;

# Check proper usage
die "Usage: npc.pl process rpipe wpipe\n" if (!$process or !$rp or !$wp);

unlink($rp);
die "npc: mknod error" if (system("mknod $rp p"));
unlink($wp);
die "npc: mknod error" if (system("mknod $wp p"));

# Set up pipes (and unbuffer them as appropriate)
pipe IREAD, IWRITE;
pipe OREAD, OWRITE;
select IWRITE;
$| = 1;
select OWRITE;
$| = 1;

# Unbuffer the default handles, leaving STDOUT selected
select STDERR;
$| = 1;
select STDOUT;
$| = 1;

#### Stick ourselves in the background and return as soon as possible
###if (!defined($tmppid = fork)) {
###    die "Fork failure!\n";
###} elsif ($tmppid) {			    # Parent
###    exit;
###}

# Create and communicate with child
if (!defined($pid = fork)) {                # Fork() failure
    die "Fork failure!\n";
} elsif (!$pid) {                           # Child

    # Here, simply set up I/O and spawn our target process
    close IWRITE;
    close OREAD;
    open STDIN, "<&IREAD";
    open STDOUT, ">&OWRITE";
    open STDERR, ">&OWRITE";
    exec $process;

} else {				    # Parent

    $SIG{CHLD} = \&cleanup;		    # Handle child's termination
    $SIG{INT} = \&cleanup;		    # Handle manual server termination

    # Close unnecessary handles
    close IREAD;
    close OWRITE;

    # Open the named pipes
    open RP, "< $rp" or die "npc.pl: open error";
    open WP, "> $wp" or die "npc.pl: open error";

    # Our model is as follows and is intended to support an approach
    # to I/O where our target process "takes turns" reading and writing.
    # This is done to preserve the ability for our client process(es)
    # to check whether our target process is blocking on I/O.
    # 
    # (a) Block on OREAD; when it's ready to be read, route anything that
    #     comes from it to WP.
    # (b) Block on RP; when it's ready to be read, route anything that comes
    #     from it to IWRITE.
    # (c) Repeat the cycle again, starting from (a).
    #
    # Note that this assumes that our target process initiates communciation.
    # This is an imperfect assumption but is made for the sake of simplicity;
    # the biggest set of applications that this appears to rule out is
    # straightforward 'filter' applications (such as 'fmt').  These
    # applications can still be used with 'wish' but will need to be handled
    # differently (at worst, via file redirection).
    #
    # We use a simple technique involving select() instead of alternating
    # between a blocking and nonblocking handle.  We give each handle
    # up to $patience seconds to respond.

    while (1) {

#printf("Handling OREAD...\n");
	# Handle OREAD
	$rin = '';
	vec($rin, fileno(OREAD), 1) = 1;
	select($rin, undef, undef, undef);			# block
	do {
	    sysread OREAD, $c, 1;
	    syswrite WP, $c, 1;
	} while (select($rin, undef, undef, $patience));	# poll
	syswrite WP, "\n", 1;

#printf("Handling RP...\n");
	# Handle RP
	$rin = '';
	vec($rin, fileno(RP), 1) = 1;
	select($rin, undef, undef, undef);			# block
	do {
	    sysread RP, $c, 1;
	    syswrite IWRITE, $c, 1;
	} while (select($rin, undef, undef, $patience));	# poll

    }
}

# Child terminated, so clean up and quit
sub cleanup {
   unlink($rp);
   unlink($wp);
   exit;
}
