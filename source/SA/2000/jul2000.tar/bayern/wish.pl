#!/usr/bin/perl

# wish: the web-interface shell, version 1.0
# By Shawn Bayern
# Note: This script should be run as root and depends on npc.pl.
#
###############################################################################

use Socket;

# Read in and respond to our configuration file
&configure;

# Our name (for return URLs, etc.)
$hostname = `hostname`;
chop($hostname);

# Constants for URL requests
$cr = $commandrequest = "cr";	# execute command (possibly internal)
$icommand = "ic";		# execute interactive command
$iterminate = "it";		# terminate interactive command prematurely
$viewfile = "vf";		# invoke file viewer on argument
$dirlist = "dl";		# list the current directory

# Standard socket/bind/listen sequence, made trivial by Perl.
socket(Server, PF_INET, SOCK_STREAM, getprotobyname('tcp'))
    or die "socket: $!";
bind(Server, sockaddr_in($bindport, INADDR_ANY)) or die "bind: $!";
listen(Server, SOMAXCONN) or die "listen: $!";

# Ignore SIGCHLD
$SIG{CHLD} = 'IGNORE';

# Handle SIGINT nicely
$SIG{INT} = \&dienicely;

# Reread configuration on SIGHUP
$SIG{HUP} = \&configure;

# Make sure we're not passed some CWD inadvertently from the master environment
$ENV{'CWD'} = '';

# Our basic server logic
while (TRUE) {
    $paddr = accept(Client, Server);

    select Client;				# unbuffer the Client fd
    $| = 1;
    select STDOUT;

    my ($port, $iaddr) = sockaddr_in($paddr);
    my $name = gethostbyaddr($iaddr, AF_INET);
    # We've got a connection, so fork
    if (!defined($pid = fork)) {		# Fork() failure
	print "Fork failure!\n";
    } elsif (!$pid) {				# Child
	&respond;
	exit;					# Just in case
    } else {					# Parent
	# Delete old state files
	&state_garbage_collect;

	# Get ready to accept a new client...
	print "Parent closing connection...\n";
	close Client;
	exit if $request eq "/die";		# Accept termination command
    }
}


# respond: handle a single connection; called by child processes that
# are set up to respond to individual requests
sub respond {

    print "INPUT FROM CLIENT:\n";

    # Read input from client and print it to stdout, just for our own
    # information.
    while ($clientline = <Client>) {
	last if ($clientline =~ /^\s*$/);
	print "   ",$clientline;
	if ($clientline =~ /^GET/) {

	    ($method, $request) = split " ", $clientline, 2;

	    # remove initial '/'
	    $request =~ s|^/||g;

	    # Eliminate HTTP signature and/or newline if they're present
	    $request =~ s|( HTTP/\d+(.\d+)?)?\s+$||;

	}
    }

    # Get the unique ID from the URL if it's there, and eliminate it from
    # the received request (to simplify further processing).  Accepting
    # the unique user identifier at this point and in this manner allows
    # the request format to be the same between straight, hard-coded URLs
    # and generated responses from forms.  (If we left it as a form variable,
    # which is one alternative, this would not be the case.)
    if ($request =~ /^id=/) {
	($idstring, $rest) = split /\//, $request, 2;
	$idstring =~ s/^id=//;
	$ENV{'ID'} = $idstring;
	$request = $rest;
    } else  {
	# Otherwise, authenticate the user, and generate a random token
	# only if the user has presented a valid username/password pair.
	$credentials = $request;
	$credentials =~ s|^\?||;
	$credentials =~ s|/$||;
	cgiproc($credentials, \%CRED);
	($name, $password, $u, $g, $junk) = getpwnam $CRED{'username'};

	# check the password we received
	if ($name && $CRED{'password'} and
	  crypt($CRED{'password'}, $password) eq $password) {
	    $ENV{'ID'} = rand;			# successful authentication
	    &savestate($ENV{'ID'}, 'ID');
	    chown $u, $g, "$statedir/$ENV{'ID'}"
		|| unlink("$statedir/$ENV{'ID'}");
	    chmod 0600, "$statedir/$ENV{'ID'}"
		|| unlink("$statedir/$ENV{'ID'}");
	}
    }

    # Determine the command
    my ($command, $arguments) = split /\?/, $request;
    cgiproc($arguments, \%FORM);

    # Check to make sure state is valid
    if (! &validstate($ENV{'ID'}) ) {
	&greet_client(Client);
	&print_header(Client);
	&fail_client(Client);
	exit;
    } else {
	# state is valid, so assume an appropriate identity
	($junk, $junk, $junk, $junk, $uid, $gid, $junk) =
	    stat("$statedir/$ENV{'ID'}");
	($(, $)) = ($gid, "$gid $gid");
        ($<, $>) = ($uid, $uid);
    }

    # Load state based on the identifier we received (or created)
    &loadstate($ENV{'ID'});

    # Assign a current working directory (our knowledge of which is
    # maintaied with $ENV{'CWD'} if necessary
    unless ($ENV{'CWD'}) {
	chdir;
	chomp($ENV{'CWD'} = `pwd`);
	&savestate($ENV{'ID'}, 'CWD');
    }

    # Now, change the unique identifier to a new random value, and maintain
    # our internal state (in the filesystem) appropriately.
    my $oldstateID = $ENV{'ID'};
    $ENV{'ID'} = rand;
    &bridgestate($oldstateID, $ENV{'ID'});

    # Respond to the client
    &greet_client(Client);
    &print_header(Client);

    # Act on the command
    if ($command eq $commandrequest) {
	# Favor a manually entered command, if it's there.
	$command = $FORM{'cmd'} or $command = $FORM{'prevcmd'};
	if ($command) {

	    # Limit commands if desired (for security purposes)
	    @command = split " ", $command;
	    $passable = 1;
	    if ($restricted) {
		$passable = 0;
		foreach $possible (@allowed) {
		    if ($command[0] eq $possible) {
			$passable = 1;
		    }
		}
	    }

	    if ($command =~ /[^\w -\/<>]/ || ! $passable) {
		&client_error(Client, "Sorry, that command is restricted!");
	    } else {
		if ($command =~ /^cd/) {			# Int. cmds
		    ($cd, $directory) = split " ", $command;
		    chdir($directory) if $directory;
		    chomp($ENV{'CWD'} = `pwd`);
		    &savestate($ENV{'ID'}, 'CWD');
		    &client_ls(Client);				# send new list
		} else {					# Ext. cmds
		    &client_exec(Client, $command);		# Run it!
		}
	    }

	    chomp($oldhist = $ENV{'cmdhist'});
	    $ENV{'cmdhist'} = $oldhist . "$command;";		# Record it!
	    &savestate($ENV{'ID'}, 'cmdhist');			# Save it!

	}
    } elsif ($command eq $viewfile) {
	&viewfile(Client, $arguments);				# Show file
    } elsif ($command eq $dirlist) {
	&client_ls(Client);					# List dir.
	chomp($oldhist = $ENV{'cmdhist'});
	$ENV{'cmdhist'} = $oldhist . "ls;";
	&savestate($ENV{'ID'}, 'cmdhist');
    } elsif ($command eq $icommand) {

	# Handle interactive command
	if (!$ENV{'ICOMMAND'}) {			# new icommand

	    $ENV{'ICOMMAND'} = $FORM{'cmd'};		# marker

            # Limit commands if desired (for security purposes)
            @command = split " ", $FORM{'cmd'};
            $passable = 1;
            if ($restricted) {
                $passable = 0;
                foreach $possible (@allowed) {
                    if ($command[0] eq $possible) {
                        $passable = 1;
                    }
                }
            }
	    if (!$ passable) {
		print Client "Sorry, that command is restricted!\n";
		$ENV{'ICOMMAND'} = "";
                &savestate($ENV{'ID'}, 'ICOMMAND');
                &command_prompt(Client);
                return;
	    }

	    # Remove slashes from command for use in named pipes' names
	    $pipebase = $ENV{'ICOMMAND'};
	    $pipebase =~ s|/|,|g;

	    &savestate($ENV{'ID'}, 'ICOMMAND');
	    $ENV{'RPIPE'} = "/tmp/$pipebase-$$-r";	# read pipe
	    &savestate($ENV{'ID'}, 'RPIPE');
	    $ENV{'WPIPE'} = "/tmp/$pipebase-$$-w";	# write pipe
	    &savestate($ENV{'ID'}, 'WPIPE');

	    # Fork so that we can spawn npc.pl after closing the Client
	    # file descriptor (so that the connection to the browser
	    # closes when we die or close the 'Client' handle ourselves)
	    if (!defined($tmppid=fork)) {
		die "Fork error!\n";
	    } elsif (!$tmppid) {			# Child

		close Client;

		# Record our process ID (which, of course, persists
		# through 'exec'
		$ENV{'IPROCESS'} = $$;
		&savestate($ENV{'ID'}, 'IPROCESS');

		# Run the named-pipe-based wrapper
		exec "$npc $ENV{'ICOMMAND'} $ENV{'RPIPE'} $ENV{'WPIPE'}";
	    }

	    # Wait until npc.pl actually runs
	    my $counter = 5;
	    while ($counter-- > 0) {
		last if (-e $ENV{'RPIPE'});
		sleep(1);
	    }
	    if (! -e $ENV{'RPIPE'}) {
		print Client "The program did not start successfully.\n";
		$ENV{'ICOMMAND'} = "";
		&savestate($ENV{'ID'}, 'ICOMMAND');
		&command_prompt(Client);
		return;
	    }

	} else {					# old command
	    # If this is a continuing session, then we must have
	    # input for our program (from the user's form). 
	    open RPIPE, "> $ENV{'RPIPE'}" or
		print Client "The program died (write error).\n";
	    open WPIPE, "< $ENV{'WPIPE'}";
	    print RPIPE "$FORM{'IDATA'}\n";
	    close WPIPE;
	    close RPIPE;
	}

	# Now, regardless of whether we just started or not, we can
	# block on RPIPE, get information, and then display the next
	# prompt for the user.
	print Client
	    "<FONT COLOR=blue>Interactively running $ENV{'ICOMMAND'}</FONT>\n";
	print Client "<PRE>\n";
	if (!open RPIPE, "> $ENV{'RPIPE'}") {	# icommand still running?
	    print Client "The program died (read error 1)\n</PRE>";
	    $ENV{'ICOMMAND'} = "";
	    &savestate($ENV{'ID'}, 'ICOMMAND');
	    &command_prompt(Client);
	    return;
	}
	if (!open WPIPE, "< $ENV{'WPIPE'}") {	# icommand still running?
	    print Client "The program died (read error 2)\n</PRE>";
	    $ENV{'ICOMMAND'} = "";
	    &savestate($ENV{'ID'}, 'ICOMMAND');
	    &command_prompt(Client);
	    return;
	}
	$rin = '';
	vec($rin, fileno(WPIPE), 1) = 1;
	do {
	    if (! -e $ENV{'WPIPE'}) {		# icommand still running?
		print Client "The program died (read error 3)\n</PRE>";
		$ENV{'ICOMMAND'} = "";
		&savestate($ENV{'ID'}, 'ICOMMAND');
		&command_prompt(Client);
		return;
	    }
	    $line = <WPIPE>;
	    print Client $line;
	} while (select($rin, undef, undef, 1.0));
	print Client<<ENDHTML;
	<FORM METHOD=GET
	    ACTION="http://$hostname:$bindport/id=$ENV{'ID'}/$icommand">
	<INPUT TYPE=TEXT
		NAME=IDATA SIZE=50
        >
        <INPUT VALUE=SEND
		TYPE=SUBMIT
        ></FORM
        ><FORM METHOD=GET
	    ACTION="http://$hostname:$bindport/id=$ENV{'ID'}/$iterminate">
	<INPUT VALUE=TERMINATE TYPE=SUBMIT>
	</FORM>
	</PRE>
	<HR>
ENDHTML

    } elsif ($command eq $iterminate) {
	if ($ENV{'ICOMMAND'}) {
	    print Client<<END_RESPONSE;
<h3>$ENV{'ICOMMAND'} ($ENV{'IPROCESS'}) terminated</h3>
<HR>
<P>
END_RESPONSE
	    kill 2, $ENV{'IPROCESS'};
	    $ENV{'ICOMMAND'} = '';
	    &savestate($ENV{'ID'}, 'ICOMMAND');
	}
    } else {
	# When no explicit command is given, list the current directory.
	&client_ls(Client);
    }

    &command_prompt(Client);
    &savestate($ENV{'ID'}, 'ID');

    # Clean up the Client fd
    close Client;

    # We're done...
    exit;
}


# determine whether the program named by $_[0] is in our path
sub inpath {
    my $found = 0;
    for $dir (split ":", $ENV{'PATH'}) {
	if (-x "$dir/$_[0]") {
	    $found = 1;
	}
    }
    $found;
}


# Greet the client at $_[0] with a standard HTTP greeting.
sub greet_client {
    my $fd = shift(@_);
    print $fd <<END_RESPONSE;
HTTP/1.0 200 OK
Server: WISH/1.00
Cache-Control: no-cache
Pragma: no-cache
Content-type: text/html

END_RESPONSE
}


# Print an 'authentication failure' message to the client at $[0]
sub fail_client {
    my $fd = shift(@_);
    print $fd <<END_RESPONSE;
<FONT COLOR=RED>
<H2>
Login necessary
</H2>
</FONT>
<FONT COLOR=#EE4422>
<H4>Please provide a valid username and password for this system:</H4>
</FONT>

<FORM METHOD=GET ACTION="http://$hostname:$bindport">
<PRE>
Username: <INPUT NAME=username>
Password: <INPUT NAME=password TYPE=password>
</PRE>
<INPUT TYPE=SUBMIT VALUE=Login>
</BODY>
</HTML>
END_RESPONSE
}


# Send an HTML header to the client at $_[0]
sub print_header {
    my $fd = shift(@_);
    print $fd <<END_RESPONSE;

<HTML>
<HEAD><TITLE>wish: $hostname</TITLE></HEAD>
<BODY BGCOLOR=#EEEEEE>
<FONT COLOR=#222222><H2><TT>$hostname</TT><HR></H2></FONT>

END_RESPONSE
}


# Present the client at $_[0] with a directory listing that constructs
# commands automatically based on the listed files.
# NOTE: We need to send back the unique user ID as part of the URL
# and adjust the server to accept it either as part of the URL or via
# POST.  (Right now, only POST works.)
sub client_ls {
    my $fd = shift(@_);

    # Get and parse a listing of the current directory
    @ls = `ls -la | tail +2`;
    foreach $file (@ls) {
	# Generate 'viewfile' URLs for files
	$file =~
            s|(.*)\s(.+?)$
	     |$1 <A HREF=
	"http://$hostname:$bindport/id=$ENV{'ID'}/$viewfile?$2">$2</A>|x;

	$thisfile = $2;

	# If we've got a directory, change the entry's URL to a 'cd'
	# command, which will be processed as an internal command request
	# when we receive it.  (Note how we don't worry about converting
	# weird characters to CGI's standard representation.  Does this
	# fail if files have truly bizarre names?)
	if (-d $thisfile) {
	    $file =~
		s/$viewfile\?$thisfile/$commandrequest?cmd=cd $thisfile/;
	    $file = "<font color=#880088>" . $file . "</font>";
	} elsif (-x $thisfile) {
	    $file =~
		s|rwx|rw<A
		 HREF=
		 "http://$hostname:$bindport/id=$ENV{'ID'}/$cr?cmd=$thisfile"
		 >x</A>|;
	}

    }

    print $fd <<END_RESPONSE;
<FONT COLOR=#444444><H4><TT>$ENV{'CWD'}:</TT></H4></FONT>
<PRE>
 @ls
</PRE>
<HR>
END_RESPONSE
}


# Present the client at $_[0] with a command prompt.
# The command will come back to us as $FORM{'cmd'} or $FORM{'prevcmd'}
sub command_prompt {
    my $fd = shift(@_);

    print $fd <<END_RESPONSE;

<h4>The current directory is
   <A HREF="http://$hostname:$bindport/id=$ENV{'ID'}/$dirlist">$ENV{'CWD'}</A>
</h4>

<FORM METHOD=GET
   ACTION="http://$hostname:$bindport/id=$ENV{'ID'}/$commandrequest">
<INPUT TYPE=TEXT NAME=cmd SIZE=30>
<INPUT TYPE=SUBMIT VALUE=Run>
<BR>
END_RESPONSE

    $history = $ENV{'cmdhist'};
    chomp($history);

    # Let the user select from previous commands if there are any.
    if ($history =~ /[^;]/) {
	my @prevcmds = split /;/, $history;		# Get previous cmds

	print $fd "<SELECT NAME=prevcmd><OPTION>\n";
	foreach $cmd (@prevcmds) {			# Print a list
	    print $fd "<OPTION>$cmd\n" if $cmd;
	}
	print $fd "</SELECT>\n";
    }

    print $fd "</FORM>\n";

    # Let the user run something interactively (assuming something's not
    # running interactively already)
    if (!$ENV{'ICOMMAND'}) {
        print $fd <<END_RESPONSE;
<FORM METHOD=GET
    ACTION="http://$hostname:$bindport/id=$ENV{'ID'}/$icommand">
<INPUT TYPE=TEXT NAME=cmd SIZE=30>
<INPUT TYPE=SUBMIT VALUE="Run Interactively">
END_RESPONSE
    }
}


# Send an error message ($_[1]) to the client at $_[0]
sub client_error {
    my $fd = shift(@_);
    my $errmsg = shift(@_);
    print $fd <<END_RESPONSE;

<H4><FONT COLOR=RED>$errmsg</FONT></H4>

END_RESPONSE
}


# Read a file ($_[1]) and send the output to the client at $_[0]
sub viewfile {
    my $fd = shift(@_);
    my $file = shift(@_);

    if (! open FILE, $file) {
	print $fd "<FONT COLOR=RED>Unable to read $file</FONT><P>\n";
	return;
    } else {
	print $fd "<font color=#2222FF><h4><TT>$file</TT></h4></font>\n";
    }

    open STDOUT_old, ">&STDOUT";                        # Save STDOUT
    open STDERR_old, ">&STDERR";                        # Save STDERR

    open STDOUT, ">&$fd";                               # Redirect STDOUT
    open STDERR, ">&$fd";                               # Redirect STDERR

    # Deal with special files, using simple commands to format them if
    # appropriate.  TODO: Support this with a better data structure.
    $extension = $file;
    $extension =~ s/^.*\.//;
    if (! $FILTER{$extension}) {
	$FILTER{$extension} = 'cat';
    }
    my $oldbuf = $|;
    $| = 1;
    print "<PRE>\n" if ($HTML{$extension} < 1);

    # execute command to view file
    system("$FILTER{$extension} < $file");

    # record this command in the history
    chomp($oldhist = $ENV{'cmdhist'});
    $ENV{'cmdhist'} = $oldhist . "$FILTER{$extension} < $file;";
    &savestate($ENV{'ID'}, 'cmdhist');

    print "</PRE>\n" if ($HTML{$extension} < 1);
    $| = $oldbuf;

    open STDOUT, ">&STDOUT_old";                        # Restore STDOUT
    open STDERR, ">&STDERR_old";                        # Restore STDERR

    close FILE;
}


# Execute a command ($_[1]) and send the output to the client at $_[0]
sub client_exec {
    my $fd = shift(@_);
    my $cmd = shift(@_);

    open STDOUT_old, ">&STDOUT";			# Save STDOUT
    open STDERR_old, ">&STDERR";			# Save STDERR

    open STDOUT, ">&$fd";				# Redirect STDOUT
    open STDERR, ">&$fd";				# Redirect STDERR

    $savedbuffer = $|;
    $| = 1;

    @cmd = split " ", $cmd;
    if (-x $cmd[0] || &inpath($cmd[0])) {
	print "<font color=#2222FF><h3><TT>$cmd:</TT></h3></font>\n";
	print "<PRE>\n";
	system($cmd);
	print "</PRE>\n";
    } else {
	print "<font color=red><h4>$cmd[0]: command not found</H4></font>\n";
    }

    $| = $savedbuffer;

    open STDOUT, ">&STDOUT_old";			# Restore STDOUT
    open STDERR, ">&STDERR_old";			# Restore STDERR
}    


# Handle CGI input from the string in $_[0]; store name/value pairs
# in the hash given by $_[1].  (Based on code generally used by Yale ACS's
# CGI scripts.)
sub cgiproc {
    my @pairs = split(/&/, $_[0]);
    foreach $pair (@pairs)
    {
	my ($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	chomp($value);
        $_[1]{$name} = $value;
    }
}


# SIGINT handler
sub dienicely {
    close Server;
    close Client;
    exit;
}


###########################################################################

#
# Functions to manage session state (disk <-> environment)
#

# Based on the ID string given by $_[0], load state information for a
# given user into the environment
sub loadstate {
    my $id = shift(@_);

    return if (! &lock("$statedir/$id"));

    open(STATEFILE, "$statedir/$id");
    while ($line = <STATEFILE>) {
	my ($name, $value) = split "=", $line;
	chomp($ENV{$name} = $value);
    }

    &unlock("$statedir/$id");

    # Take some appropriate actions based on the the state we loaded
    chdir($ENV{'CWD'}) if $ENV{'CWD'};

    close(STATEFILE);
}

# Check the ID string given by $_[0] for validity; return 1 on success,
# 0 on failure
sub validstate {
    my $id = shift(@_);
    if (-f "$statedir/$id") {
	1;
    } else {
	0;
    }
}


# Based on the ID string given by $_[0], save the environment variable whose
# name is $_[1] to a permanent state file.
sub savestate {
    my $id = shift(@_);
    my $name = shift(@_);
    my $value = $ENV{$name};
    my $modified = 0;				# Have we modified an entry?

    return if (! &lock("$statedir/$id"));

    open(OLD, "$statedir/$id");
    open(NEW, ">$statedir/$id.new");
    while ($line = <OLD>) {
	my ($curname, $curvalue) = split "=", $line;
	if ($curname ne $name) {
	    print NEW $line;
	} else {
	    $modified = 1;
	    print NEW "$curname=$value\n";	# Modify old entry
	}
    }
    print NEW "$name=$value\n" if !$modified;	# New entry
    close(NEW);
    close(OLD);
    rename("$statedir/$id.new", "$statedir/$id");

    &unlock("$statedir/$id");
}


# Change the name of a 'state file', given by $_[0], to $_[1].
# Errors are ignored, but just in case, we always attempt to erase the
# old file.  (Lost state is better than extra state, for security reasons.)
sub bridgestate {
    my $oldname = shift(@_);
    my $newname = shift(@_);

    return if (! &lock("$statedir/$oldname"));

    rename("$statedir/$oldname", "$statedir/$newname");
    chmod 0600, "$statedir/$newname";
    unlink("$statedir/$oldname");

    &unlock("$statedir/$oldname");		# it's gone, but that's fine
}


# Erase old state files, based on a threshold age
sub state_garbage_collect
{
    my $threshold_minutes = $state_thresh;	# expire in $state_thresh min.
    my $threshold = $threshold_minutes / (60*24);

    foreach $file (<$statedir/*>) {
	if (-M $file > $threshold and -A $file > $threshold) {
	    unlink $file;
	}
    }
}


#
# File locking.  (Our own implementation to make sure it works over NFS.
# Why not?)  Does *not* depend on the existence of a file; we're not using
# flock, and we don't care about any properties of the actual file we're
# locking: it's just a name.
#

# Gain an exclusive lock to $_[0].  Retry $retries times.
# Return TRUE on success, FALSE on failure.
sub lock {
    my $file = shift(@_);
    my $retries = 5;

    chop($hostname = `hostname`);
    my $unique = "$file.$hostname.$$";
    `touch $unique`;				# Create the unique file

    link($unique, "$file.lock");		# Purposely ignore errors
    @ustat = stat $unique;			# Are we a winner?
    while ($retries--) {
	if ($count = $ustat[3] > 1) {
	    # Lock successfully gained
	    return TRUE;
	} else {
	    # Unsuccessful.  Wait and retry
	    sleep 1;
 	}
    }
    unlink($unique);
    return FALSE;
}

# Give up an exclusive lock to $_[0].
sub unlock {
    my $file = shift(@_);
    my $unique = "$file.$hostname.$$";

    unlink("$file.lock");
    unlink("$unique");
}


###########################################################################

#
# Configuration support
# (sets global configuration variables)
#
# Called on startup and when we received SIGHUP
#

sub configure {

    # Look for the configuration file in the following places, in order:
    #
    #   1. $ENV{'WISHCONF'}
    #   2. ./wish.conf

    # defaults
    $statedir = "./data";
    $npc = "./npc.pl";
    undef $restricted;
    undef @allowed;
    $state_thresh = 10; 

    my $configfile = $ENV{'WISHCONF'} || "./wish.conf";

    open CONF, $configfile;
    while (<CONF>) {
	chop;
	next if /^#/;				# skip comments
	@line = split " ", $_, 2;

	$line[0] =~ /^userstate/i 		&& do {
						    $statedir = $line[1];
						};
	$line[0] =~ /^npc/i			&& do {
						    $npc = $line[1];
						};

	$line[0] =~ /^port/i			&& do {
						    $bindport = $line[1];
						};
	$line[0] =~ /^restricted/i		&& do {
						    $restricted = 1;
						};
	$line[0] =~ /^allow/i			&& do {
						    @allowed =
							split " ", $line[1];
						};
	$line[0] =~ /^expire/i			&& do {
						    $state_thresh = $line[1];
						};
	$line[0] =~ /^map/i && do {
	    @mapping = split " ", $line[1], 3;
	    $HTML{$mapping[0]} = $mapping[1];
            $FILTER{$mapping[0]} = $mapping[2];
	}

    }
    close CONF;

    # Check certain parameters and report errors we find
    if (! -d $statedir or ! -x $statedir) {
	die "Invalid state directory '$statedir'\n";
    }
    if (! -x $npc) {
	die "Invalid location for NPC wrapper '$npc'\n";
    }
}
